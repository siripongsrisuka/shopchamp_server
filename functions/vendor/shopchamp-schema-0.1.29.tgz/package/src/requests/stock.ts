import { z } from "zod";
import { CompanyOrderPayMethod, slipRequiredUnlessQr } from "./company";

/**
 * คำขอ API ชุดใหม่ของโดเมนสต๊อก (ก้อน 9a · DEV-0001) · strict ทุกตัว (field เกิน = ถูกปัด) ต่างจาก schema เอกสารที่ passthrough
 * สัญญา: `shopchamp-center/api/stock.*.yaml` (1 ไฟล์ต่อ endpoint) · เอกสารงาน `lanes/dev/source/chunk9/9a-stock.md`
 *
 * หลักร่วม (ที่มา `lanes/dev/source/bug-decisions/stock.md` · Pack เคาะ "แก้ทั้งหมด" 2026-11-06):
 * - แอปส่ง **เจตนา** ไม่ส่งค่าผูกสต๊อก/คงเหลือ/ต้นทุนที่จำไว้ ⇒ server อ่าน doc สดใน transaction (ST-017 ST-018 ST-020 ST-025 ST-105)
 * - การเขียนที่สร้างเอกสารใหม่มีรหัสกันซ้ำจากแอป (`*UUID` = doc id) ⇒ ส่งซ้ำได้ผลเดิม (ST-055 ST-060)
 * - จำนวนเป็น number จริง ไม่ใช่สตริง (ST-093) · ค่าว่างปัด ไม่ถือเป็น 0 (ST-029 ST-030 ST-037 ST-044 ST-135)
 * - ทศนิยมจำนวนไม่เกิน 4 ตำแหน่ง ตามระบบเครื่องชั่ง (decision 2026-11-06 ข้อ ②) · เงินไม่เกิน 4 ตำแหน่งเท่าที่แอปเดิมแสดง (`useToLocale4`)
 * - `staffId` `staffName` = คนที่ทำรายการ (เครื่องใช้บัญชีร่วมกันแล้วสลับคนด้วยรหัส · รูปเดียวกับ `requests/shift.ts`)
 *   server ตรวจว่าอยู่ใน `shop.humanResource[]` และ status active (decision B-11 · พนักงานไม่ใช้งานถูกบล็อกใน API ใหม่)
 */

const DOC_ID_MAX = 128;

/** doc id ของ Firestore · ห้ามว่าง ห้ามมี `/` ห้ามเป็น `.` `..` · ยาวไม่เกิน 128 */
const docId = (label: string) =>
  z
    .string()
    .min(1, { message: `${label} ห้ามว่าง` })
    .max(DOC_ID_MAX, { message: `${label} ยาวเกิน ${DOC_ID_MAX}` })
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${label} ห้ามมี / หรือเป็น . ..` });

/** ทศนิยมไม่เกิน n ตำแหน่ง · เทียบผ่าน toFixed เพราะ float คูณแล้วไม่เป็นจำนวนเต็ม */
const atMostDecimals = (n: number) => (v: number) => Number(v.toFixed(n)) === v;

/** จำนวนสินค้า > 0 · ทศนิยมไม่เกิน 4 (เครื่องชั่ง) · ไม่รับสตริง/NaN/Infinity */
const positiveQty = z
  .number()
  .finite()
  .positive({ message: "จำนวนต้องมากกว่า 0 (ST-044 ST-029)" })
  .refine(atMostDecimals(4), { message: "จำนวนทศนิยมไม่เกิน 4 ตำแหน่ง" });

/** จำนวนที่ 0 ได้ (แก้ใบรับลดเป็น 0) */
const nonNegativeQty = z
  .number()
  .finite()
  .nonnegative({ message: "จำนวนติดลบไม่ได้" })
  .refine(atMostDecimals(4), { message: "จำนวนทศนิยมไม่เกิน 4 ตำแหน่ง" });

/** เงิน ≥ 0 · ทศนิยมไม่เกิน 4 (ต้นทุนต่อหน่วยหลังรวม VAT มีเศษได้) */
const money = z
  .number()
  .finite()
  .nonnegative({ message: "ค่าเงินติดลบไม่ได้" })
  .refine(atMostDecimals(4), { message: "ทศนิยมไม่เกิน 4 ตำแหน่ง" });

/** วันที่จากแอป: ISO string ที่อ่านได้ (วันหมดอายุ · วันเริ่ม/จบโปร) */
const isoDate = z
  .string()
  .min(1)
  .refine((s) => !Number.isNaN(Date.parse(s)), { message: "ต้องเป็นวันที่รูป ISO ที่อ่านได้" });

const staffFields = {
  staffId: z.string().min(1).describe("คนที่ทำรายการ · ต้องอยู่ใน shop.humanResource และ active (B-11)"),
  staffName: z.string().max(200).describe("ชื่อคนทำรายการ · string แม้ว่าง กันเขียน undefined"),
};

const shopIdField = z.string().min(1).describe("ร้าน (doc id) · ด่านสิทธิ์ร้านใช้ค่านี้");

// ── stock.receive · รับสินค้าเข้า (ใบรับ importProduct + เพิ่มสต๊อก + ต้นทุนถัวเฉลี่ยถ่วงน้ำหนัก #22) ──

export const StockReceiveLine = z
  .object({
    id: docId("id").describe("doc id ของ `stock` ที่รับเข้า · ค่าผูกสต๊อก server อ่านจาก doc เอง (ST-017)"),
    qty: positiveQty.describe("จำนวนในหน่วยของสินค้าตัวนี้ (ไม่ใช่หน่วยเล็กสุด)"),
    cost: money.describe("ต้นทุนต่อหน่วยของตัวนี้ · แอปคิด VAT แล้ว (ST-007 แก้ที่จอ) · 0 ได้"),
    exp: isoDate.nullable().optional().describe("วันหมดอายุของล็อตนี้ · ไม่มี = null/ไม่ส่ง"),
    lot: z.string().max(100).optional().describe("เลขล็อตพิมพ์เอง · แสดงอย่างเดียว"),
  })
  .strict();

export const StockReceiveRequest = z
  .object({
    shopId: shopIdField,
    receiveUUID: z.uuid().describe("รหัสการกดยืนยัน 1 ครั้ง = doc id ของ `importProduct` · ส่งซ้ำได้ผลเดิม (ST-055)"),
    supplierId: docId("supplierId").describe("doc id ของ `supplier` ของร้านนี้ · server คัดสำเนาคู่ค้าจากฐานเอง (ST-099)"),
    billNumber: z.string().max(100).describe("เลขใบสั่งซื้อที่พิมพ์เอง · `''` ได้"),
    lines: z.array(StockReceiveLine).min(1, { message: "ยังไม่มีรายการสินค้า" }).max(500, { message: "รายการเกิน 500 ต่อใบ" }),
    vatIncluded: z.boolean().optional().describe("ต้นทุนที่ส่งรวม VAT แล้วหรือไม่ · บันทึกลงใบให้ตามรอยได้ (ST-007)"),
    ...staffFields,
  })
  .strict();

// ── stock.receiveEdit · แก้ 1 แถวของใบรับ ──

export const StockReceiveEditRequest = z
  .object({
    shopId: shopIdField,
    importId: docId("importId").describe("doc id ของ `importProduct`"),
    lineIndex: z.number().int().nonnegative().describe("ตำแหน่งแถวใน `product[]` ของใบ (แทน tempId ที่สุ่มใหม่ ST-026)"),
    expect: z
      .object({
        id: docId("expect.id"),
        qty: z.number().finite(),
        cost: z.number().finite(),
      })
      .strict()
      .describe("ค่าของแถวที่จอเห็น · server เทียบกับใบในฐาน ไม่ตรง = 409 (ST-025 ST-027)"),
    nextQty: nonNegativeQty.describe("จำนวนใหม่ · 0 ได้ · ว่างปัด (ST-029)"),
    nextCost: money.describe("ต้นทุนต่อหน่วยใหม่ · ไม่ใช่ตัวเลขปัด (ST-030)"),
    nextExp: isoDate
      .nullable()
      .optional()
      .describe("วันหมดอายุใหม่ของแถว (ST-112) · ไม่ส่ง = ไม่แก้ · null = เอาออก · server ย้ายล็อตใน expReport ทุกตัวในกลุ่ม"),
    ...staffFields,
  })
  .strict();

// ── stock.requisition · เบิกสินค้าใช้ในร้าน ──

export const StockRequisitionRequest = z
  .object({
    shopId: shopIdField,
    requisitionUUID: z.uuid().describe("doc id ของ `requisition` · ส่งซ้ำไม่ตัดซ้ำ (ST-055)"),
    reason: z.string().max(500).describe("เหตุผลการเบิก · `''` ได้เหมือนแอปเดิม"),
    lines: z
      .array(z.object({ id: docId("id"), qty: positiveQty }).strict())
      .min(1, { message: "กรุณาเลือกสินค้าอย่างน้อย 1 รายการ" })
      .max(500),
    ...staffFields,
  })
  .strict();

// ── stock.linkCreate / linkUpdate / linkDelete · กลุ่มผูกสต๊อก (ลัง แพ็ก ชิ้น) ──

export const StockLinkCreateRequest = z
  .object({
    shopId: shopIdField,
    linkUUID: z.uuid().describe("doc id ของ `stockLink` · กดยืนยันซ้ำไม่ได้กลุ่มซ้ำ (ST-060)"),
    stockGroupName: z.string().trim().min(1, { message: "กรุณาตั้งชื่อสต๊อกรวม" }).max(200),
    upgrade: z.boolean().describe("อัปหน่วยในตะกร้าอัตโนมัติ"),
    members: z
      .array(
        z
          .object({
            id: docId("id"),
            linkMultiply: z
              .number()
              .int({ message: "ตัวคูณต้องเป็นจำนวนเต็ม (ST-058)" })
              .min(1, { message: "ตัวคูณต้องไม่น้อยกว่า 1 (ST-040)" })
              .max(100000)
              .describe("หน่วยเล็กสุดต่อ 1 หน่วยนี้ · ตัวอ้างอิง = 1"),
          })
          .strict(),
      )
      .min(2, { message: "กลุ่มต้องมีสินค้าอย่างน้อย 2 ตัว (ST-060)" })
      .max(20),
  })
  .strict();

export const StockLinkUpdateRequest = z
  .object({
    shopId: shopIdField,
    linkId: docId("linkId"),
    stockGroupName: z.string().trim().min(1, { message: "ชื่อกลุ่มห้ามว่าง" }).max(200).optional(),
    upgrade: z.boolean().optional(),
  })
  .strict()
  .refine((v) => v.stockGroupName !== undefined || v.upgrade !== undefined, { message: "ไม่มีอะไรให้แก้" });

export const StockLinkDeleteRequest = z
  .object({
    shopId: shopIdField,
    linkId: docId("linkId"),
  })
  .strict();

// ── stock.productSave · เพิ่ม/แก้สินค้า (ฟอร์มสินค้า) ──

const promotionField = z
  .object({
    status: z.boolean(),
    qty: z.union([positiveQty, z.literal("")]),
    price: z.union([money, z.literal("")]),
    startDate: isoDate.nullable().optional(),
    endDate: isoDate.nullable().optional(),
  })
  .strict()
  .refine((p) => !p.status || (p.qty !== "" && p.price !== ""), {
    message: "กรุณาตั้งค่าโปรโมชั่นให้เรียบร้อย หรือ ปิดโปรโมชั่น",
  });

/** ช่องที่ฟอร์มแก้ได้ · ❌ ไม่มี stock cost link* (ST-022: ฟอร์มเขียนทั้งก้อนทับคงเหลือ/ต้นทุน/กลุ่มผูก) */
export const StockProductFields = z
  .object({
    name: z.string().trim().min(1, { message: "กรุณากรอกชื่อสินค้า" }).max(300),
    price: money.describe("ราคาขาย · number (ST-093)"),
    unit: z.string().max(50),
    barcode: z.string().max(100),
    barcodeStatus: z.boolean(),
    imageId: z.string().max(2000).describe("URL รูปที่แอปอัปขึ้น Storage แล้ว · `''` ได้"),
    selfImage: z.boolean(),
    category: z.array(z.string().min(1)).max(10),
    currentCategory: z.array(z.record(z.string(), z.unknown())).max(10),
    cashierShow: z.boolean(),
    consignment: z.boolean(),
    delivery: z.boolean().describe("ช่องของฟอร์มเดิม (`config/initialProduct.js`) · ไม่มีคนอ่าน · รับไว้ให้ฟอร์มเดิมส่งได้"),
    rent: z.boolean().describe("ช่องของฟอร์มเดิม · ไม่มีคนอ่าน"),
    vatExemption: z.boolean(),
    pointStatus: z.boolean(),
    stockCountStatus: z.boolean(),
    customQtyStatus: z.boolean(),
    customPriceStatus: z.boolean(),
    priceLevelStatus: z.boolean(),
    priceLevel: z.array(z.object({ qty: positiveQty, price: money }).strict()).max(20),
    promotion: promotionField,
    safetyStock: z.object({ status: z.boolean(), qty: nonNegativeQty }).strict(),
  })
  .strict();

export const StockProductSaveRequest = z.discriminatedUnion("op", [
  z
    .object({
      op: z.literal("create"),
      shopId: shopIdField,
      productUUID: z.uuid().describe("doc id ของ `stock` ตัวใหม่ · กดซ้ำไม่ได้สินค้าซ้ำ"),
      product: StockProductFields.partial()
        .required({ name: true, price: true })
        .describe("ช่องที่ไม่ส่ง server ใส่ค่าตั้งต้นรูปเดิมของแอป (`config/initialProduct.js`) ⇒ แอปเก่าอ่านได้ ตัดสต๊อกตามเดิม"),
      stock: z
        .number()
        .finite()
        .refine(atMostDecimals(4))
        .describe("คงเหลือตั้งต้น · ต้องส่งเป็นเลข (ST-135 `''` แล้วขายติดลบ)"),
      cost: money.describe("ต้นทุนตั้งต้นต่อหน่วย"),
      ...staffFields,
    })
    .strict(),
  z
    .object({
      op: z.literal("update"),
      shopId: shopIdField,
      productId: docId("productId"),
      product: StockProductFields.partial().refine((p) => Object.keys(p).length > 0, { message: "ไม่มีอะไรให้แก้" }),
      ...staffFields,
    })
    .strict(),
]);

// ── stock.productDelete · ลบสินค้า (soft delete แบบเดิม) ──

export const StockProductDeleteRequest = z
  .object({
    shopId: shopIdField,
    productId: docId("productId"),
    ...staffFields,
  })
  .strict();

// ── stock.adjust · แก้ราคา / คงเหลือ / ต้นทุน / ลบวันหมดอายุ ของสินค้า 1 ตัว ──

export const StockAdjustRequest = z.discriminatedUnion("op", [
  z
    .object({
      op: z.literal("price"),
      shopId: shopIdField,
      productId: docId("productId"),
      newPrice: money.describe("ราคาใหม่ · ว่างปัด (ST-037)"),
      ...staffFields,
    })
    .strict(),
  z
    .object({
      op: z.literal("stock"),
      shopId: shopIdField,
      productId: docId("productId"),
      newStock: z.number().finite().refine(atMostDecimals(4)).describe("คงเหลือใหม่ในหน่วยของสินค้าตัวนี้ · ติดลบได้เหมือนเดิม"),
      seenStock: z
        .number()
        .finite()
        .describe("คงเหลือที่จอเห็นตอนเปิดหน้าต่าง · ฐานเปลี่ยนไปแล้ว = 409 stock_changed (ST-086)"),
      ...staffFields,
    })
    .strict(),
  z
    .object({
      op: z.literal("cost"),
      shopId: shopIdField,
      productId: docId("productId"),
      newCost: money.describe("ต้นทุนต่อหน่วยใหม่ของตัวนี้ · สินค้าผูก server แปลงให้ทั้งกลุ่ม"),
      ...staffFields,
    })
    .strict(),
  z
    .object({
      op: z.literal("expRemove"),
      shopId: shopIdField,
      productId: docId("productId"),
      exp: isoDate.describe("วันหมดอายุที่จะลบ 1 ล็อต (ST-110) · สินค้าผูกลบทุกตัวในกลุ่ม (ST-111)"),
      ...staffFields,
    })
    .strict(),
]);

// ── stock.supplier · คู่ค้า ──

const supplierFields = {
  vender_Name: z.string().trim().min(1, { message: "กรุณากรอกชื่อผู้ขาย" }).max(200),
  sale_Name: z.string().max(200),
  tel: z.string().max(50),
  lineId: z.string().max(100),
  detail: z.string().max(1000),
};

export const StockSupplierRequest = z.discriminatedUnion("op", [
  z.object({ op: z.literal("create"), shopId: shopIdField, supplierUUID: z.uuid(), ...supplierFields }).strict(),
  z.object({ op: z.literal("update"), shopId: shopIdField, supplierId: docId("supplierId"), ...supplierFields }).strict(),
  z.object({ op: z.literal("delete"), shopId: shopIdField, supplierId: docId("supplierId") }).strict(),
]);

// ── stock.uploadOpen · เปิดหน้าเว็บนำเข้าสินค้าจากไฟล์ ──

export const StockUploadOpenRequest = z.object({ shopId: shopIdField }).strict();

// ── stock.orderCreate · ซื้อชุดสินค้าพร้อมขาย (ใบ stockOrder แนบสลิป) ──

export const StockOrderCreateRequest = z
  .object({
    shopId: shopIdField,
    orderUUID: z.uuid().describe("doc id ของ `stockOrder` · กดซ้ำไม่ได้ใบซ้ำ และไม่เผาเลขใบ"),
    packId: z
      .number()
      .int()
      .min(2, { message: "ชุด 0 1 เป็นชุดฟรี ไม่ต้องสั่งซื้อ" })
      .describe("รหัสชุดสินค้า (`id` เดิม · ตาราง `app:Modal/Modal_FastProduct.js:29-37`) · ราคาและจำนวน server ใช้ตารางของตัวเอง"),
    price: money.describe("ยอดที่จอแสดง · ไม่ตรงตาราง server = 409 (กันจอเก่า/แก้ราคาในเครื่อง)"),
    qty: z.number().int().positive(),
    imageId: z
      .string()
      .regex(/^https:\/\//, { message: "ต้องเป็น URL สลิปที่อัปขึ้น Storage แล้ว" })
      .max(2000)
      .optional()
      .describe("สลิปโอนเงิน · แอปอัปเองก่อนเรียก (เดิมอัประหว่าง transaction ที่ retry ได้) · ไม่ส่งได้เฉพาะ payMethod qr"),
    payMethod: CompanyOrderPayMethod.optional().describe(
      "วิธีจ่าย (0.1.23 DEV-0003 U2b · กฎเดียวกับใบบริษัท requests/company.ts) · ไม่ส่ง = slip บังคับสลิปเหมือนเดิม · qr = จ่าย QR หลังสร้างใบ ห้ามส่ง imageId",
    ),
    ...staffFields,
  })
  .strict()
  .superRefine(slipRequiredUnlessQr("imageId"));

// ── stock.reorder · จัดเรียงสินค้าหน้าขาย (จอเดิมเขียนตรง `ReOrderProductScreen.js:104` → `useLocalStock.js:74-90`) ──

export const StockReorderRequest = z
  .object({
    shopId: shopIdField,
    ids: z
      .array(docId("ids[]"))
      .min(1, { message: "ไม่มีสินค้าให้จัดเรียง" })
      .max(5000, { message: "สินค้าเกิน 5,000 ตัวต่อครั้ง" })
      .refine((a) => new Set(a).size === a.length, { message: "มีสินค้าซ้ำในลำดับ" })
      .describe("doc id ของ `stock` เรียงตามลำดับที่จอแสดง · server ตั้ง timestamp ให้ (ตัวที่ i = ตอนนี้ − 1 วัน + 30 วินาที × i)"),
  })
  .strict();

// ── stock.cloneRepair · ซ่อมร้าน clone ที่สินค้าผูกยังชี้ร้านต้นทาง (#10 ST-001) · ทีมงานเท่านั้น ──

export const StockCloneRepairRequest = z.discriminatedUnion("mode", [
  z.object({ mode: z.literal("plan"), shopId: shopIdField }).strict(),
  z
    .object({
      mode: z.literal("apply"),
      shopId: shopIdField,
      approvalRef: z
        .string()
        .trim()
        .min(3, { message: "ต้องมีรหัสการอนุมัติของ Pack รายร้าน" })
        .max(200)
        .describe("ร่องรอยว่า Pack อนุมัติร้านนี้ (เลขใบ/ข้อความ) · ซ่อมร้านลูกค้า = ขอ Pack รายครั้ง"),
      planHash: z.string().regex(/^[0-9a-f]{16}$/, { message: "planHash ต้องมาจากผล plan" }).describe("ผลของ plan ที่ Pack ดู · ฐานเปลี่ยนแล้ว = 409"),
    })
    .strict(),
]);

export type StockReceiveRequest = z.infer<typeof StockReceiveRequest>;
export type StockReceiveEditRequest = z.infer<typeof StockReceiveEditRequest>;
export type StockRequisitionRequest = z.infer<typeof StockRequisitionRequest>;
export type StockLinkCreateRequest = z.infer<typeof StockLinkCreateRequest>;
export type StockLinkUpdateRequest = z.infer<typeof StockLinkUpdateRequest>;
export type StockLinkDeleteRequest = z.infer<typeof StockLinkDeleteRequest>;
export type StockProductSaveRequest = z.infer<typeof StockProductSaveRequest>;
export type StockProductDeleteRequest = z.infer<typeof StockProductDeleteRequest>;
export type StockAdjustRequest = z.infer<typeof StockAdjustRequest>;
export type StockSupplierRequest = z.infer<typeof StockSupplierRequest>;
export type StockUploadOpenRequest = z.infer<typeof StockUploadOpenRequest>;
export type StockOrderCreateRequest = z.infer<typeof StockOrderCreateRequest>;
export type StockReorderRequest = z.infer<typeof StockReorderRequest>;
export type StockCloneRepairRequest = z.infer<typeof StockCloneRepairRequest>;

// ── DEV-0010 อ่านสต๊อกผ่าน API (แทนการอ่าน Firestore ตรงจากแอป) ──

/**
 * stock.sync — สินค้าของร้านทีละหน้า เรียงตามเวลาแก้ล่าสุด (updateTime) แล้วตาม doc id
 * ไม่ส่ง cursor = โหลดทั้งร้านตั้งแต่ต้น · ส่ง cursor = เฉพาะตัวที่เปลี่ยนหลังจุดนั้น (query เดียวกัน)
 * cursor = ค่า `nextCursor` ที่ server ให้ (เวลาละเอียดนาโนวินาที + doc id) · แอปเก็บเฉย ๆ ห้ามสร้างเอง · รูปผิด = 400
 */
export const StockSyncRequest = z
  .object({
    shopId: shopIdField,
    cursor: z.string().min(1).max(300).optional().describe("nextCursor จากคำตอบก่อน · ไม่ส่ง = เริ่มจากต้น"),
    limit: z.number().int().min(1).max(1000).optional().describe("ต่อหน้า · ไม่ส่ง = 500 · เพดาน 1000"),
  })
  .strict();

/**
 * stock.findBarcode — ค้นสินค้าของร้านด้วยบาร์โค้ด (แทน `stock where shopId == … and barcode == …` 7 จอ)
 * catalog: true = ไม่เจอในร้านแล้วค้นคลังกลาง `product` ต่อในคำขอเดียว (จอขาย · ตะกร้าบาร์โค้ด · ฟอร์มสินค้า)
 * บาร์โค้ดไม่ trim ให้ (ค้นตรงตามที่สแกนได้ แบบแอปเดิม)
 */
export const StockFindBarcodeRequest = z
  .object({
    shopId: shopIdField,
    barcode: z.string().min(1, { message: "บาร์โค้ดห้ามว่าง" }).max(100).describe("ค่าที่สแกน/พิมพ์ · ค้นแบบเท่ากันเป๊ะ"),
    catalog: z.boolean().optional().describe("true = ไม่เจอในร้านแล้วค้นคลังกลางต่อ · ไม่ส่ง = ค้นเฉพาะร้าน"),
  })
  .strict();

/**
 * stock.linkList — ชุดผูกสต๊อกทั้งหมดของร้าน (แทน fetchStockLink `stockLink where shopId == …`)
 */
export const StockLinkListRequest = z.object({ shopId: shopIdField }).strict();

/**
 * stock.receiveList — ใบรับสินค้าของร้าน ใหม่ก่อน ทีละหน้า (แทน fetchImports `importProduct … orderBy dateTime desc limit 30`)
 * cursor = ค่า `nextCursor` ที่ server ให้ (เวลาละเอียดนาโนวินาที + doc id ของใบสุดท้ายที่อ่าน) · แอปเก็บเฉย ๆ ห้ามสร้างเอง
 */
export const StockReceiveListRequest = z
  .object({
    shopId: shopIdField,
    cursor: z.string().min(1).max(300).optional().describe("nextCursor จากคำตอบก่อน · ไม่ส่ง = หน้าแรก (ใหม่สุด)"),
    limit: z.number().int().min(1).max(100).optional().describe("ต่อหน้า · ไม่ส่ง = 30 (เท่าแอปเดิม) · เพดาน 100"),
  })
  .strict();

/**
 * stock.supplierList — คู่ค้าทั้งหมดของร้าน (แทน fetchSupplier `supplier where shopId == …`) · เส้นเขียนแยกอยู่ที่ stock.supplier
 */
export const StockSupplierListRequest = z.object({ shopId: shopIdField }).strict();

export type StockSyncRequest = z.infer<typeof StockSyncRequest>;
export type StockFindBarcodeRequest = z.infer<typeof StockFindBarcodeRequest>;
export type StockLinkListRequest = z.infer<typeof StockLinkListRequest>;
export type StockReceiveListRequest = z.infer<typeof StockReceiveListRequest>;
export type StockSupplierListRequest = z.infer<typeof StockSupplierListRequest>;

import { z } from "zod";

/**
 * คำขอ API `profile.loading` (ก้อน 4 · DEV-0001) · strict
 * แทนการอ่าน Firestore ตรงของ `app:screens/LoadingScreen.js:49-90` (profile · shop · admin/updateShopchamp)
 * ตัวตนมาจาก token (`req.auth.uid`) เท่านั้น · ร้านมาจาก `profile.currentLogin.shopId` ในฐาน ไม่รับจาก body
 * ใช้จด memo ของบูตออฟไลน์: แอปเก็บ `serverTime` ของคำตอบล่าสุด (`offline-pattern-from-sibling.md` §3.1)
 */
export const ProfileLoadingRequest = z
  .object({
    platform: z.enum(["ios", "android"]).describe("เลือกก้อน `admin/updateShopchamp.<platform>` ส่งกลับให้จอเตือนอัปเดต"),
  })
  .strict();

export type ProfileLoadingRequest = z.infer<typeof ProfileLoadingRequest>;

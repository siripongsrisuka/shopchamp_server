import { z } from "zod";

/**
 * คำขอ API `shift.manage` (ก้อน 4 · `architecture-plan.md` §2) · op-dispatch 3 ทาง: open · during · close
 * ตามแบบพี่น้อง `shift.manage.yaml` แต่ไม่รับก้อน payload อิสระ ⇒ strict ทุกชั้น field เกิน = ปัด
 *
 * ที่มา: `lanes/dev/source/schema/shift.md` W6 W7 W8 (§4) · ข้อเสนอ `แก้` ใน `bug-decisions/shift-cash.md` (Pack เคาะ 2026-11-06)
 * - ไม่รับเวลาจากเครื่อง: `openTime` `timestamp` ให้ server ใส่เอง (SC-13 ขอบรอบเทียบนาฬิกาคนละเครื่อง)
 * - ไม่รับ `shiftCount` `lastShiftDate`: server นับจากเอกสารที่อ่านใน transaction (SC-19 SC-30) · เป็นเลขลำดับ ไม่ใช่ยอดเงิน
 * - ปิดกะรับ `expectedCash` ที่จอแสดงให้แคชเชียร์เห็น (คิดด้วย `@shopchamp/logic` › `shift.closeShift`) · ไม่รับ `closeDiff` แยก กัน 3 ค่าขัดกันเอง
 * - ⚠️ ร่างสัญญา `api/draft/shift.manage.yaml` (ก้อน 4) เขียนตามข้อแนะนำที่รอ Pack เคาะ (`lanes/dev/source/chunk4-contracts.md` คำถามข้อ 1):
 *   server รวมยอดกะจากบิลเองใน transaction ตอนปิด (แบบ `/shift/test` เดิม · ใช้ `logic.shift.roundSummary` ตัวเดียวกับจอ)
 *   แล้วเทียบกับ `expectedCash` นี้ · ไม่เท่า = 409 `summary_changed` พร้อมยอดใหม่ ให้แคชเชียร์ยืนยันซ้ำ (SC-14) · เท่า = เขียน `currentCash` (SC-28)
 *   ⇒ ไม่รับก้อนสรุปรายช่องจ่าย/สินค้า (`thisPayment` `thisProduct` …) จากแอป · ถ้า Pack เลือกให้แอปคิด คำขอนี้ต้องเพิ่มก้อนสรุป
 *   · `lateSales` ไม่มาทางนี้ `sale.create` เป็นคนบวก (plan ก้อน 4 #18)
 * - ถอนเงินเกินยอดนับ / นำเงินออกเกินเงินคาด = ผ่าน (SC-26 เตือน ไม่บล็อก · คำเตือนอยู่ที่ logic `WITHDRAW_OVER` `CASH_OUT_OVER`)
 * - ยอดเงินเป็นข้อความทศนิยมไม่เกิน 2 ตำแหน่ง เพราะ doc เก็บเป็น string ให้แอปเก่าอ่านได้ (`shift.md` §9)
 */

/**
 * ยอดเงินจากช่องกรอก: ห้ามว่าง (SC-25) · ห้ามติดลบ จุลภาค เลขยกกำลัง (SC-27) · ทศนิยมไม่เกิน 2 ตำแหน่ง · ไม่เกิน 9 หลัก
 * รับ `'100.'` (พิมพ์จุดค้าง) และ `'.5'` ด้วย เพราะช่องกรอกเดิม `twoDigitNumber` (`app:Utility/function.js:1392-1414`) ให้ได้จริง
 * และ `Number()` ของแอปเก่าอ่านได้ตรง · `'.'` อย่างเดียวไม่รับ
 */
export const ShiftMoneyText = z
  .string()
  .regex(/^(\d{1,9}(\.\d{0,2})?|\.\d{1,2})$/, {
    message: "ยอดเงินต้องเป็นตัวเลขไม่ติดลบ ทศนิยมไม่เกิน 2 ตำแหน่ง และห้ามว่าง",
  });

/** เงินคาดที่แอปคิด · number จริง · ติดลบได้ (นำเงินออกเกินที่มี SC-26) · ทศนิยมไม่เกิน 2 ตำแหน่ง */
const ShiftCashNumber = z
  .number()
  .finite()
  .refine((n) => Math.abs(n) < 1e10, { message: "ยอดเงินเกินเพดาน" })
  .refine((n) => Math.abs(Math.round(n * 100) - n * 100) < 1e-6, { message: "ยอดเงินทศนิยมไม่เกิน 2 ตำแหน่ง" });

const shiftDocId = z
  .string()
  .min(1, { message: "shiftId ห้ามว่าง (SC-31)" })
  .refine((s) => !s.includes("/"), { message: "shiftId ห้ามมี /" });

const common = {
  shopId: z.string().min(1).describe("ร้านของผู้เรียก · server เทียบกับตัวตนจาก token และ `shift.shopId` (ไม่เชื่อ body)"),
  shiftId: shiftDocId.describe("doc id ของ `shift` จาก `shop.POSs[].shiftId`"),
  requestId: z
    .string()
    .min(1)
    .max(128)
    .describe("id ต่อ 1 การกด · กันเปิด/ปิด/บันทึกซ้ำเมื่อกดรัวหรือส่งซ้ำ (SC-23 SC-46)"),
  staffId: z.string().min(1).describe("พนักงานที่ทำรายการ · ห้ามว่าง เพราะ server ใช้ `openId` เป็นเงื่อนไขรวมบิล (SC-60)"),
  staffName: z.string().describe("ชื่อพนักงาน · ต้องมีเป็น string แม้ว่าง กันเขียน `undefined` แล้ว batch ล้ม (SC-36)"),
};

export const ShiftOpenRequest = z
  .object({
    op: z.literal("open"),
    ...common,
    openCash: ShiftMoneyText.describe("เงินสดเปิดกะ · `0` ได้ · ว่างไม่ได้"),
  })
  .strict();

export const ShiftDuringRequest = z
  .object({
    op: z.literal("during"),
    ...common,
    type: z
      .union([z.literal(1), z.literal(2)])
      .describe("1 นำเข้า · 2 นำออก · ต้องส่งเอง ไม่มีค่าตั้งต้น (SC-45)"),
    amount: ShiftMoneyText.refine((s) => Number(s) > 0, {
      message: "ยอดเงินเข้าออกต้องมากกว่า 0 (SC-25)",
    }).describe("ยอดเงินเข้าออก"),
    comment: z.string().max(500).describe("เหตุผล · ว่างได้"),
  })
  .strict();

export const ShiftCloseRequest = z
  .object({
    op: z.literal("close"),
    ...common,
    closeCash: ShiftMoneyText.describe("เงินสดที่นับได้ตอนปิด · `0` ได้ · ว่างไม่ได้ (SC-25)"),
    closeWithDraw: ShiftMoneyText.describe("เงินที่ถอนออกตอนปิด · `0` ได้ · ว่างไม่ได้ · เกินยอดนับได้ (SC-26 เตือน ไม่บล็อก)"),
    expectedCash: ShiftCashNumber.describe(
      "เงินสดที่คาดไว้จาก `logic.shift.closeShift().expectedCash` · server เขียนลง `shiftHistory.currentCash` (SC-28)",
    ),
  })
  .strict();

export const ShiftManageRequest = z.discriminatedUnion("op", [
  ShiftOpenRequest,
  ShiftDuringRequest,
  ShiftCloseRequest,
]);

export type ShiftManageRequest = z.infer<typeof ShiftManageRequest>;
export type ShiftOpenRequest = z.infer<typeof ShiftOpenRequest>;
export type ShiftDuringRequest = z.infer<typeof ShiftDuringRequest>;
export type ShiftCloseRequest = z.infer<typeof ShiftCloseRequest>;

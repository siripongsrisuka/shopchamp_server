import { z } from "zod";
import { ReceiptGuardDocId } from "../entities/receiptGuard";

/**
 * คำขอ API โดเมนการขาย (ก้อน 4 · DEV-0001) · strict ทุกชั้น: field เกิน = ปัด 400
 * สัญญา: `shopchamp-center/api/draft/sale.{create,get,void,amend,discardPending}.yaml` (ร่าง · รอ Pack เซ็นชุด case)
 *
 * หลักที่เคาะแล้ว (`progress-shopchamp-architecture-upgrade.md` 🎯 2026-11-06):
 * - server เชื่อยอดเงินจากแอป ไม่คิดซ้ำ (2-2) ⇒ schema นี้คือด่านเดียวของยอดเงิน: ตัวเลขจริง · ไม่ติดลบ (#5) · ทศนิยมเงิน ≤ 2
 * - เงินเซ็นต้องมีสมาชิก (#7) · แลกแต้มต้องมีสมาชิก (member F4)
 * - จำนวนสินค้าเป็นทศนิยมได้ ≤ 4 ตำแหน่ง (เครื่องชั่ง ① ②) เก็บใน `qty` เหมือนเดิม
 * - ออฟไลน์: แอปส่ง `offline:true` + `soldAt` (ISO มี offset) · server ตัดสินช่วง 4 วัน / 5 นาทีเอง ไม่ใช่หน้าที่ schema
 * - ไม่รับเวลาเครื่องเป็นเวลาบิล: `dateTime` `billDate` `receiptNumber` `receiptType` `existPoint` server ใส่เอง
 * - ไม่รับ `taxNumber` `taxCustomer`: ใบกำกับออกแยก (#20) · ออฟไลน์ไม่ออกใบกำกับ
 */

/** ทศนิยมไม่เกิน n ตำแหน่ง · เทียบผ่าน toFixed เพราะ `0.29 * 100` ไม่เป็นจำนวนเต็มใน float */
const atMostDecimals = (n: number) => (v: number) => Number(v.toFixed(n)) === v;

/** เงินจากแอป: ตัวเลขจริง · ไม่ติดลบ (#5 K04) · ทศนิยม ≤ 2 · เพดาน 1e10 (NaN Infinity ถูกปัดโดย z.number) */
export const SaleMoney = z
  .number()
  .finite()
  .nonnegative({ message: "ยอดเงินห้ามติดลบ (#5)" })
  .lt(1e10, { message: "ยอดเงินเกินเพดาน" })
  .refine(atMostDecimals(2), { message: "ยอดเงินทศนิยมไม่เกิน 2 ตำแหน่ง" });

/** ปัดเศษ: ติดลบได้ (ปัดลง) · ทศนิยม ≤ 2 */
const SaleRounding = z
  .number()
  .finite()
  .refine((v) => Math.abs(v) < 1e10, { message: "ยอดเงินเกินเพดาน" })
  .refine(atMostDecimals(2), { message: "ยอดเงินทศนิยมไม่เกิน 2 ตำแหน่ง" });

/** จำนวนขาย: มากกว่า 0 · ทศนิยม ≤ 4 (เครื่องชั่ง ② · Pack เคาะ 2026-11-06) · เพดาน 1e7 */
export const SaleQty = z
  .number()
  .finite()
  .positive({ message: "จำนวนต้องมากกว่า 0" })
  .lt(1e7, { message: "จำนวนเกินเพดาน" })
  .refine(atMostDecimals(4), { message: "จำนวนทศนิยมไม่เกิน 4 ตำแหน่ง" });

/** doc id ที่ไม่ใช่ guard: ห้ามว่าง ห้ามมี `/` · ≤ 128 */
const DocId = z
  .string()
  .min(1, { message: "id ห้ามว่าง" })
  .max(128)
  .refine((s) => !s.includes("/"), { message: "id ห้ามมี /" });

/** เวลา ISO ที่มี `Z` หรือ offset · ไม่มี offset = ปัด (ตีความโซนผิดได้) */
const IsoTime = z.iso.datetime({ offset: true });

/** ช่องเงินเซ็นรุ่นปัจจุบัน (`app:config/initialShop.js:118`) · รหัสเก่า `'035'` แอปใหม่ไม่ส่ง */
export const CREDIT_PAYMENT_ID = 3;
const LEGACY_PAYMENT_CODE = /^\d{3}$/;

/** `bill.product[]` ที่แอปใหม่ส่ง · รูป `leanProduct` (`app:Utility/function.js:611-640`) + บรรทัดชั่งน้ำหนัก */
export const SaleLine = z
  .object({
    id: DocId.describe("รหัสสินค้า · server ใช้หา stock/stockLink ตัดสต็อก"),
    qty: SaleQty.describe("จำนวน · ทศนิยมได้ ≤ 4 (สินค้าชั่ง)"),
    name: z.string().max(300).describe("ชื่อตอนขาย"),
    net: SaleMoney.describe("ยอดหลังลดรายสินค้า"),
    totalPrice: SaleMoney.describe("ยอดก่อนลด"),
    totalCost: z.number().finite().nonnegative().lt(1e10).describe("ต้นทุนรวม · ทศนิยมไม่จำกัด (ถัวเฉลี่ย #22)"),
    priceType: z.string().max(100).optional(),
    category: z.array(z.string()).optional().describe("id หมวด"),
    consignment: z.unknown().optional().describe("ฝากขาย · ค่าตามสินค้า ไม่ล็อกชนิด (เหมือนรูปอ่าน)"),
    barcode: z.string().max(100).optional(),
    qtyUnit: z.string().max(30).optional().describe("หน่วยของสินค้าชั่ง เช่น กิโลกรัม (เครื่องชั่ง ⑥)"),
    unitPrice: SaleMoney.optional().describe("ราคาต่อหน่วยของสินค้าชั่ง"),
  })
  .strict();

/** `bill.payment[]` ที่แอปใหม่ส่ง · ยอดเป็นตัวเลขเท่านั้น (รูปสตริงของบิลเก่ารับแค่ตอนอ่าน) */
export const SalePayment = z
  .object({
    id: z
      .union([
        z.number().int().positive(),
        z
          .string()
          .min(1)
          .max(128)
          .refine((s) => !LEGACY_PAYMENT_CODE.test(s), { message: "รหัสช่องรุ่นเก่า 3 หลัก แอปใหม่ไม่ส่ง" }),
      ])
      .describe("1 เงินสด · 2 พร้อมเพย์ · 3 เงินเซ็น · uuid = ช่องที่ร้านเพิ่มเอง"),
    amount: SaleMoney.describe("ยอดที่รับในช่องนี้ (รวมส่วนที่ทอน)"),
    name: z.string().max(100).describe("ชื่อช่อง ณ ตอนขาย"),
    change: SaleMoney.optional().describe("เงินทอนของช่องนี้"),
  })
  .strict();

export const SaleMember = z
  .object({
    id: DocId.describe("doc id ของ `member` · server ตรวจว่าเป็นของร้านนี้"),
    name: z.string().max(200),
  })
  .strict();

export const SaleCampaign = z
  .object({
    id: z.union([z.string(), z.number()]),
    name: z.string().max(200),
    rights: z.number().finite().optional(),
    discount: SaleMoney,
    promotionId: z.string().max(20).optional(),
  })
  .strict();

const isCreditPayment = (p: { id: unknown; amount: number }) => p.id === CREDIT_PAYMENT_ID && p.amount > 0;

/** ส่วนเงินของบิล ใช้ร่วม `sale.create` และ `sale.amend` */
const saleMoneyFields = {
  moneyMustPaid: SaleMoney.describe("ยอดสุทธิ · ต่ำสุด 0 (#5)"),
  productDiscount: SaleMoney.optional(),
  vatAmount: SaleMoney.optional(),
  rounding: SaleRounding.optional(),
  change: SaleMoney.optional(),
};

export const SaleCreateRequest = z
  .object({
    shopId: DocId.describe("shop doc id ของร้านผู้เรียก · ต้องตรง `req.shopAccess.shopId` ไม่งั้น 403"),
    receiptUUID: ReceiptGuardDocId.refine((s) => s.length <= 128, { message: "receiptUUID ยาวเกิน 128" }).describe(
      "กุญแจกันบิลซ้ำ 1 การกด · = doc id ของ `receiptGuard` · รูปเดียวกับแอปเก่า `${shop.shopId}${uuid}` (#1)",
    ),
    product: z.array(SaleLine).min(1, { message: "บิลต้องมีสินค้าอย่างน้อย 1 รายการ" }).max(500),
    payment: z.array(SalePayment).max(20).describe("ว่างได้เมื่อยอด 0"),
    ...saleMoneyFields,
    manualDiscount: SaleMoney.optional(),
    pointDiscount: z.object({ value: SaleMoney, point: z.number().int().nonnegative() }).strict().optional(),
    posId: z.string().max(128).optional(),
    posNumber: z.string().max(50).optional(),
    cashierId: z.string().max(128).optional(),
    cashierName: z.string().max(200).optional(),
    currentCredit: SaleMoney.optional().describe("ซ้ำกับช่อง 3 · คงไว้ให้รูปเท่าแอปเก่า"),
    pointToItem: z.array(z.record(z.string(), z.unknown())).max(100).optional(),
    lucky: z.array(z.string().max(200)).max(100).optional(),
    gainPoint: z.number().finite().nonnegative().lt(1e10).optional().describe("แต้มที่ได้ (logic ฝั่งแอป)"),
    usedPoint: z.number().int().nonnegative().optional(),
    campaign: z.array(SaleCampaign).max(50).optional(),
    vatType: z.enum(["Include", "Exclude"]).optional(),
    note: z.string().max(500).optional(),
    member: SaleMember.optional().describe("ไม่มี = ขายไม่มีสมาชิก · ออฟไลน์ไม่มีเสมอ (decision 3-1)"),
    franchiseId: z.string().max(128).optional(),
    shiftId: DocId.describe("doc `shift` ของจุดขายที่ขาย · บังคับ (#18)"),
    shiftOpenTime: IsoTime.describe("เวลาเปิดรอบที่เปิดอยู่ตอนขาย (#18) · server ใช้หารอบ ไม่ใช้เป็นเวลาบิล"),
    offline: z.literal(true).optional().describe("ป้ายบิลออฟไลน์ · ไม่ใช่ออฟไลน์ = ไม่ส่ง"),
    soldAt: IsoTime.optional().describe("เวลาขายจริงตอนออฟไลน์ · บังคับเมื่อ offline · server ตัดช่วง 4 วัน/5 นาที"),
    offlineRef: z.string().min(1).max(40).optional().describe("รหัสใบรับเงินชั่วคราว `T…` (logic.docNumber.nextOfflineRef)"),
  })
  .strict()
  .superRefine((b, ctx) => {
    const hasMember = !!b.member;
    if (b.payment.some(isCreditPayment) && !hasMember) {
      ctx.addIssue({ code: "custom", path: ["member"], message: "เงินเซ็นต้องเลือกสมาชิก (#7)" });
    }
    if (((b.usedPoint ?? 0) > 0 || (b.pointDiscount?.value ?? 0) > 0) && !hasMember) {
      ctx.addIssue({ code: "custom", path: ["member"], message: "แลกแต้มต้องมีสมาชิก" });
    }
    if (b.offline === true && b.soldAt === undefined) {
      ctx.addIssue({ code: "custom", path: ["soldAt"], message: "บิลออฟไลน์ต้องมี soldAt" });
    }
    if (b.offline !== true && (b.soldAt !== undefined || b.offlineRef !== undefined)) {
      ctx.addIssue({ code: "custom", path: ["offline"], message: "soldAt และ offlineRef ส่งได้เฉพาะบิลออฟไลน์" });
    }
  });

export const SaleGetRequest = z
  .object({
    shopId: DocId,
    billId: DocId.describe("doc id ของ `bill` (ได้จาก sale.create หรือคำตอบ duplicate)"),
  })
  .strict();

const Reason = z
  .string()
  .trim()
  .min(1, { message: "ต้องกรอกเหตุผล" })
  .max(500);

export const SaleVoidRequest = z
  .object({
    shopId: DocId,
    billId: DocId,
    requestId: z.uuid().describe("1 การกดยกเลิก · ยิงซ้ำได้ผลเดิม (#6)"),
    reason: Reason,
    staffId: z.string().min(1).max(128).describe("พนักงานที่กดยกเลิก (บัญชีเครื่องใช้ร่วมกัน)"),
    staffName: z.string().max(200),
    shiftId: DocId.optional().describe("กะของจุดขายที่กดยกเลิก · เงินคืนลงกะนี้ (SC-06 ทางแรก)"),
  })
  .strict();

/** แถวของบิลใหม่ตอนแก้ไข · `fromIndex` = ตำแหน่งแถวในบิลเดิม (บิล Shopchamp ไม่มี tempId · `bill-edit-pattern` §3 🪤) */
export const SaleAmendLine = SaleLine.extend({
  fromIndex: z.number().int().nonnegative().describe("ตำแหน่งใน `product[]` ของบิลเดิม · ต้องไม่ซ้ำ"),
}).strict();

export const SaleAmendRequest = z
  .object({
    shopId: DocId,
    billId: DocId.describe("บิลเดิมที่จะแก้"),
    requestId: z.uuid().describe("ออกครั้งเดียวตอนเปิดหน้าต่างแก้ · ยิงซ้ำ = เดินต่อจากขั้นที่ค้าง"),
    reason: Reason,
    staffId: z.string().min(1).max(128),
    staffName: z.string().max(200),
    product: z.array(SaleAmendLine).min(1, { message: "ต้องเหลืออย่างน้อย 1 รายการ" }).max(500),
    payment: z.array(SalePayment).max(20),
    ...saleMoneyFields,
  })
  .strict()
  .superRefine((b, ctx) => {
    const seen = new Set<number>();
    b.product.forEach((l, i) => {
      if (seen.has(l.fromIndex)) ctx.addIssue({ code: "custom", path: ["product", i, "fromIndex"], message: "fromIndex ซ้ำ" });
      seen.add(l.fromIndex);
    });
    if (b.payment.some((p) => p.id === CREDIT_PAYMENT_ID)) {
      ctx.addIssue({ code: "custom", path: ["payment"], message: "บิลเงินเซ็นแก้ไม่ได้ (decision แก้ไขบิล ④)" });
    }
  });

export const SaleDiscardPendingRequest = z
  .object({
    shopId: DocId,
    receiptUUID: ReceiptGuardDocId.refine((s) => s.length <= 128, { message: "receiptUUID ยาวเกิน 128" }),
    offlineRef: z.string().max(40).optional(),
    body: z.record(z.string(), z.unknown()).describe("body ของ sale.create ที่ค้างในคิว · รับทุกรูป เพราะใบที่ลบมักเป็นใบที่เสีย"),
    reason: Reason,
    deviceAt: IsoTime.optional().describe("เวลาเครื่องตอนกดลบ (ออฟไลน์ลงคิวไว้ส่งทีหลัง)"),
  })
  .strict();

export type SaleLine = z.infer<typeof SaleLine>;
export type SalePayment = z.infer<typeof SalePayment>;
export type SaleCreateRequest = z.infer<typeof SaleCreateRequest>;
export type SaleGetRequest = z.infer<typeof SaleGetRequest>;
export type SaleVoidRequest = z.infer<typeof SaleVoidRequest>;
export type SaleAmendLine = z.infer<typeof SaleAmendLine>;
export type SaleAmendRequest = z.infer<typeof SaleAmendRequest>;
export type SaleDiscardPendingRequest = z.infer<typeof SaleDiscardPendingRequest>;

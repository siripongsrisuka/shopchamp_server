// @shopchamp/schema — รูปเอกสาร Firestore และรูปคำขอ API ของ Shopchamp
// แหล่งเดียว: import จากที่นี่ ห้ามนิยามซ้ำในแอปหรือ server
// โครง: 1 ไฟล์ต่อ entity ที่ src/entities/<ชื่อ>.ts · คำขอ API ที่ src/requests/<โดเมน>.ts
//   0.1.0 (ก้อน 0 · DEV-0001): receiptGuard ตัวเดียว เพื่อพิสูจน์ทาง build → test → pack
//   0.2.0 (ก้อน 1-3 · DEV-0001): 14 entity + คำขอ shift · member
//   ก้อน 4 (ร่าง · ยังไม่บั๊มรุ่น): คำขอ sale · profile + field เพิ่มอย่างเดียวของ bill shop shift shiftHistory
export * from "./entities/receiptGuard";
export * from "./entities/bill";
export * from "./entities/billId";
export * from "./entities/billDayId";
export * from "./entities/member";
export * from "./entities/paidHistory";
export * from "./entities/pgWebhook";
export * from "./entities/product";
export * from "./entities/promotion";
export * from "./entities/shift";
export * from "./entities/shiftHistory";
export * from "./entities/shop";
export * from "./entities/stock";
export * from "./entities/stockLink";
export * from "./requests/member";
export * from "./requests/shift";
export * from "./requests/sale";
export * from "./requests/profile";

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `stock/{id}` — สินค้าของร้าน 1 doc ต่อสินค้า 1 ตัว (ราคา · ต้นทุน · คงเหลือ · ผูกสต๊อก)
 * ที่มา: `lanes/dev/source/schema/stock.md` §1 (field ระดับบน 38 ตัว) และ §1.1 (field ซ้อน 16 ตัวใน 5 field แม่)
 *
 * - รูปตาม **ช่อง "ตอนอยู่ในฐาน"** ของ §1 ไม่ใช่ช่องตอนเขียน · เอกสารชุดนี้แอปเก่า server เดิม และเว็บยังเขียนตรงอยู่
 *   ⇒ `.passthrough()` ทุกชั้น เก็บ field ที่ไม่รู้จักไว้ ไม่ตัดทิ้ง
 * - บังคับแค่ `shopId` (เดิมรวม `updateTime` ด้วย · คลาย 2026-11-06 ตาม `live-fit.md` S2 เพราะเอกสาร 2022-2024 ไม่มี) · field "มีตั้งแต่เกิด"
 *   เป็น optional เพราะไม่มีเครื่องบังคับในฐาน (`firestore.rules` ไม่ตรวจรูป) และยังไม่ได้วัดเอกสารร้านลูกค้า
 * - ชนิดปนที่มีอยู่จริงในฐาน (ตัวเลขเป็นสตริง · `NaN` · วันที่ 3 รูป) รับไว้ตามที่ §1 บันทึก และชี้รหัสบั๊ก
 *   การแก้บั๊กพวกนี้เป็นงาน logic/API (ก้อน 3 · 4 · 9a) ไม่ใช่งานของ schema อ่าน
 * - doc id ไม่อยู่ใน schema นี้ · field `id` ข้างในเป็นสำเนาที่ติดเข้าเอกสาร (แถว 37 · BUG-02)
 * - ไม่มี field ใหม่ของก้อน 4 (`receiptUUID` `soldAt` `offline`) ใน entity นี้ เพราะเป็นของบิล ไม่ใช่ของสินค้า
 * - ⚠️ ประชากรที่วัดของจริง < ประชากรที่ schema ครอบ: schema ครอบ 8 ทางสร้าง (§2) · ของจริงที่ parse แล้วคือ
 *   doc ของร้านทดสอบ 10 ใบ (2026-11-06 ผ่าน 10/10) ซึ่งมาจากทาง S6 แม่แบบทางเดียว ไม่มี `linkDetail` `timestamp`
 *   `id` `deleted` `currentCategory` และไม่มีค่าสตริง NaN ค่าอนันต์ map วันที่ หรือค่าจาก Excel
 *   ⇒ ส่วนที่ผ่อนให้ชนิดปนทั้งหมดพิสูจน์จากโค้ดเขียนเดิมและเทสที่พิมพ์เอง ยังไม่ได้พิสูจน์กับ doc ร้านลูกค้า
 */

/** วันที่รูป map `{seconds,nanoseconds}` ที่เกิดจาก Timestamp ผ่าน `toJSON` แล้วเขียนกลับ (BUG-06 · §0 ข้อ 9) */
export const StockTimeMap = z
  .object({ seconds: z.number(), nanoseconds: z.number() })
  .passthrough()
  .describe("Timestamp ที่ถูก serialize ผ่าน MMKV แล้วเขียนกลับเป็น map ธรรมดา (BUG-06)");

/** สตริงวันที่ ISO ที่ทาง sync เขียนกลับ (แถว 28) · ต้องอ่านเป็นวันที่ได้ */
export const StockIsoTime = z
  .string()
  .refine((s) => !Number.isNaN(Date.parse(s)), { message: "ต้องเป็นสตริงวันที่ที่อ่านได้" });

/** ค่าวันที่ที่พบใน doc สต๊อก: Timestamp/Date หรือ map ที่หลุดจาก cache */
const TimeOrMap = z.union([FirestoreTime, StockTimeMap]);

/**
 * ค่าอนันต์ (`Infinity` `-Infinity`) · Zod 4 `z.number()` ไม่รับ จึงต้องแยกตัวนี้
 * ทางเกิด: หารด้วย 0 แล้วเขียนลงตรง · `app:screens/StockLinkSettingScreen4.js:102` (`linkQty` เมื่อตัวคูณเป็น `'0'` · ST-040)
 * · `app:screens/BillHistoryScreen.js:410` (`cost` เมื่อจำนวนรับเข้า 0) · `app:screens/ImportProductScreen.js:426` (`cost` เมื่อ `totalStock` 0)
 * · `own:screens/UploadProductScreen.js:157-159` (`Number('Infinity')` จาก cell ข้อความ) · RNFB ส่งค่าอนันต์ลงฐานได้ (`rnfb:lib/utils/serialize.js:117-122`)
 */
const NumInfinite = z.custom<number>((v) => v === Infinity || v === -Infinity, {
  message: "ต้องเป็น Infinity หรือ -Infinity",
});

/** ช่องตัวเลขที่ในฐานอาจเป็น number · สตริงจากช่องกรอก · `NaN` · ค่าอนันต์ จากเว็บและการหาร 0 (BUG-05 · BUG-11 · ST-040) */
const NumLoose = z.union([z.number(), z.nan(), NumInfinite, z.string()]);

/**
 * ค่าจาก cell Excel ที่ทางอัปโหลดของเว็บ (W1) ใส่ลง `name` `unit` ตรง ๆ ไม่แปลง (BUG-11)
 * `own:screens/UploadProductScreen.js:83` `:86` อ่าน `row.getCell(n).value||''` แล้ว `:153` `:161` ใส่ลง doc
 * · exceljs 4.4.0 คืน number (`exceljs:lib/doc/cell.js:406`) · Date (`:538`) ⇒ ลงฐานเป็น Timestamp · boolean (`:926`)
 * · rich text / hyperlink / สูตร / error เป็น object (`:494` `:582` `:734` `:970`) ⇒ ลงฐานเป็น map
 * ❓ ยังไม่รู้ว่าในฐานลูกค้ามีกี่ใบ · ร้านทดสอบไม่มีของจากทาง W1
 */
const ExcelCellValue = z.union([
  z.string(),
  z.number(),
  z.boolean(),
  FirestoreTime,
  z.record(z.string(), z.unknown()),
]);

export const StockPromotion = z
  .object({
    status: z.boolean().optional().describe("เปิดโปรราคาชุด"),
    qty: z
      .union([z.number(), z.literal("")])
      .optional()
      .describe("จำนวนต่อชุด · `''` ตอนยังไม่ตั้ง (initialProduct)"),
    price: z
      .union([z.number(), z.literal("")])
      .optional()
      .describe("ราคาต่อชุด · `''` ทางที่ไม่ผ่านฟอร์ม · ฟอร์มแปลงเป็น number (BUG-21)"),
    startDate: TimeOrMap.optional().describe("Timestamp ในฐาน · ฟอร์มแปลงกลับเป็น Date"),
    endDate: TimeOrMap.optional().describe("Timestamp ในฐาน · ฟอร์มแปลงกลับเป็น Date"),
  })
  .passthrough();

export const StockSafetyStock = z
  .object({
    status: z.boolean().optional().describe("เปิดเตือนสต๊อกต่ำ"),
    qty: z
      .union([z.string(), z.number()])
      .optional()
      .describe(
        "ขั้นต่ำ เป็นสตริงจาก `twoDigitNumber` · `''` ตอนยังไม่ตั้ง · ตัวเลขพบ 80 ใบ 2022-2025 ค่า 0-85 (`live-fit.md` S3 · ❓ ยังไม่ได้ไล่ทางเขียน) ผู้อ่านแปลง `Number`",
      ),
  })
  .passthrough();

export const StockPriceLevel = z
  .object({
    qty: z.number().describe("จำนวนขั้นต่ำของขั้นราคาส่ง"),
    price: z.number().describe("ราคาต่อหน่วยของขั้นนี้"),
  })
  .passthrough();

export const StockLinkDetailRow = z
  .object({
    linkMultiply: z.number().describe("จำนวนหน่วยเล็กสุดต่อ 1 หน่วยนี้"),
    unit: z.string().describe("หน่วยนับของสมาชิก"),
    id: z.string().describe("doc id ใน `stock` · ทาง clone เป็น id ร้านต้นทาง (BUG-01)"),
  })
  .passthrough();

export const StockCurrentCategory = z
  .object({
    level: z.union([z.number(), z.string()]).optional().describe("ระดับหมวด · ตั้งต้น 1 · ฟอร์มว่างเป็น `''`"),
    name: z.string().optional(),
    id: z.string().optional(),
    aboveId: z.array(z.string()).optional().describe("id หมวดระดับบนไล่ลงมา"),
  })
  .passthrough()
  .describe("สมาชิกคือ object จาก `shop.smartCategory[].value[]` ตรง ๆ");

export const Stock = z
  .object({
    // 1-3 ร้าน · บาร์โค้ด
    shopId: z.string().describe("ร้านเจ้าของ ใช้ query ทุกทาง · `''` ได้ (BUG-20)"),
    barcode: z
      .union([z.string(), z.number().int().nonnegative().safe()])
      .optional()
      .describe(
        "บาร์โค้ด · `''` ได้ · ไม่ unique (BUG-19) · ตัวเลขจำนวนเต็มได้ (อ่านเท่านั้น · ผู้อ่านแปลง `String()` ก่อนเทียบ) " +
          "· วัดซ้ำชุดใหม่เจอ 1 ใน 1,036 ใบ ปี 2025 (`live-fit.md` §8 S4) · ทางเขียน ❓ ยังไม่ได้ตรวจ (WebOwner `UploadProductScreen` เกิด 2025-04-08 และใส่ `String(barcode)` อยู่แล้ว ⇒ ไม่ใช่ทางนั้น)",
      ),
    barcodeStatus: z
      .union([z.boolean(), z.enum(["มีบาร์โค้ด", "ไม่มีบาร์โค้ด"])])
      .optional()
      .describe(
        "`false` = ไม่มีบาร์โค้ด ระบบสร้างให้ · ข้อความ `'มีบาร์โค้ด'` (= true) `'ไม่มีบาร์โค้ด'` (= false) จากแอปก่อน `shopcham_merchant_2025@3c9390b3` (2022-05-31) " +
          "· ผู้อ่านเดิมรับทั้ง 2 รูป `['มีบาร์โค้ด',true].includes(...)` (`@1b20384a` › `src/Modal/Modal_FastProduct.js:80`) · วัด 185 ใบ 2022-2024 (`live-fit.md` S1)",
      ),
    // 4-8 ชื่อ ราคา ต้นทุน คงเหลือ หน่วย
    name: ExcelCellValue.optional().describe("ชื่อสินค้า · `''` ได้ทางเว็บ · ทาง Excel เป็น number Timestamp boolean หรือ map ได้ (BUG-11)"),
    price: NumLoose.optional().describe("ราคาขาย · number · string · NaN · ค่าอนันต์ (BUG-05)"),
    cost: z
      .union([z.number(), z.nan(), NumInfinite, z.literal("")])
      .optional()
      .describe("ต้นทุนต่อหน่วย · number ติดลบได้ (ST-032) · `''` · NaN · ค่าอนันต์จากการหาร 0 (BUG-24 BUG-25 BUG-26)"),
    stock: NumLoose.optional().describe("คงเหลือ · number ติดลบได้ · string · `''` · NaN · ค่าอนันต์ (BUG-25 BUG-26)"),
    unit: ExcelCellValue.optional().describe("หน่วยนับ · ทาง Excel เป็น number Timestamp boolean หรือ map ได้ (BUG-11)"),
    // 9-12 รูป หมวด
    imageId: z.string().optional().describe("URL รูป หรือ `''` · ชื่อว่า Id แต่เก็บ URL"),
    selfImage: z.boolean().optional().describe("รูปเป็นของร้าน ไม่ใช่ส่วนกลาง"),
    category: z
      .union([z.array(z.string()), z.string()])
      .optional()
      .describe("เส้นทาง id หมวดบนลงล่าง · ❓ string จากข้อมูลเก่าหรือ masterSectionStock (BUG-15)"),
    currentCategory: z.array(StockCurrentCategory).optional().describe("ค่าจากฟอร์มหมวด ไม่มีคนอ่าน"),
    // 13-17 สวิตช์
    cashierShow: z.boolean().optional().describe("แสดงที่หน้าแคชเชียร์"),
    consignment: z.boolean().optional().describe("สินค้าฝากขาย"),
    delivery: z.boolean().optional().describe("❓ สินค้าเดลิเวอรี่ · ไม่พบ UI ตั้งเป็น true"),
    rent: z.boolean().optional().describe("❓ สินค้าเช่า · ไม่มีคนอ่าน"),
    vatExemption: z.boolean().optional().describe("สินค้ายกเว้นภาษี"),
    // 18-19 ของซ้อน
    promotion: StockPromotion.optional().describe("โปรราคาชุด · ฟอร์มถือว่ามีเสมอ"),
    safetyStock: StockSafetyStock.optional().describe("ขั้นต่ำเตือนสต๊อก"),
    // 20-25 ราคาส่ง แต้ม ตัดสต๊อก กำหนดเอง
    priceLevelStatus: z.boolean().optional().describe("เปิดราคาส่ง"),
    priceLevel: z.array(StockPriceLevel).optional().describe("ขั้นราคาส่ง"),
    pointStatus: z.boolean().optional().describe("ให้แต้มสมาชิก"),
    stockCountStatus: z.boolean().optional().describe("ตัดสต๊อก"),
    customQtyStatus: z.boolean().optional().describe("กำหนดจำนวนเองตอนขาย"),
    customPriceStatus: z.boolean().optional().describe("กำหนดราคาเองตอนขาย"),
    // 26-31 วันหมดอายุ รหัส เวลา ลบ
    expReport: z
      .array(TimeOrMap)
      .optional()
      .describe("วันหมดอายุของล็อต · ปน Timestamp กับ map (BUG-06)"),
    sku: z.string().optional().describe("รหัสสินค้า · `delete` = เครื่องหมายลบแบบเก่า"),
    timestamp: z
      .union([FirestoreTime, StockIsoTime, StockTimeMap])
      .optional()
      .describe("ลำดับหน้าแคชเชียร์ · Timestamp · ISO · map หรือไม่มี (BUG-06)"),
    updateTime: FirestoreTime.optional().describe(
      "เวลาแก้ล่าสุด ตัวตั้งของ sync · ในฐานเป็น Timestamp (BUG-10) · ไม่มี key ได้: 84 ใบ 2022-2024 ไม่มีทั้ง `updateTime` และ `timestamp` (`live-fit.md` S2 · ❓ ยังไม่ได้ไล่แอปรุ่นที่ไม่เขียน) · " +
        "⚠️ sync ที่ query ด้วย `updateTime` มองไม่เห็นใบพวกนี้ · ทางเขียนใหม่ต้องใส่เสมอ",
    ),
    latestSaleDate: TimeOrMap.optional().describe("เวลา commit ล่าสุดที่ขายตัวนี้ · Timestamp หรือ map (BUG-14)"),
    deleted: z.literal(true).optional().describe("ลบแบบ soft · มีแค่ `true` หรือไม่มี"),
    // 32-36 ผูกสต๊อก
    linkDetail: z.array(StockLinkDetailRow).optional().describe("สมาชิกทุกตัวในกลุ่มผูก ใหญ่ไปเล็ก · `[]` หลังเลิกผูก"),
    linkNext: z.string().optional().describe("id สินค้าหน่วยใหญ่ถัดไป · `''` · ทาง clone เก็บ barcode (BUG-01)"),
    linkMultiply: z
      .union([z.number(), z.literal("")])
      .optional()
      .describe("หน่วยเล็กสุดต่อ 1 หน่วยนี้ · `''` หลังเลิกผูก"),
    linkQty: z.union([z.number(), NumInfinite]).optional().describe("จำนวนในตะกร้าที่ถึงขั้นอัปเกรด · ค่าอนันต์เมื่อตัวคูณเป็น 0 (ST-040)"),
    linkId: z.string().optional().describe("id ของ `stockLink` · `''`"),
    // 37-38 อื่น ๆ
    id: z.string().optional().describe("สำเนา doc id ที่ติดเข้าเอกสาร · ทาง clone เป็นของร้านต้นทาง (BUG-02)"),
    other: z.array(z.unknown()).optional().describe("❓ ไม่รู้ความหมาย · พบแต่ array ว่าง (S6)"),
  })
  .passthrough();

export type Stock = z.infer<typeof Stock>;

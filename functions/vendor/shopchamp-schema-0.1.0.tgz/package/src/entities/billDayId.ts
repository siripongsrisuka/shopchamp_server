import { z } from "zod";

/**
 * `billDayId/{shop.id}` — ตัวนับเลขใบเสร็จรายวันของร้าน 1 doc ต่อร้าน
 * ที่มา: `lanes/dev/source/schema/billDayId.md` §1 (field 2 ตัว F-1 `date` · F-2 `receipts`)
 *
 * - ใช้เมื่อ `shop.receiptPattern` ไม่ใช่ `'month'` (§4 P-2 P-4) · ร้านแบบเดือนใช้ `billId` แทน
 * - doc id คือ `shop.id` (§1) ไม่ใช่ field ของเอกสาร จึงไม่อยู่ใน schema นี้
 * - ทุกทางสร้าง (แอป `CO:587` · server `S:363`) เขียนครบ 2 field ⇒ บังคับทั้งคู่ (§2)
 * - แอปเก่ายังเขียน doc นี้ร่วมกับ server ใหม่ (architecture-plan §3 "ตัวนับ") ⇒ `.passthrough()`
 *   เก็บ field ที่ไม่รู้จักไว้ ไม่ตัดทิ้ง · เขียนกลับต้องไม่ลบของที่แอปเก่าเขียน
 * - ชนิดตรวจเข้ม (จำนวนเต็ม · ช่วงค่า) เพราะทุกจุดเขียนให้ค่าแบบนี้เท่านั้น (§4 W-1 ถึง W-9)
 *   ค่าที่หลุดช่วง = doc ถูกเขียนทับจากนอกทางปกติ (SB-07 rules ใน repo ไม่แยกร้าน)
 *   ถ้าเอาไป `receipts + 1` ต่อ จะได้สตริงหรือ `NaN` เป็นเลขใบเสร็จ ⇒ ผู้ใช้ schema ต้องไม่ออกเลขจาก doc ที่ parse ไม่ผ่าน
 *   ⚠️ ยังไม่ได้วัด doc จริงของร้านแบบวัน (ร้านทดสอบมี 0 doc) ⇒ ก้อน 4 ต้องวัดก่อนใช้ schema นี้ปัดการออกเลข
 * - ไม่มี field ของก้อน 4 (`receiptUUID` `soldAt` `offline`) เพราะเป็นของ `bill` ไม่ใช่ของตัวนับ
 */
export const BillDayId = z
  .object({
    date: z
      .number()
      .int()
      .min(1)
      .max(31)
      .describe(
        "F-1 เลขวันที่ของเดือน 1-31 จาก getDate() ของนาฬิกาผู้เขียน · ไม่มีเดือนและปี (SB-03) · ใช้เทียบกับวันนี้แล้วทิ้ง (§3 L-1)",
      ),
    receipts: z
      .number()
      .int()
      .min(1)
      .describe(
        "F-2 ลำดับล่าสุดที่ออกไปแล้วของวัน `date` · เขียนเป็น 1 หรือ receipts+1 เท่านั้น · ยกเลิกบิลไม่ลด · ต่อเป็นเลขใบเสร็จ YYYYMMDD + 6 หลัก (§3 L-2)",
      ),
  })
  .passthrough();

export type BillDayId = z.infer<typeof BillDayId>;

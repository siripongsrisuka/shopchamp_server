import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `stockLink/{id}` — กลุ่มผูกสต๊อก 1 doc ต่อ 1 กลุ่มสินค้าหลายหน่วย (ลัง · แพ็ก · ชิ้น)
 * ที่มา: `lanes/dev/source/schema/stockLink.md` §1 (ระดับบน 7 field · ใน `stockLink[]` 6 field)
 *
 * มี 2 schema:
 * - `StockLink` = รูปที่ **อ่านจากฐาน** · `.passthrough()` ทุกชั้น เพราะแอปเก่า · เว็บแฟรนไชส์ · route clone ยังเขียนตรงอยู่
 *   รับชนิดปนที่มีอยู่จริง (`linkMultiply` เป็น number `1` ของตัวอ้างอิง และสตริงของตัวอื่น · C1)
 * - `StockLinkWrite` = รูปที่ **โค้ดใหม่ต้องเขียน** ตามที่ Pack เคาะ "แก้" (DI-56 · ST-040 · DI-75 · ST-088)
 *   ตัวคูณเป็น number บวก · ตัวอ้างอิง 1 มีตัวเดียว · สมาชิกไม่ซ้ำ · ชื่อกลุ่มไม่ว่างหลัง trim
 *   ⇒ ปิดบั๊กได้จริงเมื่อจุดเขียนของแอปใหม่ parse ด้วยตัวนี้ก่อนเขียน (ยังไม่ได้ต่อ)
 *   · ตัวคูณอื่นที่ซ้ำกัน (เช่น โหล 12 กับ แพ็ก 12) **ผ่าน** เหมือนแอปเดิมและแฟรนไชส์ · ยังไม่มี decision ให้ปัด
 *   · ตัวคูณทศนิยม (เช่น 1.5) **ผ่าน** เหมือนแอปเดิม · เพดานและจำนวนเต็มยังไม่มี decision (ST-058 อยู่ที่ logic)
 *   · ลำดับสมาชิกไม่มีผล ตัวอ้างอิงอยู่ตำแหน่งไหนก็ได้
 *
 * ทางจาก doc เก่าไปรูปเขียน (จอแก้ไขเดิมเขียน `current` ทั้งก้อน `StockLinkEdit.js:90`):
 *   ผู้เขียนใหม่ต้องประกอบ object ใหม่จาก field ที่ประกาศเท่านั้น (ทิ้ง field อื่น เพราะ strict) และแปลงตัวคูณด้วย
 *   `readLinkMultiply` ของ logic ก้อน 3 (`packages/logic/src/stock.js` · สตริงเก่า → number · `'0'` → null)
 *   · สมาชิกที่แปลงได้ null (`'0'` B11) หรือมีตัวคูณ 1 สองตัว (B11) แปลงเองไม่ได้ ⇒ ตัวนี้ปัดพร้อมข้อความ ให้ผู้ใช้แก้ที่จอ
 *   ⇒ ตัวนี้ไม่แปลงชนิดเอง (ไม่ coerce) เพื่อไม่ให้ `'0'` หรือสตริงแปลก ๆ ผ่านเงียบ (ST-040)
 *
 * เวลา `timestamp` ฝั่งเขียน = `Date` ของเครื่องที่เขียน เหมือนทางสร้างเดิมทุกทาง (แอป `formatTime` คืน `Date` · แฟรนไชส์ `new Date`)
 *   ไม่ใช้ `serverTimestamp()` เพราะ field นี้ใช้แค่เรียงกลุ่ม · ตัวนี้จึงไม่รับ sentinel ของ SDK
 *   ถ้าผู้เขียนฝั่ง server (ก้อน 9a) จะใช้ `serverTimestamp()` ให้ parse ด้วย `Date` ก่อนแล้วค่อยสลับค่า
 *
 * - 2 ตระกูลใน collection เดียว (ST-012 ใช้ทางแรก = คงเมนูแฟรนไชส์): ของร้าน `shopId` = รหัสร้าน สมาชิกชี้ `stock`
 *   · ของแฟรนไชส์ `shopId` = `''` + `franchiseId` สมาชิกชี้ `warehouseItem` (C3)
 * - ตัวอ่าน `StockLink` ไม่เข้มกว่าที่ฐานมีจริง: ตัวคูณสตริง `'1.5'` `'6.'` `'0'` (`twoDigitNumber`) · `barcode` `''` (B16)
 *   · กลุ่มแฟรนไชส์สมาชิก 1 ตัว · ห้ามเติมเงื่อนไขพวกนี้ตอนอ่าน ไม่งั้น doc จริงล้มเงียบ
 * - doc id ไม่อยู่ใน schema · field `id` ระดับบนเป็นสำเนาที่บาง doc ไม่มี (แถว 7 · C2) ตัวอ่านใช้ `doc.id` เสมอ
 * - ไม่มี `updateTime` และไม่มีลบแบบ soft (§1.1 ท้ายตาราง) ⇒ ไม่ผ่านกลไก sync แบบ `stock`
 * - ไม่มี field ใหม่ของก้อน 4 (`receiptUUID` `soldAt` `offline`) เพราะเป็นของบิล · `sale.create` ตัดสต๊อกจาก
 *   `stock.linkDetail` ไม่ใช่จาก `stockLink` (§3 แถว `stockLink[].linkMultiply`) ⇒ ไม่มีคำขอ API ของ entity นี้ในก้อน 4
 */

/** ตัวคูณในฐาน: ตัวอ้างอิงเป็น number `1` · ตัวอื่นเป็นสตริงจาก `twoDigitNumber` · แฟรนไชส์เป็นสตริงทุกตัว (แถว 13 · C1) */
const LinkMultiplyRead = z.union([z.number(), z.string()]);

/** §1.2 สมาชิก 1 ตัวใน `stockLink[]` ตามที่อ่านจากฐาน */
export const StockLinkMember = z
  .object({
    id: z
      .string()
      .describe("§1.2 แถว 8 · ตระกูลร้าน = doc id ใน `stock` · ตระกูลแฟรนไชส์ = doc id ใน `warehouseItem` (C3)"),
    name: z
      .string()
      .optional()
      .describe("§1.2 แถว 9 · สำเนาชื่อ ณ ตอนผูก ไม่ตามสินค้า (B14) · ใช้แสดงเท่านั้น"),
    unit: z.string().optional().describe("§1.2 แถว 10 · สำเนาหน่วย (B14) · ใช้แสดง"),
    imageId: z.string().optional().describe("§1.2 แถว 11 · สำเนา URL รูป (B14) · ใช้แสดง"),
    barcode: z
      .string()
      .optional()
      .describe("§1.2 แถว 12 · สำเนาบาร์โค้ด · `/cloneShop2` ใช้จับคู่ (B16) · `''` ได้"),
    linkMultiply: LinkMultiplyRead.describe(
      "§1.2 แถว 13 · จำนวนหน่วยเล็กสุดต่อ 1 หน่วยนี้ · number หรือสตริง (C1) · เรียงแบบสตริงแล้วลำดับเพี้ยน (B6 · `money.md` F14)",
    ),
  })
  .passthrough();

/** §1.1 doc `stockLink` ตามที่อ่านจากฐาน */
export const StockLink = z
  .object({
    shopId: z
      .string()
      .describe("§1.1 แถว 1 · ร้านเจ้าของกลุ่ม ใช้ query · ตระกูลแฟรนไชส์เป็น `''` (ST-012)"),
    franchiseId: z.string().optional().describe("§1.1 แถว 2 · มีเฉพาะตระกูลแฟรนไชส์"),
    stockGroupName: z
      .string()
      .describe("§1.1 แถว 3 · ชื่อกลุ่ม · จอแก้ไขเดิมไม่ตรวจ ⇒ doc เก่าอาจเป็น `''` (B19)"),
    stockLink: z
      .array(StockLinkMember)
      .describe("§1.1 แถว 4 · สมาชิก · ลำดับคือลำดับตอนเลือก · ไม่บังคับจำนวนตอนอ่าน (UI เดิม: แอป ≥ 2 · แฟรนไชส์ ≥ 1)"),
    timestamp: FirestoreTime.describe(
      "§1.1 แถว 5 · Timestamp · ใช้เรียงกลุ่ม · ตระกูลแฟรนไชส์เป็นเวลาโหลดโมดูล ไม่ใช่เวลาสร้าง (B5)",
    ),
    upgrade: z.boolean().describe("§1.1 แถว 6 · เปิดอัปเกรดหน่วยในตะกร้าอัตโนมัติ · แฟรนไชส์เป็น `true` เสมอ"),
    id: z.string().optional().describe("§1.1 แถว 7 · สำเนา doc id · doc จากแอปตอนสร้างไม่มี (C2) · ไม่มีผู้อ่าน"),
  })
  .passthrough();

/** สมาชิก 1 ตัวที่โค้ดใหม่เขียน · strict เพราะ wizard เดิมต้องตัด `qty` `oldStock` `cost` `totalCost` ทิ้งก่อนเขียน (§1.2 ท้ายตาราง) */
export const StockLinkMemberWrite = z
  .object({
    id: z.string().min(1, { message: "สมาชิกต้องมี id" }),
    name: z.string(),
    unit: z.string(),
    imageId: z.string(),
    barcode: z.string(),
    linkMultiply: z
      .number({ message: "ตัวคูณต้องเป็น number (DI-56)" })
      .finite()
      .positive({ message: "ตัวคูณต้องมากกว่า 0 (ST-040)" }),
  })
  .strict();

/** doc ที่โค้ดใหม่เขียน (สร้างหรือแก้ทั้งก้อน) */
export const StockLinkWrite = z
  .object({
    shopId: z.string(),
    franchiseId: z.string().min(1).optional(),
    stockGroupName: z.string().trim().min(1, { message: "ชื่อกลุ่มห้ามว่าง (DI-75 · B19)" }),
    stockLink: z.array(StockLinkMemberWrite).min(1, { message: "กลุ่มต้องมีสมาชิก" }),
    timestamp: FirestoreTime,
    upgrade: z.boolean(),
    id: z.string().min(1).optional(),
  })
  .strict()
  .superRefine((doc, ctx) => {
    if (doc.shopId === "" && !doc.franchiseId) {
      ctx.addIssue({ code: "custom", path: ["shopId"], message: "ต้องระบุร้านหรือแฟรนไชส์เจ้าของกลุ่ม (ST-012 · C3)" });
    }
    const ids = doc.stockLink.map((m) => m.id);
    if (new Set(ids).size !== ids.length) {
      ctx.addIssue({ code: "custom", path: ["stockLink"], message: "สมาชิกซ้ำในกลุ่มเดียว (ST-088 · B25)" });
    }
    // ตัวอ้างอิง 1 ต้องมีตัวเดียว (B11: `"1"` ซ้ำกับตัวอ้างอิงเคยผ่าน) · ตัวคูณอื่นซ้ำกันได้ (ดูหัวไฟล์)
    const ones = doc.stockLink.filter((m) => m.linkMultiply === 1).length;
    if (doc.stockLink.length > 0 && ones === 0) {
      ctx.addIssue({ code: "custom", path: ["stockLink"], message: "ต้องมีตัวอ้างอิงตัวคูณ 1 (ST-040 · B11)" });
    }
    if (ones > 1) {
      ctx.addIssue({ code: "custom", path: ["stockLink"], message: "ตัวอ้างอิงตัวคูณ 1 มีได้ตัวเดียว (B11)" });
    }
  });

export type StockLink = z.infer<typeof StockLink>;
export type StockLinkMember = z.infer<typeof StockLinkMember>;
export type StockLinkWrite = z.infer<typeof StockLinkWrite>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `paidHistory/{autoId}` — ประวัติรับชำระเงินเซ็นของสมาชิก 1 ใบต่อการรับชำระ 1 ครั้ง (DEV-0001 ก้อน 1)
 * ที่มา: `lanes/dev/source/schema/paidHistory.md` §1 (6 field) · §3 ทางสร้าง W1 แอป · W2 เว็บเจ้าของร้าน
 *
 * - แอปเก่าและเว็บเดิมยังเขียน collection นี้ตรงอยู่ ⇒ `.passthrough()` เก็บ field ที่ไม่รู้จักไว้ ไม่ตัดทิ้ง
 * - doc id อัตโนมัติ ไม่ใช่ field ของเอกสาร จึงไม่อยู่ใน schema นี้
 * - บังคับ = `memberId` `timestamp` เพราะ query เดียวของระบบพึ่ง 2 ตัวนี้ (§3 ผลคำนวณ · §6 Q1)
 *   อีก 4 ตัว (`shopId` `paid` `existCredit` `billDate`) มีทุกทางสร้างใน repo แต่เป็น optional
 *   เพราะรุ่นที่ปล่อยแล้ว (`2.86.00` `3.12.00`) ยังไม่ได้เปิดดูรูปเอกสาร (§หัวเอกสาร ❓) และร้านทดสอบมี 0 ใบ
 *   ⇒ ยังไม่มีข้อมูลยืนยันว่าเอกสารเก่าทุกใบมีครบ · ตัวอ่านเดิมแสดงช่องว่างเมื่อขาด (§3)
 * - ชนิดกว้างเท่าที่ของเดิมเขียนจริง ไม่แคบกว่า ⇒ **ห้ามใช้ schema นี้ตัดสินว่ายอดถูก**
 *   `paid` เป็นข้อความอิสระได้ (PHB-01 · MBB-01 MBB-02 MBB-23) · `existCredit` เป็น `NaN` ได้ (PHB-03)
 *   ตัวเขียนใหม่ (ก้อน 4 `member.payCredit`) ต้องเขียน `paid` เป็นตัวเลขจากคำขอที่ตรวจแล้ว ไม่ใช่ข้อความจากช่องกรอก (F45)
 *   `existCredit` ไม่ใส่ขั้นต่ำ: ของเดิมไม่มีด่านค่า (K4 เว็บกรอกยอดติดลบได้ · F3) และ `member.credit` ไม่ได้บังคับ ≥ 0
 *   ⇒ ไม่มีหลักฐานว่าค่าติดลบไม่เคยถูกเขียน
 * - ยอดที่กรอกกับยอดที่ตัดจริงต่างกันได้ (F12 MBB-24) · แก้ที่ logic ของก้อน 4 ไม่ใช่ที่รูปเอกสาร
 */

/**
 * ตัวเลขจากของเดิม · รับ `NaN` และ `Infinity` ด้วย เพราะ `z.number()` ของ Zod 4 ปัดค่าพวกนี้
 * และ `existCredit` เป็น `NaN` ได้เมื่อ `member.credit` เป็น `NaN` มาก่อน (PHB-03 · F3)
 */
const LegacyNumber = z.custom<number>((v) => typeof v === "number", { message: "ต้องเป็นตัวเลข" });

export const PaidHistory = z
  .object({
    shopId: z
      .string()
      .optional()
      .describe("§1 แถว 1 · ร้านเจ้าของ จาก state ร้าน · ไม่พบผู้อ่าน ไม่อยู่ใน query · มีทุกทางสร้างใน repo"),
    paid: z
      .union([z.string(), z.number()])
      .optional()
      .describe(
        "§1 แถว 2 · ยอดที่ **กรอก** ไม่ใช่ยอดที่ตัดจริง (MBB-24) · ของเดิมเป็นข้อความเสมอ: แอปกรองเลขได้ `''` `'100.'` `'.5'` · เว็บไม่กรอง ได้ `'abc'` `'1,000'` `'-50'` (PHB-01) · ตัวเขียนใหม่ใช้ตัวเลข finite",
      ),
    existCredit: LegacyNumber.optional().describe(
      "§1 แถว 3 · หนี้คงเหลือหลังรับชำระ ภาพนิ่ง ณ ตอนนั้น · ไม่ปัดเศษ (MBB-30) · `NaN` ได้ (PHB-03) · ต่ำกว่าจริงเมื่อมีบิลเซ็นค้างคิว (SE-12)",
    ),
    memberId: z
      .string()
      .min(1, { message: "memberId ห้ามว่าง" })
      .describe("§1 แถว 4 · doc id ของ `member` · query เดียวของระบบกรองด้วยค่านี้ · ค้างเมื่อสมาชิกถูกลบ (PHB-04)"),
    timestamp: FirestoreTime.describe(
      "§1 แถว 5 · `serverTimestamp()` ทั้ง 2 ทางสร้าง · ใช้กรอง 365 วัน เรียง และแสดง · ขาดแล้ว query ไม่คืนใบนี้",
    ),
    billDate: z
      .string()
      .regex(/^\d{8}$/, { message: "billDate ต้องเป็น YYYYMMDD 8 หลัก" })
      .optional()
      .describe(
        "§1 แถว 6 · `stringYMDHMS3` = YYYYMMDD จากนาฬิกาเครื่องผู้กด · ปฏิทิน ไม่ใช่วันธุรกิจ ไม่ตัดตาม cutOff · ไม่ได้ชี้บิล · ไม่พบผู้อ่าน (PHB-05)",
      ),

    // field ใหม่ของก้อน 4 `member.payCredit` · เพิ่มแบบ optional เท่านั้น เพราะเอกสารเดิม แอปเก่า และเว็บไม่เขียน (architecture-plan §3)
    // ชื่อและรูปเป็นข้อเสนอของก้อน 1 · ตัวจริงยึดสัญญา `api/member.payCredit.yaml` ที่ Pack เซ็นในก้อน 4 · สัญญาต่างจากนี้ = แก้ไฟล์นี้ตาม
    // ก้อน 4 ไม่มีทางออฟไลน์ (เงินเซ็นซ่อนตอนออฟไลน์ decision 3-1 · คิวส่งเข้า `sale.create` ตัวเดียว) ⇒ ไม่มี `offline` `soldAt` ในเอกสารนี้
    receiptUUID: z
      .string()
      .min(1)
      .optional()
      .describe("ใหม่ (ก้อน 4) · รหัส 1 การกดรับชำระ · กันใบซ้ำเมื่อกดซ้ำหรือส่งซ้ำ (MBB-35 · F11) · เอกสารเดิมไม่มี"),
    shiftId: z
      .string()
      .min(1)
      .optional()
      .describe(
        "ใหม่ (ก้อน 4 · #17 SC-01) · กะที่รับเงิน = doc `shift` ประจำจุดชำระเงิน ใช้ซ้ำทุกรอบ ⇒ แยกรอบต้องคู่ `shiftOpenTime` · เอกสารที่ไม่มีค่านี้ (แอปเก่า เว็บ) ไม่นับเข้าเงินคาดของกะ",
      ),
    shiftOpenTime: FirestoreTime.optional().describe(
      "ใหม่ (ก้อน 4 · #17) · เวลาเปิดรอบของ `shiftId` ตอนรับเงิน · แบบเดียวกับ `bill.shiftOpenTime` (#18)",
    ),
    staffId: z
      .string()
      .min(1)
      .optional()
      .describe("ใหม่ (ก้อน 4 · #17 SC-01) · คนรับเงิน · ของเดิมไม่รู้ว่าใครรับ"),
    staffName: z
      .string()
      .optional()
      .describe("ใหม่ (ก้อน 4 · #17) · ชื่อคนรับ ณ ตอนนั้น · ว่างได้แบบ `shift` request (SC-36)"),
    paymentId: z
      .union([z.number(), z.string().min(1)])
      .optional()
      .describe(
        "ใหม่ (ก้อน 4 · #17 SC-01) · ช่องทางรับเงิน รหัสเดียวกับ `bill.payment[].id` · ปิดกะนับเฉพาะช่องเงินสดเข้าลิ้นชัก",
      ),
    paymentName: z.string().optional().describe("ใหม่ (ก้อน 4 · #17) · ชื่อช่องทาง ณ ตอนนั้น"),
    cutBills: z
      .array(
        z
          .object({
            billId: z.string().min(1).describe("doc id ของ `bill` = `member.creditArray[].billId`"),
            amount: z.number().describe("ยอดที่ตัดจากหนี้ของบิลนี้ · ตัวเลข finite"),
          })
          .passthrough(),
      )
      .optional()
      .describe(
        "ใหม่ (ก้อน 4 · F22 PHB-02) · บิลที่ถูกตัดหนี้ในการรับชำระครั้งนี้ · ส่วนที่ตัดยอดตั้งต้น `member.credit` (ไม่มีบิล) ไม่อยู่ในรายการนี้ · ของเดิมไล่ไม่ได้ว่าตัดบิลไหน",
      ),
  })
  .passthrough();

export type PaidHistory = z.infer<typeof PaidHistory>;

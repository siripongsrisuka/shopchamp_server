import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `member/{autoId}` — สมาชิกของร้าน 1 doc ต่อ 1 คน
 * ที่มา: `lanes/dev/source/schema/member.md` §1.1 (บนสุด 16) · §1.2 `bought[]` (4) · §1.3 `creditArray[]` (5)
 *
 * - แอปเก่าและเว็บเจ้าของร้านยังเขียน collection นี้ตรงอยู่ (§4.1 · 17 จุด) ⇒ `.passthrough()` ทุกชั้น
 * - บังคับ = แถวที่ §1 ช่อง "บังคับ" เขียนว่า "บังคับ" มีตัวเดียวคือ `shopId` (query ทุกรายการพึ่ง)
 *   แถว "มีตั้งแต่เกิด" เป็น optional เพราะโค้ดเดิมเติมค่าเริ่มตอนอ่านเอง (`point = 0` · `bought = []`
 *   ที่ `app:Utility/function.js:255-257`) และ doc รุ่นเก่ายังไม่ได้วัดว่ามีครบ (หัวเอกสาร "ยังไม่ได้ตรวจ" ข้อ 1)
 * - ชนิดกว้างเท่าที่โค้ดเดิมเขียนจริง ไม่แคบกว่า ไม่งั้น doc จริงถูกปัด · ห้ามใช้ schema นี้ตัดสินว่าแต้มหรือหนี้ถูก
 *   (แต้มติดลบ K1 K7 · `NaN` จากเว็บ PHB-03 เป็นงานของ logic ก้อน 3 ไม่ใช่ของ schema)
 * - `memberList` เป็น collection แยก มีไม้บรรทัดของตัวเอง `schema/memberList.md` ⇒ ไม่อยู่ในไฟล์นี้
 * - doc id ไม่ใช่ field ของเอกสาร (§1.5 แถว `id`) ⇒ ไม่อยู่ใน schema
 * - ค่าที่คำนวณตอนอ่าน `id` `totalBuy` `totalCredit` `accessEnable` (§1.5) ไม่อยู่ในฐาน ⇒ ไม่ประกาศ
 */

/**
 * ตัวเลขแต้มและเงินจากโค้ดเดิม · รับ `NaN` และ `Infinity` ด้วย (§1.1 แถว 3-4: เว็บอัปไฟล์ได้ `NaN` ·
 * ยกเลิกบิลที่ doc ไม่มี `point` ได้ `undefined - n`) เพราะ `z.number()` ของ Zod 4 ปัดค่าพวกนี้
 * ⇒ doc ที่มีค่าแบบนี้จะถูกปัดทั้งใบ ทั้งที่แอปเก่ายังอ่านได้
 */
const LegacyNumber = z.custom<number>((v) => typeof v === "number", { message: "ต้องเป็นตัวเลข" });

/** §1.2 `member.bought[]` · ยอดซื้อรายเดือน 1 แถวต่อเดือน · รูปปัจจุบัน */
export const MemberBoughtMonth = z
  .object({
    yearMonth: z
      .string()
      .describe("§1.2 · `YYYYMM` เดือนที่บวกยอด · ทางซิงก์ใช้เดือนตอนซิงก์ ไม่ใช่เดือนที่ขาย (M-02)"),
    buy: LegacyNumber.describe("§1.2 · ยอด `moneyMustPaid` สะสม ไม่ปัด · ยกเลิกบิลลบออกได้จนติดลบ"),
    time: LegacyNumber.describe("§1.2 · จำนวนบิลของเดือน"),
    year: z
      .string()
      .optional()
      .describe("§1.2 · `YYYY` ใช้คิด `totalBuy` ปีนี้ · เขียนตอนสร้างแถวเท่านั้น · ❓ แถวรุ่นเก่าอาจไม่มี"),
  })
  .passthrough();

/**
 * `bought[]` แถวรุ่นแรก · ยอดรายปี `{year, totalBuy, paid}` ไม่มี `yearMonth` `buy` `time`
 * ทางเขียน `shopcham_merchant_2025@73201b73` (2022-02-14) › `src/hook/useUpdateOrder.js` `bought.push({year, totalBuy, paid:false})`
 * วัด 2026-11-06 (`live-fit.md` M1): 63 แถวใน 50 doc 32 ร้าน ปี 2022-2023 · 16 doc มีแถวทั้ง 2 รูปปนกัน
 * ผู้อ่านใหม่ (`logic:member.js`) หาแถวด้วย `yearMonth` ⇒ ข้ามแถวรูปนี้และคัดลอกกลับไว้ตามเดิม
 */
export const MemberBoughtLegacyYear = z
  .object({
    year: z.string().regex(/^\d{4}$/, "ต้องเป็น YYYY").describe("ปีที่บวกยอด"),
    totalBuy: LegacyNumber.describe("ยอดซื้อสะสมของปี"),
    paid: z.boolean().describe("❓ ไม่รู้ความหมาย · เขียน false ตอนสร้าง"),
  })
  .passthrough();

/** แถว `bought[]` ทุกรุ่น */
export const MemberBought = z.union([MemberBoughtMonth, MemberBoughtLegacyYear]);

/** §1.3 `member.creditArray[]` · หนี้เงินเซ็นรายบิล */
export const MemberCreditEntry = z
  .object({
    receiptNumber: z.string().describe("§1.3 · เลขใบเสร็จ · ออนไลน์กับซิงก์ต่างกัน (M-07)"),
    billId: z.string().describe("§1.3 · doc id ของ `bill` · ยกเลิกบิลลบแถวด้วยค่านี้"),
    totalCredit: LegacyNumber.describe("§1.3 · ยอดเซ็นตั้งต้นของบิล"),
    remainCredit: LegacyNumber.describe("§1.3 · ยอดค้าง · แถวที่เหลือ <=0 ถูกกรองออกตอนรับชำระ"),
    timestamp: FirestoreTime.describe("§1.3 · เวลาเซ็นจากนาฬิกาเครื่อง · ทางซิงก์เป็นเวลาซิงก์"),
    receiptUUID: z
      .string()
      .optional()
      .describe(
        "ไม่อยู่ใน §1 · ของใหม่ให้ก้อน 4 (`sale.create`) ผูกแถวหนี้กับการขาย 1 ครั้ง เท่ากับ doc id ของ `receiptGuard` · แถวเก่าไม่มี",
      ),
    soldAt: FirestoreTime.optional().describe(
      "ไม่อยู่ใน §1 · ของใหม่ให้ก้อน 4 เวลาขายจริงของบิลออฟไลน์ เพราะ `timestamp` ทางซิงก์เป็นเวลาซิงก์ · แถวเก่าไม่มี",
    ),
  })
  .passthrough();

export const Member = z
  .object({
    name: z
      .union([z.string(), LegacyNumber, z.boolean()])
      .optional()
      .describe("§1.1 แถว 1 · ชื่อลูกค้า · แอปเป็น string ไม่ว่าง · เว็บอัปไฟล์ได้ number boolean หรือ '' ตามเซลล์ (SMB-06)"),
    tel: z
      .union([z.string(), LegacyNumber])
      .optional()
      .describe("§1.1 แถว 2 · เบอร์ · ไม่ unique · เว็บอัปไฟล์ได้ number (เสีย 0 นำหน้า)"),
    point: LegacyNumber.optional().describe(
      "§1.1 แถว 3 · แต้มคงเหลือ · ติดลบ ทศนิยม NaN ได้ · ❓ doc รุ่นเก่าอาจเป็นสตริง ยังไม่ได้วัด",
    ),
    credit: LegacyNumber.optional().describe(
      "§1.1 แถว 4 · เงินเซ็นยกยอดตั้งต้นและยอดจาก logic เก่า · รายการใหม่อยู่ `creditArray` · NaN ได้จากเว็บ",
    ),
    moreCredit: LegacyNumber.optional().describe("§1.1 แถว 5 · `0` จาก `initialMember` · ไม่มีจุดอ่าน (SMB-02)"),
    shopId: z.string().describe("§1.1 แถว 6 · **บังคับ** · ร้านเจ้าของ · query ทุกรายการ · ไม่มีจุดแก้หลังสร้าง"),
    landlordId: z.string().optional().describe("§1.1 แถว 7 · `''` เสมอ · ไม่มีจุดอ่าน (SMB-02)"),
    timestamp: FirestoreTime.optional().describe("§1.1 แถว 8 · วันสมัคร · `serverTimestamp` ทั้ง 2 ทางสร้าง"),
    bought: z
      .array(MemberBought)
      .optional()
      .describe("§1.1 แถว 9 · ยอดซื้อรายเดือน · ทางยกเลิกบิลไม่มี default ⇒ doc ที่ไม่มีค่านี้ยกเลิกบิลไม่ได้ (SMB-09)"),
    config: z.array(z.unknown()).optional().describe("§1.1 แถว 10 · `[]` เสมอ · ไม่มีจุดอ่าน (SMB-02)"),
    uid: z.string().optional().describe("§1.1 แถว 11 · `''` · คอมเมนต์ว่าเชื่อม LINE OA · ไม่มีจุดอ่านหรือแก้ (SMB-02)"),
    providerId: z.string().optional().describe("§1.1 แถว 12 · `''` · คอมเมนต์ว่าเชื่อมหลายสาขา · ไม่มีจุดอ่าน (SMB-02)"),
    imageId: z.string().optional().describe("§1.1 แถว 13 · `''` เสมอ · อ่านในรายการค้นหา แต่ไม่มีทางใส่ค่า (SMB-02)"),
    letter: z
      .string()
      .optional()
      .describe("§1.1 แถว 14 · ชี้ `memberList/{letter+shopId}` · แอป 1 ตัว เว็บ 2 ตัว · ❓ doc เก่าไม่มี โค้ดรองรับ"),
    lastTime: FirestoreTime.optional().describe("§1.1 แถว 15 · เกิดทีหลัง · เวลาซื้อล่าสุดจากนาฬิกาเครื่อง · ยกเลิกบิลไม่ย้อน (SMB-08)"),
    creditArray: z
      .array(MemberCreditEntry)
      .optional()
      .describe("§1.1 แถว 16 · เกิดทีหลัง · หนี้เงินเซ็นรายบิล"),
  })
  .passthrough();

export type MemberBought = z.infer<typeof MemberBought>;
export type MemberCreditEntry = z.infer<typeof MemberCreditEntry>;
export type Member = z.infer<typeof Member>;

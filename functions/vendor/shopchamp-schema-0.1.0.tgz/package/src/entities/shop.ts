import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `shop/{id}` — ร้าน 1 doc ต่อ 1 ร้าน (ตัวตน · พนักงาน · จุดขาย · ตั้งค่าขาย ใบเสร็จ แต้ม แพ็กเกจ)
 * ที่มา: `lanes/dev/source/schema/shop.md` §3 ตาราง field (ระดับบน 66 ตัว · 3.1-3.12) และ §3.13 รูปข้อมูลซ้อน
 *   (§1 ของไฟล์นี้เป็นป้ายและเครื่องบังคับ ตารางจริงอยู่ §3)
 *
 * - รูปตาม **ช่อง "ฐาน"** ของ §3 ไม่ใช่ช่องเขียนหรือ cache · แอปเก่า 3 เว็บ และ care ยังเขียน doc นี้ตรงอยู่ (§7 · 45 จุด)
 *   ⇒ `.passthrough()` ทุกชั้น เก็บ field ที่ไม่รู้จักไว้ ไม่ตัดทิ้ง
 * - บังคับแค่ `shopId` · เป็น field เดียวที่ทุกทางสร้างจริงใส่ (C-NEW · C-ADD · C-OLD §5) และทุก query ใช้ (§8)
 *   field "บังคับ" ตัวอื่นใน §3 (`name` `tel` `humanResource` `POSs` `vip`) เป็น optional เพราะร้านรุ่นเก่า C-OLD
 *   ยังเป็น ❓ (§5) และแอปเติมค่าตั้งต้นให้ที่ `handleShop` · doc ผีจาก C-CLONE ที่มีแค่ `smartCategory` (S10) ถูกปัดโดยตั้งใจ
 * - ชนิดปนที่โค้ดเขียนจริงรับไว้ (`scShopId` `''` · field ตัวเลขรับ `number|string` ตามแผนก้อน 1 · ตัวเลขจาก `twoDigitNumber` เป็นสตริง · id ช่องจ่าย number หรือ uuid)
 * - ❓ field ที่ไม่มีคนเขียนใน 6 repo (§3.12 · D2) รับแบบหลวม เพราะยังไม่เคยเห็นค่าในฐาน
 * - ข้อมูลลับใน doc (`humanResource[].password` ข้อความล้วน · `line.channelAccessToken`) รับไว้ตามที่มี ไม่ใช่การยอมรับว่าถูก (S1)
 *   ⇒ API ใหม่ห้ามคืน doc นี้ตรง ๆ (`api-pattern-from-sibling.md` `req.shopData` ดิบ ห้ามคืน)
 * - doc id ไม่อยู่ใน schema นี้ · `id` ข้างในเป็นสำเนา · ร้านเก่า `shopId` ≠ doc id ได้ (S5)
 * - ไม่มี field ใหม่ของก้อน 4 (`receiptUUID` `soldAt` `offline`) เพราะเป็นของบิล · ไม่มี `offlineEnable` เพราะ Pack เคาะ
 *   2026-11-06 ขายออฟไลน์ได้ทุกร้าน ไม่มีสวิตช์
 */

/** ตัวเลขที่โค้ดบางทางเขียนเป็นสตริงจากช่องกรอก (`twoDigitNumber` คืนสตริง `app:Utility/function.js:1392`) */
const NumOrStr = z.union([z.number(), z.string()]);

// ---------- §3.13 รูปข้อมูลซ้อน ----------

/** `humanResource[]` · รวม 4 ทางเขียน (NS · ค้นเบอร์ · จอพนักงาน · ร้านเก่าที่ LoadingScreen สร้าง) */
export const ShopHumanResource = z
  .object({
    id: z.string().describe("profile id ของพนักงาน · ทุกทางเขียนใส่ · ตัวที่ server ใช้หาผู้เรียก"),
    position: z.array(z.string()).optional().describe("id ตำแหน่ง เช่น `['001']` · ค้นเบอร์ได้ `[]`"),
    status: z
      .string()
      .optional()
      .describe("`active` · ร้านเก่าที่ LoadingScreen สร้างไม่มี field นี้ (S4)"),
    name: z.string().optional(),
    imageId: z.string().optional().describe("URL รูป หรือ `''`"),
    email: z.string().optional(),
    tel: z.string().optional(),
    rights: z.array(z.string()).optional().describe("รหัสสิทธิ์ · ร้านเก่าไม่มี (S4)"),
    password: z.string().optional().describe("รหัสแคชเชียร์ **ข้อความล้วน** (S1 · ห้ามคืนออก API)"),
    owner: z.boolean().optional().describe("จอพนักงานเติมตอนเปิด แล้วเขียนกลับ `app:screens/StaffScreen.js:160`"),
  })
  .passthrough();

/** `position[]` ตำแหน่งตั้งต้น (แถว 18) */
export const ShopPosition = z
  .object({
    id: z.string(),
    name: z.string().optional(),
    rights: z.array(z.string()).optional(),
  })
  .passthrough();

const BluetoothSlot = z
  .object({ address: z.string().optional(), name: z.string().optional() })
  .passthrough();

/** `POSs[]` จุดขาย (แถว 29) · `id` `shiftId` ขาดได้จริง (`print.md` PR-003) */
export const ShopPos = z
  .object({
    id: z.string().optional().describe("uuid จุดขาย · ขาดได้ (PR-003)"),
    name: z.string().optional(),
    shiftId: z.string().optional().describe("กะปัจจุบันของจุดขาย · ขาดได้ (PR-003)"),
    uniqueId: z.string().optional().describe("เครื่องที่ผูก · `''` = ว่าง"),
    deviceName: z.string().optional(),
    posNumber: NumOrStr.optional().describe("`''` ตั้งต้น"),
    printerType: z.string().optional().describe("`bluetooth` ฯลฯ"),
    printerSize: NumOrStr.optional().describe("`'58'` ตั้งต้น"),
    printerBluetooth: z
      .object({ android: BluetoothSlot.optional(), ios: BluetoothSlot.optional() })
      .passthrough()
      .optional(),
    printerEthernet: z.string().optional().describe("IP หรือ `''`"),
    printerUsb: z
      .object({
        vendor_id: NumOrStr.optional(),
        product_id: NumOrStr.optional(),
        device_name: z.string().optional(),
      })
      .passthrough()
      .optional(),
    drawer: z.unknown().optional().describe("ค่ารุ่นเก่า อ่านตอนย้ายโครงเท่านั้น `app:screens/HomeScreen.js:470`"),
    printerId: z.unknown().optional().describe("ค่ารุ่นเก่า อ่านตอนย้ายโครงเท่านั้น `app:screens/HomeScreen.js:378`"),
  })
  .passthrough();

/** `shopchampPayment[]` ช่องทางชำระ (แถว 32) */
export const ShopPaymentChannel = z
  .object({
    id: NumOrStr.describe("1-4 ช่องตั้งต้น หรือ uuid ช่องที่ร้านเพิ่ม"),
    name: z.string(),
    mortal: z.boolean().optional().describe("`true` = ลบไม่ได้"),
    status: z.boolean().optional().describe("เปิดใช้ช่องนี้"),
  })
  .passthrough();

const ImageToggle = z
  .object({ imageId: z.string().optional(), status: z.boolean().optional() })
  .passthrough();

/** `receipt` หัวท้ายใบเสร็จ (แถว 39) · ร้านทดสอบมีแค่ 4 คีย์ ⇒ ทุกตัว optional */
export const ShopReceipt = z
  .object({
    footer: z.string().optional(),
    footerImage: ImageToggle.optional(),
    header: z.string().optional().describe("ค่าตั้งต้นเป็นบริษัทสมมติ (S13)"),
    headerImage: ImageToggle.optional().describe("ค่าตั้งต้น status ต่างกันระหว่าง 2 ไฟล์ (C3)"),
    headerStatus: z.boolean().optional(),
    footerStatus: z.boolean().optional(),
    promptpayId: z.string().optional(),
    promptpayStatus: z.boolean().optional(),
    price: z.unknown().optional().describe("❓ §3.13 ลงชื่อไว้ ไม่ได้ลงชนิด"),
    bottomEnable: z.boolean().optional(),
    thankText: z.string().optional(),
    note: z.string().optional(),
  })
  .passthrough();

/** `tax` ข้อมูลออกใบกำกับของร้าน (แถว 37) และสมาชิกของ `taxCustomer[]` (แถว 38) */
export const ShopTax = z
  .object({
    name: z.string().optional(),
    tel: z.string().optional(),
    address: z.string().optional(),
    taxNumber: z.string().optional(),
    branch: z.string().optional(),
    fax: z.string().optional(),
    status: z.boolean().optional(),
    headquarter: z.boolean().optional(),
  })
  .passthrough();

export const ShopTaxCustomer = ShopTax.extend({ id: z.string().describe("uuid") }).passthrough();

/** สมาชิกระดับลึกของ `smartCategory` / `categoryExpense` */
export const ShopCategoryItem = z
  .object({
    id: z.string(),
    name: NumOrStr.optional().describe(
      "ชื่อหมวด · ตัวเลขได้: พบ 1 ร้าน 34 หมวด 2025 (`live-fit.md` P1 · ❓ ยังไม่ได้ไล่ทางเขียน) · ผู้อ่านแสดงผลต้อง `String()` เอง",
    ),
    level: NumOrStr.optional(),
    aboveId: z.array(z.string()).optional().describe("id หมวดระดับบน"),
  })
  .passthrough();

/** แถวต่อระดับของ `smartCategory` / `categoryExpense` (แถว 41-42) */
export const ShopCategoryLevel = z
  .object({
    level: NumOrStr.optional(),
    value: z.array(ShopCategoryItem),
  })
  .passthrough();

const IdValue = z.object({ id: NumOrStr, value: NumOrStr }).passthrough();

/** `smartPoint` สูตรแต้ม (แถว 43) · ค่าผ่าน `twoDigitNumber` เป็นสตริงได้ ผู้อ่านครอบ `Number()` */
export const ShopSmartPoint = z
  .object({
    rate: NumOrStr.optional().describe("กี่บาทได้แต้ม · `0`/`''` อ่านได้ แต่สูตรแต้มต้องกันหารศูนย์เอง (member-point-credit:455)"),
    point: NumOrStr.optional(),
    date: z.array(IdValue).optional().describe("แต้มพิเศษรายวันที่"),
    days: z.array(IdValue).optional().describe("แต้มพิเศษรายวันในสัปดาห์"),
    memberTier: z.array(z.unknown()).optional().describe("ดู `member.md` MB-106"),
    expire: z
      .object({
        status: z.boolean().optional(),
        duration: z.string().optional(),
        period: NumOrStr.optional(),
      })
      .passthrough()
      .optional(),
  })
  .passthrough();

/** `smartCoupon[]` (แถว 45) */
export const ShopCoupon = z
  .object({
    id: NumOrStr,
    name: z.string().optional(),
    point: NumOrStr.optional(),
    status: z.boolean().optional(),
    value: NumOrStr.optional(),
    imageId: z.string().optional().describe("URL"),
  })
  .passthrough();

/** `smartReward[]` (แถว 46) */
export const ShopReward = z
  .object({
    id: z.string().describe("uuid"),
    imageId: z.string().optional(),
    point: NumOrStr.optional(),
    timestamp: FirestoreTime.optional(),
    status: z.boolean().optional(),
  })
  .passthrough();

/** `vip[]` แพ็กเกจ (แถว 50) */
export const ShopVip = z
  .object({
    type: z.string().describe("`premium` `staff` `member` `warehouse` `delivery` หรือชนิดที่ care เติม"),
    expire: FirestoreTime.describe("วันหมดอายุ · ตรวจฝั่งเครื่อง (S1)"),
  })
  .passthrough();

/** `line` (แถว 56) · token อยู่ใน doc ร้าน (S1) */
export const ShopLine = z
  .object({
    liff: z.string().optional(),
    channelAccessToken: z.string().optional().describe("ห้ามคืนออก API (S1)"),
    userId: z.string().optional(),
  })
  .passthrough();

export const ShopLineUser = z
  .object({ name: z.string().optional(), userId: z.string() })
  .passthrough();

/** `soundPlayers[]` (แถว 59) */
export const ShopSoundPlayer = z
  .object({
    mainStatus: z.boolean().optional(),
    status: z.boolean().optional(),
    sound: z.string().optional(),
    name: z.string().optional(),
  })
  .passthrough();

/** `receiptPay` รุ่นเก่า (แถว 34) · ไม่มีคนเขียน ❓ ชนิดในฐาน */
export const ShopReceiptPay = z
  .object({
    status: z.unknown().optional(),
    paymentId: z.unknown().optional(),
    footer: z.unknown().optional(),
  })
  .passthrough();

const IdList = z.array(z.string()).describe("array ของ profile id");

// ---------- เอกสาร ----------

export const Shop = z
  .object({
    // 3.1 ตัวตนร้าน (1-16)
    shopId: z.string().describe("แถว 1 · รหัสร้านที่ doc อื่นอ้าง · ร้านใหม่เท่า doc id · ร้านเก่าเป็น uid เจ้าของได้ (S5)"),
    id: z.string().optional().describe("แถว 2 · สำเนา doc id · เฉพาะ NS"),
    scShopId: NumOrStr.optional().describe(
      "แถว 3 · เลขร้านลำดับรวม · `''` ค่าตั้งต้น (C1) · รับสตริงตามแบบ field ตัวเลข (`architecture-plan.md` ก้อน 1) ผู้อ่านครอบ `Number()`",
    ),
    name: z.string().optional().describe("แถว 4 · ชื่อร้าน"),
    tel: z.string().optional().describe("แถว 5 · เบอร์ร้าน ใช้ค้นร้าน"),
    address: z.string().optional().describe("แถว 6"),
    smartAddress: z.array(NumOrStr).optional().describe("แถว 7 · [จังหวัด อำเภอ ตำบล zipcode]"),
    destinationAddress: z.array(z.unknown()).optional().describe("แถว 8 · ❓ ความหมาย · พบแต่ `[]`"),
    logo: z.string().optional().describe("แถว 9 · URL หรือ `''`"),
    imageUrl: z.array(z.unknown()).optional().describe("แถว 10 · รูปรุ่นเก่า ❓ ชนิดสมาชิก"),
    branch: NumOrStr.optional().describe("แถว 11 · ❓ จำนวนสาขา"),
    dateTime: FirestoreTime.optional().describe("แถว 12 · วันสร้างร้าน"),
    ownerName: z.string().optional().describe("แถว 13 · รุ่นเก่า ไม่มีคนเขียน ❓ ในฐาน"),
    email: z.string().optional().describe("แถว 14 · รุ่นเก่า ไม่มีคนเขียน ❓ ในฐาน"),
    franchiseId: z.string().optional().describe("แถว 15 · สาขาของแฟรนไชส์ไหน · ลงบิลทุกใบ · ไม่มี = `''` (`app:screens/CheckoutScreen.js:143`)"),
    wholesaleId: z.string().optional().describe("แถว 16"),
    // 3.2 พนักงานและสิทธิ์ (17-19)
    humanResource: z.array(ShopHumanResource).optional().describe("แถว 17 · ตัว index 0 เข้าได้แม้แพ็กเกจหมด"),
    position: z.array(ShopPosition).optional().describe("แถว 18"),
    attendance: z.array(z.unknown()).optional().describe("แถว 19 · ❓ รุ่นเก่า"),
    // 3.3 ผู้รับ push (20-28)
    notiImport: IdList.optional().describe("แถว 20"),
    notiShift: IdList.optional().describe("แถว 21 · ลบพนักงานแล้วไม่ถูกตัด (S2)"),
    notiStaff: IdList.optional().describe("แถว 22"),
    notiStock: IdList.optional().describe("แถว 23"),
    notiSummary: IdList.optional().describe("แถว 24"),
    notiCancelBill: IdList.optional().describe("แถว 25 · ลบพนักงานแล้วไม่ถูกตัด (S2)"),
    notiCheckin: IdList.optional().describe("แถว 26"),
    notiCredit: IdList.optional().describe("แถว 27"),
    notiRequisition: IdList.optional().describe("แถว 28"),
    // 3.4 จุดขายและกะ (29-31)
    POSs: z.array(ShopPos).optional().describe("แถว 29 · จุดขาย"),
    printers: z.array(z.unknown()).optional().describe("แถว 30 · เครื่องพิมพ์รุ่นเก่า"),
    shift: z.boolean().optional().describe("แถว 31 · เปิดระบบกะ"),
    // 3.5 เงินและใบเสร็จ (32-40)
    shopchampPayment: z.array(ShopPaymentChannel).optional().describe("แถว 32"),
    payment: z.array(z.unknown()).optional().describe("แถว 33 · รุ่นเก่า ไม่ว่าง = ย้ายโครง"),
    receiptPay: ShopReceiptPay.optional().describe("แถว 34 · รุ่นเก่า ไม่มีคนเขียน"),
    rounding: z
      .object({ status: z.boolean().optional(), type: z.enum(["up", "down", "half"]).optional() })
      .passthrough()
      .optional()
      .describe("แถว 35 · ปัดเศษยอดบิล · doc ไม่มี field = แอปเติม `{status:false, type:'down'}` (`app:config/initialShop.js:140`)"),
    shopchampVat: z
      .object({
        status: z.boolean().optional(),
        value: z
          .object({
            type: z.enum(["Include", "Exclude"]).optional().describe("ไม่ใช่ `Include` = คิดแบบแยก `app:screens/CheckoutScreen.js:406`"),
            amount: NumOrStr.optional().describe(
              "อัตรา % · แอปเขียนเป็นสตริง (`\"7\"`) แต่รับตัวเลขด้วย · สูตรเดิมครอบ `Number()` ⇒ `''`/ข้อความ = 0/NaN ต้องกันที่ logic ไม่ใช่ที่นี่",
            ),
          })
          .passthrough()
          .optional(),
      })
      .passthrough()
      .optional()
      .describe("แถว 36 · doc ไม่มี field = แอปเติม `{status:true, value:{type:'Include', amount:'7'}}` (`app:config/initialShop.js:146`)"),
    tax: ShopTax.optional().describe("แถว 37"),
    taxCustomer: z.array(ShopTaxCustomer).optional().describe("แถว 38"),
    receipt: ShopReceipt.optional().describe(
      "แถว 39 · แอปรวมตื้นกับ `app:config/initialReceipt.js` ทุกครั้ง (`app:redux/shopSlice.js:59`) · `price` `bottomEnable` `thankText` ไม่มีในค่าตั้งต้น จอคิดเงินใช้ `false` `false` `'ขอบคุณที่อุดหนุนนะคะ'` (`app:screens/CheckoutScreen.js:130`)",
    ),
    receiptPattern: z.enum(["month", "day"]).optional().describe("แถว 40 · เลือก `billId` หรือ `billDayId` · doc ไม่มี field = `month` (`app:config/initialShop.js:155` · `app:screens/CheckoutScreen.js:142`)"),
    amendBill: z
      .boolean()
      .optional()
      .describe("ใหม่ (ก้อน 4) · สวิตช์รายร้าน \"เปิดให้แก้บิล\" · ไม่มี = ปิด (Pack อนุญาต 2026-11-06 ข้อ ⑤) · ใช้ได้เมื่อมีแพ็กเกจ premium ด้วย"),
    // 3.6 หมวด (41-42)
    smartCategory: z.array(ShopCategoryLevel).optional().describe("แถว 41 · `stock.category` อ้าง id ในนี้"),
    categoryExpense: z.array(ShopCategoryLevel).optional().describe("แถว 42"),
    // 3.7 สมาชิกและแต้ม (43-48)
    smartPoint: ShopSmartPoint.optional().describe("แถว 43"),
    creditPoint: z.boolean().optional().describe("แถว 44 · ขายเงินเซ็นแล้วให้แต้มไหม · สูตรเดิมเช็กด้วยความจริง ⇒ สตริง `'false'` = เปิด ต้องปัด"),
    smartCoupon: z.array(ShopCoupon).optional().describe("แถว 45"),
    smartReward: z.array(ShopReward).optional().describe("แถว 46"),
    totalMember: NumOrStr.optional().describe("แถว 47 · ตัวนับสมาชิก"),
    providerId: z.string().optional().describe("แถว 48 · ไม่มีคนเขียน ❓ ในฐาน"),
    // 3.8 เวลาตัดรอบ (49)
    cutOff: FirestoreTime.optional().describe("แถว 49 · ใช้ชั่วโมงนาที ❓"),
    // 3.9 แพ็กเกจและโควตา (50-55)
    vip: z.array(ShopVip).optional().describe("แถว 50"),
    IsVip: z.boolean().optional().describe("แถว 51 · care ตั้ง"),
    lossVip: z.boolean().optional().describe("แถว 52 · care ตั้ง"),
    currentPackage: z.array(NumOrStr).optional().describe("แถว 53 · ประวัติ package id"),
    imageLimit: NumOrStr.optional().describe("แถว 54 · โควตารูปฟรี"),
    imageMore: NumOrStr.optional().describe("แถว 55 · โควตารูปที่ซื้อเพิ่ม"),
    // 3.10 LINE (56-58)
    line: ShopLine.optional().describe("แถว 56"),
    lineUsers: z.array(ShopLineUser).optional().describe("แถว 57"),
    lineNoti: z.record(z.string(), z.array(z.string())).optional().describe("แถว 58 · key → array userId"),
    // 3.11 เสียงและจอลูกค้า (59-61)
    soundPlayers: z.array(ShopSoundPlayer).optional().describe("แถว 59"),
    soundStatus: z.boolean().optional().describe("แถว 60"),
    customerAds: z.array(z.string()).optional().describe("แถว 61 · URL"),
    // 3.12 มีแต่ฝั่งอ่าน ❓ ชนิดในฐาน (62-66)
    smartTable: z.array(z.unknown()).optional().describe("แถว 62 · ❓ โต๊ะ ร้านอาหารรุ่นเก่า (S6)"),
    channel: z.unknown().optional().describe("แถว 63 · ❓ ชนิดไม่รู้"),
    smartOption: z.array(z.unknown()).optional().describe("แถว 64 · ❓"),
    yourCode: z.string().optional().describe("แถว 65 · ❓"),
    createdDate: FirestoreTime.optional().describe("แถว 66 · ❓ คนละตัวกับ `dateTime`"),
  })
  .passthrough();

export type Shop = z.infer<typeof Shop>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `shift/{shiftId}` — เอกสารกะประจำจุดชำระเงิน 1 ใบต่อ 1 จุด (ไม่ใช่ 1 ใบต่อรอบ)
 * ที่มา: `lanes/dev/source/schema/shift.md` §1.1 (23 field) · §1.2 (`duringShift[]` 6 field) · §2 (ช่องบังคับ)
 *
 * - เปิดกะ/ปิดกะ `update` เอกสารเดิม · ปิดกะแค่ตั้ง `status:false` และ `duringShift:[]` ⇒ ค่า `open*` ของรอบก่อนค้างอยู่ (§A ข้อ 2-3)
 * - แอปเก่ายังเขียน collection นี้ตรงอยู่ ⇒ `.passthrough()` เก็บ field ที่ไม่รู้จักไว้
 * - ช่องที่ required = ช่องที่ทุกรุ่นของ `initialShift` มี: `shopId` `openTime` `duringShift`
 *   `status` `lastShiftDate` `shiftCount` เป็น "บังคับ" ใน §2 ของรุ่นปัจจุบัน แต่เพิ่งเข้า `initialShift` ที่ commit แอป `1789e064` (2025-03-11)
 *   ⇒ doc ที่สร้างก่อนนั้น (`b447959d:src/config/initialShift.js` 17 key · `POSScreen.js:54` `add({...initialShift,shopId,posId})`)
 *   และยังไม่เคยเปิดกะด้วยแอปรุ่นใหม่ ไม่มี 3 ช่องนี้ ⇒ optional · ผู้อ่านใช้ค่าตั้งต้น `false` `'20230909'` `0`
 *   แบบที่ server เดิม merge `{ ...initialShift, ...doc }` (`srv:apis/shift.js:242`) · ❓ จำนวน doc แบบนี้ในฐานจริงยังไม่ได้นับ
 *   ช่อง "มีตั้งแต่เกิด" กับ "ไม่บังคับ" = optional เหตุเดียวกัน
 * - เงินที่มาจากช่องกรอกเก็บเป็น string จาก `twoDigitNumber` และเป็น `''` ได้ (§9 · SB-17) ⇒ doc ไม่บังคับรูปตัวเลข
 *   รูปเข้มอยู่ที่คำขอ API (`requests/shift.ts`) ไม่ใช่ที่นี่ เพราะ doc เก่าต้องอ่านได้
 * - doc id = `shiftId` ที่ `shop.POSs[].shiftId` ชี้มา · ไม่อยู่ใน schema นี้ เพราะไม่ใช่ field ของเอกสาร
 */

/** §1.1 แถว 8 · `''` ตอนสร้างจาก `initialShift` · Timestamp หลังเปิดกะครั้งแรก */
const ShiftOpenTime = z.union([z.literal(""), FirestoreTime]);

/**
 * §1.2 · สมาชิกของ `duringShift[]` · ประกอบที่ `app:screens/ShiftScreen.js:229-237`
 * เขียนใน transaction ที่อ่านจากฐาน ⇒ `timestamp` ในฐานเป็น Timestamp (รูป map `_seconds` เกิดแค่ใน `shiftHistory` · SB-07)
 */
export const ShiftDuringEntry = z
  .object({
    type: z
      .union([z.literal(1), z.literal(2), z.literal("เติมเงิน"), z.literal("ถอนเงิน")])
      .describe(
        "§1.2 · 1 นำเข้า · 2 นำออก (`Modal_DuringShift.js:61,64`) · แอปรุ่นปี 2023 เขียนข้อความ `'เติมเงิน'` `'ถอนเงิน'` (`b447959d:src/screens/ShiftScreen.js:112,181,193`) ค้างอยู่ได้ใน doc ที่ยังเปิดกะจากแอปรุ่นนั้น",
      ),
    amount: z
      .string()
      .describe("§1.2 · ยอดเป็น string จาก `twoDigitNumber` · `''` ได้ (SB-17)"),
    comment: z.string().describe("§1.2 · เหตุผล · `''` ได้"),
    staff: z.string().describe("§1.2 · ชื่อพนักงานที่บันทึก · แอปรุ่นปี 2023 เก็บ id พนักงานในช่องนี้"),
    staffId: z
      .string()
      .optional()
      .describe("§1.2 · id พนักงาน · ทางเขียนปัจจุบันใส่เสมอ แต่ไม่พบคนอ่าน ⇒ optional เผื่อแอปรุ่นเก่า"),
    timestamp: FirestoreTime.describe("§1.2 · `new Date()` ของเครื่องที่กด"),
    entryId: z
      .string()
      .min(1)
      .optional()
      .describe(
        "ไม่อยู่ใน §1.2 · ของใหม่ให้ก้อน 4 (`shift.manage` op during) ใส่ id ต่อรายการเพื่อกันต่อท้ายซ้ำเมื่อ transaction รันซ้ำ (SC-46) · รายการเก่าไม่มี",
      ),
  })
  .passthrough();

export const Shift = z
  .object({
    // ---- บังคับ (§2) ----
    shopId: z.string().min(1).describe("§1.1 แถว 1 · ร้าน · ถูกคัดลอกเข้าประวัติแล้วเป็นตัว query ของ `shiftHistory`"),
    openTime: ShiftOpenTime.describe("§1.1 แถว 8 · `''` ยังไม่เคยเปิด · Timestamp เวลาเครื่องตอนเปิดกะ = ขอบล่างของบิลรอบนี้ (SB-13)"),
    duringShift: z
      .array(ShiftDuringEntry)
      .describe("§1.1 แถว 11 · เงินเข้าออกระหว่างกะ · ล้างเป็น `[]` ตอนปิด · `ShiftScreen.js:228` destructure ตรง ขาดไม่ได้"),

    // ---- บังคับใน §2 ของรุ่นปัจจุบัน แต่ doc ก่อน 2025-03-11 ไม่มี ⇒ optional (หัวไฟล์) ----
    status: z
      .boolean()
      .optional()
      .describe("§1.1 แถว 4 · เปิดกะอยู่ไหม · ไม่มี = `false` · ประตูเข้าจอขาย (`HomeScreen.js:677`) และเงื่อนไขรวมบิล (`srv:apis/shift.js:246`)"),
    lastShiftDate: z
      .string()
      .regex(/^\d{8}$/, { message: "lastShiftDate ต้องเป็น YYYYMMDD" })
      .optional()
      .describe("§1.1 แถว 9 · วันเปิดกะ `YYYYMMDD` ตามเครื่อง (`stringYMDHMS3` เติม 0 ครบ) · ไม่มี = `20230909` · ตัว query ของประวัติ"),
    shiftCount: z
      .number()
      .int()
      .nonnegative()
      .optional()
      .describe("§1.1 แถว 10 · เลขกะของวันเปิดกะ ต่อจุดชำระเงิน · ไม่มี = 0"),

    // ---- มีตั้งแต่เกิด / ไม่บังคับ (§2) ⇒ optional ----
    posId: z.string().optional().describe("§1.1 แถว 2 · จุดชำระเงินเจ้าของเอกสาร (uuid) · ไม่พบคนอ่าน"),
    id: z.string().optional().describe("§1.1 แถว 3 · สำเนา doc id · ทาง C3 C4 ไม่ใส่ · server ทับด้วย doc id ทุกครั้ง"),
    openCash: z.string().optional().describe("§1.1 แถว 5 · เงินสดเปิดกะของรอบล่าสุด · string · `''` ได้ (SB-17)"),
    openName: z.string().optional().describe("§1.1 แถว 6 · ชื่อพนักงานเปิดกะ · เกิดครั้งแรกตอนเปิดกะ"),
    openId: z.string().optional().describe("§1.1 แถว 7 · id พนักงานเปิดกะ · ไม่มีค่า = server ไม่รวมบิล (SC-60)"),
    closeCash: z.string().optional().describe("§1.1 แถว 12 · `''` ตลอดอายุ · ค่าจริงอยู่ใน `shiftHistory`"),
    closeWithDraw: z.string().optional().describe("§1.1 แถว 13 · `''` ตลอดอายุ"),
    closeDiff: z.string().optional().describe("§1.1 แถว 14 · `''` ตลอดอายุ"),
    closeTime: z
      .union([z.literal(""), FirestoreTime])
      .optional()
      .describe("§1.1 แถว 15 · `''` ตลอดอายุ · รับเวลาไว้ด้วยเผื่อแอปรุ่นเก่า เพราะชื่อเป็นเวลา"),
    closeBy: z.string().optional().describe("§1.1 แถว 16 · `''` ไม่มีคนเขียนต่อ ไม่มีคนอ่าน"),
    closeComment: z.string().optional().describe("§1.1 แถว 17 · เหมือนแถว 16"),
    openBy: z.string().optional().describe("§1.1 แถว 18 · เหมือนแถว 16"),
    openComment: z.string().optional().describe("§1.1 แถว 19 · เหมือนแถว 16"),
    openDiff: z.string().optional().describe("§1.1 แถว 20 · เหมือนแถว 16"),
    openWithDraw: z.string().optional().describe("§1.1 แถว 21 · เหมือนแถว 16"),
    currentCash: z.number().optional().describe("§1.1 แถว 22 · 0 ตลอดอายุ · ไม่ใช่เงินคาด (SB-08)"),
    receiptNumber: z.string().optional().describe("§1.1 แถว 23 · `''` ตลอดอายุ · คนละตัวกับ `bill.receiptNumber` · doc ก่อน 2025-03-11 ไม่มี"),
    openRequestId: z
      .string()
      .optional()
      .describe("ใหม่ (ก้อน 4 `shift.manage` op open) · กุญแจของคำขอเปิดรอบนี้ · ส่งซ้ำ = ผลเดิม (SC-23) · แอปเก่าไม่เขียน และเปิดทับได้โดยไม่ลบค่านี้"),
  })
  .passthrough();

export type Shift = z.infer<typeof Shift>;
export type ShiftDuringEntry = z.infer<typeof ShiftDuringEntry>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `shiftHistory/{autoId}` — ประวัติกะ 1 ใบต่อการปิดกะ 1 ครั้ง (DEV-0001 ก้อน 1)
 * ที่มา: `lanes/dev/source/schema/shiftHistory.md` §1 (บนสุด 42 · ซ้อน 27 · รวม 69 แถว)
 *
 * - ทางสร้างเดียว H1 `{...thisSummary, ...shift, closeCash, closeName, closeId, closeTime, closeWithDraw, closeDiff}`
 *   (`app:screens/ShiftScreen.js:272-281` · `batch.set` ที่ `:301`) ⇒ field บนสุด 40 ตัวมีตั้งแต่เกิด
 * - `thisCashier` `thisVat` ไม่บังคับ: แอปแทนก้อนสรุปทั้งก้อนด้วยของ server (`app:screens/ShiftScreen.js:144`)
 *   และ server รุ่นก่อนไม่ส่ง 2 ตัวนี้ (`shopcham_firebase_nodejs_2022` › `functions/apis/shift.js`:
 *   `58c4084` ไม่มีทั้งคู่ · `7961ced` 2025-03-11 เพิ่ม `thisCashier` · `0ffb915` 2025-04-27 เพิ่ม `thisVat`)
 *   ⇒ ประวัติกะที่ปิดตอน server รุ่นนั้นไม่มี 2 key นี้
 * - `ShiftHistory` = รูปปัจจุบัน (มีก้อนสรุป) ตรวจเข้มเหมือนเดิม · เอกสารรุ่นแรกไม่มีก้อนสรุปแยกไป `ShiftHistoryLegacy`
 *   อ่านทุกรุ่นใช้ `AnyShiftHistory` (เพิ่ม 2026-11-06 ตามตัวอย่างจริง `lanes/dev/source/chunk1-3-verify/live-fit.md` §3 H1 H2)
 * - แอปเก่ายังเขียน collection นี้ตรงอยู่ ⇒ `.passthrough()` ทั้งเอกสารและสมาชิกใน array
 *   (สมาชิก `thisPayment[]` กระจาย `...a` จาก `bill.payment[]` มา จึงมี key อื่นติดได้ · `srv:apis/shift.js:148`)
 * - doc id ไม่อยู่ใน schema · field `id` ในเอกสารคือ id ของ `shift` ต้นทาง ไม่ใช่ doc id (§1 แถว 1 · §9)
 * - รูปที่ §1 ระบุว่ามีได้มากกว่า 1 แบบ รับทุกแบบ: เวลา (Timestamp หรือ map) · id ช่องจ่าย (เลขหรือข้อความ)
 *   · `cashierId` เป็น `null` ได้ · `thisProduct[].thisQty` เป็นข้อความได้เมื่อ `qty` ในบิลเป็นข้อความ
 */

/**
 * เวลาที่ผ่าน `res.send` ของ server มาแล้วถูก `batch.set` ลงตรง ๆ
 * `Timestamp` ของ `@google-cloud/firestore@6.8.0` ไม่มี `toJSON` ⇒ กลายเป็น map ธรรมดา (§2 ทาง V1 V2 · SB-07)
 */
export const ShiftHistoryTimeMap = z.object({
  _seconds: z.number(),
  _nanoseconds: z.number(),
});

/** เวลาในเอกสารนี้: Timestamp/Date (ทาง V3 และ `closeTime`) หรือ map `{_seconds,_nanoseconds}` (ทาง V1 V2) */
export const ShiftHistoryTime = z.union([FirestoreTime, ShiftHistoryTimeMap]);

/** id ที่ §1 ระบุว่า "ตามต้นทาง" · เป็นเลขหรือข้อความได้ */
const LooseId = z.union([z.string(), z.number()]);

/** §1.5 `duringShift[]` (6 ตัว) · เงินเข้าออกระหว่างกะ · รูปปัจจุบัน type เป็นเลข */
export const ShiftHistoryDuringCurrent = z
  .object({
    type: z.union([z.literal(1), z.literal(2)]).describe("1 นำเงินเข้า · 2 นำเงินออก (`app:Modal/Modal_DuringShift.js:61-64`)"),
    amount: z.string().describe("จากช่องกรอก · `''` ได้ · ผู้อ่านแปลง `Number` ก่อนรวม (SB-17)"),
    comment: z.string().describe("เหตุผล · `''` ได้"),
    staff: z.string().describe("ชื่อพนักงาน (`app:screens/ShiftScreen.js:233`)"),
    staffId: z.string().describe("id พนักงาน · ไม่พบผู้อ่าน (`app:screens/ShiftScreen.js:234`)"),
    timestamp: ShiftHistoryTime.describe("Timestamp หรือ map ตามทาง §2 · เว็บเรียก `.toDate()` ตรงจึงพังกับ map (SB-07)"),
  })
  .passthrough();

/**
 * `duringShift[]` รูปแอปรุ่นแรก · `type` เป็นข้อความ `'เติมเงิน'` `'ถอนเงิน'` · ไม่มี `staffId` · `staff` เป็น id พนักงาน
 * ทางเขียน `shopcham_merchant_2025@1b20384a` › `src/screens/ShiftScreen.js:30` `:248` `:260`
 * ผู้อ่านเดิม `'เติมเงิน'` = บวก นอกนั้นลบ (`src/Utility/function.js:473-482`) ⇒ เทียบได้กับ type 1 / 2
 * วัด 2026-11-06 (`live-fit.md` H2): 400 แถวใน 109 ใบ · อยู่ในเอกสารรูปปัจจุบันด้วย 4 แถว 3 ใบ (กะที่เปิดด้วยแอปเก่า ปิดด้วยแอปใหม่ ❓)
 * ⚠️ `logic:shift.js` `duringSat` นับเฉพาะ `type === 1/2` ⇒ แถวรูปนี้ตกไปอยู่ `ignored`
 */
export const ShiftHistoryDuringLegacy = z
  .object({
    type: z.enum(["เติมเงิน", "ถอนเงิน"]).describe("เติมเงิน = นำเงินเข้า (เทียบ 1) · ถอนเงิน = นำเงินออก (เทียบ 2)"),
    amount: z.string().describe("จากช่องกรอก · ผู้อ่านแปลง `Number`"),
    comment: z.string(),
    staff: z.string().describe("id พนักงาน ไม่ใช่ชื่อ (`ShiftScreen.js:30` `staff:id`)"),
    staffId: z.string().optional().describe("รุ่นนี้ไม่เขียน · ไม่พบในตัวอย่างเลย"),
    timestamp: ShiftHistoryTime,
  })
  .passthrough();

/** แถวเงินเข้าออกระหว่างกะ ทุกรุ่น · แถวเลขต้องมี `staffId` เหมือนเดิม */
export const ShiftHistoryDuring = z.union([ShiftHistoryDuringCurrent, ShiftHistoryDuringLegacy]);

/** §1.4 `thisPayment[]` · รวมตาม `payment[].id` */
export const ShiftHistoryPayment = z
  .object({
    id: LooseId.describe("รหัสช่อง · เงินสดคือ 1 · รหัสเก่าเป็นข้อความ · ไม่มีช่องจ่ายได้ `'noId'`"),
    name: z.string().optional().describe("ชื่อช่อง · `undefined` ก่อนผ่าน JSON จึงหายได้"),
    amount: z.number().describe("ยอดหลังหักทอน"),
    qty: z.number().describe("จำนวนรายการ"),
    change: z.number().optional().describe("เงินทอนของบิลแรกในช่องนั้น ไม่ใช่ผลรวม · มาจาก `...a` จึงมีเฉพาะเมื่อบิลมี (SB-09)"),
  })
  .passthrough();

/** §1.4 `thisProduct[]` · รวมตาม `product[].id` */
export const ShiftHistoryProduct = z
  .object({
    id: LooseId.describe("ตาม `bill.product[].id`"),
    name: z.string().describe("ชื่อ ณ บิลแรกที่เจอ"),
    thisQty: z
      .union([z.number(), z.string()])
      .describe("จำนวนรวม · ข้อความได้เมื่อ `qty` ในบิลเป็นข้อความ เพราะ `+=` ต่อสตริง (§1 แถว 50 ❓)"),
    count: z.number().describe("จำนวนบรรทัดที่สั่ง"),
    thisTotalPrice: z.number().describe("ยอดรวม"),
  })
  .passthrough();

/** §1.4 `thisCategory[]` · รวมตามหมวดระดับแรก */
export const ShiftHistoryCategory = z
  .object({
    id: LooseId.describe("id หมวดระดับแรก · ไม่มีหมวดได้ข้อความ `'id'`"),
    name: z.string().describe("ชื่อตาม `smartCategory` · `No Category` · `UnKnow Category`"),
    thisQty: z.union([z.number(), z.string()]).describe("จำนวนรวม · เหตุเดียวกับ `thisProduct[].thisQty`"),
    thisTotalPrice: z.number().describe("ยอดรวม"),
  })
  .passthrough();

/** §1.4 `thisCampaign[]` · รวมตาม `campaign[].id` */
export const ShiftHistoryCampaign = z
  .object({
    id: LooseId.describe("ตามโปรโมชัน"),
    name: z.string().describe("ชื่อโปรโมชัน"),
    qty: z.number().describe("ครั้งที่ใช้"),
    discount: z.number().describe("ส่วนลดรวม"),
  })
  .passthrough();

/** §1.4 `thisCashier[]` · รวม `moneyMustPaid` ตาม `cashierId` */
export const ShiftHistoryCashier = z
  .object({
    cashierId: z.string().nullable().describe("`''` เมื่อบิลไม่มี field นี้ · `null` ได้ถ้าบิลเก็บเป็น `null` (§1 แถว 61 ❓)"),
    cashierName: z.string().describe("ชื่อแคชเชียร์ · `care:` อ่านผิดชื่อ (SB-15)"),
    amount: z.number().describe("ยอดรวม · `care:` อ่าน `totalNet` ไม่ตรง (SB-15)"),
  })
  .passthrough();

export const ShiftHistory = z
  .object({
    // §1.1 กลุ่ม ก: คัดลอกจาก `shift` state (19)
    id: z.string().describe("id ของเอกสาร `shift` ต้นทาง ≠ doc id · ผู้อ่านทุกตัวทับด้วย doc id (SB-16)"),
    shopId: z.string().describe("ตัว query ทุกทาง · มาจากเอกสาร `shift`"),
    posId: z.string().describe("จุดชำระเงิน (uuid) · ไม่มีผู้อ่าน แต่จำเป็นต่อการแยกเครื่อง (§9)"),
    status: z.boolean().describe("คัดลอกก่อนปิด จึงเป็น `true` ในทางปกติ · ไม่ใช่สถานะของประวัติ"),
    openCash: z.string().describe("เงินสดเปิดกะ · จากช่องกรอก · `''` ได้ (SB-17)"),
    openName: z.string().describe("ชื่อคนเปิดกะ"),
    openId: z.string().describe("id คนเปิดกะ"),
    lastShiftDate: z
      .string()
      .regex(/^\d{8}$/, "ต้องเป็น YYYYMMDD")
      .describe("วันเปิดกะ (ไม่ใช่วันปิด) ตามนาฬิกาเครื่อง · ตัว query ทุกทาง (SB-19 SB-24)"),
    shiftCount: z.number().describe("เลขกะของวันเปิดกะ ต่อจุดชำระเงิน"),
    openTime: ShiftHistoryTime.describe("เวลาเปิดกะ · Timestamp หรือ map ตามทาง §2 (SB-07)"),
    duringShift: z.array(ShiftHistoryDuring).describe("เงินเข้าออกระหว่างกะ เท่าที่อยู่ใน state ของเครื่องที่ปิด (SB-04 SB-20)"),
    currentCash: z.number().describe("`0` เสมอจากค่าตั้งต้น · **ไม่ใช่เงินคาด** (SB-08)"),
    closeBy: z.string().describe("ค่าตั้งต้นติดมา `''` · ไม่มีคนเขียนคนอ่าน"),
    closeComment: z.string().describe("ค่าตั้งต้นติดมา `''`"),
    openBy: z.string().describe("ค่าตั้งต้นติดมา `''`"),
    openComment: z.string().describe("ค่าตั้งต้นติดมา `''`"),
    openDiff: z.string().describe("ค่าตั้งต้นติดมา `''`"),
    openWithDraw: z.string().describe("ค่าตั้งต้นติดมา `''`"),
    receiptNumber: z.string().describe("ค่าตั้งต้นติดมา `''` · คนละตัวกับ `bill.receiptNumber`"),

    // §1.2 กลุ่ม ข: เขียนตอนปิดกะ (6)
    closeCash: z.string().describe("เงินที่นับได้ · จากช่องกรอก · `''` ได้ (SB-17)"),
    closeName: z.string().describe("ชื่อคนปิดกะ จาก `cart.staff`"),
    closeId: z.string().describe("id คนปิดกะ · ไม่มีผู้อ่าน แต่ใช้สอบย้อน (§9)"),
    closeTime: FirestoreTime.describe("เวลาปิดกะตามนาฬิกาเครื่อง · เว็บเรียงและ `care:` กรองช่วงวันด้วยค่านี้"),
    closeWithDraw: z.string().describe("เงินที่ถอนออก · จากช่องกรอก · `''` ได้ (SB-17)"),
    closeDiff: z.number().describe("`Number(closeCash) - currentCash` · คิดจากก้อนสรุปตอนเปิดจอ (SB-01)"),

    // §1.3 กลุ่ม ค: ก้อนสรุปจาก `manageSummary` (17) · ผ่าน JSON มาแล้ว · ทาง V3 เป็นศูนย์ทั้งก้อน
    thisPayment: z.array(ShiftHistoryPayment).describe("รวมตามช่องจ่าย"),
    thisProduct: z.array(ShiftHistoryProduct).describe("รวมตามสินค้า"),
    thisCategory: z.array(ShiftHistoryCategory).describe("รวมตามหมวดระดับแรก"),
    thisCampaign: z.array(ShiftHistoryCampaign).describe("รวมตามโปรโมชัน"),
    thisCashier: z.array(ShiftHistoryCashier).optional().describe("รวมตามแคชเชียร์ (SB-15) · server ก่อน `7961ced` ไม่ส่ง"),
    thisSelectedQty: z.number().describe("จำนวนบิลไม่ void"),
    thisVoidQty: z.number().describe("จำนวนบิล void"),
    saleRate: z.number().describe("`thisTotalNet / thisSelectedQty` · 0 ถ้าไม่มีบิล"),
    thisTotalNet: z.number().describe("ผลรวม `moneyMustPaid` (บิลไม่มีค่านี้นับ 999 · BX-07)"),
    thisTotalPrice: z.number().describe("ผลรวม `product[].totalPrice` · ไม่มีผู้อ่านจากประวัติ"),
    thisRounding: z.number().describe("ผลรวม `rounding` · ไม่มีผู้อ่านจากประวัติ"),
    thisTotalCash: z.number().describe("ยอดของ `thisPayment` ที่ `id===1` · ขาดแล้วเงินคาดเป็น `NaN`"),
    thisTotalChange: z.number().describe("ผลรวม `change` · ไม่มีผู้อ่านจากประวัติ"),
    totalManualDiscount: z.number().describe("ผลรวม `manualDiscount`"),
    totalPointDiscount: z.number().describe("ผลรวม `pointDiscount.value`"),
    totalProductDiscount: z.number().describe("ผลรวม `productDiscount`"),
    thisVat: z.number().optional().describe("ผลรวม `vatAmount` · server ก่อน `0ffb915` (2025-04-27) ไม่ส่ง"),

    // field ใหม่ (architecture-plan หัวข้อ 3 · ก้อน 4 #18) · เพิ่มอย่างเดียว เอกสารเดิมและแอปเก่าไม่มี
    lateSales: z
      .number()
      .optional()
      .describe("ใหม่ · ผลรวม `moneyMustPaid` ของบิลที่มาถึงหลังปิดกะ server บวกเข้ารอบนี้ใน transaction เดียวกับบิล (`sale.create` #18)"),
    lateBillQty: z.number().int().nonnegative().optional().describe("ใหม่ · จำนวนบิลที่มาถึงหลังปิดกะ (`sale.create` #18)"),
    closeRequestId: z
      .string()
      .optional()
      .describe("ใหม่ (ก้อน 4 `shift.manage` op close) · กุญแจของคำขอปิด · doc id ของประวัติที่ server ใหม่เขียน = `${shiftId}_${openTime ms}` กันปิดซ้ำ (SC-19 SC-23)"),
  })
  .passthrough();

/**
 * `shiftHistory` รุ่นแรก · **ไม่มีก้อนสรุป** (`this*` `total*` `saleRate` `receiptNumber`) ไม่มี `closeName` `closeId`
 * ทางเขียน: แอปก่อน `1789e064` (2025-03-11) ปิดกะด้วย `db.collection('shiftHistory').add(currentShift)`
 * (`shopcham_merchant_2025@1b20384a` › `src/redux/shiftSlice.js:37-46`) · `currentShift` = `initialShift` (`src/config/initialShift.js`)
 * + เอกสาร `shift` + `openDate` · `openBy` `closeBy` เป็น id พนักงาน
 * วัด 2026-11-06 (`live-fit.md` H1): 394 ใบ 152 ร้าน · 2024-01 ถึง 2025-06 เป็นหลัก (ลูกค้าอัปแอปช้ากว่าวัน commit)
 * · 9 ใบ 2025-10 ถึง 2026-10 มี `openId` `openName` `lastShiftDate` `shiftCount` แต่ยังไม่มีก้อนสรุป ❓ ยังไม่ได้ไล่ว่าแอปรุ่นไหน
 * - บังคับ = key ที่มีครบ 394/394 · ตัวแยกจากรูปปัจจุบัน = `thisPayment` ต้องไม่มี
 * - ผู้อ่านใหม่ต้องคำนวณยอดกะจากบิลเองเมื่อเป็นรูปนี้ · รายงานกะเก่าจะแสดงอย่างไร = Pack เคาะ (`live-fit.md` §5 H1)
 */
export const ShiftHistoryLegacy = z
  .object({
    thisPayment: z.never().optional().describe("ต้องไม่มี · ตัวแยกจาก `ShiftHistory`"),
    id: z.string().describe("id ของเอกสาร `shift` ต้นทาง"),
    shopId: z.string(),
    posId: z.string(),
    openDate: z.string().regex(/^\d{8}$/, "ต้องเป็น YYYYMMDD").describe("วันเปิดกะ · รุ่นนี้ใช้แทน `lastShiftDate`"),
    openTime: ShiftHistoryTime,
    openCash: z.string(),
    openBy: z.string().describe("id พนักงานที่เปิดกะ"),
    openComment: z.string(),
    openDiff: z.string(),
    openWithDraw: z.string(),
    duringShift: z.array(ShiftHistoryDuring),
    currentCash: z.number(),
    closeBy: z.string().describe("id พนักงานที่ปิดกะ"),
    closeCash: z.string(),
    closeComment: z.string(),
    closeTime: FirestoreTime,
    closeWithDraw: z.string(),
    closeDiff: z.number(),
    status: z.boolean().optional().describe("มี 15/394 ใบ"),
    openId: z.string().optional().describe("มี 9/394 ใบ (2025-10 ขึ้นไป)"),
    openName: z.string().optional(),
    lastShiftDate: z.string().regex(/^\d{8}$/, "ต้องเป็น YYYYMMDD").optional(),
    shiftCount: z.number().optional(),
  })
  .passthrough();

/** ประวัติกะทุกรุ่น · ลองรูปปัจจุบันก่อน · ผู้อ่านแยกด้วย `thisPayment` ว่ามีไหม */
export const AnyShiftHistory = z.union([ShiftHistory, ShiftHistoryLegacy]);

export type ShiftHistory = z.infer<typeof ShiftHistory>;
export type ShiftHistoryLegacy = z.infer<typeof ShiftHistoryLegacy>;
export type AnyShiftHistory = z.infer<typeof AnyShiftHistory>;
export type ShiftHistoryDuring = z.infer<typeof ShiftHistoryDuring>;

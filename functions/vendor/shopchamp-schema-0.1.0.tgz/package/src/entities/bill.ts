import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `bill/{id}` — บิลขาย 1 doc ต่อ 1 ใบเสร็จ · **รูปที่อ่านจากฐาน** (ทุกร้าน ทุกรุ่นแอป)
 * ที่มา: `lanes/dev/source/schema/bill.md` §1 (ระดับบน 35 + doc id · ซ้อน 29 · ก้อนเปิด 2)
 *
 * - แอปเก่ายังเขียน collection นี้ตรงอยู่ (ทาง A B ของ §หัวเอกสาร) ⇒ `.passthrough()` ทุกชั้น
 *   field รุ่นเก่าใน §1.4 (`net` `timestamp` `totalQty` `discount` `coupon` `profileName` `tableName` `fine` ...)
 *   ไม่มีจุดเขียนในรุ่นนี้ จึงไม่ประกาศ แต่ไม่ตัดทิ้ง
 * - ระดับบน บังคับ = แถวที่ §1.1 ช่อง "บังคับ" เขียนว่า "บังคับ" (ทุกทางสร้างใส่ และมี query หรือผู้อ่านพึ่ง)
 * - แถว "มีทุกทาง" เป็น optional เพราะ **ฐานอาจมีบิลที่ไม่มี key นั้น** ไม่ใช่เพราะผู้อ่านปลอดภัย:
 *   ทาง B ตัด key ที่ค่าเป็น `undefined` (`online B-44`) · บิลรุ่นเก่ายังไม่ได้วัด
 *   ⚠️ ผ่าน schema นี้ ≠ ผู้อ่านเดิมไม่พัง: `Franchise` ไม่เติมค่าเริ่มเลย (§2 `fr:redux/billSlice.js:39-45` · BX-11)
 *   ผู้อ่านหลายจุดอ่าน `pointDiscount.value` ตรง ไม่มี field = throw (§1.1 แถว 7)
 *   ส่วนที่เติมค่าเริ่ม (`WebOwner` · `srv:apis/shift.js`) ได้ `moneyMustPaid:999` เมื่อไม่มี field (BX-07)
 *   ⇒ ตัวเขียนใหม่ (ก้อน 4) ต้องใส่ทุกแถว "มีทุกทาง" เอง ห้ามอาศัยว่า schema นี้ปล่อยผ่าน
 * - field ซ้อน บังคับเฉพาะตัวที่ใช้ระบุของแล้วเขียนกลับ หรือเป็นเงื่อนไขที่ทำให้ก้อนนั้นถูกเขียน:
 *   `product[].id` `product[].qty` (ยกเลิกบิลคืนสต็อก `app:screens/BillHistoryScreen.js:347-357`) · `member.id` (§1.1 แถว 29)
 *   ตัวอื่นตรวจชนิดเมื่อมีเท่านั้น · ตัวที่ไม้บรรทัดติด ❓ ชนิด (`category` `consignment` ค่าใน `taxCustomer`) ไม่ล็อกชนิด
 * - ชนิดกว้างเท่าที่โค้ดเดิมเขียนจริง (§11) ไม่แคบกว่า ไม่งั้นเอกสารจริงถูกปัด
 * - 🚫 **ห้ามใช้ `Bill` เป็นด่านก่อนเขียน** และห้ามใช้ตัดสินว่ายอดถูก: เงินรับ `NaN` `Infinity` (ดู `LegacyNumber`)
 *   และแถว "มีทุกทาง" ขาดได้ · ด่านเขียนของ `sale.create` ต้องเป็น schema คำขอใน `src/requests/` (ก้อน 4 · ยังไม่มี)
 *   ที่ใช้ตัวเลขจำกัดค่า (`z.number()` ปัด NaN และ Infinity) และบังคับแถว "มีทุกทาง" ครบ
 *   (decision 2026-11-06 2-2: server เชื่อยอดจากแอป ⇒ ด่านรูปคำขอเป็นด่านเดียวของยอดเงิน)
 * - ผู้อ่านใหม่ (`sale.get` `sale.void` ก้อน 4) ใช้ `safeParse` · ข้อเสนอเมื่อบิลเก่าตก: ไม่เขียนทับบิลนั้น
 *   ตอบ error พร้อมรหัสบิล และ log `issues` เพื่อขยาย schema · ❓ ยังไม่เคาะรหัส error (ก้อน 4)
 *   ของจริงที่วัดแล้วมีแค่ 3 ใบของร้านทดสอบ (2026-11-06 · ทาง A 1 ทาง B 2) ไม่มีใบยกเลิก ใบกำกับ สมาชิก
 *   รหัสช่องจ่ายเก่า ทาง C หรือแอปรุ่นเก่า ⇒ ชนิดที่ล็อกไว้ยังไม่ได้พิสูจน์กับบิลรุ่นเก่า
 * - doc id ไม่อยู่ใน schema เพราะไม่ใช่ field ของเอกสาร (§1.1 แถว 0 · อ้างจาก `member.creditArray[].billId`)
 * - 2026-11-06 คลายตามตัวอย่างจริง 3,000 บิล (`lanes/dev/source/chunk1-3-verify/live-fit.md` §3 · หัวข้อ "หลังคลาย"):
 *   `shiftId` optional · `member` รับ `{}` · `payment[].amount` `manualDiscount` `product[].totalPrice` รับสตริงตัวเลข (อ่านเท่านั้น)
 *   บิลรุ่นแรกไม่มี `receiptNumber` แยกไป `BillLegacyV1` · อ่านทุกรุ่นใช้ `AnyBill`
 */

/**
 * ตัวเลขเงินและจำนวนจากแอปเดิม · รับ `NaN` และ `Infinity` ด้วย (`online B-45`: `totalCost` `gainPoint`)
 * เพราะ `z.number()` ของ Zod 4 ปัดค่าพวกนี้ ⇒ บิลเก่าที่มีค่าแบบนี้จะถูกปัดทั้งใบ
 * ใช้กับเงินทุกตัวรวม `moneyMustPaid` เพราะเป็นรูปอ่าน · ฝั่งเขียนห้ามใช้ตัวนี้ (ดูหัวไฟล์)
 */
const LegacyNumber = z.custom<number>((v) => typeof v === "number", { message: "ต้องเป็นตัวเลข" });

/** `''` เมื่อไม่มีค่า หรือตัวเลข · `manualDiscount` `rounding` `existPoint` (§11) */
const EmptyOrNumber = z.union([z.literal(""), LegacyNumber]);

/**
 * สตริงตัวเลขไม่ติดลบ เช่น `'120'` `'35.5'` · **รับเฉพาะตอนอ่าน** ของที่แอปเก่าเขียนเป็นสตริงลงฐานแล้ว
 * (`live-fit.md` §3 B4 B5 B6 · 2026-11-06) · ไม่รับ `''` ช่องว่าง เครื่องหมาย หรือข้อความอื่น
 * ผู้อ่านแปลงด้วย `money.toNumber` ก่อนรวม · 🚫 ทางเขียนใหม่ต้องส่ง number เท่านั้น ห้ามใช้ตัวนี้เป็นด่านเขียน
 */
const LegacyNumericString = z.string().regex(/^\d+(\.\d+)?$/, "ต้องเป็นสตริงตัวเลข");

/** §1.2 `pointDiscount` · ส่วนลดแลกแต้ม · ทาง A เขียนทั้ง 2 key เสมอ (`app:screens/CheckoutScreen.js:323-326`) */
export const BillPointDiscount = z
  .object({
    value: LegacyNumber.optional().describe("บาทที่ลด · ผู้อ่านหลายจุดอ่านตรง ไม่มี key = ได้ undefined ไม่ throw"),
    point: LegacyNumber.optional().describe("แต้มที่ใช้ · ไม่พบผู้อ่าน"),
  })
  .passthrough();

/** §1.2 `product[]` · รายการสินค้ารูป `leanProduct` (`app:Utility/function.js:610-624`) */
export const BillProductLine = z
  .object({
    id: z.string().describe("รหัสสินค้า · บังคับ: ยกเลิกบิลใช้หา stock คืน `app:screens/BillHistoryScreen.js:350`"),
    qty: LegacyNumber.describe(
      "จำนวน · บังคับ: ยกเลิกบิลคืนสต็อกตามค่านี้ `app:screens/BillHistoryScreen.js:355` · ทางกรอกเองครอบ Number() ก่อนเข้าตะกร้า `app:screens/CashierScreen.js:504` `app:screens/BarcodeCartScreen.js:172`",
    ),
    net: LegacyNumber.optional().describe("ยอดหลังลดรายสินค้า"),
    name: z.string().optional().describe("ชื่อตอนขาย"),
    totalPrice: z
      .union([LegacyNumber, LegacyNumericString])
      .optional()
      .describe("ยอดก่อนลด · สตริงตัวเลขพบ 3 ใบ 2024-2025 (`live-fit.md` B6) รับตอนอ่านเท่านั้น · ทางเขียนต้องส่งเลข"),
    totalCost: LegacyNumber.optional().describe("ต้นทุนรวม · NaN ได้ (online B-45)"),
    priceType: z.string().optional().describe("เช่น ราคาขายทั่วไป"),
    category: z
      .unknown()
      .optional()
      .describe("id หมวด · ผู้อ่านคาด array แต่สินค้าบางตัวไม่ใช่ array (`app:hook/useLocalStock.js:332` กันไว้) ⇒ ไม่ล็อกชนิด"),
    consignment: z
      .unknown()
      .optional()
      .describe("ฝากขาย · ค่าตามสินค้า (§1.2) · ไม่มี key ได้ถ้าสินค้าไม่มีค่า (online B-44) · ผู้อ่านใช้ truthy ⇒ ไม่ล็อกชนิด"),
    barcode: z.string().optional().describe("ทาง C ไม่มี (`srv:apis/checkout.js:157-169`)"),
  })
  .passthrough();

/** §1.2 `payment[]` · ช่องชำระ · รูปหลัก: ยอดเป็นตัวเลข */
export const BillPaymentNumber = z
  .object({
    id: z
      .union([z.number(), z.string()])
      .describe(
        "ช่องปัจจุบันเป็นตัวเลข 1 2 3 · บิลเก่าเป็นรหัส '001' '009' '035' '036' '037' · รับ string ทุกค่า เพราะไม้บรรทัดยังไม่ได้นับรหัสเก่าครบ (§1.2 ❓) · ของจริงมี uuid ด้วย (`live-fit.md` 2026-11-06)",
      ),
    amount: LegacyNumber.describe("ยอดรวมส่วนที่ทอน · ผู้อ่านรวมตรง `srv:apis/shift.js:145`"),
    name: z.string().optional().describe("บิลเก่าไม่มีได้ ผู้อ่านเติมจาก paymentNameMaps"),
    change: LegacyNumber.optional().describe("เงินทอนของช่องนี้"),
  })
  .passthrough();

/**
 * §1.2 `payment[]` รูปรองที่มีอยู่ในฐาน: ยอดเป็นสตริงตัวเลข · **เฉพาะช่องรหัสเก่า 3 หลัก** (`'009'` `'035'` `'036'` `'037'`)
 * วัด 2026-11-06 (`live-fit.md` B4): 57 แถวใน 57 บิล 43 ร้าน ปี 2024-2025 · แปลงเป็นเลขได้ทุกแถว · ไม่พบกับช่อง 1 2 3 หรือ uuid
 * ⇒ แยกเป็นรูปของตัวเอง ช่องปัจจุบันยังต้องเป็นตัวเลข · ❓ ยังไม่ได้ไล่ทางเขียนที่ส่งสตริง (ควรเป็นใบบั๊กของทางนั้น)
 */
export const BillPaymentLegacyString = z
  .object({
    id: z.string().regex(/^\d{3}$/, "สตริงยอดรับเฉพาะช่องรหัสเก่า 3 หลัก").describe("รหัสช่องเก่า 3 หลัก"),
    amount: LegacyNumericString.describe(
      "สตริงตัวเลข · **รับตอนอ่านเท่านั้น** ผู้อ่านแปลงด้วย `money.toNumber` (`logic:shift.js` `sat` · `logic:member.js` `toSatang`) · 🚫 ทางเขียนต้องส่ง number",
    ),
    name: z.string().optional(),
    change: LegacyNumber.optional(),
  })
  .passthrough();

export const BillPayment = z.union([BillPaymentNumber, BillPaymentLegacyString]);

/** §1.2 `campaign[]` · โปรโมชันที่ใช้ (`app:Utility/function.js:1838`) */
export const BillCampaign = z
  .object({
    id: z.unknown().optional().describe("ตามโปรโมชัน ชนิดไม่ปิด"),
    name: z.string().optional(),
    rights: LegacyNumber.optional(),
    discount: LegacyNumber.optional().describe("บาทที่ลด · สรุปกะรวมค่านี้"),
    promotionId: z.string().optional().describe("ชนิดโปรโมชัน เช่น '5'"),
  })
  .passthrough();

/**
 * §1.2 `taxCustomer` · รูปเริ่มจาก `app:config/initialTax.js:1` · ค่าจริงมาจากรายการ `shop.taxCustomer`
 * ที่จอตั้งค่าและเว็บเขียน (`app:Modal/Modal_FindTax.js:48`) ไม้บรรทัดติด ❓ ⇒ ประกาศ key แต่ไม่ล็อกชนิด
 * ผู้อ่านใช้แสดงผลเท่านั้น (`own:screens/ReportVatScreen.js:106` `app:hook/usePrintAction.js:219`)
 */
export const BillTaxCustomer = z
  .object({
    name: z.unknown().optional().describe("initialTax: string"),
    tel: z.unknown().optional().describe("initialTax: string"),
    address: z.unknown().optional().describe("initialTax: string"),
    taxNumber: z.unknown().optional().describe("initialTax: string"),
    branch: z.unknown().optional().describe("initialTax: string"),
    fax: z.unknown().optional().describe("initialTax: string"),
    status: z.unknown().optional().describe("initialTax: boolean"),
    headquarter: z.unknown().optional().describe("initialTax: boolean"),
  })
  .passthrough();

/** §1.3 `member` · สำเนาสมาชิกทั้งก้อน · ผู้อ่านใช้แค่ `id` `name` · query ด้วย `member.id` */
export const BillMember = z
  .object({
    id: z
      .string()
      .describe("doc id สมาชิก · บังคับ: ก้อนนี้ถูกเขียนเฉพาะเมื่อ currentMember.id มีค่า (§1.1 แถว 29) · ใช้ query ประวัติ `app:redux/memberSlice.js:50`"),
    name: z.string().optional(),
  })
  .passthrough();

/**
 * `member: {}` · ขายแบบไม่มีสมาชิกจากแอปที่ใส่ `member: leanMember(receipt.member)` ทุกบิล
 * `leanMember` คืน `{}` เมื่อสมาชิกไม่มี `name` (`shopcham_merchant_2025@26701fcf` › `src/Utility/function.js:695-701`)
 * วัด 2026-11-06 (`live-fit.md` B2): 666 บิล 248 ร้าน ปี 2024-2025 · ว่างจริงทุกใบ ⇒ รับเฉพาะ object ว่าง ไม่รับ object ที่มี key แต่ไม่มี id
 * ผู้อ่านใหม่ถือว่า `{}` = ไม่มีสมาชิก
 */
export const BillMemberEmpty = z.strictObject({});

/** §1.3 `pointToItem[]` · สำเนาของแถมแลกแต้ม + qty · รูปเต็มตามข้อมูลร้าน */
export const BillPointToItem = z.object({}).passthrough();

export const Bill = z
  .object({
    // ── บังคับ (§1.1 แถว 1 2 3 4 5 11 14 15)
    shopId: z.string().describe("ร้านเจ้าของบิล · query หลัก"),
    receiptNumber: z.string().describe("เลขใบเสร็จ 12 หลัก (เดือน) หรือ 14 หลัก (วัน)"),
    billDate: z
      .string()
      .describe(
        "YYYYMMDD ปฏิทินเครื่องตอนกดจ่าย · ไม่ใช่วันธุรกิจ · เว็บ query ด้วยค่านี้แล้วดึงเผื่อ 1 วัน (§1.1 แถว 3) · " +
          "⚠️ ไม้บรรทัดขัดกัน: `architecture-plan.md:101` ให้ server ใหม่เขียนวันธุรกิจ แต่ `:269` ห้ามเปลี่ยนความหมาย field เดิม ⇒ ต้องให้ Pack เคาะก่อนก้อน 4 · ถ้าเปลี่ยน บิลเก่าและใหม่ในฐานเดียวจะมี billDate คนละความหมาย",
      ),
    dateTime: z
      .union([FirestoreTime, z.string()])
      .describe("เวลาขายจากนาฬิกาเครื่อง · string เฉพาะทาง C ที่ค่าผ่าน JSON (§11 · BX-01) · ไม่มีเวลา server ใน doc (BX-09)"),
    moneyMustPaid: LegacyNumber.describe("ยอดสุทธิ · ผู้อ่านที่เติมค่าเริ่มได้ 999 เมื่อไม่มี field (BX-07) จึงบังคับ"),
    shiftId: z
      .string()
      .optional()
      .describe(
        "doc ประจำเครื่อง POS ใช้ซ้ำทุกรอบเปิดกะ ไม่ใช่รหัสกะ · แยกรอบต้องใช้คู่กับเวลา (§10 ข้อห้าม) · " +
          "optional เพราะแอปเริ่มเขียน key นี้ลงบิลที่ `shopcham_merchant_2025@f95d0366` (2025-03-11) · บิลรูปปัจจุบันจากแอปก่อนนั้นไม่มี " +
          "(วัด 2026-11-06 `live-fit.md` B1: 716 ใบ ปี 2024-2025 + 2026 1 ใบ) · บิลไม่มี key นี้ `logic:shift.js` `pickRound` ตอบ NO_SHIFT ไม่เข้ารอบใด · " +
          "🚫 ทางเขียนใหม่ (ก้อน 4) ต้องใส่เสมอ",
      ),
    product: z.array(BillProductLine),
    payment: z.array(BillPayment).describe("ว่างได้"),

    // ── มีทุกทาง (§1.1 แถว 6-10 12 13 16-28) · optional เพราะฐานอาจไม่มี key ไม่ใช่เพราะผู้อ่านปลอดภัย (ดูหัวไฟล์)
    manualDiscount: z
      .union([EmptyOrNumber, LegacyNumericString])
      .optional()
      .describe("`''` หรือเลข · สตริงตัวเลขพบ 5 ใบ 2024-2025 (`live-fit.md` B5) รับตอนอ่านเท่านั้น · ทางเขียนต้องส่งเลข"),
    pointDiscount: BillPointDiscount.optional().describe("ผู้อ่านหลายจุดอ่าน .value ตรง ไม่มี field = throw"),
    productDiscount: LegacyNumber.optional(),
    posId: z.string().optional(),
    posNumber: z.string().optional().describe("ค่าเริ่ม '' จาก initialPos"),
    cashierId: z.string().optional(),
    cashierName: z.string().optional(),
    currentCredit: LegacyNumber.optional().describe("ซ้ำกับ payment.id===3 · ไม่พบผู้อ่าน"),
    pointToItem: z.array(BillPointToItem).optional(),
    lucky: z.array(z.string()).optional(),
    gainPoint: LegacyNumber.optional().describe("Infinity ได้ถ้า rate=0 (online B-45)"),
    usedPoint: LegacyNumber.optional(),
    existPoint: EmptyOrNumber.optional().describe("A: แต้มหรือ '' · B: 0 เสมอ · C: '' (online B-03)"),
    campaign: z.array(BillCampaign).optional(),
    change: LegacyNumber.optional(),
    vatAmount: LegacyNumber.optional(),
    vatType: z.string().optional().describe("Include · Exclude · ไม่มี key ได้ถ้าร้านไม่มีค่า"),
    rounding: EmptyOrNumber.optional().describe("ลบได้"),
    note: z.string().optional(),
    receiptType: z.string().optional().describe("receiptPattern ของร้าน เช่น month"),

    // ── บางทาง / บางเงื่อนไข (§1.1 แถว 29-35)
    member: z
      .union([BillMember, BillMemberEmpty])
      .optional()
      .describe("มีเมื่อขายให้สมาชิก · `{}` = ไม่มีสมาชิก (แอปช่วง 2024-2025 · ดู `BillMemberEmpty`)"),
    franchiseId: z.string().optional().describe("ทาง A เท่านั้น · '' ได้"),
    void: z
      .boolean()
      .optional()
      .describe(
        "โค้ดรุ่นนี้เขียน true เท่านั้น · ไม่มี key = ปกติ · รับ false ด้วย เพราะบิลรุ่นเก่ายังไม่วัด (WR-68) และ false ให้ผลเดียวกันทั้ง `=== true` และ `!a.void` (§11)",
      ),
    voidStaff: z.string().optional().describe("ชื่อพนักงาน ไม่ใช่ id"),
    reason: z.string().optional(),
    taxNumber: z.string().optional().describe("YYYYMM + 6 หลัก · มีค่า = เคยออกใบกำกับ"),
    taxCustomer: BillTaxCustomer.optional(),

    // ── ใหม่ของก้อน 4 (`sale.create`) · optional เท่านั้น เพราะแอปเก่าไม่เขียน (`architecture-plan.md:98-105` · `:269`)
    //    ห้ามประทับ `timestamp = soldAt` แบบพี่น้อง เพราะ `timestamp` เป็น field เดิมที่มีผู้อ่าน (§1.4)
    receiptUUID: z.string().optional().describe("รหัส 1 การกดขาย · กันบิลซ้ำ (#1) · ตรงกับ receiptGuard doc id"),
    soldAt: FirestoreTime.optional().describe("เวลาขายจริงตอนออฟไลน์ หลังตัดช่วง 4 วัน/5 นาทีแล้ว (#18 #19)"),
    offline: z.boolean().optional().describe("ป้ายในคำขอ · แบบพี่น้องตัดทิ้งก่อนเขียนแล้วประทับ offlineSync แทน ⇒ ไม่ควรพบในบิล · ประกาศไว้กันชนิดเพี้ยน"),
    offlineSync: z.literal(true).optional().describe("server ประทับเมื่อเชื่อป้ายออฟไลน์ · ไม่มี key = บิลปกติ"),
    syncedAt: FirestoreTime.optional().describe("นาฬิกา server ตอนรับบิลออฟไลน์ · คู่กับ soldAt บอกว่าค้างในเครื่องนานเท่าไร (BX-09)"),
    offlineRef: z.string().max(40).optional().describe("รหัสบนใบรับเงินชั่วคราว · server ประทับเอง ≤ 40 ตัว"),
    soldAtClamped: z.literal(true).optional().describe("soldAt นอกช่วงจึงใช้เวลา server แทน"),
    shiftOpenTime: FirestoreTime.optional().describe("เวลาเปิดรอบของ shiftId ตอนขาย · ใช้แยกรอบ (#18)"),
    shiftUnassigned: z.literal(true).optional().describe("หารอบใน shiftHistory ไม่เจอ ให้รายงานเห็น (#18)"),

    // ── ใหม่ของก้อน 4 (`sale.void` · `sale.amend`) · optional เท่านั้น · แอปเก่าอ่านแค่ `void` `voidStaff` `reason` ต่อไป
    voidAt: FirestoreTime.optional().describe("นาฬิกา server ตอนยกเลิกผ่าน `sale.void` · ยกเลิกจากแอปเก่าไม่มี"),
    voidStaffId: z.string().optional().describe("id พนักงานที่ยกเลิก · `voidStaff` เดิมเป็นชื่อ"),
    voidRequestId: z.string().optional().describe("กุญแจของคำขอยกเลิก · ยิงซ้ำด้วยค่าเดิม = ผลเดิม (#6)"),
    voidShiftId: z.string().optional().describe("กะของจุดที่กดยกเลิก · เงินคืนลงกะนี้ (SC-06 ทางแรก)"),
    voidShiftOpenTime: FirestoreTime.optional().describe("เวลาเปิดรอบของ `voidShiftId` ตอนยกเลิก · แยกรอบแบบเดียวกับ `shiftOpenTime`"),
    amendOf: z.string().optional().describe("บิลใหม่จากการแก้ไข → doc id ของบิลเดิม (`bill-edit-pattern-from-sibling.md` §1.4)"),
    amendedBy: z.string().optional().describe("บิลเดิมที่ถูกแก้ → doc id ของบิลใหม่ · มีค่า = ยกเลิกเพราะแก้ ไม่ใช่ยกเลิกทิ้ง"),
    amend: z
      .object({
        status: z.enum(["pending", "done"]),
        requestId: z.string(),
        at: FirestoreTime.optional(),
        staff: z.string().optional(),
        newBillId: z.string().optional(),
        newReceiptNumber: z.string().optional(),
        ofReceiptNumber: z.string().optional(),
        refundDue: z.number().optional(),
      })
      .passthrough()
      .optional()
      .describe("สถานะการแก้ไข · บนบิลเดิมและบิลใหม่ (`sale.amend`)"),
  })
  .passthrough();

/** บรรทัดสินค้าของบิลรุ่นแรก · สำเนาเอกสาร `stock` ทั้งตัว + `qty` `totalPrice` `totalCost` · ระบุเฉพาะที่ใช้คืนสต็อก */
export const BillLegacyV1ProductLine = z
  .object({
    id: z.string().describe("รหัสสินค้า · คืนสต็อกตอนยกเลิกต้องใช้"),
    qty: LegacyNumber.describe("จำนวน"),
    name: z.string().optional(),
    price: LegacyNumber.optional(),
    cost: LegacyNumber.optional(),
    totalPrice: LegacyNumber.optional(),
    totalCost: LegacyNumber.optional(),
  })
  .passthrough();

/** `void` ของบิลรุ่นแรก · object ไม่ใช่ boolean (`live-fit.md` B7: 1 ใบ 2023) */
export const BillLegacyV1Void = z
  .object({
    dateTime: FirestoreTime.optional(),
    remark: z.string().optional(),
    user: z.string().optional(),
    userId: z.string().optional(),
  })
  .passthrough();

/**
 * `bill/{id}` **รุ่นแรก** (ไม่มี `receiptNumber`) · คนละรูปกับ `Bill` ทั้งใบ · **รูปอ่านอย่างเดียว ห้ามเขียนรูปนี้**
 * ที่มา: ตัวอย่างจริง 574 ใบ 124 ร้าน ปี 2022-2024 (`live-fit.md` §3 B3 · วัด 2026-11-06) ≈ 6% ของบิลสุ่ม
 * - บังคับ = key ที่มีครบ 574/574 ในตัวอย่าง · optional = มีบางใบ (`customerTel` 531 `earnPoint` 531 `scShopId` `eyosDiscount*` 368)
 * - `receiptNumber` ต้องไม่มี ⇒ ไม่ทับกับ `Bill` (บิลหนึ่งใบเข้าได้รูปเดียว)
 * - ❓ ยังไม่ได้ไล่โค้ดแอปรุ่นที่เขียนรูปทั้งใบ · รูปนี้ถอดจากข้อมูล (ตัวอย่างชุดใหม่ 400/400 ผ่าน · `live-fit.md` §8)
 * - ทางเขียน `void` object: แอปรุ่นแรก `@bdf186d9` (2023-02-24) › `src/screens/HistoryDetail.js` · ทุกรุ่นอ่านแบบ truthy (`live-fit.md` §8)
 * - ⚠️ **นโยบายยกเลิกบิลรุ่นนี้ (คืนสต็อกหรือปฏิเสธ) รอ Pack เคาะ** · `sale.void` ห้ามเดาเอง · ข้อเท็จจริงของแอปเก่าอยู่ที่ `live-fit.md` §8
 *   "ยกเลิกแล้วไหม" ตัดสินด้วย `logic:billState.js` `isVoidedBill` (truthy) ทั้ง `shift` และ `docNumber`
 */
export const BillLegacyV1 = z
  .object({
    receiptNumber: z.never().optional().describe("ต้องไม่มี · ตัวแยกจาก `Bill`"),
    shopId: z.string(),
    dateTime: FirestoreTime.describe("เวลาขาย · Timestamp ทุกใบในตัวอย่าง"),
    orderId: z.string(),
    product: z.array(BillLegacyV1ProductLine),
    paymentType: z.string().describe("ชื่อช่องจ่ายเป็นข้อความ · ไม่มี `payment[]`"),
    cashReceived: LegacyNumber,
    cashChange: LegacyNumber,
    credit: LegacyNumber,
    promptpay: z.union([z.string(), LegacyNumber]).describe("สตริง 553 · ตัวเลข 21 ในตัวอย่าง"),
    discount: LegacyNumber,
    totalPrice: LegacyNumber,
    totalCost: LegacyNumber,
    customerId: z.string().describe("`''` ได้เมื่อไม่มีสมาชิก ❓"),
    customerName: z.string(),
    customerTel: z.string().optional(),
    earnPoint: LegacyNumber.optional(),
    scShopId: z.string().optional(),
    eyosDiscount: LegacyNumber.optional(),
    eyosDiscountList: z.array(z.unknown()).optional(),
    void: BillLegacyV1Void.optional(),
  })
  .passthrough();

/** บิลที่อ่านจากฐานได้ทุกรุ่น · ลอง `Bill` ก่อน แล้ว `BillLegacyV1` · ผู้อ่านแยกด้วย `receiptNumber` ว่ามีไหม */
export const AnyBill = z.union([Bill, BillLegacyV1]);

export type Bill = z.infer<typeof Bill>;
export type BillLegacyV1 = z.infer<typeof BillLegacyV1>;
export type AnyBill = z.infer<typeof AnyBill>;
export type BillProductLine = z.infer<typeof BillProductLine>;
export type BillPayment = z.infer<typeof BillPayment>;
export type BillCampaign = z.infer<typeof BillCampaign>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `product/{id}` — คลังบาร์โค้ดกลางข้ามร้าน 1 doc ต่อบาร์โค้ด (ไม่ unique) · ไม่ใช่สินค้าของร้าน (นั่นคือ `stock`)
 * ที่มา: `lanes/dev/source/schema/product.md` §1 (field 16 ตัว = 1.1 มีจุดเขียน 9 · 1.2 อ่านอย่างเดียว 6 · 1.4 เฉพาะประวัติ git 1)
 *
 * - รูปตาม **ช่อง "ตอนอยู่ในฐาน"** ของ §1 · แอปเก่ายังเขียน collection นี้ตรงอยู่ (W1 W2) ⇒ `.passthrough()` ทุกชั้น
 * - ในฐานมีได้ 2 รูปปนกัน: รูปคลังกลางจาก W2 (ไม่มี `shopId`) และรูปรายร้านที่ `care` อ่าน (มี `shopId` · ไม่พบทางสร้าง · B5)
 *   ⇒ schema เดียวรับทั้ง 2 รูป · field ของรูปรายร้าน (แถว 10-15) เป็น optional ทั้งหมด
 * - `barcode` บังคับ **เฉพาะรูปคลังกลาง (ไม่มี field `shopId`)** · เหตุ: ทุกจุดสร้างรูปนี้ใส่ (W2 และ H1-H6 ในประวัติ ✅ §2)
 *   และ query ของแอปทั้ง 3 จุดพึ่งค่านี้
 *   รูปรายร้าน (มี `shopId` แม้เป็น `''`) ไม่บังคับ: §2 ให้ `barcode` เป็น ❓ · ผู้อ่าน `care` 4 จุดไม่อ่าน `barcode` จาก doc
 *   (มีแค่ค่าตั้งต้น `''` ที่เติมตอนอ่าน `care:configs/initialProduct.js:50`) ⇒ บังคับ = เข้มเกินหลักฐาน
 * - `barcode` รับ string ใดก็ได้ รวม `''` อักษรไทย สัญลักษณ์ ช่องว่างหน้าหลัง และไม่ trim
 *   เพราะ rules ไม่ตรวจรูป และกฎ normalize บาร์โค้ดยังรอเคาะ (DI-11 · B3 B4 B8) · แปลงค่าตอน parse = query `barcode ==` ไม่ตรงของในฐาน
 * - ร้านทดสอบวัดได้ 0 doc ทั้งนิยาม `shopId ==` และ `createdBy2 ==` (2026-11-06) ⇒ **ยังไม่มีของจริงยืนยันว่า parse ผ่าน 100%**
 *   เทสพิสูจน์ได้แค่รูปที่อ่านจากโค้ด · doc รูปรายร้านในฐานจริงยังไม่เคยมีใครเห็น
 * - field อื่นเป็น optional แม้ W2 ใส่ครบ เพราะ doc จากประวัติ git และจากนอกโค้ดอาจไม่มี (B7 · doc ไม่มี `unit`/`imageId`)
 *   การเติมค่าตั้งต้นตอนอ่าน (กัน `undefined` เข้า `stock`) เป็นงาน logic ก้อน 9b ไม่ใช่งานของ schema อ่าน
 * - `sku` รับค่าเพี้ยน `0NaNNaNNaNNaNNaNNaN` ไว้ (B6 · DI-77) · ห้ามใช้ `sku` ของ doc เดิมเป็นรหัสจริง
 * - doc id ไม่อยู่ใน schema · ทุกจุดอ่านเติม `id` จาก `doc.id` ไม่ใช่ field ในเอกสาร (§1.3)
 * - ไม่มี field ใหม่ของก้อน 4 (`receiptUUID` `soldAt` `offline`) เพราะเป็นของบิล ไม่ใช่ของคลังบาร์โค้ด
 * - ไม่มีคำขอ API ของ `product` ในก้อน 4 (ไม่มี route ที่ทำงานอยู่แตะ `product` · §6) ⇒ ไม่มี `requests/product.ts`
 */

/**
 * สมาชิกของ `price[]` ในรูปรายร้านที่ `care` อ่าน (แถว 13)
 * ผู้อ่านหาด้วย `id` แล้วอ่าน `.price` แบบทนของขาด: `price.find(d=>d.id==a.id)?.price || ''` (`care:components/ReportProductInfo.js:167` เทียบหลวม · `:107` เทียบตรง)
 * ⇒ ไม่บังคับทั้ง 2 key · `id` รับเลขด้วย (เทียบหลวมยังตรง) · แม่แบบของ `care` เองใช้ key `type` ไม่ใช่ `id` (`care:configs/initialProduct.js:9-21`)
 */
export const ProductChannelPrice = z
  .object({
    id: z.union([z.string(), z.number()]).optional().describe("❓ id ช่องทางขาย · ใช้ `find` เทียบ · ไม่มีได้"),
    price: z.union([z.number(), z.string()]).optional().describe("❓ ราคาของช่องทางนี้ · ชนิดอนุมานจากการแสดงผล · แม่แบบเป็น `''`"),
  })
  .passthrough();

export const Product = z
  .object({
    // §1.1 field ที่มีจุดเขียน (9) · W2 `app:screens/ProductSetting.js:679-689`
    barcode: z.string().optional().describe("แถว 1 · key ของคลังกลาง ไม่ unique · `''` ได้ · ไม่ trim (B3 B4 B8 · DI-11) · บังคับเฉพาะรูปคลังกลาง ดู superRefine"),
    name: z.string().optional().describe("แถว 2 · ชื่อที่ร้านแรกพิมพ์ เติมให้ร้านถัดไป (B2 · C42)"),
    unit: z.string().optional().describe("แถว 3 · หน่วยนับ · ค่าเริ่ม `ชิ้น` · doc ที่ไม่มีทำให้เพิ่มด่วนล้ม (B7 · ST-065)"),
    imageId: z.string().optional().describe("แถว 4 · URL รูปกลาง หรือ `''` · ชื่อว่า Id แต่เก็บ URL (B1 B11 · DI-10)"),
    sku: z.string().optional().describe("แถว 5 · HEAD เขียน `0NaNNaNNaNNaNNaNNaN` เสมอ (B6) · ประวัติเขียน `''` แล้วแก้เป็น doc id"),
    adminChecked: z.boolean().optional().describe("แถว 6 · W2 เขียน `false` · doc รุ่นก่อน 2023-10-31 ไม่มี · ไม่พบคนอ่าน"),
    createdBy: z.string().optional().describe("แถว 7 · HEAD เขียน `''` · ประวัติเคยใส่ชื่อผู้ใช้"),
    createdBy2: z.string().optional().describe("แถว 8 · HEAD เขียน `''` · ประวัติเคยใส่ id ร้าน"),
    dateTime: FirestoreTime.optional().describe("แถว 9 · เวลาสร้างจากนาฬิกาเครื่อง · ในฐานเป็น Timestamp"),
    // §1.2 field ที่อ่านอย่างเดียว ไม่มีจุดเขียนที่ HEAD (6) · รูปรายร้านที่ `care` อ่าน · ชนิดทุกแถวเป็น ❓ อนุมานจากวิธีอ่าน
    shopId: z.string().optional().describe("แถว 10 · ร้านเจ้าของ เฉพาะรูปรายร้าน · W2 ไม่ใส่ ⇒ รายงาน care ว่าง (B5 · AC-51)"),
    timestamp: FirestoreTime.optional().describe("แถว 11 · ❓ Timestamp · care เรียก `.toDate()` ไม่กันค่าว่าง (B5)"),
    category: z
      .union([z.array(z.string()), z.string()])
      .optional()
      .describe("แถว 12 · ❓ array อ่าน `[0]` · ❓ string `''` จาก writer ในประวัติ"),
    price: z
      .array(ProductChannelPrice)
      .optional()
      .describe("แถว 13 · ❓ array ของ `{id, price}` · **ต่างจาก `stock.price`** ที่เป็นเลขเดี่ยว"),
    stock: z.number().optional().describe("แถว 14 · ❓ จำนวนคงเหลือ · ใช้เรียงและแสดง"),
    stockCount: z.boolean().optional().describe("แถว 15 · ❓ ตัดสต๊อก · ใช้กรอง"),
    // §1.4 field ที่พบเฉพาะในประวัติ git (1)
    imageId2: z.string().optional().describe("แถว 16 · ❓ รูปตัวอย่างหรือ `''` จาก writer รุ่นเก่า · ไม่มีคนอ่านที่ HEAD"),
  })
  .passthrough()
  .superRefine((doc, ctx) => {
    // รูปคลังกลาง (ไม่มี field `shopId`) ต้องมี `barcode` · รูปรายร้านไม่บังคับ (เหตุอยู่ที่ comment หัวไฟล์)
    if (doc.shopId === undefined && doc.barcode === undefined) {
      ctx.addIssue({ code: "custom", path: ["barcode"], message: "doc รูปคลังกลาง (ไม่มี shopId) ต้องมี barcode" });
    }
  });

export type Product = z.infer<typeof Product>;

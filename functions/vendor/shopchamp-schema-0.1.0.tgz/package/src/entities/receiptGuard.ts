import { z } from "zod";

/**
 * `receiptGuard/{id}` — เครื่องหมายกันบิลคิวซิงก์ซ้ำ 1 doc ต่อ 1 ใบในคิวที่ commit แล้ว
 * ที่มา: `lanes/dev/source/schema/receiptGuard.md` §1 (doc id + field 3 ตัว)
 *
 * - ตัวที่ทำงานจริงคือ "มี doc หรือไม่" ไม่มีใครอ่านค่า field (§10)
 * - แอปเก่ายังเขียน collection นี้ตรงอยู่ ⇒ `.passthrough()` เก็บ field ที่ไม่รู้จักไว้ ไม่ตัดทิ้ง
 * - doc เก่ามี 2 รูป (RG-B6): ทางแอป `{createdAt, usedBy}` · ทาง route `{createdAt, usedBy, shopId}`
 *   ⇒ schema อ่านทนทั้ง 2 รูป · `usedBy` ความหมายไม่เท่ากันระหว่าง 2 รูป อย่าใช้ชี้กลับหาบิล
 * - doc id (§1 แถว 0) ไม่ใช่ field ของเอกสาร ⇒ ตรวจแยกด้วย `ReceiptGuardDocId`
 *
 * ความหมายเดียวของ writer ใหม่ (`sale.create` ก้อน 4 · ปิด RG-B6 ฝั่งของใหม่):
 * - `usedBy` = เลขบิล (`receiptNumber`) ตามแบบพี่น้อง (`api-pattern-from-sibling.md:76`) ตรงกับรูป route เดิม
 * - `billId` = bill doc id · ใช้ field นี้ชี้กลับหาบิล ไม่ใช้ `usedBy`
 * - `shopId` = shop doc id ที่ผ่าน `requireShopAccess` แล้ว (ไม่ใช่ field `shop.shopId`)
 *
 * ⚠️ ด่านข้ามร้าน 409 ของก้อน 4 (`architecture-plan.md` ก้อน 4) — ห้ามเขียนเป็น `guard.shopId !== ร้านผู้เรียก` ตรง ๆ
 * - doc ทางแอปเก่าไม่มี `shopId` เลย (ร้านทดสอบวัด 2026-11-06: 2/2 ใบไม่มี) ⇒ เทียบตรง ๆ = ใบคิวที่แอปเก่าซิงก์แล้ว
 *   ได้ 409 แทน duplicate (ผิดหัวข้อ 3 "เจอ guard เดิม = duplicate = สำเร็จ")
 * - มี `shopId` = เทียบกับ shop doc id · ไม่มี `shopId` = เทียบ prefix ของ doc id กับ field `shop.shopId`
 *   ของร้านผู้เรียก (แอปตั้ง id จาก `shop.shopId` ไม่ใช่ doc id · `CO:113,710` · ร้านเก่า 2 ค่านี้ต่างกันได้ `schema/shop.md` S5)
 * - doc รูป route เดิมก็มี `shopId` = body `id` ซึ่งแอปส่ง `shop.id` (`CO:110,708`) = shop doc id · ❓ ไม่มีผู้เรียก route จึงไม่มีของจริงให้วัด
 */

/** เวลาที่ Firestore คืน: `Timestamp` (มี `toDate()`) หรือ `Date` ตอนเขียน */
export const FirestoreTime = z.custom<Date | { toDate: () => Date }>(
  (v) =>
    v instanceof Date ||
    (v !== null && typeof v === "object" && typeof (v as { toDate?: unknown }).toDate === "function"),
  { message: "ต้องเป็น Firestore Timestamp หรือ Date" },
);

/** จำนวน byte เมื่อเข้ารหัส UTF-8 · เขียนเองเพราะไม่พึ่ง `TextEncoder` ที่บางเครื่องอาจไม่มี */
const utf8Bytes = (s: string): number => {
  let n = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 0x80) n += 1;
    else if (c < 0x800) n += 2;
    else if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) {
      const d = s.charCodeAt(i + 1);
      if (d >= 0xdc00 && d <= 0xdfff) {
        n += 4;
        i++;
      } else n += 3;
    } else n += 3;
  }
  return n;
};

/**
 * §1 แถว 0 · doc id ของ guard
 * - แอปตั้งเป็น `${shop.shopId}${uuid v4}` ไม่มีตัวคั่น (`CO:113,710`) · prefix คือ field `shop.shopId` ไม่ใช่ shop doc id
 * - route เดิมรับ string ใดก็ได้จาก body
 * - ว่าง = admin SDK โยนก่อนถึงฐาน (`GCF/path.js:444-445` · RG-B4) · `undefined` = ถูกปัด (แอปได้ id สุ่ม · RG-B5)
 * - มี `/` = ชี้ไปคนละ doc หรือโยน เพราะ `.doc()` แตก path เป็นชั้น (`GCF/reference.js:2311-2313`)
 * - กติกา doc id ของ Firestore เอง: ไม่ใช่ `.` หรือ `..` · ไม่ใช่รูป `__...__` · ไม่เกิน 1,500 byte
 *   ❓ มาจากเอกสาร Firestore ไม่ได้ยิงฐานจริง · admin SDK 6.8.0 ไม่ตรวจเองฝั่ง client ⇒ ตรวจที่นี่ให้ได้ 400 แทนล้มใน transaction
 *   doc ที่อยู่ในฐานแล้วผ่านกติกานี้เสมอ เพราะ Firestore ไม่ยอมให้สร้าง
 * - ไม่บังคับรูป uuid เพราะ doc เก่าจาก route เป็น string อิสระ และไม่บังคับ prefix ร้าน
 *   เพราะร้านเก่า `shop.shopId` ≠ doc id ของร้านได้ (`schema/shop.md` S5)
 */
export const ReceiptGuardDocId = z
  .string()
  .min(1, { message: "doc id ของ receiptGuard ห้ามว่าง" })
  .refine((s) => !s.includes("/"), { message: "doc id ของ receiptGuard ห้ามมี /" })
  .refine((s) => s !== "." && s !== "..", { message: "doc id ของ receiptGuard ห้ามเป็น . หรือ .." })
  .refine((s) => !/^__[\s\S]*__$/.test(s), { message: "doc id ของ receiptGuard ห้ามเป็นรูป __...__ (Firestore สงวนไว้)" })
  .refine((s) => utf8Bytes(s) <= 1500, { message: "doc id ของ receiptGuard ห้ามเกิน 1,500 byte" })
  .describe("§1 แถว 0 · `${shop.shopId}${uuid}` จากแอป · ตัวกันซ้ำ ไม่ซ้ำต่อ 1 ใบในคิว");

export const ReceiptGuard = z
  .object({
    createdAt: FirestoreTime.describe(
      "§1 แถว 1 · เวลาที่ commit โดยประมาณ · นาฬิกาเครื่อง (แอป) หรือนาฬิกา server (route) · ไม่ใช่ server timestamp · ไม่พบผู้อ่าน",
    ),
    usedBy: z
      .string()
      .describe(
        "§1 แถว 2 · doc เก่าความหมายต่างตามทาง: แอป = bill doc id · route = receiptNumber (RG-B6) · writer ใหม่ = receiptNumber · ไม่พบผู้อ่าน",
      ),
    shopId: z
      .string()
      .optional()
      .describe(
        "§1 แถว 3 · doc ทางแอปไม่มี field นี้ · route เดิม = body `id` (RG-B6) · writer ใหม่ = shop doc id · ไม่มี = เทียบร้านจาก prefix ของ doc id กับ `shop.shopId` ห้ามตีเป็นข้ามร้าน",
      ),
    billId: z
      .string()
      .optional()
      .describe(
        "ไม่อยู่ใน §1 · ของใหม่ให้ก้อน 4 (`sale.create`) เขียน bill doc id แยกจาก `usedBy` ตามแบบพี่น้อง (`api-pattern-from-sibling.md:76,152`) · doc เก่าไม่มี",
      ),
  })
  .passthrough();

export type ReceiptGuard = z.infer<typeof ReceiptGuard>;

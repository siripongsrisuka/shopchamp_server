import { z } from "zod";
import { WatcherUid, WatcherLevel, WATCHER_ROSTER_MAX } from "../entities/watcherRoster";

/**
 * คำขอ API ของ shopchampoffice (DEV-0003 · Watcher Console) · strict (field เกิน = ถูกปัด)
 * สัญญา: `shopchamp-center/api/office.*.yaml` · เอกสาร `lanes/dev/source/office-watcher-console.md`
 * route ทั้งหมด = `POST /pos/office/*` · auth "user" (ตัดสินคนในทะเบียน watcher/roster ที่ handler · client ไม่อ่าน doc เอง)
 *
 * พิธี passkey (WebAuthn) ยกแบบจากบ้านพี่น้อง: challenge อยู่ที่ server · ใช้ครั้งเดียว · หมดอายุ 5 นาที · requireUserVerification
 *   ทุกการเขียนทะเบียนต้องแนบผลแตะนิ้วใบใหม่ (`passkey`) ⇒ server ตรวจ + กิน challenge ก่อนเขียน
 */

/** origin ของหน้าเว็บที่ทำพิธี (window.location.origin) · server รับเฉพาะใน allowlist ของตัวเอง */
const origin = z.string().min(1).max(200).describe("window.location.origin · ไม่อยู่ใน allowlist ของ server = 400 bad_origin");

const b64url = z.string().min(1).max(8192).regex(/^[A-Za-z0-9_-]+$/, { message: "ต้องเป็น base64url" });

/** ผล `startAuthentication()` ของ @simplewebauthn/browser (AuthenticationResponseJSON) · ตรวจลายเซ็นที่ server */
export const PasskeyAuthResponse = z
  .object({
    id: b64url,
    rawId: b64url,
    type: z.literal("public-key"),
    response: z
      .object({
        clientDataJSON: b64url,
        authenticatorData: b64url,
        signature: b64url,
        userHandle: b64url.optional(),
      })
      .passthrough(),
    clientExtensionResults: z.record(z.string(), z.unknown()).optional(),
    authenticatorAttachment: z.string().max(40).optional(),
  })
  .passthrough();

/** ผล `startRegistration()` (RegistrationResponseJSON) */
export const PasskeyRegistrationResponse = z
  .object({
    id: b64url,
    rawId: b64url,
    type: z.literal("public-key"),
    response: z
      .object({
        clientDataJSON: b64url,
        attestationObject: b64url,
        transports: z.array(z.string().max(40)).max(10).optional(),
      })
      .passthrough(),
    clientExtensionResults: z.record(z.string(), z.unknown()).optional(),
    authenticatorAttachment: z.string().max(40).optional(),
  })
  .passthrough();

/** ผลแตะนิ้ว 1 ครั้งที่แนบไปกับคำสั่งเขียน */
export const PasskeyAssertion = z.object({ origin, authResp: PasskeyAuthResponse }).strict();

export const OfficeWhoamiRequest = z.object({}).strict();
export const OfficeRosterGetRequest = z.object({}).strict();

export const OfficeResolveEmailRequest = z
  .object({ email: z.string().trim().toLowerCase().max(254).pipe(z.email()) })
  .strict()
  .describe("root พิมพ์อีเมล → server หาใน Firebase Auth แล้วคืน uid/ชื่อให้ยืนยัน (ยังไม่มีทะเบียนพนักงานบริษัท)");

export const OfficeRosterPersonInput = z
  .object({
    uid: WatcherUid,
    name: z.string().trim().max(120),
    level: WatcherLevel,
  })
  .strict();

export const OfficeRosterSaveRequest = z
  .object({
    people: z.array(OfficeRosterPersonInput).max(WATCHER_ROSTER_MAX).describe("รายชื่อทั้งชุด (แทนที่ทั้ง doc) · อีเมลไม่รับจากจอ server ดึงจาก Auth"),
    expectCount: z.number().int().nonnegative().describe("จำนวนที่จอเห็น · ไม่ตรง people.length = 400 count_mismatch"),
    allowEmpty: z.literal(true).optional().describe("รายชื่อว่าง = ไม่มีทีมงานเลย · ต้องติ๊กยืนยัน"),
    baseRosterSha: z.string().max(64).regex(/^([0-9a-f]{64})?$/).describe("rosterSha ของชุดที่จอโหลดมา ('' = ยังไม่มี doc) · ไม่ตรงของบนฐาน = 409 roster_changed"),
    passkey: PasskeyAssertion,
  })
  .strict();

export const OfficePasskeyRegisterOptionsRequest = z
  .object({ origin, authResp: PasskeyAuthResponse.optional().describe("มีกุญแจอยู่แล้ว = ต้องแตะกุญแจเดิมก่อน · ยังไม่มี = ห้ามส่ง") })
  .strict();

export const OfficePasskeyRegisterVerifyRequest = z
  .object({ origin, attResp: PasskeyRegistrationResponse, label: z.string().trim().max(60).optional() })
  .strict();

export const OfficePasskeyAssertOptionsRequest = z.object({ origin }).strict();

export const OfficePasskeyAssertVerifyRequest = z.object({ origin, authResp: PasskeyAuthResponse }).strict();

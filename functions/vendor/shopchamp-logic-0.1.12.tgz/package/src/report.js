// report — สูตรรายงานที่ server (`pos_heavy` · ก้อน 9e · DEV-0001) และเว็บ (DEV-0002) ใช้ร่วมกัน · ฟังก์ชันล้วน ไม่แตะฐาน ไม่อ่านนาฬิกา
//
// ผู้ใช้: shopchamp_server/functions/pos/report/*.js (สัญญา shopchamp-center/api/report.*.yaml)
// อ่านเอกสารทุกรุ่นที่แอปเก่าเขียน: บิล `Bill` + `BillLegacyV1` (AnyBill) · ประวัติกะ `ShiftHistory` + `ShiftHistoryLegacy` (AnyShiftHistory)
//   ไฟล์นี้ไม่ dep schema ⇒ แยกรุ่นด้วย key ตัวแยกเดียวกับ schema: บิลมี `receiptNumber` = current · ไม่มีแต่มี `orderId` = legacyV1
//   ประวัติกะมี `thisPayment` = current · ไม่มี = legacy (ไม่มีก้อนสรุป)
//
// ปิดบั๊ก (ฝั่งสูตร · รหัสตาม lanes/dev/source/bug-decisions/ · Pack เคาะ "แก้ทั้งหมด" 2026-11-06):
//   #24 WR-01  วันของรายงาน = วันธุรกิจตาม cutOff (businessDay) ไม่ใช่เที่ยงคืน · ทุก endpoint ใช้ reportRange/businessDayOf ตัวเดียว
//   #23 WR-02  ส่วนลดท้ายบิลกระจายลงรายสินค้าตามสัดส่วน `net` ตอนอ่าน (distributeBillDiscount) · items[] และ categories[] มีทั้งก่อนและหลังกระจาย
//   #21 RT-05  ใบกำกับที่ยกเลิกยังอยู่ในรายงานภาษี มีป้าย voided · ยอดแยก active / voided ไม่ปนกัน
//   WR-09      รายงานภาษีมีเลขใบกำกับ `taxNumber` · ก่อนภาษี + ภาษี + ปัดเศษ + ยกเว้น = สุทธิ ทุกแถว (vat.vatDocOf)
//   #19 RT-01  รายการเลขใบเสร็จ/ใบกำกับที่ซ้ำกันในร้าน (เลขจากแอปเก่าที่ออกเองตามนาฬิกาเครื่อง)
//   #18 SC-02  รายงานกะแสดง `lateSales` `lateBillQty` (บิลมาช้าที่ sale.create บวกเข้ารอบเดิม) และยอดรวมหลังบวกบิลมาช้า
//              + บิลที่หากะไม่เจอ (`shiftUnassigned`) นับให้เห็นในรายงานยอดขาย
//   WR-68      บิลยกเลิกไม่นับในยอดขาย (นับแยกเป็น voidQty voidTotal) · ตัวตัดสินเดียว billState.isVoidedBill
//              (WR-04 เป็นบั๊กของเว็บแฟรนไชส์ · สูตรนี้พร้อมใช้ แต่ยังไม่ปิดจนกว่าแฟรนไชส์มีเส้น)
//   WR-42      บิลไม่มี `moneyMustPaid` ไม่ถูกบวก 999 · นับเป็น 0 และนับจำนวนไว้ใน netMissingQty
//   WR-41      ค่าที่ไม่ใช่ตัวเลข = 0 ผ่าน money.toNumber จุดเดียว · คิดเป็นสตางค์จำนวนเต็ม
//   WR-14      ประวัติกะลงวันธุรกิจของเวลาปิดกะ (ค้นวันปิดแล้วเจอ) · ❓ ทางเลือกนี้ต้องให้ Pack ยืนยัน (chunk9/9e-reports.md คำถาม 1)
//   WR-50      เวลาในประวัติกะที่เป็น map `{_seconds,_nanoseconds}` อ่านได้ ไม่ทำจอขาว
//   ด่านแพ็กเกจเดิม: ร้านไม่พรีเมี่ยมเลือกวันเริ่มย้อนเกิน 62 วันไม่ได้ (เว็บเดิม own:components/TimeContainer.js:77-83 · freeWindowOk)
//              ❓ ค่าตั้งต้นรอ Pack ยืนยัน (chunk9/9e-reports.md คำถาม 7)
//
// สูตรเดิมที่เทียบ (lanes/dev/source/compare/old-logic/report.js · ตัวเทียบอยู่ใน test/report.test.js):
//   srv:apis/bill.js:64-96 `/bill/summary` (จอประวัติบิลของแอป main3 BillHistoryScreen.js:240-241) qty · totalSale · average
//   own:screens/ReportVatScreen.js ตัดบิล void ทิ้งก่อนถึงจอ (own:redux/billSlice.js:151-152,160) ⇒ #21
//
// ❌ ไม่ throw · ของที่อ่านไม่ได้นับเป็น 0 และนับจำนวนไว้ให้เห็น ไม่ทิ้งเงียบ
"use strict";

const { toNumber, toSatang, fromSatang } = require("./money");
const { isVoidedBill } = require("./billState");
const { businessDayOf, businessDayRange } = require("./businessDay");
const { toMillis, summarizeShiftBills, duringTotals } = require("./shift");
const { billDiscountTotal, distributeBillDiscount } = require("./distributeBillDiscount");
const { vatDocOf } = require("./vat");

/** ช่วงยาวสุดของคำขอรายงาน 1 ครั้ง (วันธุรกิจ) · เว็บที่ต้องการหลายเดือนเรียกทีละช่วง */
const REPORT_MAX_DAYS = 31;
/** ร้านไม่พรีเมี่ยมย้อนวันเริ่มได้ไม่เกินกี่วัน (เว็บเดิม `minusDays(today, 62)` · own:components/TimeContainer.js:77-83) */
const FREE_BACK_DAYS = 62;
const DAY_MS = 86400000;
const MONTH_KEY = /^(\d{4})(\d{2})$/;

const objs = (arr) => (Array.isArray(arr) ? arr.filter((x) => x && typeof x === "object") : []);
const str = (v) => (typeof v === "string" ? v : "");
const baht = (s) => fromSatang(s);
const iso = (ms) => (ms === null || ms === undefined ? null : new Date(ms).toISOString());

/**
 * reportRange({fromDay, toDay, cutOff}) — ช่วงเวลาของรายงานจากวันธุรกิจแรกถึงวันสุดท้าย (รวมทั้ง 2 วัน)
 * @returns {{ok:true, fromKey, toKey, start:Date, end:Date, days:string[]}
 *          | {ok:false, reason:'day-invalid'|'range-reversed'|'range-too-long'}}
 *   บิลอยู่ในช่วงเมื่อ start < เวลา <= end (นิยามเดียวกับ businessDay) · ไม่อ่านนาฬิกา
 */
function reportRange({ fromDay, toDay, cutOff } = {}) {
  const a = businessDayRange(fromDay, cutOff);
  const b = businessDayRange(toDay, cutOff);
  if (!a.ok || !b.ok) return { ok: false, reason: "day-invalid" };
  const n = Math.round((b.start.getTime() - a.start.getTime()) / DAY_MS) + 1;
  if (n < 1) return { ok: false, reason: "range-reversed" };
  if (n > REPORT_MAX_DAYS) return { ok: false, reason: "range-too-long" };
  const days = [];
  for (let i = 0; i < n; i++) {
    const k = businessDayOf(new Date(a.start.getTime() + i * DAY_MS + 1), cutOff);
    days.push(k.key);
  }
  return { ok: true, fromKey: a.key, toKey: b.key, start: a.start, end: b.end, days };
}

/**
 * freeWindowOk({fromDay, now, cutOff}) — ร้านที่ไม่มีพรีเมี่ยมเปิดช่วงนี้ได้ไหม (กติกาเว็บเดิม: วันเริ่มย้อนได้ไม่เกิน 62 วันจากวันนี้)
 *   วันนี้ = วันธุรกิจของ now ตาม cutOff · ตรวจเฉพาะวันเริ่ม (เว็บเดิมตรวจแค่วันเริ่ม) · วันผิดรูป/นาฬิกาเพี้ยน = false (fail-closed)
 */
function freeWindowOk({ fromDay, now, cutOff } = {}) {
  const t = businessDayOf(now, cutOff);
  if (!t.ok) return false;
  const today = businessDayRange(t.key, cutOff);
  const from = businessDayRange(fromDay, cutOff);
  if (!today.ok || !from.ok) return false;
  return from.start.getTime() >= today.start.getTime() - FREE_BACK_DAYS * DAY_MS;
}

/** monthPrefix('202611') → {ok, key} · เดือนผิดรูป = ok:false */
function monthPrefix(month) {
  const m = typeof month === "string" ? MONTH_KEY.exec(month) : null;
  if (!m) return { ok: false, reason: "month-invalid" };
  const y = Number(m[1]), mo = Number(m[2]);
  if (y < 2000 || y > 9999 || mo < 1 || mo > 12) return { ok: false, reason: "month-invalid" };
  return { ok: true, key: month };
}

/** รุ่นของบิล: 'current' (มี receiptNumber) · 'legacyV1' (ไม่มี receiptNumber แต่มี orderId) · 'unknown' */
function billShapeOf(bill) {
  if (!bill || typeof bill !== "object") return "unknown";
  if (typeof bill.receiptNumber === "string") return "current";
  if (bill.receiptNumber === undefined && typeof bill.orderId === "string") return "legacyV1";
  return "unknown";
}

/** เวลาขาย (ms) · soldAt (บิลออฟไลน์แอปใหม่) ก่อน ไม่งั้น dateTime · อ่านไม่ได้ = null */
function saleMsOf(bill) {
  if (!bill || typeof bill !== "object") return null;
  const s = toMillis(bill.soldAt);
  return s !== null ? s : toMillis(bill.dateTime);
}

/**
 * billNetSatang(bill) → {satang, missing}
 *   current: `moneyMustPaid` · ไม่มีค่า = 0 และ missing:true (WR-42 · เดิมเว็บเติม 999)
 *   legacyV1: totalPrice − eyosDiscount − discount (สูตรจอประวัติของแอปรุ่นแรก `@5d69306d` src/screens/HistoryScreen.js:190)
 */
function billNetSatang(bill) {
  const shape = billShapeOf(bill);
  if (shape === "legacyV1") {
    return { satang: toSatang(bill.totalPrice) - toSatang(bill.eyosDiscount) - toSatang(bill.discount), missing: false };
  }
  const m = bill && bill.moneyMustPaid;
  if (m === undefined || m === null || m === "") return { satang: 0, missing: true };
  return { satang: toSatang(m), missing: false };
}

/**
 * reportBillRow(id, bill, cutOff) — แถวบิล 1 ใบในรายงาน (รูปเดียวทุกรุ่น)
 *   { id, shape, number, taxNumber, at, businessDay, net, netMissing, voided, cashierName, posId, paymentNames, payments, offline, shiftUnassigned, amendOf, amendedBy, voidStaff, reason }
 *   number = receiptNumber (current) | orderId (legacyV1) · at = เวลาขาย ISO | null
 */
function reportBillRow(id, bill, cutOff) {
  const b = bill && typeof bill === "object" ? bill : {};
  const shape = billShapeOf(b);
  const ms = saleMsOf(b);
  const day = ms === null ? null : businessDayOf(ms, cutOff);
  const net = billNetSatang(b);
  const names = shape === "legacyV1"
    ? (str(b.paymentType) ? [b.paymentType] : [])
    : objs(b.payment).map((p) => str(p.name)).filter((x) => x);
  return {
    id,
    shape,
    number: shape === "legacyV1" ? b.orderId : str(b.receiptNumber),
    taxNumber: str(b.taxNumber) || null,
    at: iso(ms),
    businessDay: day && day.ok ? day.key : null,
    net: baht(net.satang),
    netMissing: net.missing,
    voided: isVoidedBill(b),
    cashierName: shape === "legacyV1" ? "" : str(b.cashierName),
    posId: str(b.posId),
    paymentNames: names,
    payments: shape === "legacyV1" ? [] : objs(b.payment).map((p) => ({ id: p.id === undefined ? null : p.id, name: str(p.name), amount: baht(toSatang(p.amount)) })),
    offline: b.offlineSync === true,
    shiftUnassigned: b.shiftUnassigned === true,
    amendOf: str(b.amendOf) || null,
    amendedBy: str(b.amendedBy) || null,
    voidStaff: str(b.voidStaff) || (b.void && typeof b.void === "object" ? str(b.void.user) : "") || null,
    reason: str(b.reason) || (b.void && typeof b.void === "object" ? str(b.void.remark) : "") || null,
  };
}

/** เรียงแถวบิลล่าสุดก่อน (เวลาเท่ากันเรียง id มากก่อน) · เวลาอ่านไม่ได้ไปท้าย */
function sortRowsDesc(rows) {
  return rows.slice().sort((x, y) => {
    const a = x.at === null ? -Infinity : Date.parse(x.at);
    const b = y.at === null ? -Infinity : Date.parse(y.at);
    if (a !== b) return b - a;
    return x.id < y.id ? 1 : x.id > y.id ? -1 : 0;
  });
}

// ───────────────────────── ยอดขาย (#23 #24 WR-04 WR-42) ─────────────────────────

/**
 * summarizeSales(entries, {cutOff, fromDay, toDay, smartCategory}) — ยอดขายของช่วงวันธุรกิจ
 * @param entries [{id, data}] บิลทุกรุ่นที่อ่านจากฐาน (server ค้นด้วยช่วงเวลาแล้ว · บิลนอกช่วงนับใน outsideQty ไม่รวมยอด)
 * @returns {{ok:false, reason} | {ok:true,
 *   billQty, totalSale, average, voidQty, voidTotal, netMissingQty, legacyV1Qty, unknownQty, outsideQty,
 *   unassignedQty, unassignedTotal, offlineQty, amendedQty,
 *   days:[{day, billQty, totalSale, voidQty}],
 *   payments, cashiers, campaigns (สูตรเดียวกับรายงานกะ shift.summarizeShiftBills · บิลรุ่นปัจจุบันเท่านั้น),
 *   categories:[{id, name, qty, totalPrice, net, billDiscountShare, netAfterBillDiscount}] (ชื่อหมวดและการจัดกลุ่มแบบรายงานกะ · ยอดหลังกระจายส่วนลดท้ายบิล #23),
 *   billDiscount:{manual, point, campaign, total, applied, excess},
 *   items:[{key, id, name, qty, count, totalPrice, net, billDiscountShare, netAfterBillDiscount, totalCost}],
 *   itemsNetAfterBillDiscount, reconcileDiff, currentTotal, legacyV1Total }}
 *   totalSale = currentTotal + legacyV1Total (current `moneyMustPaid` + legacyV1 สูตรรุ่นแรก · บิลไม่ยกเลิก) · average ปัด 2 ตำแหน่ง ครึ่งปัดออกจากศูนย์
 *   ⚠️ payments cashiers campaigns categories items นับเฉพาะบิลรุ่นปัจจุบัน (บิลรุ่นแรกไม่มีรายช่องจ่าย/รายสินค้าที่มียอด)
 *      ⇒ ผลรวมช่องจ่ายเทียบกับ currentTotal ไม่ใช่ totalSale · ส่วนต่างของบิลรุ่นแรกอยู่ใน legacyV1Total ให้จอแสดง ไม่ซ่อน
 *   reconcileDiff = totalSale(current) − ผลรวม netAfterBillDiscount (ปัดเศษ · VAT แยก · แถวติดลบ) ให้จอแสดงว่าต่างกันเท่าไรไม่ซ่อน
 */
function summarizeSales(entries, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const range = reportRange({ fromDay: o.fromDay, toDay: o.toDay, cutOff: o.cutOff });
  if (!range.ok) return { ok: false, reason: range.reason };
  const dayMap = new Map(range.days.map((d) => [d, { day: d, billQty: 0, total: 0, voidQty: 0 }]));
  let billQty = 0, total = 0, voidQty = 0, voidTotal = 0, netMissingQty = 0, legacyV1Qty = 0, unknownQty = 0, outsideQty = 0;
  let unassignedQty = 0, unassignedTotal = 0, offlineQty = 0, amendedQty = 0, curTotal = 0;
  const current = [];
  const disc = { manual: 0, point: 0, campaign: 0, applied: 0, excess: 0 };
  const items = new Map();
  // หมวด: ชื่อจาก smartCategory[0].value · จัดกลุ่มด้วย category[0] (ไม่มีหมวด = "id" "No Category") แบบ shift.summarizeShiftBills
  const smart = o.smartCategory;
  const catNames = Array.isArray(smart) && smart[0] && Array.isArray(smart[0].value) ? objs(smart[0].value) : [];
  const cats = [];
  for (const e of objs(entries)) {
    const b = e.data && typeof e.data === "object" ? e.data : null;
    if (!b) continue;
    const row = reportBillRow(e.id, b, o.cutOff);
    if (row.shape === "unknown") { unknownQty++; continue; }
    const d = row.businessDay ? dayMap.get(row.businessDay) : undefined;
    if (!d) { outsideQty++; continue; }
    const net = billNetSatang(b).satang;
    if (row.voided) {
      voidQty++; voidTotal += net; d.voidQty++;
      if (row.amendedBy) amendedQty++;
      if (row.shape === "current") current.push(b); // summarizeShiftBills นับ void ของมันเอง
      continue;
    }
    billQty++; total += net; d.billQty++; d.total += net;
    if (row.netMissing) netMissingQty++;
    if (row.offline) offlineQty++;
    if (row.shiftUnassigned) { unassignedQty++; unassignedTotal += net; }
    if (row.shape === "legacyV1") { legacyV1Qty++; continue; }
    current.push(b);
    curTotal += net;
    // #23: ส่วนลดท้ายบิลกระจายลงรายสินค้าตามสัดส่วน net
    const dt = billDiscountTotal(b);
    disc.manual += toSatang(dt.manual); disc.point += toSatang(dt.point); disc.campaign += toSatang(dt.campaign);
    const dist = distributeBillDiscount(b.product, dt.total);
    disc.applied += toSatang(dist.applied); disc.excess += toSatang(dist.excess);
    for (const ln of dist.lines) {
      const id = typeof ln.id === "string" && ln.id !== "" ? ln.id : null;
      const name = str(ln.name);
      const key = id !== null ? `id:${id}` : `name:${name}`;
      let it = items.get(key);
      if (!it) { it = { key, id, name, qty: 0, count: 0, totalPrice: 0, net: 0, share: 0, after: 0, cost: 0 }; items.set(key, it); }
      it.qty = Number((it.qty + toNumber(ln.qty)).toPrecision(12)) || 0;
      it.count++;
      it.totalPrice += toSatang(ln.totalPrice);
      it.net += toSatang(ln.net);
      it.share += toSatang(ln.billDiscountShare);
      it.after += toSatang(ln.netAfterBillDiscount);
      it.cost += toSatang(ln.totalCost);
      const cl = Array.isArray(ln.category) ? ln.category : [];
      const cat = cl.length === 0 ? "id" : cl[0];
      let c = cat ? cats.find((x) => x.id === cat) : null;
      if (!c) {
        const nm = cl.length === 0 ? "No Category" : (catNames.find((x) => x.id === cat) || {}).name;
        c = { id: cat === undefined ? null : cat, name: typeof nm === "string" && nm ? nm : "UnKnow Category", qty: 0, totalPrice: 0, net: 0, share: 0, after: 0 };
        cats.push(c);
      }
      c.qty = Number((c.qty + toNumber(ln.qty)).toPrecision(12)) || 0;
      c.totalPrice += toSatang(ln.totalPrice);
      c.net += toSatang(ln.net);
      c.share += toSatang(ln.billDiscountShare);
      c.after += toSatang(ln.netAfterBillDiscount);
    }
  }
  const s = summarizeShiftBills(current, { smartCategory: o.smartCategory });
  const itemList = [...items.values()].map((it) => ({
    key: it.key, id: it.id, name: it.name, qty: it.qty, count: it.count,
    totalPrice: baht(it.totalPrice), net: baht(it.net), billDiscountShare: baht(it.share),
    netAfterBillDiscount: baht(it.after), totalCost: baht(it.cost),
  })).sort((a, b) => b.netAfterBillDiscount - a.netAfterBillDiscount || (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  const afterAll = itemList.reduce((acc, it) => acc + toSatang(it.netAfterBillDiscount), 0);
  return {
    ok: true,
    fromDay: range.fromKey,
    toDay: range.toKey,
    start: range.start.toISOString(),
    end: range.end.toISOString(),
    billQty,
    totalSale: baht(total),
    average: billQty > 0 ? baht(Math.sign(total) * Math.round(Math.abs(total) / billQty)) : 0,
    voidQty,
    voidTotal: baht(voidTotal),
    netMissingQty,
    legacyV1Qty,
    unknownQty,
    outsideQty,
    unassignedQty,
    unassignedTotal: baht(unassignedTotal),
    offlineQty,
    amendedQty,
    days: [...dayMap.values()].map((d) => ({ day: d.day, billQty: d.billQty, totalSale: baht(d.total), voidQty: d.voidQty })),
    payments: s.payments,
    cashiers: s.cashiers,
    campaigns: s.campaigns,
    categories: cats.map((c) => ({
      id: c.id, name: c.name, qty: c.qty, totalPrice: baht(c.totalPrice), net: baht(c.net),
      billDiscountShare: baht(c.share), netAfterBillDiscount: baht(c.after),
    })),
    totalVat: s.totalVat,
    totalRounding: s.totalRounding,
    billDiscount: {
      manual: baht(disc.manual), point: baht(disc.point), campaign: baht(disc.campaign),
      total: baht(disc.manual + disc.point + disc.campaign), applied: baht(disc.applied), excess: baht(disc.excess),
    },
    items: itemList,
    itemsNetAfterBillDiscount: baht(afterAll),
    reconcileDiff: baht(curTotal - afterAll),
    currentTotal: baht(curTotal),
    legacyV1Total: baht(total - curTotal),
  };
}

// ───────────────────────── รายงานภาษีขาย (#21 WR-09) ─────────────────────────

/**
 * taxInvoiceReport(entries, {month, cutOff}) — ใบกำกับภาษีของเดือนภาษี (ตามเลข `taxNumber` ขึ้นต้น YYYYMM)
 * @returns {{ok:false, reason} | {ok:true, month, rows[], active:{qty, net, beforeVat, vatAmount, rounding, noVatAmount},
 *          voided:{qty, net, beforeVat, vatAmount, rounding, noVatAmount}, vatErrorQty, duplicateTaxNumbers[]}}
 *   rows เรียงตามเลขใบกำกับ (เลขเท่ากันเรียง id) · ใบยกเลิกอยู่ในรายการพร้อม voided:true (#21) และไม่รวมในยอด active
 *   แถวเพี้ยน = vatError ไม่รวมยอดทั้ง 2 ฝั่ง แต่ยังอยู่ในรายการ (ไม่ทิ้งเงียบ):
 *     vatDocOf ปัด (net-missing · vat-negative) · net-unreadable (`moneyMustPaid` มีค่าแต่อ่านเป็นตัวเลขไม่ได้ เช่น "abc")
 *     · before-vat-negative (สุทธิ − ปัดเศษ − ภาษี − ยกเว้น < 0 = ตัวเลขในบิลขัดกันเอง)
 */
// moneyMustPaid มีค่าแต่ไม่ใช่ตัวเลขที่อ่านได้ (money.toNumber คืน 0 เงียบ ๆ) · ตัวเลข 0 จริงไม่นับ
function netUnreadable(m) {
  if (typeof m === "number") return !Number.isFinite(m);
  if (typeof m !== "string") return m !== undefined && m !== null;
  return m.trim() !== "" && toNumber(m) === 0 && !/^\s*[-+]?0*(\.0*)?\s*$/.test(m);
}
function vatRowOf(b) {
  const v = vatDocOf(b);
  if (!v.ok) return v;
  if (netUnreadable(b.moneyMustPaid)) return { ok: false, reason: "net-unreadable" };
  if (v.beforeVat < 0) return { ok: false, reason: "before-vat-negative" };
  return v;
}
function taxInvoiceReport(entries, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const mp = monthPrefix(o.month);
  if (!mp.ok) return { ok: false, reason: mp.reason };
  const zero = () => ({ qty: 0, net: 0, beforeVat: 0, vatAmount: 0, rounding: 0, noVatAmount: 0 });
  const act = zero(), vd = zero();
  let vatErrorQty = 0;
  const rows = [];
  const seen = new Map();
  for (const e of objs(entries)) {
    const b = e.data && typeof e.data === "object" ? e.data : null;
    if (!b) continue;
    const tn = str(b.taxNumber);
    if (!tn.startsWith(mp.key)) continue;
    const base = reportBillRow(e.id, b, o.cutOff);
    const v = vatRowOf(b);
    const tc = b.taxCustomer && typeof b.taxCustomer === "object" ? b.taxCustomer : {};
    const row = {
      id: e.id,
      taxNumber: tn,
      receiptNumber: base.number,
      at: base.at,
      businessDay: base.businessDay,
      customerName: str(tc.name),
      customerTaxId: str(tc.taxNumber) || str(tc.taxId),
      voided: base.voided,
      voidStaff: base.voidStaff,
      reason: base.reason,
      amendedBy: base.amendedBy,
      vatType: v.ok ? v.type : null,
      net: v.ok ? v.net : null,
      beforeVat: v.ok ? v.beforeVat : null,
      vatAmount: v.ok ? v.vatAmount : null,
      rounding: v.ok ? v.rounding : null,
      noVatAmount: v.ok ? v.noVatAmount : null,
      vatError: v.ok ? null : v.reason,
    };
    rows.push(row);
    seen.set(tn, (seen.get(tn) || 0) + 1);
    if (!v.ok) { vatErrorQty++; continue; }
    const t = row.voided ? vd : act;
    t.qty++;
    t.net += toSatang(v.net); t.beforeVat += toSatang(v.beforeVat); t.vatAmount += toSatang(v.vatAmount);
    t.rounding += toSatang(v.rounding); t.noVatAmount += toSatang(v.noVatAmount);
  }
  rows.sort((a, b) => (a.taxNumber < b.taxNumber ? -1 : a.taxNumber > b.taxNumber ? 1 : a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  const out = (t) => ({ qty: t.qty, net: baht(t.net), beforeVat: baht(t.beforeVat), vatAmount: baht(t.vatAmount), rounding: baht(t.rounding), noVatAmount: baht(t.noVatAmount) });
  return {
    ok: true,
    month: mp.key,
    rows,
    active: out(act),
    voided: out(vd),
    vatErrorQty,
    duplicateTaxNumbers: [...seen.entries()].filter(([, n]) => n > 1).map(([k]) => k).sort(),
  };
}

// ───────────────────────── เลขเอกสารซ้ำ (#19) ─────────────────────────

/**
 * duplicateNumberReport(entries, {month, cutOff}) — เลขใบเสร็จและเลขใบกำกับที่ซ้ำกันในร้าน ของเดือนตามเลขเอกสาร (YYYYMM)
 * @returns {{ok:false, reason} | {ok:true, month, receipt:{groups[], billQty}, tax:{groups[], billQty}, scanned}}
 *   group = {number, count, bills:[{id, at, net, voided, posId, cashierName, offline}]} เรียงเลขน้อยไปมาก · ใบในกลุ่มเรียงเวลาขาย
 *   นับใบยกเลิกด้วย (เลขที่ออกไปแล้วยังเป็นของกระดาษที่ลูกค้าถือ) · เลขว่าง/ไม่ใช่ข้อความไม่นับ
 *   ⚠️ เดือนของเลขอาจไม่ตรงเดือนที่ขายจริงเมื่อนาฬิกาเครื่องเพี้ยน (ต้นเหตุของ #19) ⇒ จัดกลุ่มตามเลข ไม่ตามเวลา
 */
function duplicateNumberReport(entries, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const mp = monthPrefix(o.month);
  if (!mp.ok) return { ok: false, reason: mp.reason };
  const byReceipt = new Map(), byTax = new Map();
  let scanned = 0;
  const add = (map, num, item) => {
    if (!num.startsWith(mp.key)) return;
    const g = map.get(num) || [];
    if (!g.some((x) => x.id === item.id)) g.push(item);
    map.set(num, g);
  };
  for (const e of objs(entries)) {
    const b = e.data && typeof e.data === "object" ? e.data : null;
    if (!b) continue;
    scanned++;
    const r = reportBillRow(e.id, b, o.cutOff);
    const item = { id: e.id, at: r.at, net: r.net, voided: r.voided, posId: r.posId, cashierName: r.cashierName, offline: r.offline };
    if (r.shape === "current" && r.number) add(byReceipt, r.number, item);
    if (r.taxNumber) add(byTax, r.taxNumber, item);
  }
  const groups = (map) => [...map.entries()]
    .filter(([, g]) => g.length > 1)
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([number, g]) => ({
      number,
      count: g.length,
      bills: g.slice().sort((x, y) => (Date.parse(x.at || "") || 0) - (Date.parse(y.at || "") || 0) || (x.id < y.id ? -1 : 1)),
    }));
  const rg = groups(byReceipt), tg = groups(byTax);
  return {
    ok: true,
    month: mp.key,
    scanned,
    receipt: { groups: rg, billQty: rg.reduce((a, g) => a + g.count, 0) },
    tax: { groups: tg, billQty: tg.reduce((a, g) => a + g.count, 0) },
  };
}

// ───────────────────────── รายงานกะ (#18 WR-14 WR-50) ─────────────────────────

/** รุ่นของประวัติกะ: 'current' (มีก้อนสรุป thisPayment) · 'legacy' (ไม่มี) */
function shiftShapeOf(doc) {
  return doc && typeof doc === "object" && Array.isArray(doc.thisPayment) ? "current" : "legacy";
}

// ชื่อพนักงานจาก shop.humanResource ด้วย id · ไม่เจอ = "" (ไม่เอา id มาแสดงแทนชื่อ)
function staffNameOf(humanResource, id) {
  if (typeof id !== "string" || id === "") return "";
  const h = objs(humanResource).find((x) => x.id === id);
  return h ? str(h.name) : "";
}

/**
 * shiftReportRow(docId, doc, cutOff, {humanResource}) — ประวัติกะ 1 ใบ · อ่านได้ทุกรุ่น · เวลา map `{_seconds}` อ่านได้ (WR-50)
 *   รุ่นแรก `openBy` `closeBy` เป็น id พนักงาน (schema ShiftHistoryLegacy) ⇒ ชื่อมาจาก humanResource ของร้าน · ไม่เจอ = "" · id คืนแยกใน openById closeById
 *   businessDay = วันธุรกิจของเวลาปิดกะ (WR-14 · ❓ รอ Pack ยืนยัน) · summary = null เมื่อเป็นรุ่นแรก (ไม่มีก้อนสรุปให้อ่าน)
 *   totalNetWithLate = thisTotalNet + lateSales (#18) · late* ไม่มี = 0
 */
function shiftReportRow(docId, doc, cutOff, opts) {
  const d = doc && typeof doc === "object" ? doc : {};
  const hr = opts && typeof opts === "object" ? opts.humanResource : undefined;
  const shape = shiftShapeOf(d);
  const openMs = toMillis(d.openTime);
  const closeMs = toMillis(d.closeTime);
  const byOpen = opts && typeof opts === "object" && opts.dayBy === "open";
  const dayMs = byOpen ? openMs : closeMs;
  const day = dayMs === null ? null : businessDayOf(dayMs, cutOff);
  const lateS = toSatang(d.lateSales);
  const lateQty = Math.max(0, Math.trunc(toNumber(d.lateBillQty)));
  let summary = null;
  if (shape === "current") {
    const netS = toSatang(d.thisTotalNet);
    summary = {
      billQty: toNumber(d.thisSelectedQty),
      voidQty: toNumber(d.thisVoidQty),
      totalNet: baht(netS),
      cashSales: baht(toSatang(d.thisTotalCash)),
      totalVat: baht(toSatang(d.thisVat)),
      payments: objs(d.thisPayment).map((p) => ({ id: p.id === undefined ? null : p.id, name: str(p.name), amount: baht(toSatang(p.amount)), qty: toNumber(p.qty) })),
      totalNetWithLate: baht(netS + lateS),
      // ก้อนสรุปที่แอปเขียนตอนปิดกะ ส่งต่อให้ Modal_Shift ของเว็บ (DEV-0002) · ตัวเลขผ่าน toSatang
      categories: objs(d.thisCategory).map((c) => ({ id: c.id === undefined ? null : c.id, name: str(c.name), qty: toNumber(c.thisQty), totalPrice: baht(toSatang(c.thisTotalPrice)) })),
      products: objs(d.thisProduct).map((c) => ({ id: c.id === undefined ? null : c.id, name: str(c.name), qty: toNumber(c.thisQty), totalPrice: baht(toSatang(c.thisTotalPrice)) })),
      cashiers: objs(d.thisCashier).map((c) => ({ cashierId: c.cashierId === undefined ? null : c.cashierId, cashierName: str(c.cashierName), amount: baht(toSatang(c.amount)) })),
      campaigns: objs(d.thisCampaign).map((c) => ({ id: c.id === undefined ? null : c.id, name: str(c.name), qty: toNumber(c.qty), discount: baht(toSatang(c.discount)) })),
      saleRate: baht(toSatang(d.saleRate)),
      manualDiscount: baht(toSatang(d.totalManualDiscount)),
      pointDiscount: baht(toSatang(d.totalPointDiscount)),
      productDiscount: baht(toSatang(d.totalProductDiscount)),
    };
  }
  // เงินเข้าออกระหว่างกะ (สูตรเดียวกับรายงานกะ shift.duringTotals · type ข้อความรุ่นเก่า map เป็น 1/2 · กันแถวซ้ำด้วย entryId)
  const during = duringTotals(d.duringShift);
  const duringRows = objs(d.duringShift).map((x) => ({
    entryId: str(x.entryId) || null,
    type: x.type === "เติมเงิน" ? 1 : x.type === "ถอนเงิน" ? 2 : x.type,
    amount: baht(toSatang(x.amount)),
    staff: str(x.staff),
    comment: str(x.comment),
    at: iso(toMillis(x.timestamp)),
  }));
  const closeCashS = d.closeCash === "" || d.closeCash === undefined || d.closeCash === null ? null : toSatang(d.closeCash);
  const withDrawS = toSatang(d.closeWithDraw);
  const cashSalesS = summary ? toSatang(summary.cashSales) : null;
  return {
    id: docId,
    shape,
    shiftId: str(d.id) || null,
    posId: str(d.posId) || null,
    shiftCount: d.shiftCount === undefined ? null : toNumber(d.shiftCount),
    openTime: iso(openMs),
    closeTime: iso(closeMs),
    businessDay: day && day.ok ? day.key : null,
    openName: shape === "current" ? str(d.openName) : str(d.openName) || staffNameOf(hr, d.openBy),
    closeName: shape === "current" ? str(d.closeName) : staffNameOf(hr, d.closeBy),
    openById: shape === "current" ? str(d.openId) || null : str(d.openBy) || str(d.openId) || null,
    closeById: shape === "current" ? str(d.closeId) || null : str(d.closeBy) || null,
    openCash: baht(toSatang(d.openCash)),
    closeCash: d.closeCash === "" || d.closeCash === undefined || d.closeCash === null ? null : baht(toSatang(d.closeCash)),
    closeDiff: baht(toSatang(d.closeDiff)),
    lateSales: baht(lateS),
    lateBillQty: lateQty,
    duringShift: duringRows,
    cashIn: during.cashIn,
    cashOut: during.cashOut,
    closeWithDraw: baht(withDrawS),
    // เงินที่ควรมีในลิ้นชัก = ขายเงินสด + เงินเปิดกะ + เติม − ถอน (สูตรจอประวัติกะเว็บเดิม own:screens/ReportShiftScreen.js:37) · รุ่นแรกไม่มียอดขายเงินสด = null
    cashExpected: cashSalesS === null ? null : baht(cashSalesS + toSatang(d.openCash) + toSatang(during.cashIn) - toSatang(during.cashOut)),
    // เงินคงเหลือในลิ้นชัก = เงินนับตอนปิด − ถอนตอนปิด (own:screens/ReportShiftScreen.js:38) · ยังไม่ปิด = null
    cashRemain: closeCashS === null ? null : baht(closeCashS - withDrawS),
    summary,
  };
}

/**
 * shiftReport(entries, {cutOff, fromDay, toDay, humanResource}) — ประวัติกะของช่วงวันธุรกิจ (ตามเวลาปิด)
 * @returns {{ok:false, reason} | {ok:true, fromDay, toDay, rows[], totals:{shiftQty, legacyQty, totalNet, lateSales, lateBillQty, totalNetWithLate, closeDiff}, outsideQty}}
 *   totals.totalNet รวมเฉพาะกะรุ่นปัจจุบัน (รุ่นแรกไม่มีก้อนสรุป นับใน legacyQty) · rows เรียงเวลาปิดล่าสุดก่อน
 */
function shiftReport(entries, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const range = reportRange({ fromDay: o.fromDay, toDay: o.toDay, cutOff: o.cutOff });
  if (!range.ok) return { ok: false, reason: range.reason };
  const days = new Set(range.days);
  const rows = [];
  let outsideQty = 0, legacyQty = 0, net = 0, late = 0, lateQty = 0, diff = 0;
  for (const e of objs(entries)) {
    const r = shiftReportRow(e.id, e.data, o.cutOff, { humanResource: o.humanResource, dayBy: o.dayBy });
    if (!r.businessDay || !days.has(r.businessDay)) { outsideQty++; continue; }
    rows.push(r);
    late += toSatang(r.lateSales); lateQty += r.lateBillQty; diff += toSatang(r.closeDiff);
    if (r.summary) net += toSatang(r.summary.totalNet);
    else legacyQty++;
  }
  const sortKey = o.dayBy === "open" ? "openTime" : "closeTime";
  rows.sort((a, b) => (Date.parse(b[sortKey]) || 0) - (Date.parse(a[sortKey]) || 0) || (a.id < b.id ? 1 : -1));
  return {
    ok: true,
    fromDay: range.fromKey,
    toDay: range.toKey,
    dayBy: o.dayBy === "open" ? "open" : "close",
    rows,
    totals: {
      shiftQty: rows.length, legacyQty, totalNet: baht(net), lateSales: baht(late), lateBillQty: lateQty,
      totalNetWithLate: baht(net + late), closeDiff: baht(diff),
    },
    outsideQty,
  };
}

// ───────────────────────── รายละเอียดบิลต่อแถว (DEV-0002 · จอ 4.1 4.3 1.2 ของเว็บ) ─────────────────────────

const isTimeObj = (v) => !!v && typeof v === "object" && !Array.isArray(v)
  && (typeof v.toDate === "function" || typeof v.toMillis === "function" || typeof v._seconds === "number" || (typeof v.seconds === "number" && typeof v.nanoseconds === "number"));

/**
 * plainDoc(v) — เอกสารที่ส่งออกเป็น JSON ได้ · เวลาทุกรูป (Timestamp · map {_seconds}) เป็น ISO · ลึกสุด 6 ชั้น
 *   ตัวเลขไม่แปลง (moneyMustPaid ไม่ถูกตีเป็นเวลา) · ค่าที่ลึกเกินคืน null
 */
function plainDoc(v, depth) {
  const d = depth === undefined ? 0 : depth;
  if (v === undefined) return undefined;
  if (v === null || typeof v !== "object") return typeof v === "number" && !Number.isFinite(v) ? null : v;
  if (d > 6) return null;
  if (v instanceof Date) return Number.isFinite(v.getTime()) ? v.toISOString() : null;
  if (isTimeObj(v)) return iso(toMillis(v));
  if (Array.isArray(v)) return v.map((x) => plainDoc(x, d + 1));
  const out = {};
  for (const [k, x] of Object.entries(v)) { const y = plainDoc(x, d + 1); if (y !== undefined) out[k] = y; }
  return out;
}

/**
 * billDetailOf(bill) — ตัวเลขที่จอรายงานคิดจากบิลเต็ม (ยอดสินค้า ส่วนลด ต้นทุน ภาษี ช่องจ่ายหลังหักทอน สมาชิก) · สูตรเดียวทุกจอ
 *   totalPrice = ผลรวม product.totalPrice · totalCost = ผลรวม product.totalCost (บิลรุ่นแรก = bill.totalCost)
 *   discount = {manual, point, campaign, product, total} (manual point campaign จาก billDiscountTotal · product = productDiscount)
 *   vat = vat.vatDocOf + ด่านเดียวกับรายงานภาษี (ยอดอ่านไม่ได้ · ก่อนภาษีติดลบ) · ใช้ไม่ได้ = null และเหตุใน vatError
 *   payments: ช่องจ่ายหลังหักทอน (สูตรรายงานกะ shift.summarizeShiftBills · เงินทอนหักจากช่องเงินสด SC-04)
 */
function billDetailOf(bill) {
  const b = bill && typeof bill === "object" ? bill : {};
  const shape = billShapeOf(b);
  const products = objs(b.product);
  const totalPrice = products.reduce((a, p) => a + toSatang(p.totalPrice), 0);
  const totalCost = shape === "legacyV1" ? toSatang(b.totalCost) : products.reduce((a, p) => a + toSatang(p.totalCost), 0);
  const dt = billDiscountTotal(b);
  const prod = Math.max(0, toSatang(b.productDiscount));
  const discTotal = toSatang(dt.total) + prod;
  let vat = null, vatError = null;
  if (shape === "current") {
    const v = vatRowOf(b);
    if (v.ok) vat = { type: v.type, net: v.net, beforeVat: v.beforeVat, vatAmount: v.vatAmount, rounding: v.rounding, noVatAmount: v.noVatAmount };
    else vatError = v.reason;
  } else vatError = "legacy-bill";
  const payments = shape === "current"
    ? summarizeShiftBills([{ ...b, void: false }], {}).payments.map((p) => ({ id: p.id, name: p.name, amount: p.amount }))
    : [];
  const m = b.member && typeof b.member === "object" ? b.member : {};
  return {
    totalPrice: baht(totalPrice),
    totalCost: baht(totalCost),
    discount: { manual: dt.manual, point: dt.point, campaign: dt.campaign, product: baht(prod), total: baht(discTotal) },
    vat,
    vatError,
    payments,
    memberId: str(m.id) || null,
    memberName: str(m.name) || null,
  };
}

// ───────────────────────── ยอดแยกมิติ (DEV-0002 · จอ 1.1-1.6 2.1-2.6 ของเว็บ) ─────────────────────────

const BREAKDOWN_DIMENSIONS = Object.freeze(["total", "hour", "item", "consignment", "category", "payment", "discount"]);
const BREAKDOWN_GRANULARITY = Object.freeze(["total", "day"]);
const qtyAdd = (a, b) => Number((a + toNumber(b)).toPrecision(12)) || 0;
const THAI_MS = 7 * 3600000;

// ชื่อหมวดชั้นแรก: smartCategory ตัวที่ level 1 (แบบจอเว็บ) ไม่มี = ตัวแรก (แบบรายงานกะ) · ร้านเดียวกันได้ชุดเดียวกัน
function firstLevelNames(smartCategory) {
  const list = objs(smartCategory);
  const lv = list.find((x) => x.level === 1) || list[0];
  return new Map(objs(lv && lv.value).filter((c) => typeof c.id === "string" || typeof c.id === "number").map((c) => [c.id, str(c.name)]));
}

/**
 * salesBreakdown(entries, {cutOff, fromDay, toDay, dimension, granularity, smartCategory}) — ยอดขายแยกตามมิติ ของช่วงวันธุรกิจ
 *   สูตรเดียวกับ summarizeSales: ไม่นับใบยกเลิก (isVoidedBill) · วันตาม cutOff · บิลรุ่นแรกนับในยอดรวม · ส่วนลดท้ายบิลกระจายลงสินค้า (#23)
 *   granularity 'total' = แถวละ key · 'day' = แถวละ (วันธุรกิจ, key) · ผลรวมทุกช่องบวกข้ามช่วงได้ (เว็บที่ขอเกิน 31 วันเรียกทีละช่วงแล้วบวก)
 * @returns {{ok:false, reason} | {ok:true, fromDay, toDay, start, end, dimension, granularity,
 *   totals:{billQty, totalSale, currentTotal, legacyV1Total, legacyV1Qty, totalCost, voidQty, voidTotal, netMissingQty, unknownQty, outsideQty},
 *   periods:[{period, billQty, totalSale, totalCost, voidQty, voidTotal}], rows:[...]}}
 *   แถวตามมิติ (period = null เมื่อ granularity total · ไม่งั้น YYYYMMDD):
 *     total       {period, key:'all', billQty, totalSale, totalCost}                       (รวมบิลรุ่นแรก)
 *     hour        {period, key:'00'..'23', billQty, totalSale}                              (ชั่วโมงเวลาไทยของเวลาขาย · รวมบิลรุ่นแรก)
 *     item        {period, key, id, name, categoryId, qty, count, totalPrice, net, billDiscountShare, netAfterBillDiscount, totalCost}
 *     consignment เหมือน item เฉพาะแถวสินค้าที่ consignment เป็นจริง
 *     category    {period, key, id, name, qty, totalPrice, net, billDiscountShare, netAfterBillDiscount, totalCost} · ไม่มีหมวด key 'none' id null · ชื่อหาไม่เจอ name null
 *     payment     {period, key, id, name, qty, amount}  (สูตรรายงานกะ: เงินทอนหักจากช่องเงินสด · บิลไม่มีช่องจ่าย = 'noId')
 *     discount    {period, key:'manual'|'point'|'product'|'campaign:<id>', id, name, qty, amount}
 *   ⚠️ item consignment category payment discount นับเฉพาะบิลรุ่นปัจจุบัน (บิลรุ่นแรกไม่มีรายสินค้าที่มียอด) ⇒ เทียบกับ totals.currentTotal
 *   opts.itemKey 'barcode' (0.1.7 · ยอดแฟรนไชส์): item/consignment รวมแถวด้วยบาร์โค้ด (key 'bc:<บาร์โค้ด>') และแถวมีช่อง barcode · ไม่ส่ง = เหมือนเดิมทุกไบต์
 */
function salesBreakdown(entries, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const dim = o.dimension;
  const gran = o.granularity === undefined ? "total" : o.granularity;
  if (!BREAKDOWN_DIMENSIONS.includes(dim)) return { ok: false, reason: "dimension-invalid" };
  if (!BREAKDOWN_GRANULARITY.includes(gran)) return { ok: false, reason: "granularity-invalid" };
  const range = reportRange({ fromDay: o.fromDay, toDay: o.toDay, cutOff: o.cutOff });
  if (!range.ok) return { ok: false, reason: range.reason };
  const days = new Set(range.days);
  const per = new Map(range.days.map((d) => [d, { period: d, billQty: 0, total: 0, cost: 0, voidQty: 0, voidTotal: 0 }]));
  const T = { billQty: 0, total: 0, cur: 0, legacyQty: 0, cost: 0, voidQty: 0, voidTotal: 0, netMissingQty: 0, unknownQty: 0, outsideQty: 0 };
  const rows = new Map();
  const curByPeriod = new Map();
  const cats = firstLevelNames(o.smartCategory);
  const rowOf = (period, key, init) => {
    const k = `${period === null ? "" : period}|${key}`;
    let r = rows.get(k);
    if (!r) { r = { period, key, ...init() }; rows.set(k, r); }
    return r;
  };
  const lineInit = () => ({ qty: 0, count: 0, totalPrice: 0, net: 0, share: 0, after: 0, cost: 0 });
  for (const e of objs(entries)) {
    const b = e.data && typeof e.data === "object" ? e.data : null;
    if (!b) continue;
    const shape = billShapeOf(b);
    if (shape === "unknown") { T.unknownQty++; continue; }
    const ms = saleMsOf(b);
    const day = ms === null ? null : businessDayOf(ms, o.cutOff);
    if (!day || !day.ok || !days.has(day.key)) { T.outsideQty++; continue; }
    const p = per.get(day.key);
    const period = gran === "day" ? day.key : null;
    const nt = billNetSatang(b);
    if (isVoidedBill(b)) { T.voidQty++; T.voidTotal += nt.satang; p.voidQty++; p.voidTotal += nt.satang; continue; }
    const detail = billDetailOf(b);
    const cost = toSatang(detail.totalCost);
    T.billQty++; T.total += nt.satang; T.cost += cost; p.billQty++; p.total += nt.satang; p.cost += cost;
    if (nt.missing) T.netMissingQty++;
    if (shape === "legacyV1") T.legacyQty++; else T.cur += nt.satang;
    if (dim === "total" || dim === "hour") {
      const key = dim === "total" ? "all" : String(new Date(ms + THAI_MS).getUTCHours()).padStart(2, "0");
      const r = rowOf(period, key, () => ({ billQty: 0, total: 0, cost: 0 }));
      r.billQty++; r.total += nt.satang; r.cost += cost;
      continue;
    }
    if (shape !== "current") continue;
    if (dim === "payment" || dim === "discount") {
      const pk = period === null ? "" : period;
      if (!curByPeriod.has(pk)) curByPeriod.set(pk, []);
      curByPeriod.get(pk).push(b);
      continue;
    }
    const dist = distributeBillDiscount(b.product, billDiscountTotal(b).total);
    for (const ln of dist.lines) {
      if (dim === "consignment" && !ln.consignment) continue;
      const cl = Array.isArray(ln.category) ? ln.category : [];
      let r;
      if (dim === "category") {
        const cid = cl.length === 0 || cl[0] === "" || cl[0] === null || cl[0] === undefined ? null : cl[0];
        r = rowOf(period, cid === null ? "none" : `id:${cid}`, () => ({ id: cid, name: cid === null ? null : (cats.has(cid) ? cats.get(cid) || null : null), ...lineInit() }));
      } else {
        const id = (typeof ln.id === "string" && ln.id !== "") || typeof ln.id === "number" ? ln.id : null;
        const name = str(ln.name);
        // itemKey 'barcode' (ยอดแฟรนไชส์ · id สินค้าต่างกันทุกสาขา): รวมแถวด้วยบาร์โค้ด · ไม่มีบาร์โค้ด = รวมด้วย id ตามเดิม
        const bc = o.itemKey === "barcode" ? barcodeOf(ln.barcode) : "";
        const key = bc ? `bc:${bc}` : id !== null ? `id:${id}` : `name:${name}`;
        r = rowOf(period, key, () => ({ id, name, categoryId: cl.length ? cl[0] : null, ...(o.itemKey === "barcode" ? { barcode: bc } : {}), ...lineInit() }));
      }
      r.qty = qtyAdd(r.qty, ln.qty); r.count++;
      r.totalPrice += toSatang(ln.totalPrice); r.net += toSatang(ln.net);
      r.share += toSatang(ln.billDiscountShare); r.after += toSatang(ln.netAfterBillDiscount); r.cost += toSatang(ln.totalCost);
    }
  }
  // ช่องจ่าย · ส่วนลด: สูตรรายงานกะตัวเดียว (summarizeShiftBills) ต่อช่วง
  for (const [pk, bills] of curByPeriod) {
    const period = pk === "" ? null : pk;
    const s = summarizeShiftBills(bills, {});
    if (dim === "payment") {
      for (const g of s.payments) {
        const r = rowOf(period, g.id === undefined || g.id === null ? `name:${g.name}` : `id:${g.id}`, () => ({ id: g.id === undefined ? null : g.id, name: g.name, qty: 0, amount: 0 }));
        r.qty += g.qty; r.amount += toSatang(g.amount);
      }
    } else {
      const bills2 = bills;
      const cnt = (f) => bills2.filter(f).length;
      const add = (key, id, name, qty, amt) => {
        if (amt === 0 && qty === 0) return;
        const r = rowOf(period, key, () => ({ id, name, qty: 0, amount: 0 }));
        r.qty += qty; r.amount += amt;
      };
      add("manual", null, null, cnt((b) => toSatang(b.manualDiscount) > 0), toSatang(s.totalManualDiscount));
      add("point", null, null, cnt((b) => toSatang(b.pointDiscount && typeof b.pointDiscount === "object" ? b.pointDiscount.value : 0) > 0), toSatang(s.totalPointDiscount));
      add("product", null, null, cnt((b) => toSatang(b.productDiscount) > 0), toSatang(s.totalProductDiscount));
      s.campaigns.forEach((c, i) => add(c.id === null ? `campaign:#${i}:${c.name}` : `campaign:${c.id}`, c.id, c.name, c.qty, toSatang(c.discount)));
    }
  }
  const out = [...rows.values()].map((r) => {
    const base = { period: r.period, key: r.key };
    if (dim === "total" || dim === "hour") return { ...base, billQty: r.billQty, totalSale: baht(r.total), ...(dim === "total" ? { totalCost: baht(r.cost) } : {}) };
    if (dim === "payment" || dim === "discount") return { ...base, id: r.id, name: r.name, qty: r.qty, amount: baht(r.amount) };
    const line = { qty: r.qty, count: r.count, totalPrice: baht(r.totalPrice), net: baht(r.net), billDiscountShare: baht(r.share), netAfterBillDiscount: baht(r.after), totalCost: baht(r.cost) };
    if (dim === "category") return { ...base, id: r.id, name: r.name, ...line };
    return { ...base, id: r.id, name: r.name, categoryId: r.categoryId, ...(r.barcode !== undefined ? { barcode: r.barcode } : {}), ...line };
  });
  const primary = (r) => (r.netAfterBillDiscount !== undefined ? r.netAfterBillDiscount : r.amount !== undefined ? r.amount : 0);
  out.sort((a, b) => {
    const pa = a.period || "", pb = b.period || "";
    if (pa !== pb) return pa < pb ? -1 : 1;
    if (dim === "hour" || dim === "total") return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
    return primary(b) - primary(a) || (a.key < b.key ? -1 : a.key > b.key ? 1 : 0);
  });
  return {
    ok: true,
    fromDay: range.fromKey,
    toDay: range.toKey,
    start: range.start.toISOString(),
    end: range.end.toISOString(),
    dimension: dim,
    granularity: gran,
    totals: {
      billQty: T.billQty, totalSale: baht(T.total), currentTotal: baht(T.cur), legacyV1Total: baht(T.total - T.cur), legacyV1Qty: T.legacyQty,
      totalCost: baht(T.cost), voidQty: T.voidQty, voidTotal: baht(T.voidTotal), netMissingQty: T.netMissingQty, unknownQty: T.unknownQty, outsideQty: T.outsideQty,
    },
    periods: [...per.values()].map((x) => ({ period: x.period, billQty: x.billQty, totalSale: baht(x.total), totalCost: baht(x.cost), voidQty: x.voidQty, voidTotal: baht(x.voidTotal) })),
    rows: out,
  };
}

/** บาร์โค้ดเป็นข้อความ (ข้อมูลเดิมมีทั้งตัวเลขและข้อความ) · ว่าง/อ่านไม่ได้ = '' */
function barcodeOf(v) {
  if (typeof v === "number" && Number.isFinite(v)) return String(v);
  return typeof v === "string" ? v.trim() : "";
}

// ───────────────────────── ยอดแฟรนไชส์ (DEV-0002 · Pack เคาะ 2026-11-07: สูตรกลางตัวเดียวกับรายงานร้าน) ─────────────────────────

/**
 * franchiseBreakdown(branches, {fromDay, toDay}) — ยอดของแฟรนไชส์ = salesBreakdown ของแต่ละสาขา (cutOff ของสาขานั้น) แล้วบวกข้ามสาขา
 *   ❌ ไม่มีสูตรเงินของตัวเอง: ทุกตัวเลขมาจาก salesBreakdown (ไม่นับใบยกเลิก · ส่วนลดท้ายบิลกระจาย #23 · วันธุรกิจตาม cutOff #24) · ที่นี่แค่บวกสตางค์
 * @param branches [{shopId, cutOff, entries:[{id, data}]}] · บิลของสาขานั้น (server ค้นกว้างกว่าช่วง ⇒ บิลนอกช่วงไม่นับและไม่รายงาน)
 * @returns {{ok:false, reason} | {ok:true, fromDay, toDay,
 *   totals:{billQty, totalSale, average, currentTotal, legacyV1Total, legacyV1Qty, voidQty, voidTotal, netMissingQty, unknownQty, shopQty, shopWithSale},
 *   shops:[{shopId, billQty, totalSale, average, voidQty, voidTotal}]   (ทุกสาขาที่ส่งเข้ามา · เรียงยอดมากก่อน),
 *   hours:[{key:'00'..'23', billQty, totalSale}]                         (ชั่วโมงเวลาไทยของเวลาขาย · เฉพาะชั่วโมงที่มีบิล),
 *   items:[{key, barcode, name, qty, count, totalPrice, net, billDiscountShare, netAfterBillDiscount}] (รวมข้ามสาขาด้วยบาร์โค้ด · เรียงหลังกระจายมากก่อน)}}
 *   items ไม่มีบาร์โค้ด = แยกแถวต่อสาขา (key 'shop:<shopId>|id:<id>') ไม่รวมข้ามร้าน · ชื่อ = ชื่อของแถวแรกที่เจอ
 *   average ปัด 2 ตำแหน่ง ครึ่งปัดออกจากศูนย์ (แบบ summarizeSales)
 */
function franchiseBreakdown(branches, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const range = reportRange({ fromDay: o.fromDay, toDay: o.toDay });
  if (!range.ok) return { ok: false, reason: range.reason };
  const T = { billQty: 0, total: 0, cur: 0, legacyQty: 0, voidQty: 0, voidTotal: 0, netMissingQty: 0, unknownQty: 0 };
  const shops = [];
  const hours = new Map();
  const items = new Map();
  const avg = (s, n) => (n > 0 ? baht(Math.sign(s) * Math.round(Math.abs(s) / n)) : 0);
  for (const br of objs(branches)) {
    const base = { cutOff: br.cutOff, fromDay: o.fromDay, toDay: o.toDay, granularity: "total" };
    const total = salesBreakdown(br.entries, { ...base, dimension: "total" });
    if (!total.ok) return { ok: false, reason: total.reason };
    const t = total.totals;
    const s = { total: toSatang(t.totalSale), voidTotal: toSatang(t.voidTotal) };
    T.billQty += t.billQty; T.total += s.total; T.cur += toSatang(t.currentTotal); T.legacyQty += t.legacyV1Qty;
    T.voidQty += t.voidQty; T.voidTotal += s.voidTotal; T.netMissingQty += t.netMissingQty; T.unknownQty += t.unknownQty;
    shops.push({ shopId: str(br.shopId), billQty: t.billQty, totalSale: baht(s.total), average: avg(s.total, t.billQty), voidQty: t.voidQty, voidTotal: baht(s.voidTotal) });
    if (t.billQty === 0) continue;
    for (const r of salesBreakdown(br.entries, { ...base, dimension: "hour" }).rows) {
      const h = hours.get(r.key) || { key: r.key, billQty: 0, total: 0 };
      h.billQty += r.billQty; h.total += toSatang(r.totalSale);
      hours.set(r.key, h);
    }
    for (const r of salesBreakdown(br.entries, { ...base, dimension: "item", itemKey: "barcode" }).rows) {
      const key = r.barcode ? r.key : `shop:${str(br.shopId)}|${r.key}`;
      let it = items.get(key);
      if (!it) { it = { key, barcode: r.barcode, name: r.name, qty: 0, count: 0, totalPrice: 0, net: 0, share: 0, after: 0 }; items.set(key, it); }
      it.qty = qtyAdd(it.qty, r.qty); it.count += r.count;
      it.totalPrice += toSatang(r.totalPrice); it.net += toSatang(r.net);
      it.share += toSatang(r.billDiscountShare); it.after += toSatang(r.netAfterBillDiscount);
    }
  }
  const byKey = (a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0);
  return {
    ok: true,
    fromDay: range.fromKey,
    toDay: range.toKey,
    totals: {
      billQty: T.billQty, totalSale: baht(T.total), average: avg(T.total, T.billQty), currentTotal: baht(T.cur), legacyV1Total: baht(T.total - T.cur), legacyV1Qty: T.legacyQty,
      voidQty: T.voidQty, voidTotal: baht(T.voidTotal), netMissingQty: T.netMissingQty, unknownQty: T.unknownQty,
      shopQty: shops.length, shopWithSale: shops.filter((x) => x.billQty > 0).length,
    },
    shops: shops.sort((a, b) => b.totalSale - a.totalSale || (a.shopId < b.shopId ? -1 : a.shopId > b.shopId ? 1 : 0)),
    hours: [...hours.values()].map((h) => ({ key: h.key, billQty: h.billQty, totalSale: baht(h.total) })).sort(byKey),
    items: [...items.values()].map((it) => ({
      key: it.key, barcode: it.barcode, name: it.name, qty: it.qty, count: it.count,
      totalPrice: baht(it.totalPrice), net: baht(it.net), billDiscountShare: baht(it.share), netAfterBillDiscount: baht(it.after),
    })).sort((a, b) => b.netAfterBillDiscount - a.netAfterBillDiscount || byKey(a, b)),
  };
}

module.exports = {
  REPORT_MAX_DAYS,
  franchiseBreakdown,
  FREE_BACK_DAYS,
  BREAKDOWN_DIMENSIONS,
  BREAKDOWN_GRANULARITY,
  plainDoc,
  billDetailOf,
  salesBreakdown,
  reportRange,
  freeWindowOk,
  monthPrefix,
  billShapeOf,
  saleMsOf,
  reportBillRow,
  sortRowsDesc,
  summarizeSales,
  taxInvoiceReport,
  duplicateNumberReport,
  shiftShapeOf,
  shiftReportRow,
  shiftReport,
};

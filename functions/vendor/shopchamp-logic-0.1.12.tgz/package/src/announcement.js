// @shopchamp/logic — announcement · ประกาศถึงร้าน ใครเห็น · เห็นช่องไหน · เมื่อไหร่ (DEV-0003 0e · Pack สั่ง 2026-11-11)
//   แบบ: lanes/dev/source/office-announcement-design.md · Pack เคาะ 1a (ชั่วคราว + ถาวรตามเงื่อนไข) · 2a (แบนเนอร์/ป๊อปอัป/กล่องข่าว/ปักแบนเนอร์) · 3b (ทุกร้าน/เลือกร้าน/กรอง + เจ้าของ/ทุกคน)
//   ยกท่าจากบ้านพี่น้อง (คัดลอกแล้วแก้ให้เข้าข้อมูล Shopchamp · ไม่มี surface · ไม่มี push/อีเมล · ไม่มีร้านทดลองฟรี)
//
// server เป็นคนคัด (แอปไม่คัดเอง) — pos/announcement/feed.js เรียกต่อใบ:
//   ร้าน+คน: announcementMatchesShop && announcementMatchesPerson
//   ถาวร:    announcementEvergreenMatch → cycleKey + vars
//   ช่อง:    announcementChannelVisible(a, 'banner'|'popup'|'inbox', seen, now, cycleKey)
//   office:  announcementSaveInput (ตรวจ+จัดรูปคำขอบันทึก) · announcementDisplayStatus (สถานะบนตาราง)
// ทุก fn = pure · ไม่ throw · ไม่อ่านนาฬิกาเอง · ข้อมูลเพี้ยน = false (ประกาศไม่ขึ้น ดีกว่าขึ้นผิดคน)
// วันตัดตามเวลาไทย (UTC+7 · ไทยไม่มีเวลาออมแสง ⇒ บวก 7 ชั่วโมงตรง ๆ)
"use strict";

const { toMillis } = require("./shift");

/** เข้าหน้าแรกกี่ครั้ง (ขณะแบนเนอร์อยู่ในแถบ) แล้วแบนเนอร์หายสำหรับคนนั้น */
const ANNOUNCEMENT_BANNER_MAX_VIEWS = 3;
const ANNOUNCEMENT_CHANNELS = Object.freeze(["banner", "popup", "inbox"]);
/** ป้ายแพ็กเกจที่กรองได้ = shop.vip[].type (Pack 3b · ไม่รวม gateway) */
const ANNOUNCEMENT_PLAN_TYPES = Object.freeze(["premium", "staff", "member", "warehouse", "delivery"]);
/** ชื่อแพ็กเกจที่ร้านอ่าน (ตัวแปร {แพ็กเกจ}) · ไม่รู้จัก = ชื่อชนิดตรง ๆ */
const ANNOUNCEMENT_PLAN_LABEL = Object.freeze({ premium: "พรีเมี่ยม", staff: "พนักงาน", member: "สมาชิก", warehouse: "คลังสินค้า", delivery: "เดลิเวอรี่" });
/** แพ็กเกจไหนก็ได้ (packageEnding/packageExpired/purchased) */
const ANNOUNCEMENT_ANY_PLAN = "any";
const ANNOUNCEMENT_TRIGGER_TYPES = Object.freeze(["newShop", "packageEnding", "packageExpired", "purchased"]);
const ANNOUNCEMENT_TRIGGER_DEFAULT_DAYS = Object.freeze({ newShop: 30, packageEnding: 7, packageExpired: 30, purchased: 7 });
const ANNOUNCEMENT_TRIGGER_DAYS_MAX = 365;
/** ตำแหน่งเจ้าของร้านใน humanResource[].position */
const ANNOUNCEMENT_OWNER_POSITION = "001";
/** ตัวแปรในข้อความ (ไทย) → คีย์ใน vars · จอ office ใช้ชุดนี้ทำปุ่มแทรก */
const ANNOUNCEMENT_TEXT_VARS = Object.freeze({ "ชื่อร้าน": "shopName", "แพ็กเกจ": "packageName", "วันหมดอายุ": "expireDate", "เหลือวัน": "daysLeft" });
const ANNOUNCEMENT_LIMITS = Object.freeze({
  title: 120, body: 3000, images: 10, imageUrl: 1000, buttonText: 40, buttonUrl: 500,
  shopIds: 1000, categoryIds: 20, id: 128,
});

// vip ของร้านที่ไม่เคยซื้อ = 2011-01-01 ไทย (initialVip) ⇒ expire ก่อนปี 2012 = ไม่เคยซื้อ ไม่นับ
const NEVER_BOUGHT_BEFORE_MS = Date.UTC(2012, 0, 1);
const TH_OFFSET_MS = 7 * 3600000;
const DAY_MS = 86400000;
const THAI_MONTH_ABBR = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const absent = (v) => v === undefined || v === null;
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const stamped = (v) => !absent(v) && v !== "" && toMillis(v) !== null;
/** เวลา → เลขวันไทยต่อเนื่อง (ลบกันได้) · อ่านไม่ออก = null */
const thaiDay = (v) => { const ms = toMillis(v); return ms === null ? null : Math.floor((ms + TH_OFFSET_MS) / DAY_MS); };
const isoOfDay = (n) => new Date(n * DAY_MS).toISOString().slice(0, 10);
const labelOf = (t) => (has(ANNOUNCEMENT_PLAN_LABEL, t) ? ANNOUNCEMENT_PLAN_LABEL[t] : t);
const validId = (v) => typeof v === "string" && v !== "" && v.length <= ANNOUNCEMENT_LIMITS.id && !v.includes("/") && v !== "." && v !== "..";

/**
 * แพ็กเกจที่ร้านใช้อยู่ ณ now — แถว vip ที่วันหมดอายุ (วันไทย) ≥ วันนี้ (กติกาเดียวกับแอป vipEnableOf · ใช้ได้ทั้งวันหมด)
 * @returns {string[]} ชนิดเรียงตามที่พบ ไม่ซ้ำ
 */
function announcementActivePlans(shop, now) {
  const today = thaiDay(now);
  const vip = shop && Array.isArray(shop.vip) ? shop.vip : [];
  const out = [];
  if (today === null) return out;
  for (const row of vip) {
    if (!isObj(row) || typeof row.type !== "string" || row.type === "") continue;
    const d = thaiDay(row.expire);
    if (d !== null && d >= today && !out.includes(row.type)) out.push(row.type);
  }
  return out;
}

/**
 * ร้านนี้อยู่ในกลุ่มผู้รับไหม (audience.shops) — ยังไม่ดูเวลา/ช่อง/คน
 *   all = ทุกร้าน · list = shopId ∈ shopIds
 *   filter = ต้องตรงทุกตัวกรองที่ตั้ง (AND) · ไม่ได้ตั้งเลย = ไม่เข้า
 *     plans.has     ต้องมีแพ็กเกจที่ใช้อยู่ครบทุกตัว · plans.missing ต้องไม่มีสักตัว · ชนิดไม่รู้จัก = ไม่เข้า
 *     categoryIds   ร้านติดป้ายประเภทอย่างน้อย 1 ตัวในรายการ (ป้ายมาจาก shopCategoryTag · server ส่งเข้ามา)
 * @param {object} a ประกาศ
 * @param {{shopId:string, shop:object, categoryIds?:string[]}} ctx
 * @param {any} now
 */
function announcementMatchesShop(a, ctx, now) {
  const aud = a && isObj(a.audience) ? a.audience.shops : null;
  if (!isObj(aud) || !isObj(ctx) || !validId(ctx.shopId)) return false;
  if (aud.mode === "all") return true;
  if (aud.mode === "list") return Array.isArray(aud.shopIds) && aud.shopIds.includes(ctx.shopId);
  if (aud.mode !== "filter") return false;
  let set = 0;
  const plans = aud.plans;
  if (!absent(plans)) {
    if (!isObj(plans)) return false;
    const hasList = absent(plans.has) ? [] : plans.has;
    const missList = absent(plans.missing) ? [] : plans.missing;
    if (!Array.isArray(hasList) || !Array.isArray(missList)) return false;
    if (hasList.length || missList.length) {
      set++;
      if (hasList.concat(missList).some((t) => !ANNOUNCEMENT_PLAN_TYPES.includes(t))) return false;
      if (toMillis(now) === null) return false;
      const mine = announcementActivePlans(ctx.shop, now);
      if (!hasList.every((t) => mine.includes(t))) return false;
      if (missList.some((t) => mine.includes(t))) return false;
    }
  }
  const cats = aud.categoryIds;
  if (!absent(cats)) {
    if (!Array.isArray(cats)) return false;
    if (cats.length) {
      set++;
      const mine = Array.isArray(ctx.categoryIds) ? ctx.categoryIds : [];
      if (!cats.some((c) => typeof c === "string" && c !== "" && mine.includes(c))) return false;
    }
  }
  return set > 0;
}

/**
 * คนนี้ (uid) ในร้านนี้เป็นผู้รับไหม (audience.people)
 *   owner = มีแถว humanResource ของ uid นี้ที่ position มี '001' · all = มีแถวของ uid นี้
 *   ไม่ดู status (ด่านเข้าร้านตัดสินคนที่ใช้งานได้แล้ว) · ทีมงานที่ไม่มีแถวในร้าน = ไม่เห็น
 */
function announcementMatchesPerson(a, shop, uid) {
  const people = a && isObj(a.audience) ? a.audience.people : null;
  if (people !== "owner" && people !== "all") return false;
  if (typeof uid !== "string" || uid === "" || !shop || !Array.isArray(shop.humanResource)) return false;
  return shop.humanResource.some((row) => isObj(row) && row.id === uid
    && (people === "all" || (Array.isArray(row.position) && row.position.includes(ANNOUNCEMENT_OWNER_POSITION))));
}

/** seen ของรอบนี้ (ประกาศถาวร) = seen.cycles[cycleKey] หรือ null */
function announcementCycleSeen(seen, cycleKey) {
  if (!isObj(seen) || !isObj(seen.cycles) || typeof cycleKey !== "string") return null;
  return isObj(seen.cycles[cycleKey]) ? seen.cycles[cycleKey] : null;
}

/**
 * ประกาศนี้ขึ้นช่อง channel ให้คนนี้ไหม ณ now (ผู้เรียกผ่าน matches มาก่อน)
 *   ต้องเปิดช่อง · ไม่ถูกยกเลิก
 *   banner = ในช่วง startAt..endAt · หายเมื่อ readAt มีค่า หรือ bannerViews ≥ 3 · ปักแบนเนอร์ (bannerSticky) = ไม่หาย
 *   popup  = ในช่วง · คนละครั้ง (popupSeenAt)
 *   inbox  = ตั้งแต่ startAt ไปตลอด
 *   ถาวร (kind evergreen): active ต้อง true · ต้องมี cycleKey · seen ดูของรอบ (seen.cycles[cycleKey]) · inbox ขึ้นตลอดที่เข้าเงื่อนไข
 * @param {object|null} seen announcement/{id}/seen/{uid}
 */
function announcementChannelVisible(a, channel, seen, now, cycleKey) {
  if (!isObj(a) || a.status === "cancelled" || !ANNOUNCEMENT_CHANNELS.includes(channel)) return false;
  if (!isObj(a.channels) || a.channels[channel] !== true) return false;
  const allows = (s) => {
    if (channel === "inbox") return true;
    if (channel === "popup") return !(s && stamped(s.popupSeenAt));
    if (a.bannerSticky === true || !s) return true;
    const views = typeof s.bannerViews === "number" && Number.isFinite(s.bannerViews) ? s.bannerViews : 0;
    return !(stamped(s.readAt) || views >= ANNOUNCEMENT_BANNER_MAX_VIEWS);
  };
  if (a.kind === "evergreen") {
    if (a.active !== true || typeof cycleKey !== "string" || cycleKey === "") return false;
    return allows(announcementCycleSeen(seen, cycleKey));
  }
  if (a.kind !== "campaign") return false;
  const start = toMillis(a.startAt);
  const end = toMillis(a.endAt);
  const t = toMillis(now);
  if (start === null || end === null || t === null || t < start) return false;
  if (channel !== "inbox" && t > end) return false;
  return allows(isObj(seen) ? seen : null);
}

/** trigger → {type, days, plan?} ที่ใช้ได้ หรือ null (ใช้ร่วมกับตัวตรวจคำขอ) */
function triggerOf(trig) {
  if (!isObj(trig) || !ANNOUNCEMENT_TRIGGER_TYPES.includes(trig.type)) return null;
  const days = absent(trig.days) ? ANNOUNCEMENT_TRIGGER_DEFAULT_DAYS[trig.type] : trig.days;
  if (!Number.isInteger(days) || days < 0 || days > ANNOUNCEMENT_TRIGGER_DAYS_MAX) return null;
  if (trig.type === "newShop") return absent(trig.plan) ? { type: trig.type, days } : null;
  const plan = absent(trig.plan) ? ANNOUNCEMENT_ANY_PLAN : trig.plan;
  if (plan !== ANNOUNCEMENT_ANY_PLAN && !ANNOUNCEMENT_PLAN_TYPES.includes(plan)) return null;
  return { type: trig.type, days, plan };
}

/**
 * ร้านนี้เข้าเงื่อนไขของประกาศถาวรไหม ณ now → {match, cycleKey, vars}
 *   vars = {shopName, packageName, expireDate 'YYYY-MM-DD', daysLeft} · ไม่มีค่า = null · ตัดวันตามเวลาไทย
 *   newShop        เปิดร้าน (shop.dateTime) ไม่เกิน days วัน และร้านเปิดหลังวันสร้างประกาศ (a.createdAt) · รอบเดียว "newShop"
 *   packageEnding  แพ็กเกจ plan (หรือ any = ตัวที่ใกล้หมดที่สุด) เหลือ 0..days วัน · รอบ "packageEnding:<plan>:<ชนิด>:<วันหมด>" (ต่ออายุ = รอบใหม่)
 *   packageExpired หมดมาแล้ว 1..days วัน (any = ตัวที่เพิ่งหมดล่าสุด) · ชนิดนั้นต่อแล้ว = ไม่เข้า · expire ก่อนปี 2012 (ไม่เคยซื้อ) = ไม่นับ
 *   purchased      ซื้อแพ็กเกจสำเร็จภายใน 0..days วัน (ctx.lastPurchase {at, packageName, types[]} · server หาจาก packageOrder)
 *                  plan ระบุชนิด = ใบซื้อต้องมีชนิดนั้น · รอบ "purchased:<เวลาซื้อ ms>"
 * @param {object} a ประกาศ (kind evergreen · active · trigger · createdAt)
 * @param {{shop:object, lastPurchase?:object|null}} ctx
 */
function announcementEvergreenMatch(a, ctx, now) {
  const NO = { match: false, cycleKey: null, vars: null };
  if (!isObj(a) || a.kind !== "evergreen" || a.active !== true || a.status === "cancelled") return NO;
  const trig = triggerOf(a.trigger);
  const shop = isObj(ctx) && isObj(ctx.shop) ? ctx.shop : null;
  const today = thaiDay(now);
  if (!trig || !shop || today === null) return NO;
  const vars = { shopName: typeof shop.name === "string" && shop.name.trim() !== "" ? shop.name.trim() : null, packageName: null, expireDate: null, daysLeft: null };

  if (trig.type === "newShop") {
    const createdMs = toMillis(shop.dateTime);
    const announcedMs = toMillis(a.createdAt);
    if (createdMs === null || announcedMs === null || createdMs < announcedMs) return NO;
    const age = today - thaiDay(createdMs);
    if (age < 0 || age > trig.days) return NO;
    return { match: true, cycleKey: "newShop", vars };
  }

  // วันหมดล่าสุดต่อชนิด (ไม่นับแถวของร้านที่ไม่เคยซื้อ)
  const latest = new Map();
  for (const row of Array.isArray(shop.vip) ? shop.vip : []) {
    if (!isObj(row) || typeof row.type !== "string" || row.type === "") continue;
    const ms = toMillis(row.expire);
    if (ms === null || ms < NEVER_BOUGHT_BEFORE_MS) continue;
    const d = thaiDay(ms);
    if (!latest.has(row.type) || d > latest.get(row.type)) latest.set(row.type, d);
  }

  if (trig.type === "packageEnding" || trig.type === "packageExpired") {
    const ending = trig.type === "packageEnding";
    const types = trig.plan === ANNOUNCEMENT_ANY_PLAN ? [...latest.keys()].filter((t) => ANNOUNCEMENT_PLAN_TYPES.includes(t)) : [trig.plan];
    const hits = types.filter((t) => latest.has(t)).map((t) => ({ t, d: latest.get(t) })).filter(({ d }) => {
      const left = d - today;
      return ending ? left >= 0 && left <= trig.days : -left >= 1 && -left <= trig.days;
    });
    if (!hits.length) return NO;
    // ใกล้หมด = หมดก่อนมาก่อน · หมดแล้ว = หมดล่าสุดมาก่อน · วันเท่ากัน = ตามชื่อชนิด
    hits.sort((x, y) => (ending ? x.d - y.d : y.d - x.d) || (x.t < y.t ? -1 : x.t > y.t ? 1 : 0));
    const { t, d } = hits[0];
    vars.packageName = labelOf(t);
    vars.expireDate = isoOfDay(d);
    vars.daysLeft = ending ? d - today : 0;
    return { match: true, cycleKey: `${trig.type}:${trig.plan}:${t}:${isoOfDay(d)}`, vars };
  }

  // purchased
  const lp = isObj(ctx.lastPurchase) ? ctx.lastPurchase : null;
  const atMs = lp ? toMillis(lp.at) : null;
  if (atMs === null || atMs > toMillis(now)) return NO;
  const since = today - thaiDay(atMs);
  if (since < 0 || since > trig.days) return NO;
  const bought = Array.isArray(lp.types) ? lp.types.filter((x) => typeof x === "string" && x !== "") : [];
  if (trig.plan !== ANNOUNCEMENT_ANY_PLAN && !bought.includes(trig.plan)) return NO;
  const named = typeof lp.packageName === "string" && lp.packageName.trim() !== "" ? lp.packageName.trim() : null;
  vars.packageName = named || (bought.length ? [...new Set(bought)].map(labelOf).join(", ") : null);
  const exp = bought.filter((x) => latest.has(x)).map((x) => latest.get(x)).sort((x, y) => y - x)[0];
  if (exp !== undefined) { vars.expireDate = isoOfDay(exp); vars.daysLeft = Math.max(0, exp - today); }
  return { match: true, cycleKey: `purchased:${atMs}`, vars };
}

/**
 * แทนตัวแปรในข้อความ — {ชื่อร้าน} {แพ็กเกจ} {วันหมดอายุ} {เหลือวัน}
 *   ไม่มีค่า = แทนด้วยว่าง (ไม่ปล่อยวงเล็บค้างให้ร้านเห็น) · วันที่ 'YYYY-MM-DD' → '20 พ.ย. 2569' · วงเล็บอื่นคงเดิม · ช่องว่างในวงเล็บได้
 */
function announcementFillText(text, vars) {
  if (typeof text !== "string" || text === "") return "";
  const v = isObj(vars) ? vars : {};
  const fmt = (val) => {
    if (absent(val) || val === "") return "";
    if (typeof val === "number") return Number.isFinite(val) ? String(val) : "";
    if (typeof val !== "string") return "";
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(val);
    return m ? `${Number(m[3])} ${THAI_MONTH_ABBR[Number(m[2]) - 1] || m[2]} ${Number(m[1]) + 543}` : val;
  };
  return text.replace(/\{\s*([^{}]+?)\s*\}/g, (whole, name) => (has(ANNOUNCEMENT_TEXT_VARS, name) ? fmt(v[ANNOUNCEMENT_TEXT_VARS[name]]) : whole));
}

/**
 * สถานะบนตาราง office ณ now
 *   ชั่วคราว: cancelled · scheduled (ยังไม่ถึง startAt) · live · ended (เลย endAt) — ตัดสินจากเวลา ไม่เชื่อช่อง status ที่ประทับไว้
 *   ถาวร: active = live · ปิด = cancelled
 */
function announcementDisplayStatus(a, now) {
  if (!isObj(a)) return "cancelled";
  if (a.kind === "evergreen") return a.active === true ? "live" : "cancelled";
  if (a.status === "cancelled") return "cancelled";
  const start = toMillis(a.startAt);
  const end = toMillis(a.endAt);
  const t = toMillis(now);
  if (start === null || end === null || t === null) return "ended";
  if (t < start) return "scheduled";
  return t > end ? "ended" : "live";
}

// ── ตรวจคำขอบันทึกของ office (server ใช้ตัวนี้ตัวเดียว · ผิด = 400 invalid_request พร้อมข้อความ) ──────────────

const SAVE_KEYS = ["id", "clientRequestId", "kind", "title", "body", "images", "buttonText", "buttonUrl", "channels", "bannerSticky", "audience", "startAt", "endAt", "trigger", "active"];
const REQUEST_ID_RE = /^[A-Za-z0-9_-]{8,64}$/;
const HTTPS_RE = /^https:\/\/[^\s]+$/;

class Bad extends Error {}
const bad = (m) => { throw new Bad(m); };
function only(o, keys, label) {
  const extra = Object.keys(o).filter((k) => !keys.includes(k));
  if (extra.length) bad(`${label}ไม่รับช่อง: ${extra.join(", ")}`);
}
function textOf(v, label, min, max) {
  if (typeof v !== "string") bad(`${label} ต้องเป็นข้อความ`);
  const t = v.trim();
  if (t.length < min || t.length > max) bad(min ? `${label} ต้องยาว ${min}-${max} ตัว` : `${label} ยาวได้ไม่เกิน ${max} ตัว`);
  return t;
}
function timeOf(v, label) {
  const ms = typeof v === "number" ? (Number.isSafeInteger(v) ? v : null) : typeof v === "string" && v.length <= 40 ? toMillis(v) : null;
  if (ms === null) bad(`${label} ต้องเป็นเวลา (ISO หรือ ms)`);
  return new Date(ms);
}
function idListOf(v, label, max, allowEmpty) {
  if (!Array.isArray(v) || v.some((x) => !validId(x))) bad(`${label} ต้องเป็นรายการรหัส`);
  if (new Set(v).size !== v.length) bad(`${label} มีรหัสซ้ำ`);
  if (v.length > max || (!allowEmpty && v.length === 0)) bad(`${label} ต้องมี ${allowEmpty ? 0 : 1}-${max} รายการ`);
  return v.slice();
}
function plansOf(v) {
  if (absent(v)) return { has: [], missing: [] };
  if (!isObj(v)) bad("audience.shops.plans ต้องเป็น object");
  only(v, ["has", "missing"], "audience.shops.plans ");
  const list = (x, label) => {
    if (absent(x)) return [];
    if (!Array.isArray(x) || x.some((t) => !ANNOUNCEMENT_PLAN_TYPES.includes(t))) bad(`${label} ต้องเป็นชนิด ${ANNOUNCEMENT_PLAN_TYPES.join(" | ")}`);
    if (new Set(x).size !== x.length) bad(`${label} มีชนิดซ้ำ`);
    return x.slice();
  };
  const out = { has: list(v.has, "plans.has"), missing: list(v.missing, "plans.missing") };
  if (out.has.some((t) => out.missing.includes(t))) bad("ชนิดเดียวกันอยู่ทั้ง has และ missing ไม่ได้");
  return out;
}
function audienceOf(v) {
  if (!isObj(v)) bad("audience ต้องเป็น object");
  only(v, ["people", "shops"], "audience ");
  if (v.people !== "owner" && v.people !== "all") bad("audience.people ต้องเป็น owner | all");
  const s = v.shops;
  if (!isObj(s)) bad("audience.shops ต้องเป็น object");
  only(s, ["mode", "shopIds", "plans", "categoryIds"], "audience.shops ");
  if (!["all", "list", "filter"].includes(s.mode)) bad("audience.shops.mode ต้องเป็น all | list | filter");
  const shopIds = absent(s.shopIds) ? [] : idListOf(s.shopIds, "shopIds", ANNOUNCEMENT_LIMITS.shopIds, true);
  const plans = plansOf(s.plans);
  const categoryIds = absent(s.categoryIds) ? [] : idListOf(s.categoryIds, "categoryIds", ANNOUNCEMENT_LIMITS.categoryIds, true);
  const filterSet = plans.has.length + plans.missing.length + categoryIds.length > 0;
  if (s.mode === "list" && (!shopIds.length || filterSet)) bad("โหมด list ต้องมี shopIds และไม่มีตัวกรอง");
  if (s.mode === "filter" && (shopIds.length || !filterSet)) bad("โหมด filter ต้องตั้งตัวกรองอย่างน้อย 1 และไม่มี shopIds");
  if (s.mode === "all" && (shopIds.length || filterSet)) bad("โหมด all ไม่มี shopIds และตัวกรอง");
  return { people: v.people, shops: { mode: s.mode, shopIds, plans, categoryIds } };
}

/**
 * announcementSaveInput(body, now, opts) → {ok:true, id, clientRequestId, value} | {ok:false, message}
 *   body ช่องที่รับ (strict ทุกชั้น): id? clientRequestId? kind title body? images? buttonText? buttonUrl? channels bannerSticky? audience
 *     ชั่วคราว: startAt endAt (ISO หรือ ms · start < end · สร้างใหม่ endAt ต้องยังไม่ผ่าน) · ห้ามส่ง trigger/active
 *     ถาวร: trigger {type, days?, plan?} active? (ไม่ส่ง = true) · ห้ามส่ง startAt/endAt
 *   value = ช่องของ doc ที่จะเขียน (เวลาเป็น Date) · ชั่วคราวมี status ตามเวลา (scheduled/live/ended)
 *   opts.imagePrefix = รูปต้องขึ้นต้นด้วยค่านี้ (server ส่ง Storage ของ Shopchamp) · ไม่ส่ง = https อะไรก็ได้
 *   opts.creating = true เมื่อสร้างใหม่ (ตรวจ endAt ยังไม่ผ่าน)
 */
function announcementSaveInput(body, now, opts) {
  const o = isObj(opts) ? opts : {};
  try {
    if (!isObj(body)) bad("คำขอต้องเป็น object");
    only(body, SAVE_KEYS, "");
    const id = absent(body.id) ? null : body.id;
    if (id !== null && !validId(id)) bad("id ผิดรูป");
    const clientRequestId = absent(body.clientRequestId) ? null : body.clientRequestId;
    if (clientRequestId !== null && (typeof clientRequestId !== "string" || !REQUEST_ID_RE.test(clientRequestId))) bad("clientRequestId ต้องเป็น A-Z a-z 0-9 _ - ยาว 8-64 ตัว");
    if (id !== null && clientRequestId !== null) bad("แก้ใบเดิมไม่ต้องส่ง clientRequestId");
    if (body.kind !== "campaign" && body.kind !== "evergreen") bad("kind ต้องเป็น campaign | evergreen");
    const kind = body.kind;

    const title = textOf(body.title, "title", 1, ANNOUNCEMENT_LIMITS.title);
    const text = absent(body.body) ? "" : textOf(body.body, "body", 0, ANNOUNCEMENT_LIMITS.body);
    const imagesRaw = absent(body.images) ? [] : body.images;
    if (!Array.isArray(imagesRaw) || imagesRaw.some((u) => typeof u !== "string")) bad("images ต้องเป็นรายการลิงก์รูป");
    const images = imagesRaw.map((u) => u.trim()).filter((u) => u !== "");
    if (images.length > ANNOUNCEMENT_LIMITS.images) bad(`ใส่รูปได้ไม่เกิน ${ANNOUNCEMENT_LIMITS.images} รูป`);
    if (new Set(images).size !== images.length) bad("รูปซ้ำกัน");
    const prefix = typeof o.imagePrefix === "string" && o.imagePrefix !== "" ? o.imagePrefix : null;
    if (images.some((u) => u.length > ANNOUNCEMENT_LIMITS.imageUrl || !HTTPS_RE.test(u) || (prefix && !u.startsWith(prefix)))) bad("รูปต้องเป็นลิงก์ที่อัปขึ้น Storage ของ Shopchamp");
    const buttonText = absent(body.buttonText) ? "" : textOf(body.buttonText, "buttonText", 0, ANNOUNCEMENT_LIMITS.buttonText);
    const buttonUrl = absent(body.buttonUrl) ? "" : textOf(body.buttonUrl, "buttonUrl", 0, ANNOUNCEMENT_LIMITS.buttonUrl);
    if (buttonUrl !== "" && !HTTPS_RE.test(buttonUrl)) bad("buttonUrl ต้องขึ้นต้นด้วย https://");
    if ((buttonText === "") !== (buttonUrl === "")) bad("ปุ่มต้องมีทั้งข้อความและลิงก์ หรือไม่มีทั้งคู่");

    const ch = body.channels;
    if (!isObj(ch)) bad("channels ต้องเป็น object");
    only(ch, ANNOUNCEMENT_CHANNELS, "channels ");
    const channels = {};
    for (const k of ANNOUNCEMENT_CHANNELS) {
      if (!absent(ch[k]) && typeof ch[k] !== "boolean") bad(`channels.${k} ต้องเป็น true/false`);
      channels[k] = ch[k] === true;
    }
    if (!ANNOUNCEMENT_CHANNELS.some((k) => channels[k])) bad("ต้องเลือกช่องทางอย่างน้อย 1 ช่อง");
    if (!absent(body.bannerSticky) && typeof body.bannerSticky !== "boolean") bad("bannerSticky ต้องเป็น true/false");
    const bannerSticky = body.bannerSticky === true;
    if (bannerSticky && !channels.banner) bad("ปักแบนเนอร์ต้องเลือกช่องแบนเนอร์ด้วย");
    const audience = audienceOf(body.audience);

    const value = { kind, title, body: text, images, buttonText, buttonUrl, channels, bannerSticky, audience };
    if (kind === "campaign") {
      if (has(body, "trigger") || has(body, "active")) bad("ประกาศชั่วคราวไม่รับ trigger/active");
      const startAt = timeOf(body.startAt, "startAt");
      const endAt = timeOf(body.endAt, "endAt");
      if (startAt.getTime() >= endAt.getTime()) bad("startAt ต้องมาก่อน endAt");
      const t = toMillis(now);
      if (o.creating === true && t !== null && endAt.getTime() <= t) bad("ช่วงแสดงจบไปแล้ว");
      Object.assign(value, { startAt, endAt });
      value.status = announcementDisplayStatus(value, now);
    } else {
      if (has(body, "startAt") || has(body, "endAt")) bad("ประกาศถาวรไม่รับ startAt/endAt");
      if (!isObj(body.trigger)) bad("ประกาศถาวรต้องมี trigger");
      only(body.trigger, ["type", "days", "plan"], "trigger ");
      const trigger = triggerOf(body.trigger);
      if (!trigger) bad(`trigger ผิดรูป (type ${ANNOUNCEMENT_TRIGGER_TYPES.join(" | ")} · days 0-${ANNOUNCEMENT_TRIGGER_DAYS_MAX} · plan ${ANNOUNCEMENT_ANY_PLAN} | ${ANNOUNCEMENT_PLAN_TYPES.join(" | ")} · newShop ไม่มี plan)`);
      if (!absent(body.active) && typeof body.active !== "boolean") bad("active ต้องเป็น true/false");
      Object.assign(value, { trigger, active: body.active !== false });
    }
    return { ok: true, id, clientRequestId, value };
  } catch (e) {
    if (e instanceof Bad) return { ok: false, message: e.message };
    throw e;
  }
}

module.exports = {
  announcementActivePlans,
  announcementMatchesShop,
  announcementMatchesPerson,
  announcementCycleSeen,
  announcementChannelVisible,
  announcementEvergreenMatch,
  announcementFillText,
  announcementDisplayStatus,
  announcementSaveInput,
  ANNOUNCEMENT_BANNER_MAX_VIEWS,
  ANNOUNCEMENT_CHANNELS,
  ANNOUNCEMENT_PLAN_TYPES,
  ANNOUNCEMENT_PLAN_LABEL,
  ANNOUNCEMENT_ANY_PLAN,
  ANNOUNCEMENT_TRIGGER_TYPES,
  ANNOUNCEMENT_TRIGGER_DEFAULT_DAYS,
  ANNOUNCEMENT_TRIGGER_DAYS_MAX,
  ANNOUNCEMENT_OWNER_POSITION,
  ANNOUNCEMENT_TEXT_VARS,
  ANNOUNCEMENT_LIMITS,
};

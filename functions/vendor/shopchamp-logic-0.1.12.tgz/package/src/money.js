// money — เงินคิดเป็นสตางค์จำนวนเต็ม · แปลงค่าที่ร้านกรอก · ปัดเศษ (ใบ DEV-0001 ก้อน 2)
//
// เทียบกับสูตรเดิมของแอป @804ba8ff แล้ว: `lanes/dev/source/compare/old-logic/money.js` · ตาราง `test/money.golden.txt`
// ทุกแถวที่ผลต่างจากของเดิมชี้รหัสบั๊กใน `lanes/dev/source/bug-decisions/` (เทสบังคับ)
//
// หลัก
//   - เงินบวก ลบ ปัด ทำบนสตางค์จำนวนเต็ม แล้วค่อยหาร 100 จุดเดียว ⇒ ไม่มี 29.700000000000003 หลุดลงบิล (money F08)
//   - ปัดครึ่งขึ้นตามค่าทศนิยมที่คนเห็น ไม่ใช่ตามเลขฐานสองข้างใน: 1.005 → 1.01 (toFixed ของเดิมได้ 1.00 · F08)
//   - ค่าลบปัดออกจากศูนย์: -1.005 → -1.01 · fromSatang(-1999.5) → -20 · ผลเป็น 0 คืน 0 เสมอ ไม่คืน -0 (รวม toNumber(-0))
//   - บวกหลายค่า: รวมค่าดิบก่อนแล้วปัดสตางค์จุดเดียว (money F08 "ปัดจุดเดียว") ⇒ ส่วนลดโปร % ที่เก็บแบบไม่ปัด
//     (Utility/function.js:1869,1871 @804ba8ff) รวมแล้วไม่ขาดสตางค์: 2.3331 + 2.3331 = 4.67 ไม่ใช่ 4.66
//   - ❌ ไม่ throw ทุกฟังก์ชัน
//   - ค่าที่ร้านพิมพ์: ปฏิเสธค่ากำกวมแทนการเดา (money K23 ค่าตั้งต้นตามข้อเสนอ)
//     ข้อความจากช่องกรอกที่มีตัว e ("12e3" "1e5") = null ไม่ขยายเป็น 12000 (money F31 · พิมพ์ผิด/วางข้อความแล้วยอดโตพันเท่า)
//     เลขไทย "๑๒" = null ให้จอแจ้งร้าน (เดิมลบทิ้งได้ 0)
//
// ฟังก์ชัน
//   toNumber(v)                 อ่านค่าตัวเลขที่เก็บในเอกสาร (number|string) → number ที่ finite · อ่านไม่ได้ = 0
//                               ค่าที่เก็บรูป "1e1" อ่านได้เหมือนเดิม (Number() ของเดิม) · ช่องกรอกใช้ parseMoney ซึ่งไม่รับ
//   parseMoney(v, opts)         ค่าในช่องกรอก → number หรือ null (ว่าง · กำกวม · ติดลบ · เกินเพดาน = null)
//   sanitizeMoneyInput(v, opts) ข้อความที่จะแสดงในช่องกรอกหลังพิมพ์ (แทน twoDigitNumber · onlyNumberValue2)
//   toSatang(baht)              → สตางค์จำนวนเต็ม (ส่งเกตเวย์ได้ตรง · money F23)
//   fromSatang(satang)          → บาท
//   roundMoney(v)               ปัด 2 ตำแหน่ง
//   addMoney(...vals)           บวกแล้วปัดสตางค์จุดเดียว (ส่งค่าลบเพื่อลบ)
//   sumMoney(list, field?)      รวม field ของทุกแถวแล้วปัดสตางค์จุดเดียว (แทน summary)
//   calcRounding(type, amount)  ส่วนปัดเศษท้ายบิล 'up' | 'down' | 'half' | 'legal' · ยอด ≤ 0 = 0 · type อื่น/ไม่ส่ง = ปัดขึ้น (เท่าของเดิม)
//                               ยอดหลังปัด = addMoney(amount, calcRounding(type, amount)) เป็นจำนวนเต็มบาท (legal = ขั้น 25 สตางค์)

// ค่าที่เก็บในเอกสาร: ตัวเลขฐานสิบทั้งก้อน · มี exponent ได้ ("1e1") · ❌ "0x10" "0b11" "Infinity" "12abc"
const NUMERIC = /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i;
// ข้อความจากช่องกรอก: ทศนิยมธรรมดาเท่านั้น ❌ exponent (money F31)
const PLAIN = /^[+-]?(\d+\.?\d*|\.\d+)$/;
// จุลภาคคั่นหลักพันที่ถูกรูป: 1,500 · 12,345,678.5 · ❌ 1,5 · 1,50 · 15,00 · ,500
const GROUPED = /^[+-]?\d{1,3}(,\d{3})+(\.\d*)?$/;
// ช่องกรอกเงินรับได้ถึง 999,999,999.99 บาท (money F56: เดิมไม่มีเพดาน ได้ Infinity)
const MAX_MONEY = 999999999.99;

// ตัดช่องว่างหัวท้าย · จุลภาคที่ถูกรูปหลักพันถูกตัด · จุลภาครูปอื่น = null (กำกวม 1,5 อาจแปลว่า 1.5 หรือ 15)
function normalizeText(s) {
  const t = s.trim();
  if (!t.includes(",")) return t;
  return GROUPED.test(t) ? t.replace(/,/g, "") : null;
}

function noNegZero(n) {
  return n === 0 ? 0 : n;
}

// ปัดครึ่งออกจากศูนย์บนจำนวนที่สเกลแล้ว (Math.round ตรง ๆ ปัด -0.5 ไปทาง +)
function roundHalfAway(x) {
  const r = Math.round(Math.abs(x));
  return x < 0 ? -r : r;
}

// ปัด n ให้เหลือ d ตำแหน่ง แบบครึ่งออกจากศูนย์ ตามค่าทศนิยมที่คนเห็น
// toPrecision(15) ตัดเศษฐานสองทิ้งก่อนปัด: 1.005*100 = 100.49999999999999 → 100.5 → 101
function roundDecimals(n, d) {
  const f = 10 ** d;
  const scaled = Math.round(Number((Math.abs(n) * f).toPrecision(15)));
  return noNegZero((n < 0 ? -scaled : scaled) / f);
}

function toNumber(v) {
  if (typeof v === "number") return Number.isFinite(v) ? noNegZero(v) : 0;
  if (typeof v !== "string") return 0;
  const s = normalizeText(v);
  if (s === null || !NUMERIC.test(s)) return 0;
  const n = Number(s);
  return Number.isFinite(n) ? noNegZero(n) : 0;
}

function toSatang(baht) {
  const n = toNumber(baht);
  const s = Math.round(Number((Math.abs(n) * 100).toPrecision(15)));
  if (!Number.isSafeInteger(s)) return 0; // เกินช่วงที่นับสตางค์ได้แม่น = อ่านไม่ได้
  return noNegZero(n < 0 ? -s : s);
}

function fromSatang(satang) {
  const s = roundHalfAway(toNumber(satang));
  return noNegZero(s / 100);
}

function roundMoney(v) {
  return fromSatang(toSatang(v));
}

// รวมค่าดิบ แล้วปัดสตางค์จุดเดียว · ผลรวมที่ไม่ finite = 0
function sumThenRound(values) {
  let total = 0;
  for (const v of values) total += toNumber(v);
  return fromSatang(toSatang(total));
}

function addMoney(...vals) {
  return sumThenRound(vals);
}

function sumMoney(list, field) {
  if (!Array.isArray(list)) return 0;
  return sumThenRound(list.map((item) => (field === undefined ? item : item == null ? undefined : item[field])));
}

// 'legal' ปัดตามประกาศกรมการค้าภายใน (DEV-0001 · Pack 2026-11-08) · เกณฑ์ยกจากแอปพี่น้องเป๊ะ 0.88/0.76/0.63/0.51/0.38/0.26/0.13
//   เศษ 0-12 สตางค์ → .00 · 13-37 → .25 · 38-62 → .50 · 63-87 → .75 · 88-99 → +1 บาท
//   เทียบบนสตางค์จำนวนเต็ม (หลักของไฟล์นี้ F08) ⇒ เศษ .13 .38 .63 .88 พอดีเข้าช่วงบนเสมอ
//   (แอปพี่น้องเทียบด้วยทศนิยมฐานสอง 100.88-100 = 0.8799… จึงตกช่วงล่าง · ที่นี่ไม่ตาม)
function legalStep(rem) {
  if (rem >= 88) return 100;
  if (rem >= 63) return 75;
  if (rem >= 38) return 50;
  if (rem >= 13) return 25;
  return 0;
}

function calcRounding(type, amount) {
  const s = toSatang(amount);
  if (s <= 0) return 0; // money K04: ยอด ≤ 0 ไม่ปัด (ของเดิมปัดยอดติดลบให้ติดลบน้อยลง/มากขึ้น)
  const rem = s % 100;
  if (rem === 0) return 0;
  let target;
  if (type === "down") target = s - rem;
  else if (type === "half") target = rem >= 50 ? s - rem + 100 : s - rem;
  else if (type === "legal") target = s - rem + legalStep(rem);
  else target = s - rem + 100; // 'up' และค่าอื่น = ปัดขึ้น เหมือนของเดิม
  return fromSatang(target - s);
}

// opts: decimals (ค่าตั้งต้น 2 · จำนวนชิ้นที่ห้ามทศนิยมใช้ 0) · allowNegative (ค่าตั้งต้น false) · max (ค่าตั้งต้น MAX_MONEY)
// ข้อความที่มีทศนิยมเกิน decimals = null (ช่องกรอกตัดให้แล้วด้วย sanitizeMoneyInput ⇒ เกินได้ก็ต่อเมื่อวางมาทั้งก้อน)
// ข้อความรูป exponent = null (money F31) · number: ปัดเศษฐานสองทิ้ง (29.700000000000003 → 29.7 · -4.44e-16 → 0) แต่ถ้ามีหลักจริงเกิน decimals = null
function parseMoney(v, opts = {}) {
  const decimals = Number.isInteger(opts.decimals) && opts.decimals >= 0 ? opts.decimals : 2;
  const allowNegative = opts.allowNegative === true;
  const max = typeof opts.max === "number" && opts.max >= 0 ? opts.max : MAX_MONEY;

  let n;
  if (typeof v === "number") {
    n = v;
  } else if (typeof v === "string") {
    const s = normalizeText(v);
    if (s === null || s === "" || !PLAIN.test(s)) return null;
    const frac = s.split(".")[1] || "";
    if (frac.length > decimals) return null;
    n = Number(s);
  } else {
    return null;
  }
  if (!Number.isFinite(n)) return null;

  const r = roundDecimals(n, decimals);
  if (Math.abs(r - n) > 1e-9 * Math.max(1, Math.abs(n))) return null; // มีหลักจริงเกิน decimals ไม่ใช่เศษฐานสอง
  if (r < 0 && !allowNegative) return null;
  if (Math.abs(r) > max) return null;
  return r;
}

// number → ข้อความทศนิยมธรรมดาที่ปัดแล้ว ไม่มีศูนย์ท้าย: 29.7 · 100000 · 0
// ค่าตั้งแต่ 1e15 ขึ้นไปเกินเพดานแน่ ⇒ คืน String(n) ตรง ๆ ให้ parseMoney ปัด (ปัดทศนิยมช่วงนั้นเพี้ยนจากฐานสอง)
function numberText(n, d) {
  if (Math.abs(n) >= 1e15) return String(n);
  const t = roundDecimals(n, d).toFixed(d);
  return t.includes(".") ? t.replace(/\.?0+$/, "") : t;
}

// ข้อความในช่องกรอกหลังแต่ละครั้งที่พิมพ์
// ทำเฉพาะการแปลงที่ไม่กำกวม และ ❌ ไม่ลบอักขระทิ้งเงียบ ๆ (ของเดิมลบทุกอย่างที่ไม่ใช่เลขกับจุด 1,5 → 15 · 1e5 → 15 · -5 → 5)
//   ตัดช่องว่างหัวท้ายและ + นำหน้า · จุลภาคหลักพันที่ถูกรูปถูกตัด · จุดนำหน้าเติม 0 (.5 → 0.5)
//   ทศนิยมเกิน decimals ถูกตัด (เหมือนของเดิม) เมื่อ decimals ≥ 1 · decimals 0 เก็บจุดไว้ให้ parseMoney ปัด (money K24)
//   number = ปัดเป็นทศนิยมธรรมดา (จอเดิมส่ง String(number) เข้า · -4.44e-16 → "0")
//   ที่เหลือคงไว้ตามที่พิมพ์ รวมข้อความรูป exponent "12e3" และเลขไทย ⇒ parseMoney คืน null และจอต้องแจ้งร้าน
function sanitizeMoneyInput(v, opts = {}) {
  const decimals = Number.isInteger(opts.decimals) && opts.decimals >= 0 ? opts.decimals : 2;
  if (typeof v === "number") return Number.isFinite(v) ? numberText(v, decimals) : "";
  if (typeof v !== "string") return "";
  let s = v.trim();
  if (s.startsWith("+")) s = s.slice(1);
  if (GROUPED.test(s)) s = s.replace(/,/g, "");
  if (/^\d*\.?\d*$/.test(s)) {
    if (s.startsWith(".")) s = "0" + s;
    const dot = s.indexOf(".");
    if (decimals > 0 && dot >= 0 && s.length - dot - 1 > decimals) s = s.slice(0, dot + 1 + decimals);
  }
  return s;
}

module.exports = {
  MAX_MONEY,
  toNumber,
  parseMoney,
  sanitizeMoneyInput,
  toSatang,
  fromSatang,
  roundMoney,
  addMoney,
  sumMoney,
  calcRounding,
};

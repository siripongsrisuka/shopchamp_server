// company — สูตรของใบสั่งซื้อฝั่งบริษัท (แพ็กเกจ · อุปกรณ์ · พื้นที่รูป) และเลขใบสั่งซื้อ (DEV-0001 ก้อน 9d)
//
// เทียบกับสูตรเดิมของแอป main3 แล้ว: `lanes/dev/source/compare/old-logic/company.js` · ตาราง `test/company.golden.txt`
// ทุกแถวที่ผลต่างจากของเดิมชี้รหัสบั๊กใน `lanes/dev/source/bug-decisions/` หรือ `schema/*.md` (เทสบังคับ)
//
// หลัก
//   - ราคามาจากเอกสารของบริษัท (`admin/package` · `admin/hardware` · ตารางพื้นที่รูปในโค้ด) ไม่ใช่จากเครื่องผู้ซื้อ
//     (care AC-07 ค่าตั้งต้นที่ agent เลือก · ดู `lanes/dev/source/chunk9/9d-company.md` คำถามข้อ 1)
//     ⚠️ ไม่ขัด decision 2-2 (server เชื่อยอดขายของร้าน) เพราะนี่คือยอดที่ร้านจ่ายให้บริษัท ไม่ใช่ยอดขายของร้าน
//   - เงินคิดเป็นสตางค์จำนวนเต็มด้วย ./money แล้วหาร 100 จุดเดียว ⇒ ไม่มี 105.00000000000001 (hardwareOrder B6)
//   - เลขใบสั่งซื้อ = YYYYMM ตามนาฬิกาไทยของ server + ลำดับ 6 หลัก (AC-63 ใช้เวลา server · ตัวนับไม่รีเซ็ตรายเดือนเหมือนเดิม)
//   - ❌ ไม่ throw ทุกฟังก์ชัน · ผิด = {ok:false, error:<รหัสตัวใหญ่>, ...}
//
// ฟังก์ชัน
//   companyOrderNumber(stored, now)            ตัวนับ `admin/<x>Number` ที่อ่านได้ → {ok, orderNumber, value}
//   companyPackageQuote(packageDoc, ids)       แพ็กเกจที่เลือก → {ok, items[{id,name,price,save,type}], net}
//   companyPackageOrderQuote(packageDoc, ids, vat) ยอดใบแพ็กเกจ + VAT (ใบกำกับเฉพาะรายปี · DEV-0002) → {ok, items, totalPrice, vatAmount, net}
//   companyPackageMonths(day) · companyPackageIsYearly(priceRow)  รอบบิลจากช่อง `day` ของแถวราคา
//   companyPackageDays(day)                    รอบบิล → จำนวนวันที่ต่ออายุ (30 ต่อเดือน · 365 ต่อปี = ตาราง packageMaps ของ care) (DEV-0003 U1)
//   companyPackageFulfillItems(packageDoc, ids) แพ็กเกจในใบ → {ok, items[{id,type,days}]} สำหรับเปิดของ (ไม่สนว่ายังขายอยู่ไหม) (DEV-0003 U1)
//   companyVipRenewal(vip, items, now)         ต่ออายุ `shop.vip[]` ตามสูตร care ApproveSoftwareScreen.js:74-98 → {ok, vip, ids} (DEV-0003 U1)
//   companyHardwareQuote(hardwareDoc, lines, vat) ตะกร้าอุปกรณ์ → {ok, product[], totalPrice, deliveryFee, vatAmount, net} · ค่าส่งจาก companyHardwareShipping
//   companyHardwareShipping(hardwareDoc) ค่าส่ง/ส่งฟรีจาก doc (ไม่มี = 100/4000) · companyHardwareGroups(hardwareDoc) อุปกรณ์ที่ขายแบ่งตามหมวด
//   companyImageQuote(optionId)                ตัวเลือกพื้นที่รูป → {ok, qty, net}
//   companyBahtText(v)                         ตัวเลข → "1,234.00" (แทน useToLocale ของแอป)
//   companyPackageNotiText(items) · companyHardwareNotiText(product) · companyImageNotiHeading(qty)  ข้อความ notification รูปเดิม
//   COMPANY_IMAGE_OPTIONS · COMPANY_HARDWARE_LIMIT_DEFAULT · COMPANY_DELIVERY_FREE_FROM · COMPANY_DELIVERY_FEE · COMPANY_ORDER_PENDING_TEXT
"use strict";

const money = require("./money");
const { periodOf } = require("./docNumber");
const { toMillis } = require("./shift");

// ตารางพื้นที่รูปของแอปเดิม (main3 src/screens/ImageLimitScreen.js:27-33) · คัดตามตัว
const COMPANY_IMAGE_OPTIONS = Object.freeze([
  Object.freeze({ id: 1, image: 1000, price: 100 }),
  Object.freeze({ id: 2, image: 2000, price: 200 }),
  Object.freeze({ id: 3, image: 3000, price: 300 }),
  Object.freeze({ id: 4, image: 4000, price: 400 }),
  Object.freeze({ id: 5, image: 5000, price: 500 }),
]);
// จำนวนสั่งสูงสุดเมื่ออุปกรณ์ไม่ได้ตั้ง limit (main3 src/screens/HardwareScreen.js:82 `{limit:999,...a}`)
const COMPANY_HARDWARE_LIMIT_DEFAULT = 999;
// ค่าส่งอุปกรณ์ (main3 src/screens/HardwareSummaryScreen.js:64) · ยอดก่อน VAT ≥ 4000 ส่งฟรี ไม่งั้น 100
const COMPANY_DELIVERY_FREE_FROM = 4000;
const COMPANY_DELIVERY_FEE = 100;
const COMPANY_VAT_RATE_PERMILLE = 70; // 7% · คิดบนสตางค์ (0.07 ของเดิมเป็นทศนิยมลอยตัว · B6)
// แพ็กเกจรายปี = รอบ 12 เดือน (`admin/package.value[].price[].day` "12 เดือน" · ขอใบกำกับได้เฉพาะรายปี · Pack เคาะ 2026-11-07)
const COMPANY_PACKAGE_YEAR_MONTHS = 12;
// วันที่ต่ออายุต่อรอบ = ตาราง packageMaps ของ care (`care:screens/ApproveSoftwareScreen.js:18-29` · รายเดือน 30 · รายปี 365) (DEV-0003 U1)
const COMPANY_PACKAGE_MONTH_DAYS = 30;
const COMPANY_PACKAGE_YEAR_DAYS = 365;
const COMPANY_TZ = "Asia/Bangkok"; // care เทียบวันหมดอายุด้วยนาฬิกาเครื่องทีมงาน (ไทย) · server อยู่ UTC ⇒ คิดบนผนังนาฬิกาไทยเสมอ
// ท้ายข้อความ notification ของใบสั่งซื้อทุกชนิด (PayScreen.js:157 · HardwareSummaryScreen.js:152 · ImageLimitScreen.js:140)
const COMPANY_ORDER_PENDING_TEXT = "สถานะ : รอตรวจสอบ\n*รอตรวจสอบยืนยันการชำระเงิน ภายใน 24 ชั่วโมง";
const RUN_WIDTH = 6;

const isObj = (o) => o !== null && typeof o === "object" && !Array.isArray(o);
const isNonEmptyString = (v) => typeof v === "string" && v !== "";

/**
 * companyOrderNumber(stored, now) — เลขใบถัดไปจาก `admin/packageNumber` `hardwareNumber` `imageNumber` (`stockNumber` ใช้ได้ด้วย)
 * @param {object|null|undefined} stored data ของ doc ตัวนับ · ไม่มี doc = null/undefined
 * @param {Date|number} now เวลา server
 * @returns {{ok:true, orderNumber:string, value:number, created:boolean} | {ok:false, error:'COUNTER_BROKEN'|'NOW_INVALID'}}
 *   ไม่มี doc = เริ่ม 1 และผู้เรียกต้องสร้าง doc (created:true · AC-38 เดิมไม่สร้าง ⇒ ทุกใบได้เลข ...000001)
 *   มี doc แต่ value ไม่ใช่จำนวนเต็ม ≥ 0 = COUNTER_BROKEN (เดิม undefined+1 = NaN ถูกเขียนกลับ · admin B9) · ไม่เดาเลข
 *   ตัวนับไม่รีเซ็ตรายเดือน (เหมือนเดิม) · หัว YYYYMM ตามนาฬิกาไทยของ server (เดิมนาฬิกาเครื่อง · AC-63)
 */
function companyOrderNumber(stored, now) {
  const p = periodOf("month", now);
  if (!p.ok) return { ok: false, error: "NOW_INVALID" };
  let value;
  let created = false;
  if (stored === null || stored === undefined) {
    value = 1;
    created = true;
  } else {
    const v = isObj(stored) ? stored.value : undefined;
    if (typeof v !== "number" || !Number.isSafeInteger(v) || v < 0 || !Number.isSafeInteger(v + 1)) return { ok: false, error: "COUNTER_BROKEN" };
    value = v + 1;
  }
  const head = String(Math.floor(p.key / 100)).padStart(4, "0") + String(p.key % 100).padStart(2, "0");
  return { ok: true, orderNumber: head + String(value).padStart(RUN_WIDTH, "0"), value, created };
}

/**
 * ราคาจากเอกสารบริษัท → สตางค์ · รับ number ที่ finite ≥ 0 หรือข้อความทศนิยมธรรมดา ("1500" "1500.50" · ราคาอุปกรณ์เก็บเป็นข้อความ)
 *   อย่างอื่น ("" "abc" "1e3" ค่าลบ NaN) = null ⇒ ผู้เรียกปัดรายการนั้น (เดิม Number('abc') = NaN ไหลเข้ายอด)
 */
function priceOf(v) {
  if (typeof v === "number") return Number.isFinite(v) && v >= 0 ? money.toSatang(v) : null;
  if (typeof v === "string" && /^\s*\d+(\.\d+)?\s*$/.test(v)) return money.toSatang(v.trim());
  return null;
}

/**
 * แถวที่ขายผ่านแอปใหม่ได้ = `status` truthy (แถวที่แอปเดิมเห็นด้วย) **หรือ** `newApp === true`
 *   newApp = แพ็กเกจที่ขายเฉพาะแอปใหม่ · ตั้ง status:false ไว้ให้แอป 3.12 ซ่อน (main3 PackageScreen.js:44 กรองด้วย status)
 *   เช่น `gateway` (Payment Gateway · Pack เคาะ 2026-11-08) · newApp ต้องเป็น true ตรงตัว ("true" · 1 ไม่นับ)
 */
function sellableRow(row) {
  return isObj(row) && (!!row.status || row.newApp === true);
}

/** แถวราคาที่ขายอยู่ของ id (แถว `value[]` ที่ sellableRow) · ไม่เจอ = null · ใช้ร่วม companyPackageQuote และ companyPackageOrderQuote */
function sellingPackageOf(packageDoc, id) {
  for (const row of packageDoc.value) {
    if (!sellableRow(row) || !Array.isArray(row.price)) continue;
    const pr = row.price.find((p) => isObj(p) && p.id !== undefined && p.id !== null && String(p.id) === id);
    if (pr) return { row, pr };
  }
  return null;
}

/**
 * companyPackageQuote(packageDoc, ids) — ราคาแพ็กเกจที่ร้านเลือก จาก `admin/package`
 *   แถวที่ขายได้ = `value[]` ที่ `status` truthy (main3 PackageScreen.js:44 `value.filter(a=>a.status)`) หรือ `newApp === true` (sellableRow)
 *   หา `price[]` ด้วย `id` (ในฐานเป็นข้อความทั้ง 10 แถว · วัด 2026-11-06) เทียบแบบ String ⇒ รับได้ทั้งเลขและข้อความ
 *   ชื่อ = ชื่อแถว `value[].name` (แถว price ไม่มี name ในฐาน · main3 PackageScreen.js:60 `{name, ...price}`)
 *   net = ผลรวมราคา ไม่มี VAT (ใบที่มี VAT ใช้ companyPackageOrderQuote · DEV-0002)
 * @returns {{ok:true, items, net, netSatang} | {ok:false, error:'PACKAGE_DOC_INVALID'|'NO_PACKAGE'|'DUPLICATE_PACKAGE'|'PACKAGE_UNAVAILABLE'|'PACKAGE_PRICE_INVALID', id?}}
 */
function companyPackageQuote(packageDoc, ids) {
  if (!isObj(packageDoc) || !Array.isArray(packageDoc.value)) return { ok: false, error: "PACKAGE_DOC_INVALID" };
  if (!Array.isArray(ids) || ids.length === 0) return { ok: false, error: "NO_PACKAGE" };
  const seen = new Set();
  const items = [];
  let netSatang = 0;
  for (const raw of ids) {
    const id = String(raw);
    if (seen.has(id)) return { ok: false, error: "DUPLICATE_PACKAGE", id };
    seen.add(id);
    const found = sellingPackageOf(packageDoc, id);
    if (!found) return { ok: false, error: "PACKAGE_UNAVAILABLE", id };
    const s = priceOf(found.pr.price);
    if (s === null || s === 0) return { ok: false, error: "PACKAGE_PRICE_INVALID", id };
    netSatang += s;
    items.push({
      id: found.pr.id,
      name: typeof found.row.name === "string" ? found.row.name : "",
      price: money.fromSatang(s),
      save: typeof found.pr.save === "number" ? found.pr.save : null,
      type: typeof found.row.type === "string" ? found.row.type : null,
    });
  }
  return { ok: true, items, net: money.fromSatang(netSatang), netSatang };
}

/**
 * companyPackageMonths(day) — รอบบิลของแถวราคาแพ็กเกจเป็นจำนวนเดือน จาก `admin/package.value[].price[].day` (DEV-0002)
 *   ในฐานเป็นข้อความ "1 เดือน" / "12 เดือน" (วัด 2026-11-07: 10 แถว · 5 แถว "1 เดือน" id 1 3 5 7 9 · 5 แถว "12 เดือน" id 2 4 6 8 10
 *   ตรงกับตาราง packageMaps ของ care ที่ให้ 30/365 วันตาม id · `care:screens/ApproveSoftwareScreen.js:18-29`)
 *   รับ "<n> เดือน" และ "<n> ปี" (= n×12) เว้นวรรคได้ · อย่างอื่น (ไม่มีช่อง · ข้อความอื่น · ตัวเลขเปล่า) = null ⇒ ไม่รู้รอบ
 *   ❌ ไม่ดูชื่อแพ็กเกจ และไม่ดู `save` (save เป็นยอดประหยัดที่จอใช้แยกแท็บ ไม่ใช่ระยะเวลา)
 */
function companyPackageMonths(day) {
  if (typeof day !== "string") return null;
  const m = /^\s*(\d{1,3})\s*(เดือน|ปี)\s*$/.exec(day);
  if (!m) return null;
  const n = Number(m[1]);
  if (!Number.isSafeInteger(n) || n < 1) return null;
  return m[2] === "ปี" ? n * 12 : n;
}

/** companyPackageIsYearly(priceRow) — แถวราคานี้เป็นแพ็กเกจรายปีไหม (รอบ 12 เดือนพอดี) · ไม่รู้รอบ = false (ขอใบกำกับไม่ได้ · fail-closed) */
function companyPackageIsYearly(priceRow) {
  return isObj(priceRow) && companyPackageMonths(priceRow.day) === COMPANY_PACKAGE_YEAR_MONTHS;
}

/**
 * companyPackageOrderQuote(packageDoc, ids, vat) — ยอดของใบสั่งซื้อแพ็กเกจที่ server ใช้ (DEV-0002 · Pack เคาะ 2026-11-07)
 *   ราคาและการปัดเหมือน companyPackageQuote ทุกอย่าง แล้วเพิ่ม VAT:
 *   vat === true = ขอใบกำกับภาษี ⇒ ทุกแพ็กเกจในใบต้องเป็นรายปี (companyPackageIsYearly) ไม่งั้น TAX_INVOICE_YEARLY_ONLY {id ตัวแรกที่ไม่ใช่รายปี}
 *     vatAmount = 7% ของยอดรวม ปัดสตางค์ครั้งเดียว (สูตรเดียวกับอุปกรณ์ · ไม่ปัดรายแถว) · net = totalPrice + vatAmount
 *   vat ไม่ใช่ true = ไม่มี VAT (vatAmount 0 · net = totalPrice = companyPackageQuote.net)
 * @returns {{ok:true, items, totalPrice, vatAmount, net, netSatang, vat:boolean} | {ok:false, error, id?}}
 */
function companyPackageOrderQuote(packageDoc, ids, vat) {
  const q = companyPackageQuote(packageDoc, ids);
  if (!q.ok) return q;
  const withVat = vat === true;
  if (withVat) {
    for (const raw of ids) {
      const id = String(raw);
      const found = sellingPackageOf(packageDoc, id);
      if (!found || !companyPackageIsYearly(found.pr)) return { ok: false, error: "TAX_INVOICE_YEARLY_ONLY", id };
    }
  }
  const vatSatang = withVat ? Math.round((q.netSatang * COMPANY_VAT_RATE_PERMILLE) / 1000) : 0;
  const netSatang = q.netSatang + vatSatang;
  return {
    ok: true,
    items: q.items,
    totalPrice: q.net,
    vatAmount: money.fromSatang(vatSatang),
    net: money.fromSatang(netSatang),
    netSatang,
    vat: withVat,
  };
}

// ── เปิดของแพ็กเกจ (DEV-0003 U1 · ย้ายสูตรจาก care ApproveSoftwareScreen.js มาไว้ที่เดียว) ──────────────────────

/**
 * companyPackageDays(day) — จำนวนวันที่ต่ออายุจากช่อง `price[].day` ("1 เดือน" / "12 เดือน" / "<n> ปี")
 *   care ใช้ตาราง packageMaps ตาย ๆ: รายเดือน 30 วัน · รายปี 365 วัน (`care:screens/ApproveSoftwareScreen.js:18-29`)
 *   ที่นี่คิดจากช่อง day แทน ⇒ id 11/12 (gateway · "1 เดือน"/"12 เดือน") ได้ 30/365 เท่าแถว 1-10 โดยไม่ต้องแก้ตาราง
 *   สูตร: ปีเต็ม × 365 + เดือนที่เหลือ × 30 (1→30 · 12→365 · 24→730 · 13→395) · ไม่รู้รอบ = null (ผู้เรียกต้องปัด ไม่เดา)
 */
function companyPackageDays(day) {
  const months = companyPackageMonths(day);
  if (months === null) return null;
  const years = Math.floor(months / COMPANY_PACKAGE_YEAR_MONTHS);
  return years * COMPANY_PACKAGE_YEAR_DAYS + (months % COMPANY_PACKAGE_YEAR_MONTHS) * COMPANY_PACKAGE_MONTH_DAYS;
}

/** แถวราคาของ id จาก `value[]` ทุกแถว (ไม่กรอง status/newApp · ใบที่ซื้อไปแล้วต้องเปิดได้แม้วันนี้ปิดขาย) */
function anyPackageOf(packageDoc, id) {
  for (const row of packageDoc.value) {
    if (!isObj(row) || !Array.isArray(row.price)) continue;
    const pr = row.price.find((p) => isObj(p) && p.id !== undefined && p.id !== null && String(p.id) === id);
    if (pr) return { row, pr };
  }
  return null;
}

/**
 * companyPackageFulfillItems(packageDoc, ids) — รายการที่ต้องเปิดจาก `packageOrder.packageId[]` + `admin/package`
 *   type = `value[].type` (ช่องที่แอปเทียบกับ `shop.vip[].type` · `app:screens/PackageScreen.js:89`) · days = companyPackageDays(price[].day)
 *   ❌ ไม่ใช้ตาราง id→type ตาย ๆ แบบ care (ตารางนั้นมีแค่ 1-10 ⇒ ใบ gateway 11/12 อนุมัติไม่ได้ · census ช่องว่าง 3)
 *   id ซ้ำในใบ = ใส่ซ้ำตามลำดับ (care ก็วนตามลำดับ · ตัวสร้างใบกันซ้ำอยู่แล้ว)
 * @returns {{ok:true, items:[{id, type, days, name}]} | {ok:false, error:'PACKAGE_DOC_INVALID'|'NO_PACKAGE'|'PACKAGE_NOT_FOUND'|'PACKAGE_TYPE_INVALID'|'PACKAGE_PERIOD_UNKNOWN', id?}}
 */
function companyPackageFulfillItems(packageDoc, ids) {
  if (!isObj(packageDoc) || !Array.isArray(packageDoc.value)) return { ok: false, error: "PACKAGE_DOC_INVALID" };
  if (!Array.isArray(ids) || ids.length === 0) return { ok: false, error: "NO_PACKAGE" };
  const items = [];
  for (const raw of ids) {
    const id = String(raw);
    const found = anyPackageOf(packageDoc, id);
    if (!found) return { ok: false, error: "PACKAGE_NOT_FOUND", id };
    if (!isNonEmptyString(found.row.type)) return { ok: false, error: "PACKAGE_TYPE_INVALID", id };
    const days = companyPackageDays(found.pr.day);
    if (days === null) return { ok: false, error: "PACKAGE_PERIOD_UNKNOWN", id };
    items.push({ id: found.pr.id, type: found.row.type, days, name: typeof found.row.name === "string" ? found.row.name : "" });
  }
  return { ok: true, items };
}

/** วันปฏิทินไทย YYYYMMDD ของเวลาใด ๆ (Date · Timestamp · ms) · อ่านไม่ได้ = null */
function thaiDayKey(t) {
  const ms = toMillis(t);
  if (ms === null) return null;
  const p = periodOf("day", ms, COMPANY_TZ);
  return p.ok ? p.key : null;
}

/**
 * companyVipRenewal(vip, items, now) — `shop.vip[]` ใหม่หลังเปิดแพ็กเกจ · สูตรเดียวกับ care `ApproveSoftwareScreen.js:74-98` ตัวต่อตัว
 *   วนรายการตามลำดับ · ต่อชนิด (type):
 *     มีแถว type นี้: วันนี้ (ปฏิทินไทย) > วันหมดอายุ = หมดแล้ว ⇒ นับจากวันนี้ (`:81-82`) · ยังไม่หมด (รวมวันหมดอายุพอดี) ⇒ ต่อจากวันเดิม (`:83-84`)
 *       แถวที่ถูกต่อถูกแทนด้วย {type, expire} ล้วน (`:86-90` care ทิ้ง field อื่นของแถวนั้น) · ซื้อชนิดเดียว 2 รายการในใบ = ต่อซ้อนกัน
 *     ไม่มีแถว: เพิ่ม {type, expire: วันนี้ + days} ท้ายรายการ (`:91-96`)
 *   expire ของแถวที่อ่านไม่ได้ (ไม่ใช่ Date/Timestamp) = ถือว่าหมดแล้ว (care throw ทั้ง transaction ⇒ ที่นี่ fail-safe ให้ร้านได้ของ)
 *   แถวอื่นที่ไม่แตะ: คงไว้ทั้งแถว แต่ expire แปลงเป็น Date (care `:75` map ทุกแถวเป็น Date ก่อนเขียนกลับ)
 *   บวกวัน = +days × 86,400,000 ms (care ใช้ setDate บนนาฬิกาไทย · ไทยไม่มี DST ⇒ เท่ากัน)
 *   ids = รหัสที่ care ต่อเข้า `currentPackage` (`:101` · care ได้เลขจากตาราง ⇒ ที่นี่แปลง "1" → 1 เมื่อเป็นเลขล้วน · อื่นคงเดิม)
 * @param {Array} vip shop.vip[] ที่อ่านจากฐาน
 * @param {Array<{type:string, days:number, id}>} items จาก companyPackageFulfillItems
 * @param {Date|number} now เวลา server
 * @returns {{ok:true, vip:Array<{type, expire:Date}>, ids:Array, touched:string[]} | {ok:false, error:'NOW_INVALID'|'ITEMS_INVALID'}}
 */
function companyVipRenewal(vip, items, now) {
  const nowMs = toMillis(now);
  if (nowMs === null || thaiDayKey(nowMs) === null) return { ok: false, error: "NOW_INVALID" };
  if (!Array.isArray(items) || items.length === 0) return { ok: false, error: "ITEMS_INVALID" };
  for (const it of items) {
    if (!isObj(it) || !isNonEmptyString(it.type) || !Number.isSafeInteger(it.days) || it.days < 1) return { ok: false, error: "ITEMS_INVALID" };
  }
  const today = thaiDayKey(nowMs);
  const dayMs = 86400000;
  const asDate = (ms) => new Date(ms);
  let rows = (Array.isArray(vip) ? vip : []).filter(isObj).map((a) => {
    const ms = toMillis(a.expire);
    return ms === null ? { ...a } : { ...a, expire: asDate(ms) };
  });
  const touched = [];
  for (const { type, days } of items) {
    const idx = rows.findIndex((a) => a.type === type);
    if (idx >= 0) {
      const curMs = toMillis(rows[idx].expire);
      const curDay = curMs === null ? null : thaiDayKey(curMs);
      const expired = curDay === null || today > curDay;
      const base = expired ? nowMs : curMs;
      rows = rows.map((a, i) => (i === idx ? { type, expire: asDate(base + days * dayMs) } : a));
    } else {
      rows.push({ type, expire: asDate(nowMs + days * dayMs) });
    }
    if (!touched.includes(type)) touched.push(type);
  }
  const ids = items.map((it) => (typeof it.id === "string" && /^\d+$/.test(it.id) ? Number(it.id) : it.id));
  return { ok: true, vip: rows, ids, touched };
}

/** limit ของอุปกรณ์ · ไม่มี key · '' · ข้อความที่ไม่ใช่จำนวนเต็มบวก = ค่าตั้งต้น 999 (AC-67 · hardwareOrder/admin B12 เดิม '' สั่งได้ชิ้นเดียว) */
function limitOf(v) {
  if (typeof v === "number" && Number.isSafeInteger(v) && v >= 1) return v;
  if (typeof v === "string" && /^\s*\d+\s*$/.test(v)) {
    const n = Number(v.trim());
    if (Number.isSafeInteger(n) && n >= 1) return n;
  }
  return COMPANY_HARDWARE_LIMIT_DEFAULT;
}

/**
 * companyHardwareQuote(hardwareDoc, lines, vat) — ตะกร้าอุปกรณ์จาก `admin/hardware` ที่อ่านตอนสั่ง (ไม่ใช่ราคาที่ค้างในเครื่อง · B14)
 *   lines = [{id, qty}] · qty จำนวนเต็ม ≥ 1 · id ซ้ำ = ปัด
 *   แถวที่ขายได้ = `status === true` (main3 HardwareScreen.js:82 `.filter(b=>b.status)` · B19 ปิดขายแล้วยังค้างในตะกร้า)
 *   qty เกิน limit = QTY_OVER_LIMIT (เดิมกันที่ปุ่มบวกบนจออย่างเดียว · AC-67)
 *   totalPrice = Σ ราคา × qty · ค่าส่ง 0 เมื่อ totalPrice ≥ 4000 ไม่งั้น 100 · vat = 7% ของ totalPrice ปัดสตางค์ (B6)
 *   net = totalPrice + vatAmount + deliveryFee (รูปเดิม `1.07*totalPrice + deliveryFee`)
 *   product[] = แถวของบริษัท + {qty, totalPrice} (รูปเดิม `{...item, qty, totalPrice}` main3 HardwareScreen.js:57 · equipmentSlice.js:18)
 * @returns {{ok:true, product, totalPrice, deliveryFee, vatAmount, net} | {ok:false, error, id?, limit?}}
 */
function companyHardwareQuote(hardwareDoc, lines, vat) {
  if (!isObj(hardwareDoc) || !Array.isArray(hardwareDoc.value)) return { ok: false, error: "HARDWARE_DOC_INVALID" };
  if (!Array.isArray(lines) || lines.length === 0) return { ok: false, error: "EMPTY_CART" };
  const seen = new Set();
  const product = [];
  let totalSatang = 0;
  for (const line of lines) {
    if (!isObj(line) || !isNonEmptyString(line.id)) return { ok: false, error: "LINE_INVALID" };
    const qty = line.qty;
    if (typeof qty !== "number" || !Number.isSafeInteger(qty) || qty < 1) return { ok: false, error: "LINE_INVALID", id: line.id };
    if (seen.has(line.id)) return { ok: false, error: "DUPLICATE_HARDWARE", id: line.id };
    seen.add(line.id);
    const row = hardwareDoc.value.find((r) => isObj(r) && r.id === line.id);
    if (!row || row.status !== true) return { ok: false, error: "HARDWARE_UNAVAILABLE", id: line.id };
    const s = priceOf(row.price);
    if (s === null || s === 0) return { ok: false, error: "HARDWARE_PRICE_INVALID", id: line.id };
    const limit = limitOf(row.limit);
    if (qty > limit) return { ok: false, error: "QTY_OVER_LIMIT", id: line.id, limit };
    const lineSatang = s * qty;
    if (!Number.isSafeInteger(lineSatang)) return { ok: false, error: "HARDWARE_PRICE_INVALID", id: line.id };
    totalSatang += lineSatang;
    product.push({ ...row, qty, totalPrice: money.fromSatang(lineSatang) });
  }
  const vatSatang = vat === true ? Math.round((totalSatang * COMPANY_VAT_RATE_PERMILLE) / 1000) : 0;
  const ship = companyHardwareShipping(hardwareDoc);
  const feeSatang = ship.freeFrom !== null && totalSatang >= ship.freeFrom * 100 ? 0 : ship.fee * 100;
  return {
    ok: true,
    product,
    totalPrice: money.fromSatang(totalSatang),
    deliveryFee: money.fromSatang(feeSatang),
    vatAmount: money.fromSatang(vatSatang),
    net: money.fromSatang(totalSatang + vatSatang + feeSatang),
  };
}

const SHIP_FEE_MAX = 100000;
const SHIP_FREE_MAX = 10000000;
const isIntIn = (v, lo, hi) => typeof v === "number" && Number.isSafeInteger(v) && v >= lo && v <= hi;

/**
 * companyHardwareShipping(hardwareDoc) — ค่าส่งอุปกรณ์จาก `admin/hardware.shipping` (office ตั้ง · Pack เคาะ 3b 2026-11-11)
 *   {fee: บาท int ≥0, freeFrom: บาท int ≥0 | null (= ไม่มีส่งฟรี)} · ช่องหาย/ผิดรูป = ค่าเดิม 100 / 4000 (isDefault true)
 *   แอปเก่า 3.12 ไม่อ่านช่องนี้ (คิด 100/4000 เองและเขียนใบตรงฐาน)
 */
function companyHardwareShipping(hardwareDoc) {
  const sh = isObj(hardwareDoc) && isObj(hardwareDoc.shipping) ? hardwareDoc.shipping : null;
  if (sh && isIntIn(sh.fee, 0, SHIP_FEE_MAX) && (sh.freeFrom === null || isIntIn(sh.freeFrom, 0, SHIP_FREE_MAX))) {
    return { fee: sh.fee, freeFrom: sh.freeFrom, isDefault: false };
  }
  return { fee: COMPANY_DELIVERY_FEE, freeFrom: COMPANY_DELIVERY_FREE_FROM, isDefault: true };
}

/**
 * companyHardwareGroups(hardwareDoc) — อุปกรณ์ที่ขายได้ (status === true) แบ่งตามหมวดสำหรับจอร้าน (Pack เคาะ 1b 2026-11-11)
 *   หมวด = `categories[]` ที่ active ตามลำดับ array · แถวในหมวดตามลำดับ `value[]`
 *   แถวไม่มีหมวด / หมวดไม่รู้จัก / หมวดปิด = กลุ่มสุดท้าย {id:null, name:'อื่น ๆ'} · กลุ่มว่างไม่คืน
 *   ไม่มีหมวดเลย = กลุ่มเดียว {id:null, name:''} (จอแสดง grid เดิม)
 * @returns {Array<{id:string|null, name:string, items:object[]}>}
 */
function companyHardwareGroups(hardwareDoc) {
  const rows = isObj(hardwareDoc) && Array.isArray(hardwareDoc.value) ? hardwareDoc.value.filter((r) => isObj(r) && r.status === true) : [];
  const cats = isObj(hardwareDoc) && Array.isArray(hardwareDoc.categories)
    ? hardwareDoc.categories.filter((c) => isObj(c) && isNonEmptyString(c.id) && c.active === true)
    : [];
  if (!cats.length) return rows.length ? [{ id: null, name: "", items: rows }] : [];
  const known = new Set(cats.map((c) => c.id));
  const out = cats.map((c) => ({ id: c.id, name: typeof c.name === "string" ? c.name : "", items: rows.filter((r) => r.categoryId === c.id) }));
  out.push({ id: null, name: "อื่น ๆ", items: rows.filter((r) => !known.has(r.categoryId)) });
  return out.filter((g) => g.items.length > 0);
}

/** companyImageQuote(optionId) — ตัวเลือกพื้นที่รูป 1-5 → {ok, qty(=จำนวนรูป), net} · อื่น = IMAGE_OPTION_UNKNOWN */
function companyImageQuote(optionId) {
  const o = COMPANY_IMAGE_OPTIONS.find((x) => x.id === optionId);
  if (!o) return { ok: false, error: "IMAGE_OPTION_UNKNOWN" };
  return { ok: true, qty: o.image, net: o.price };
}

/** companyBahtText(v) — "1,234.00" แบบ useToLocale ของแอป (main3 src/Utility/function.js:752) · ไม่ใช่ตัวเลข = '' */
function companyBahtText(v) {
  if (typeof v !== "number" || !Number.isFinite(v)) return "";
  return v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** ข้อความ notification ของใบแพ็กเกจ · รูปเดิม main3 PayScreen.js:157 */
function companyPackageNotiText(items) {
  const list = Array.isArray(items) ? items : [];
  return `แพ็กเกจ\n${list.map((a) => `   ${a.name} (${companyBahtText(a.price)} บาท)`).join("\n")}\n${COMPANY_ORDER_PENDING_TEXT}`;
}

/** ข้อความ notification ของใบอุปกรณ์ · รูปเดิม main3 HardwareSummaryScreen.js:152 */
function companyHardwareNotiText(product) {
  const list = Array.isArray(product) ? product : [];
  return `อุปกรณ์\n${list.map((a) => `   ${a.name} x ${a.qty} (${companyBahtText(a.totalPrice)} บาท)`).join("\n")}\n${COMPANY_ORDER_PENDING_TEXT}`;
}

/** หัวข้อ notification ของใบพื้นที่รูป · คำผิด "พิ้นที่" คงตามเดิม (main3 ImageLimitScreen.js:138) ให้จอเก่าแสดงเหมือนเดิม */
function companyImageNotiHeading(qty) {
  return `ซื้อพิ้นที่เก็บรูปภาพ ${qty} รายการ`;
}

module.exports = {
  companyOrderNumber,
  companyPackageQuote,
  companyPackageMonths,
  companyPackageIsYearly,
  companyPackageOrderQuote,
  companyPackageDays,
  companyPackageFulfillItems,
  companyVipRenewal,
  companyHardwareQuote,
  companyImageQuote,
  companyBahtText,
  companyPackageNotiText,
  companyHardwareNotiText,
  companyImageNotiHeading,
  COMPANY_IMAGE_OPTIONS,
  COMPANY_HARDWARE_LIMIT_DEFAULT,
  COMPANY_DELIVERY_FREE_FROM,
  COMPANY_DELIVERY_FEE,
  companyHardwareShipping,
  companyHardwareGroups,
  COMPANY_ORDER_PENDING_TEXT,
  COMPANY_PACKAGE_YEAR_MONTHS,
  COMPANY_PACKAGE_MONTH_DAYS,
  COMPANY_PACKAGE_YEAR_DAYS,
};

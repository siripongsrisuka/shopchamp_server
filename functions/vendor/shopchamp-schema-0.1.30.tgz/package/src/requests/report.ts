import { z } from "zod";

/**
 * คำขอ API โดเมนรายงาน (ก้อน 9e · DEV-0001) · route อ่านหนักบน function `pos_heavy` · ใช้ร่วมกับเว็บ (DEV-0002)
 * strict ทุกชั้น: field เกิน = ปัด 400 · อ่านอย่างเดียว ไม่มีการเขียนฐาน
 * สัญญา: `shopchamp-center/api/report.{billList,salesTotals,taxInvoices,duplicateNumbers,shiftHistory,breakdown,memberBills}.yaml`
 *
 * หลักที่ใช้:
 * - วันที่ส่งเป็นคีย์วันธุรกิจ `YYYYMMDD` เท่านั้น ไม่รับเวลา (`logic:businessDay.js` หัวไฟล์ 🌏) · server แปลงเป็นช่วงเวลาตาม `shop.cutOff` เอง (#24 WR-01)
 * - ช่วงยาวสุด 31 วันธุรกิจต่อคำขอ (`logic:report.js` REPORT_MAX_DAYS) · เว็บที่ต้องการหลายเดือนเรียกทีละช่วง
 * - รายงานภาษีและเลขซ้ำใช้เดือนของเลขเอกสาร `YYYYMM` (เลขใบเสร็จ/ใบกำกับขึ้นต้นด้วยปีเดือนเสมอ · `logic:docNumber.js`)
 */

const MAX_DAYS = 31;
const DAY_MS = 86400000;

/** doc id: ห้ามว่าง ห้ามมี `/` · ≤ 128 */
const DocId = z
  .string()
  .min(1, { message: "id ห้ามว่าง" })
  .max(128)
  .refine((s) => !s.includes("/"), { message: "id ห้ามมี /" });

const dayNumber = (s: string): number | null => {
  const m = /^(\d{4})(\d{2})(\d{2})$/.exec(s);
  if (!m) return null;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  if (y < 2000 || y > 9999) return null;
  const t = new Date(Date.UTC(y, mo - 1, d));
  if (t.getUTCFullYear() !== y || t.getUTCMonth() !== mo - 1 || t.getUTCDate() !== d) return null;
  return Math.round(t.getTime() / DAY_MS);
};

/** คีย์วันธุรกิจ `YYYYMMDD` ที่เป็นวันจริง (ปี 2000-9999) */
export const ReportDayKey = z
  .string()
  .regex(/^\d{8}$/, { message: "วันที่ต้องเป็น YYYYMMDD" })
  .refine((s) => dayNumber(s) !== null, { message: "ไม่มีวันที่นี้" });

/** เดือนของเลขเอกสาร `YYYYMM` */
export const ReportMonthKey = z
  .string()
  .regex(/^\d{6}$/, { message: "เดือนต้องเป็น YYYYMM" })
  .refine((s) => {
    const y = Number(s.slice(0, 4)), m = Number(s.slice(4, 6));
    return y >= 2000 && m >= 1 && m <= 12;
  }, { message: "ไม่มีเดือนนี้" });

/** ช่วงวันธุรกิจ: fromDay ≤ toDay · ไม่เกิน 31 วัน */
function checkRange(v: { fromDay: string; toDay: string }, ctx: z.RefinementCtx) {
  const a = dayNumber(v.fromDay), b = dayNumber(v.toDay);
  if (a === null || b === null) return; // ฟิลด์เองฟ้องแล้ว
  if (b < a) ctx.addIssue({ code: "custom", path: ["toDay"], message: "วันสิ้นสุดต้องไม่ก่อนวันเริ่ม" });
  else if (b - a + 1 > MAX_DAYS) ctx.addIssue({ code: "custom", path: ["toDay"], message: `ช่วงวันยาวได้ไม่เกิน ${MAX_DAYS} วัน` });
}

const RangeFields = {
  shopId: DocId,
  fromDay: ReportDayKey.describe("วันธุรกิจแรก (รวม)"),
  toDay: ReportDayKey.describe("วันธุรกิจสุดท้าย (รวม)"),
};

/** ตัวชี้หน้าถัดไปของรายการบิล · ได้จาก `nextCursor` ของคำตอบก่อนหน้า */
export const ReportBillCursor = z
  .object({
    at: z.iso.datetime({ offset: true }).describe("เวลาขายของแถวสุดท้ายในหน้าก่อน"),
    id: DocId.describe("doc id ของแถวสุดท้ายในหน้าก่อน"),
  })
  .strict();

/** report.billList — รายการบิลของช่วงวันธุรกิจ ล่าสุดก่อน แบ่งหน้า (แทน `/bill/test` ของ server เดิม) */
export const ReportBillListRequest = z
  .object({
    ...RangeFields,
    pageSize: z.number().int().min(1).max(200).optional().describe("ไม่ส่ง = 50"),
    cursor: ReportBillCursor.optional(),
    detail: z.boolean().optional().describe("true = แถวมี detail (ยอดสินค้า ส่วนลด ต้นทุน ภาษี ช่องจ่ายหลังทอน สมาชิก) และ bill (เอกสารเต็ม) · จอ 4.1 4.3 ของเว็บ (DEV-0002)"),
  })
  .strict()
  .superRefine(checkRange);

/** report.salesTotals — ยอดขายของช่วงวันธุรกิจ (แทน `/bill/summary` เดิม + ยอดรายวัน รายช่องจ่าย รายสินค้าหลังกระจายส่วนลด) */
export const ReportSalesTotalsRequest = z.object({ ...RangeFields }).strict().superRefine(checkRange);

/** report.shiftHistory — ประวัติกะของช่วงวันธุรกิจ (ตามเวลาปิดกะ) พร้อมยอดบิลมาช้า */
export const ReportShiftHistoryRequest = z
  .object({
    ...RangeFields,
    dayBy: z.enum(["close", "open"]).optional().describe("ค้นตามวันปิดกะ (ไม่ส่ง) หรือวันเปิดกะ (จอประวัติกะเว็บเดิม · DEV-0002)"),
  })
  .strict()
  .superRefine(checkRange);

/** มิติของ report.breakdown (ตรงกับ logic report.BREAKDOWN_DIMENSIONS) */
export const ReportBreakdownDimension = z.enum(["total", "hour", "item", "consignment", "category", "payment", "discount"]);

/** report.breakdown — ยอดขายแยกมิติ ของช่วงวันธุรกิจ · ทั้งช่วงหรือรายวัน (จอรายงาน 1.1-1.6 2.1-2.6 ของเว็บ · DEV-0002) */
export const ReportBreakdownRequest = z
  .object({
    ...RangeFields,
    dimension: ReportBreakdownDimension,
    granularity: z.enum(["total", "day"]).optional().describe("ไม่ส่ง = total"),
  })
  .strict()
  .superRefine(checkRange);

/** report.memberBills — บิลของสมาชิก 1 คนในร้าน ล่าสุดก่อน แบ่งหน้า (แทนการค้น `bill` ตรงของ own:redux/memberSlice.js fetchMemberBill · DEV-0002) */
export const ReportMemberBillsRequest = z
  .object({
    shopId: DocId,
    memberId: DocId.describe("member.id ในบิล"),
    pageSize: z.number().int().min(1).max(100).optional().describe("ไม่ส่ง = 100 (เท่าเว็บเดิม)"),
    cursor: ReportBillCursor.optional(),
  })
  .strict();

/** report.taxInvoices — ใบกำกับภาษีของเดือนภาษี รวมใบที่ยกเลิก (#21) */
export const ReportTaxInvoicesRequest = z
  .object({ shopId: DocId, month: ReportMonthKey.describe("เดือนของเลขใบกำกับ YYYYMM") })
  .strict();

/** report.duplicateNumbers — เลขใบเสร็จ/ใบกำกับที่ซ้ำในร้าน ของเดือนตามเลขเอกสาร (#19) */
export const ReportDuplicateNumbersRequest = z
  .object({ shopId: DocId, month: ReportMonthKey.describe("เดือนของเลขเอกสาร YYYYMM") })
  .strict();

export type ReportBillListRequest = z.infer<typeof ReportBillListRequest>;
export type ReportSalesTotalsRequest = z.infer<typeof ReportSalesTotalsRequest>;
export type ReportShiftHistoryRequest = z.infer<typeof ReportShiftHistoryRequest>;
export type ReportTaxInvoicesRequest = z.infer<typeof ReportTaxInvoicesRequest>;
export type ReportDuplicateNumbersRequest = z.infer<typeof ReportDuplicateNumbersRequest>;
export type ReportBreakdownRequest = z.infer<typeof ReportBreakdownRequest>;
export type ReportMemberBillsRequest = z.infer<typeof ReportMemberBillsRequest>;

/** stock.journalDays — สมุดเคลื่อนไหวสต๊อกรายวันของช่วงวัน (จอความเคลื่อนไหวสต๊อก · DEV-0008 · premium) · ไม่เกิน 31 วัน */
export const StockJournalDaysRequest = z.object({ ...RangeFields }).strict().superRefine(checkRange);

/** ตัวชี้หน้าถัดไปของรายการทีละครั้ง · ได้จาก `nextCursor` */
export const StockMoveCursor = z
  .object({
    at: z.iso.datetime({ offset: true }).describe("time ของแถวสุดท้ายในหน้าก่อน"),
    id: DocId.describe("doc id ของแถวสุดท้ายในหน้าก่อน"),
  })
  .strict();

/** stock.moveList — รายการเคลื่อนไหวทีละครั้งของสินค้า 1 ตัว ล่าสุดก่อน แบ่งหน้า (DEV-0008 · premium) */
export const StockMoveListRequest = z
  .object({
    shopId: DocId,
    stockId: DocId.describe("stock doc id"),
    limit: z.number().int().min(1).max(100).optional().describe("ต่อหน้า · ไม่ส่ง = 50"),
    cursor: StockMoveCursor.optional(),
  })
  .strict();

export type StockJournalDaysRequest = z.infer<typeof StockJournalDaysRequest>;
export type StockMoveListRequest = z.infer<typeof StockMoveListRequest>;

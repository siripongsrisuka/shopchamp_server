import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `pgWebhook/{referenceId}` — กล่องสัญญาณของเกตเวย์ 1 doc ต่อ 1 การขอรับเงิน
 * ที่มา: `lanes/dev/source/schema/pgWebhook.md` §1 (field 4 ตัว `shopId` `timestamp` `process` `chargeId`) · §2 ตารางไขว้
 *
 * - รุ่นเดิม: แอปสร้าง doc สถานะ `request` (`CO:247` add) · webhook เปลี่ยนเป็น `success` พร้อม `chargeId` (`PG:38` update)
 * - doc id คือ `referenceId` ที่ส่งให้ผู้ให้บริการ (§1) ไม่ใช่ field จึงไม่อยู่ใน schema นี้
 * - `shopId` คือ `shop.shopId` ของร้าน (`CO:113`) · รูปของร้านเก่าไม่ตายตัว ⇒ ตรวจแค่ไม่ว่าง
 * - ใช้อ่าน doc ที่มีอยู่และที่แอปเก่ายังเขียนได้ ⇒ `.passthrough()` เก็บ field ที่ไม่รู้จักไว้
 * - collection เดียวกันนี้คือที่ก้อน 7 ใช้ (แอปฟัง `pgWebhook/{referenceId}` · `architecture-plan.md` ก้อน 7)
 *   และแบบที่ยกมาเขียนรูปต่างจากรุ่นเดิม: มี `chargeId` ตั้งแต่ยัง `request` (เป็น `null` ได้) ·
 *   EDC เขียน `success` โดยไม่มี `chargeId` · ยกเลิก QR เขียน `cancelled`
 *   ⇒ schema นี้ **ไม่ผูก `process` กับ `chargeId`** · ผูกไว้ = ปัด doc รุ่นใหม่ = จ่ายแล้วจอไม่ขยับ
 *   และการผูกนั้นก็ไม่ใช่ด่านกันปลอม เพราะผู้ปลอมใส่ `chargeId` มาด้วยก็ผ่าน
 * - ก้อน 7 เพิ่มช่องของ `pos_gateway` แบบเพิ่มอย่างเดียว ไม่บังคับทุกช่อง (doc รุ่นเดิม 4 ช่องยังผ่าน) · ดู `PgWebhookGatewayFields`
 *   `shopId` ของ doc รุ่นใหม่ = shop **doc id** (ผ่านด่านร้านแล้ว · rules ก้อน 6 เทียบกับ doc ร้านได้ตรง) ไม่ใช่ `shop.shopId` แบบรุ่นเดิม
 * - client ห้ามเขียน collection นี้ (rules ก้อน 6) · server เป็นผู้เขียนเดียวในรุ่นใหม่
 * - ไม่มี field ของก้อน 4 (`receiptUUID` `soldAt` `offline`) เพราะ doc นี้เป็นสัญญาณ ไม่ไหลเข้าบิล (§3)
 * - ข้อจำกัดที่รู้ตัว: doc รุ่นเดิมไม่มียอดเงินและไม่ยืนยันที่มา (B-03 B-05) ⇒ parse ผ่าน ≠ เงินเข้าจริง
 *   ผู้ใช้ schema ห้ามถือ `process: 'success'` เป็นหลักฐานการจ่าย
 */
export const PgWebhookProcess = z
  .enum(["request", "success", "cancelled"])
  .describe(
    "`request` แอปเขียนตอนสร้าง (`CO:250`) · `success` server เขียนเมื่อผู้ให้บริการส่ง `SUCCEEDED` (`PG:38`) · " +
      "`cancelled` แบบที่ก้อน 7 ยกมาเขียนตอนยกเลิก QR สำเร็จ · รุ่นเดิมไม่มีสถานะล้ม (B-06) · ก้อน 7 เพิ่มค่าใหม่ต้องเพิ่มที่นี่",
  );

/** ยอดบาทที่เก็บใน doc: ตัวเลขจริง ไม่ติดลบ · การเทียบถึงสตางค์ทำที่ server ด้วยตัวแปลงจำนวนเต็ม (B-08) ไม่ใช่ที่ schema */
const PgBaht = z.number().finite().nonnegative();
const PgText = z.string().max(1500);

/**
 * ช่องที่ `pos_gateway` (ก้อน 7) เขียน · ไม่บังคับทุกช่อง · ไม่มีช่อง autoCheckout / remotePay (ไม่ยก · ผลตรวจ E6)
 * ผู้เขียนเดียว = server · แอปอ่านได้เฉพาะ doc ของร้านตัวเอง (rules ก้อน 6) · ❌ ห้ามถือ `process:'success'` เป็นหลักฐานเงินเข้า
 *   หลักฐานคือ `verifiedBy` + `verifiedAmount` ที่ server ได้จากการถามผู้ให้บริการซ้ำ (หรือ `edc-device` / `simulate`)
 */
export const PgWebhookGatewayFields = {
  referenceId: PgText.optional().describe("= doc id · ซ้ำไว้ให้ query และ log"),
  channelId: PgText.optional().describe("ช่องทางในทะเบียนเจ้า"),
  providerId: PgText.optional().describe("`ntt-h2h` `kbank-qr` `beam-bolt` `posxpay` `ntt-edc`"),
  amount: PgBaht.optional().describe("ยอดที่ขอ (บาท) · webhook เทียบกับยอดที่ผู้ให้บริการตอบถึงสตางค์"),
  clientRequestId: PgText.nullable().optional().describe("กุญแจกันกดซ้ำ 15 นาทีของแอป"),
  createdBy: PgText.optional().describe("uid ผู้ขอ"),
  providerRef: PgText.nullable().optional().describe("รหัสรายการฝั่งผู้ให้บริการ (ใช้ถามซ้ำ)"),
  qrPayload: z.string().max(20000).nullable().optional().describe("ข้อความ QR หรือ url รูป · ไม่ใช่ความลับ"),
  qrKind: z.enum(["text", "image"]).nullable().optional(),
  paidAt: FirestoreTime.optional(),
  verifiedBy: PgText.optional().describe("ใครยืนยัน: `webhook-ntt` `webhook-kbank` `webhook-beam` `inquire` `edc-device` `simulate`"),
  verifiedAmount: PgBaht.optional().describe("ยอดที่ผู้ให้บริการตอบตอนถามซ้ำ (บาท)"),
  verifyMismatch: z
    .object({ at: FirestoreTime, expected: PgBaht, paid: PgBaht.nullable(), verifiedBy: PgText })
    .passthrough()
    .optional()
    .describe("ผู้ให้บริการว่าจ่ายแล้วแต่ยอดไม่ตรง ⇒ ไม่ mark success"),
  cancelRequestedAt: FirestoreTime.optional().describe("ปิดจอ QR ของเจ้าที่ไม่มี API ยกเลิก · `process` คง `request`"),
  cancelledAt: FirestoreTime.optional().describe("ยกเลิกที่ผู้ให้บริการสำเร็จ · คู่กับ `process:'cancelled'`"),
  paidAfterCancel: z.boolean().optional().describe("เงินเข้าหลังร้านปิดจอแล้ว · แอปไม่สร้างบิล · ร้านคืนเงินนอกระบบ"),
  paidAfterCancelAt: FirestoreTime.optional(),
  stationId: PgText.optional().describe("จุดคิดเงินของเครื่อง EDC"),
  invoiceNo: PgText.optional(),
  posRefNo: PgText.optional(),
  tradeType: PgText.optional(),
  approvalCode: PgText.optional(),
  terminalId: PgText.optional(),
  merchantId: PgText.optional(),
  simulated: z.boolean().optional().describe("มาจาก `payment.simulate` บนร้านทดสอบ · ไม่ใช่เงินจริง"),
};

export const PgWebhook = z
  .object({
    shopId: z
      .string()
      .min(1)
      .describe("§1 แถว 1 · ร้านที่ขอ QR = `shop.shopId` ใน redux (`CO:113` `CO:248`) · ไม่มีผู้อ่าน"),
    timestamp: FirestoreTime.describe(
      "§1 แถว 2 · เวลาสร้าง doc จาก `serverTimestamp()` (`CO:249`) · ไม่มีผู้อ่าน · ไม่มี TTL หรือ cron ลบ (B-06)",
    ),
    process: PgWebhookProcess.describe("§1 แถว 3 · สถานะการจ่าย · listener ตัดสินจากค่านี้อย่างเดียว (`CO:221-222`)"),
    chargeId: z
      .string()
      .nullable()
      .optional()
      .describe(
        "§1 แถว 4 · รหัส charge ฝั่งผู้ให้บริการ · ไม่มี = doc ที่ยัง `request` ของรุ่นเดิม หรือ EDC · " +
          "ผู้ให้บริการไม่ส่งมา = `''` (`PG:28`) · ส่ง `null` = `null` (ค่าตั้งต้นใช้กับ `undefined` เท่านั้น) · " +
          "ไม่รับตัวเลขหรือ object: เป็นการตัดสินใจ เพราะรหัส charge เป็นข้อความ และไม่มี doc จริงให้วัด · ไม่มีผู้อ่าน (B-05)",
      ),
    ...PgWebhookGatewayFields,
  })
  .passthrough();

export type PgWebhook = z.infer<typeof PgWebhook>;
export type PgWebhookProcess = z.infer<typeof PgWebhookProcess>;

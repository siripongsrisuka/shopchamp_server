import { z } from "zod";

/**
 * คำขอตรวจรหัสแคชเชียร์ที่ server (บั๊ก #13 · decision 2026-11-06 ข้อ #12 #13 ทาง 2 · DEV-0001)
 * สัญญา: `shopchamp-center/api/staff.verifyCashierCode.yaml` · route `POST /pos/staff/verify-cashier-code`
 *
 * แทน `app:modal/Modal_Staff.js:96` ที่เทียบ `inputPassword === currentStaff.password` ในเครื่อง
 *   (รหัสทุกคนอยู่ใน `shop.humanResource[].password` ที่แอปอ่านลงเครื่อง) ⇒ แอปใหม่ส่งรหัสที่พิมพ์มาให้ server ตัดสิน
 *   server ไม่คืนรหัสเลย · ผิดเกินกำหนด = ล็อกชั่วคราว (นับที่ server · ไม่ใช่ในเครื่อง)
 *
 * ⚠️ ช่อง password ของคำขอนี้ "หลวมกว่า" ตอนตั้งรหัส (`StaffSetCashierCodeRequest` ห้ามช่องว่าง) โดยตั้งใจ:
 *   รหัสที่แอปเก่าตั้งไว้แล้วเป็นข้อความที่ร้านพิมพ์เอง (อาจมีช่องว่าง/อักษรอื่น) ⇒ ถ้าคำขอตรวจปัดรูปแบบพวกนั้น = คนนั้นเข้าแอปใหม่ไม่ได้ตลอดไป
 *   ⇒ รับข้อความไม่ว่าง ยาวไม่เกิน 64 · ห้ามตัดช่องว่าง (เทียบตรงตัวแบบแอปเก่า)
 */

const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });

export const StaffVerifyCashierCodeRequest = z
  .object({
    shopId: docId("shopId").describe("doc id ร้านของผู้เรียก · server เทียบกับตัวตนจาก token"),
    staffId: docId("staffId").describe("uid ของแคชเชียร์ที่เลือกบนหน้าเลือกแคชเชียร์"),
    password: z.string().min(1, { message: "กรุณาใส่รหัสแคชเชียร์" }).max(64).describe("รหัสที่พิมพ์ · เทียบตรงตัว ไม่ตัดช่องว่าง"),
  })
  .strict();
export type StaffVerifyCashierCodeRequest = z.infer<typeof StaffVerifyCashierCodeRequest>;

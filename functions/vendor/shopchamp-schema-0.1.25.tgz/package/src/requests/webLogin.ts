import { z } from "zod";

/**
 * คำขอ API ปุ่มรายงานเปิดเว็บเจ้าของร้านในแอป + ลิงก์ login ใช้ครั้งเดียว (DEV-0001 · 0.1.15)
 * แบบ: `lanes/dev/source/owner-web-login-design.md` §2-§3 · สัญญากลาง §8
 * สัญญา: `shopchamp-center/api/webLogin.{start,approve,consume}.yaml` · route `POST /pos/web-login/*`
 *
 * ทุกตัว strict (field เกิน = 400) ⇒ ส่ง `uid` มาใน body ไม่ได้ · ตัวตนที่ออก token = `startedBy` ที่ server ผนึกไว้ใน doc เท่านั้น
 *   start / approve = ต้องมี ID token ของแอป · consume = สาธารณะ (ยามคือ secret 32 ไบต์ + ผนึก HMAC + อายุ 120 วิ + ถังต่อ IP)
 */

/** รหัสรอบ 20 ตัว [A-Za-z0-9] (server สุ่ม CSPRNG แบบไม่เอียง) */
export const WebLoginSessionId = z
  .string()
  .regex(/^[A-Za-z0-9]{20}$/, { message: "รหัสรอบไม่ถูกรูป" })
  .describe("sessionId ที่ได้จาก start · doc id ของ webLogin");

/** secret 32 ไบต์เป็น hex ตัวเล็ก 64 ตัว · server เก็บแค่ sha256 */
export const WebLoginSecret = z
  .string()
  .regex(/^[0-9a-f]{64}$/, { message: "รหัสลับไม่ถูกรูป" })
  .describe("secret ที่ได้จาก start · ส่งให้เว็บทาง #wl= เท่านั้น ห้าม log/เก็บ");

/** แอปขอเริ่มรอบ · body ว่าง (ตัวตนจาก ID token) */
export const WebLoginStartRequest = z.object({}).strict();
export type WebLoginStartRequest = z.infer<typeof WebLoginStartRequest>;

/** แอปเครื่องเดิม (uid เดียวกับที่ start) อนุญาตรอบ */
export const WebLoginApproveRequest = z.object({ sessionId: WebLoginSessionId }).strict();
export type WebLoginApproveRequest = z.infer<typeof WebLoginApproveRequest>;

/** เว็บแลกรอบเป็น custom token (ไม่มี Authorization) */
export const WebLoginConsumeRequest = z.object({ sessionId: WebLoginSessionId, secret: WebLoginSecret }).strict();
export type WebLoginConsumeRequest = z.infer<typeof WebLoginConsumeRequest>;

import { z } from "zod";

/**
 * คำขอ API ชุดใหม่ของโดเมนบริษัท (ก้อน 9d · DEV-0001) · strict (field เกิน = ถูกปัด)
 * สัญญา: `shopchamp-center/api/company.*.yaml` · บันทึกงาน `lanes/dev/source/chunk9/9d-company.md`
 *
 * ทางเดิมที่ถูกแทน (เขียน Firestore ตรงจากแอป main3):
 * - ซื้อแพ็กเกจ `src/screens/PayScreen.js:123-176` → `admin/packageNumber` `packageOrder` `notification`
 * - ซื้ออุปกรณ์ `src/screens/HardwareSummaryScreen.js:105-178` → `admin/hardwareNumber` `hardwareOrder` `notification`
 * - ซื้อพื้นที่รูป `src/screens/ImageLimitScreen.js:103-161` → `admin/imageNumber` `imageOrder` `notification`
 * - สแกนเข้าเว็บ `src/screens/LinkingWebsiteScreen.js:44-55` → `loginByScan/{docId}.uid`
 * - ลบบัญชี `src/db/firestore.js:214-244` → `deletedUser` (+ ลบ Auth)
 * - สร้างร้าน `src/screens/NewShopScreen.js:40-157` → `shopchamShopId/numOfStore` `shop` `shift` `profile`
 *
 * หลักร่วม
 * - ราคาไม่รับจากแอป: server คิดจาก `admin/package` `admin/hardware` ตารางพื้นที่รูป (care AC-07 · ค่าตั้งต้นที่ agent เลือก)
 *   แอปส่ง `expectedNet` ที่จอแสดง ⇒ ราคาในฐานเปลี่ยนระหว่างเปิดจอ = 409 `price_changed` ไม่ใช่ใบยอดคนละตัวกับสลิป (hardwareOrder B14)
 * - สลิปอัปขึ้น Storage ก่อนส่งคำขอ (AC-20 อัปนอก transaction) · รับเฉพาะ URL ของ bucket บ้านนี้ใต้โฟลเดอร์ของชนิดใบนั้น
 *   0.1.23 (DEV-0003 U2b): `payMethod: 'qr'` = จ่าย QR posxpay หลังสร้างใบ ⇒ ไม่มีสลิป (ห้ามส่ง) · ไม่ส่ง payMethod = บังคับสลิปเหมือนเดิม
 * - `orderUUID` สร้างที่แอปต่อการกด 1 ครั้ง = doc id ของใบ ⇒ ส่งซ้ำได้ใบเดิม (AC-06 · hardwareOrder B16 · shopchamShopId B9)
 *   ร้านตั้งใจซื้อหลายใบได้ตามเดิม (กดใหม่ = รหัสใหม่)
 */

/** ทศนิยมไม่เกิน 2 ตำแหน่ง · เทียบผ่าน toFixed เพราะ `0.29 * 100` ไม่เป็นจำนวนเต็มใน float */
const hasAtMost2Decimals = (v: number) => Number(v.toFixed(2)) === v;

const STORAGE_BUCKET = "shopcham-24b0b.appspot.com";

/**
 * URL สลิปที่แอปได้จาก `getDownloadURL` ของ `firebaseStorage().ref('/<folder>/...')` (main3 src/db/firestore.js:256-260)
 *   รูป: `https://firebasestorage.googleapis.com/v0/b/<bucket>/o/<folder>%2F<ไฟล์>?alt=media&token=…`
 *   ❌ URL นอก bucket บ้านนี้ · โฟลเดอร์อื่น · มีช่องว่าง (ใบชี้รูปของที่อื่นให้ทีมตรวจ = ช่องหลอกยอด AC-07)
 */
export const slipUrlOf = (folder: string) =>
  z
    .string()
    .max(2048)
    .refine((s) => s.startsWith(`https://firebasestorage.googleapis.com/v0/b/${STORAGE_BUCKET}/o/${folder}%2F`) && !/\s/.test(s), {
      message: `slipUrl ต้องเป็นไฟล์ใต้ ${folder}/ ของ Storage บ้านนี้`,
    });

// ── 0.1.23 DEV-0003 U2b: วิธีจ่ายของใบสั่งซื้อบริษัท 4 ชนิด (3 ตัวในไฟล์นี้ + stock.orderCreate) ──
//   ไม่ส่ง = 'slip' = พฤติกรรมเดิม (แอปเก่า/แอปใหม่ตัวเดิมไม่เปลี่ยน) · 'qr' = จ่ายด้วย QR posxpay หลังสร้างใบ (company.payRequest) ⇒ ❌ ห้ามส่งสลิป
//   ใบ QR ที่ร้านเปลี่ยนใจ: ส่ง orderUUID เดิมแบบ 'slip' = server แนบสลิปเข้าใบเดิม (ดู handler _orders.js › slipAttachPatch)
export const COMPANY_ORDER_PAY_METHODS = ["qr", "slip"] as const;
export const CompanyOrderPayMethod = z.enum(COMPANY_ORDER_PAY_METHODS);
export type CompanyOrderPayMethod = z.infer<typeof CompanyOrderPayMethod>;
const payMethod = CompanyOrderPayMethod.optional().describe(
  "วิธีจ่าย · ไม่ส่ง = slip (บังคับสลิป · พฤติกรรมเดิม) · qr = จ่ายด้วย QR หลังสร้างใบ ไม่ต้องมีสลิป (ส่งสลิปมาด้วย = 400)",
);
/**
 * กฎสลิปกับวิธีจ่าย (superRefine · ใช้กับทุกคำขอสร้างใบ): qr = ต้องไม่มีช่องสลิป · ไม่ใช่ qr = ต้องมีช่องสลิป
 *   issue ชี้ที่ช่องสลิป (slipUrl / imageId) เสมอ ⇒ แอปรุ่น U5 ที่ดู path ของ issue ยังแยกเรื่องสลิปออกจาก 400 เรื่องอื่นได้
 */
export const slipRequiredUnlessQr =
  (slipKey: string) =>
  (r: Record<string, unknown>, ctx: z.RefinementCtx) => {
    const qr = r.payMethod === "qr";
    const has = r[slipKey] !== undefined;
    if (qr && has) ctx.addIssue({ code: "custom", path: [slipKey], message: `จ่าย QR ไม่ต้องส่ง ${slipKey}` });
    if (!qr && !has) ctx.addIssue({ code: "custom", path: [slipKey], message: `ต้องแนบสลิป (${slipKey}) เมื่อไม่ได้จ่าย QR` });
  };

const expectedNet = z
  .number()
  .nonnegative()
  .refine(hasAtMost2Decimals, { message: "ยอดทศนิยมไม่เกิน 2 ตำแหน่ง" })
  .describe("ยอดที่จอแสดงตอนกด · server คิดเองแล้วเทียบระดับสตางค์ · ไม่ตรง = 409 price_changed (ไม่ใช้เป็นยอดของใบ)");

const orderUUID = z.uuid().describe("รหัสการกด 1 ครั้ง สร้างที่แอป = doc id ของใบ · ส่งซ้ำได้ใบเดิม (duplicate:true)");
const shopId = z.string().min(1).describe("ร้าน (doc id) · ด่านสิทธิ์ร้านใช้ค่านี้");

const packageId = z.union([z.string().min(1).max(64), z.number().int().positive()]);

export const CompanyPackageOrderRequest = z
  .object({
    shopId,
    packageIds: z
      .array(packageId)
      .min(1)
      .max(20)
      .refine((a) => new Set(a.map(String)).size === a.length, { message: "packageIds ห้ามซ้ำ" })
      .describe("`admin/package.value[].price[].id` ที่เลือก (ในฐานเป็นข้อความ · วัด 2026-11-06) · server หาแถวที่ขายอยู่เอง"),
    slipUrl: slipUrlOf("packageOrder").optional().describe("สลิปโอน · โฟลเดอร์ packageOrder/ เหมือนเดิม (PayScreen.js:128) · ไม่ส่งได้เฉพาะ payMethod qr"),
    payMethod,
    expectedNet,
    orderUUID,
    vat: z
      .boolean()
      .optional()
      .describe(
        "ขอใบกำกับภาษี (DEV-0002 · Pack เคาะ 2026-11-07) · true = server บวก VAT 7% ของยอดรวมปัดสตางค์ · ได้เฉพาะเมื่อทุกแพ็กเกจเป็นรายปี " +
          "(`admin/package.value[].price[].day` = 12 เดือน) ไม่งั้น 409 tax_invoice_yearly_only · ไม่ส่ง = false (แอปรุ่นก่อนหน้าทำเหมือนเดิม)",
      ),
    vatDetail: z
      .string()
      .max(1000)
      .optional()
      .describe("ข้อมูลออกใบกำกับ (ชื่อ เลขผู้เสียภาษี ที่อยู่) ข้อความเดียวรูปเดียวกับใบอุปกรณ์ · ต้องไม่ว่างเมื่อ vat · vat ไม่ใช่ true = server ไม่เก็บ"),
  })
  .strict()
  .refine((r) => r.vat !== true || (typeof r.vatDetail === "string" && r.vatDetail.trim() !== ""), {
    message: "ขอใบกำกับต้องมี vatDetail",
    path: ["vatDetail"],
  })
  .superRefine(slipRequiredUnlessQr("slipUrl"));
export type CompanyPackageOrderRequest = z.infer<typeof CompanyPackageOrderRequest>;

export const CompanyHardwareOrderRequest = z
  .object({
    shopId,
    lines: z
      .array(
        z
          .object({
            id: z.string().min(1).max(128).describe("`admin/hardware.value[].id`"),
            qty: z.number().int().min(1).max(999).describe("จำนวน · server ตรวจกับ limit ของรายการอีกชั้น (AC-67)"),
          })
          .strict(),
      )
      .min(1)
      .max(50)
      .refine((a) => new Set(a.map((l) => l.id)).size === a.length, { message: "lines ห้ามมี id ซ้ำ" })
      .describe("ตะกร้า · ไม่รับราคา/ชื่อจากเครื่อง (B14 ราคาค้างในตะกร้า · B19 ของที่ปิดขาย)"),
    vat: z.boolean().describe("ขอใบกำกับภาษี · true = บวก VAT 7% ของยอดสินค้า (HardwareSummaryScreen.js:67-70)"),
    vatDetail: z.string().max(1000).describe("ข้อมูลออกใบกำกับ · ต้องไม่ว่างเมื่อ vat (HardwareSummaryScreen.js:115) · vat=false server เขียน '' (B12)"),
    address: z.string().trim().min(1).max(1000).describe("ที่อยู่จัดส่ง · ห้ามว่าง (HardwareSummaryScreen.js:106)"),
    nameSername: z.string().trim().min(1).max(200).describe("ชื่อผู้รับ · ห้ามว่าง (:110)"),
    tel: z.string().trim().min(1).max(30).describe("เบอร์ติดต่อ · ห้ามว่าง (:112)"),
    slipUrl: slipUrlOf("hardwareOrder").optional().describe("สลิปโอน · โฟลเดอร์ hardwareOrder/ (HardwareSummaryScreen.js:120) · ไม่ส่งได้เฉพาะ payMethod qr"),
    payMethod,
    expectedNet,
    orderUUID,
  })
  .strict()
  .refine((r) => !r.vat || r.vatDetail.trim() !== "", { message: "ขอใบกำกับต้องมี vatDetail", path: ["vatDetail"] })
  .superRefine(slipRequiredUnlessQr("slipUrl"));
export type CompanyHardwareOrderRequest = z.infer<typeof CompanyHardwareOrderRequest>;

export const CompanyImageOrderRequest = z
  .object({
    shopId,
    optionId: z.number().int().min(1).max(5).describe("ตัวเลือกพื้นที่รูป 1-5 = 1000-5000 รูป 100-500 บาท (ImageLimitScreen.js:27-33)"),
    slipUrl: slipUrlOf("imageOrder").optional().describe("สลิปโอน · โฟลเดอร์ imageOrder/ (ImageLimitScreen.js:123) · ไม่ส่งได้เฉพาะ payMethod qr"),
    payMethod,
    expectedNet,
    orderUUID,
  })
  .strict()
  .superRefine(slipRequiredUnlessQr("slipUrl"));
export type CompanyImageOrderRequest = z.infer<typeof CompanyImageOrderRequest>;

/**
 * สแกน QR ของเว็บเจ้าของร้านรุ่นเดิม · เนื้อ QR = doc id ของ `loginByScan` (`own:modal/Modal_LoginByScan.js:36`)
 *   doc id สร้างด้วย `.doc()` ของเว็บ = 20 ตัว [A-Za-z0-9] เสมอ (loginByScan.md §2) ⇒ รูปอื่น (บาร์โค้ดสินค้า · ลิงก์ · มี /) = 400
 *   ไม่รับ uid จาก body · ตัวตนจาก token เท่านั้น
 */
export const CompanyScanLoginApproveRequest = z
  .object({
    docId: z.string().regex(/^[A-Za-z0-9]{20}$/, { message: "QR นี้ไม่ใช่ QR เข้าเว็บ" }).describe("doc id ของ loginByScan จาก QR"),
  })
  .strict();
export type CompanyScanLoginApproveRequest = z.infer<typeof CompanyScanLoginApproveRequest>;

/**
 * ลบบัญชีของผู้ถือ token (#25 · auth C30) · ตัวตนจาก token เท่านั้น
 *   ต้อง login ใหม่ไม่เกิน 5 นาที (server ตรวจ auth_time ของ token) แทนการยืนยันตัวในเครื่องแบบเดิม (ReAuthenticateScreeen.js)
 */
export const CompanyDeleteAccountRequest = z
  .object({
    confirm: z.literal(true).describe("ผู้ใช้กดยืนยันในจอแล้ว (กันเรียกพลาด)"),
    reason: z.string().max(500).optional().describe("เหตุผลที่ผู้ใช้กรอก · เดิมว่างเสมอ (deletedUser B5)"),
  })
  .strict();
export type CompanyDeleteAccountRequest = z.infer<typeof CompanyDeleteAccountRequest>;

const addressPart = z.union([z.string().min(1).max(64), z.number().int().nonnegative()]);

/**
 * สร้างร้านใหม่ (NewShopScreen) · ร้านทั้งก้อนประกอบที่ server จากแม่แบบเดิม (`main3 src/config/initialShop.js`)
 *   ⇒ แอปส่งได้แค่ช่องที่จอให้กรอก + ข้อมูลเครื่อง · ส่ง `vip` `humanResource` `scShopId` มาเองไม่ได้ (strict)
 */
export const CompanyShopCreateRequest = z
  .object({
    name: z.string().trim().min(1).max(100).describe("ชื่อร้าน · ห้ามว่าง (NewShopScreen.js:42)"),
    tel: z.string().regex(/^\d{10}$/, { message: "เบอร์ต้องเป็นตัวเลข 10 หลัก" }).describe("เบอร์ร้าน 10 หลัก (:44 เดิมเช็กแค่ความยาว)"),
    smartAddress: z
      .tuple([addressPart, addressPart, z.string().min(1).max(64), z.string().regex(/^\d{5}$/)])
      .describe("[จังหวัด, อำเภอ, ตำบล, รหัสไปรษณีย์] รูปเดิม `[a0.id, a1.id, String(a2.id), String(a2.zipcode)]` (:79)"),
    posId: z.uuid().describe("id จุดขายแรก สร้างที่แอป (uuid.v4 · :53) · แอปจดเป็นเครื่องปัจจุบัน"),
    uniqueId: z.string().min(1).max(200).describe("getUniqueId() ของเครื่อง · ผูกจุดขายแรก (:52)"),
    deviceName: z.string().max(200).describe("getDeviceName() ของเครื่อง"),
    requestId: z.uuid().describe("รหัสการกด 1 ครั้ง · ส่งซ้ำได้ร้านเดิม ไม่ได้ร้านที่ 2 (shopchamShopId B7 B9)"),
  })
  .strict();
export type CompanyShopCreateRequest = z.infer<typeof CompanyShopCreateRequest>;

// ── 0.1.22 DEV-0003 U2 ชำระเงินอัตโนมัติ (posxpay) ของใบสั่งซื้อบริษัท 4 ชนิด · แบบ lanes/dev/source/office-autopay-design.md ──

/** ชนิดใบที่จ่ายอัตโนมัติได้ = ตาราง KINDS ของ `pos/company/_fulfill.js` (package · hardware · image · stock) */
export const COMPANY_PAY_KINDS = ["package", "hardware", "image", "stock"] as const;
export const CompanyPayKind = z.enum(COMPANY_PAY_KINDS);
export type CompanyPayKind = z.infer<typeof CompanyPayKind>;

/**
 * ขอ QR จ่ายใบสั่งซื้อบริษัท (`POST /pos/company/pay-request`) · ❌ ไม่รับยอดจากจอ — server อ่านยอดจากใบ (net · ใบชุดสินค้าใช้ price)
 *   ใบต้อง status 'order' และเป็นของร้านที่ผ่านด่าน · มี QR ที่ยังรอและยังไม่หมดอายุ = คืน QR เดิม (ไม่ยิงผู้ให้บริการซ้ำ)
 */
export const CompanyPayRequestRequest = z
  .object({
    shopId,
    kind: CompanyPayKind.describe("ชนิดใบ: package = packageOrder · hardware = hardwareOrder · image = imageOrder · stock = stockOrder"),
    orderUUID: z.uuid().describe("doc id ของใบสั่งซื้อ (orderUUID ที่สร้างตอนกดซื้อ) · doc จ่าย = companyPay/<kind>-<orderUUID>"),
  })
  .strict();
export type CompanyPayRequestRequest = z.infer<typeof CompanyPayRequestRequest>;

/** ถามสถานะการจ่าย (`POST /pos/company/pay-status`) · แอป poll ทุก 2-3 วินาที · server ถามผู้ให้บริการเองแล้วเปิดของเมื่อยอดตรง */
export const CompanyPayStatusRequest = CompanyPayRequestRequest;
export type CompanyPayStatusRequest = z.infer<typeof CompanyPayStatusRequest>;

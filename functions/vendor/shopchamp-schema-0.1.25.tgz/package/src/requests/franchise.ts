import { z } from "zod";

/**
 * คำขอ API ชุดใหม่ของเว็บแฟรนไชส์ (DEV-0002 · ก้อน 9f) · strict ทุกตัว (field เกิน = ถูกปัด)
 * สัญญา: `shopchamp-center/api/franchise.*.yaml` · เอกสารงาน `lanes/dev/source/chunk9/9f-franchise.md`
 *
 * หลักร่วม:
 * - ตัวตน = Firebase ID token (route auth 'user') · ไม่มีร้านใน body · แฟรนไชส์เป้าหมาย = `franchiseId` (doc id ของ `franchise`)
 * - สิทธิ์ตามเมนูเดิมของเว็บ (`fr:configs/chainStoreFranchise.js`): 100 Dashboard · 103 ยอดตามร้าน · 104 ยอดตามสินค้า · 107 Overview
 *   · 128 คลัง หมวด ผูกสินค้า รายการสาขา · 723 กำหนดสิทธิ์ · 130 โปรไฟล์ · เดิมซ่อนแค่เมนู ⇒ server ตรวจทุกเส้น
 * - ทีมงาน Shopchamp (`admin/adminConfig.admin`) ผ่านทุกแฟรนไชส์ แทนชุด uid ที่ฝังในเว็บ (`fr:configs/initialAdmin.js`)
 * - แอปส่งเจตนา ไม่ส่งสำเนาที่จำไว้ ⇒ server อ่าน doc สดใน transaction (DI-37 · SL-39 · WH-11)
 * - สร้างเอกสารใหม่มีรหัสกันซ้ำจากเครื่อง (`*UUID` = doc id) ⇒ กดซ้ำได้ผลเดิม (SL-42 · WH-47)
 */

const DOC_ID_MAX = 128;

const docId = (label: string) =>
  z
    .string()
    .min(1, { message: `${label} ห้ามว่าง` })
    .max(DOC_ID_MAX, { message: `${label} ยาวเกิน ${DOC_ID_MAX}` })
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${label} ห้ามมี / หรือเป็น . ..` });

const uuid = (label: string) =>
  z
    .string()
    .regex(/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/, { message: `${label} ต้องเป็น UUID` });

const atMostDecimals = (n: number) => (v: number) => Number(v.toFixed(n)) === v;

/** เงิน ≥ 0 · ทศนิยมไม่เกิน 4 · 0 ได้ (ST-130 · เดิม `!price` ปัดราคา 0 เงียบ) */
const money = z
  .number()
  .finite()
  .nonnegative({ message: "ราคาติดลบไม่ได้" })
  .lt(1e10)
  .refine(atMostDecimals(4), { message: "ทศนิยมไม่เกิน 4 ตำแหน่ง" });

/** ชื่อที่คนพิมพ์: ตัดช่องว่างหัวท้าย · ห้ามว่าง (FL-35 · WC-29 · WM-22 · PR-19) */
const name = (label: string, max = 200) =>
  z.string().trim().min(1, { message: `${label}ห้ามว่าง` }).max(max, { message: `${label}ยาวเกิน ${max}` });

/** URL รูปที่อัปขึ้น Storage แล้ว หรือ '' (ไม่มีรูป) · ❌ ไม่รับ data URL / base64 (เดิมเว็บเขียน `null` ได้ PR-17 WM-21) */
const imageUrl = z
  .string()
  .max(2048)
  .refine((s) => s === "" || /^https:\/\//.test(s), { message: "รูปต้องเป็น URL https ที่อัปแล้ว หรือว่าง" });

/** รหัสสิทธิ์ของเมนูเว็บแฟรนไชส์ (`fr:configs/chainStoreFranchise.js`) */
export const FRANCHISE_RIGHTS = ["100", "103", "104", "107", "128", "723", "130"] as const;
export const FranchiseRight = z.enum(FRANCHISE_RIGHTS);

/** วันธุรกิจ 'YYYYMMDD' */
const dayKey = z.string().regex(/^\d{8}$/, { message: "วันต้องเป็น YYYYMMDD" });

/** เบอร์ที่ใช้ค้น: ตัดช่องว่าง · ห้ามว่าง (BR-21 · SF-18 เดิมค้นช่องว่างได้ทุก doc ที่ tel ว่าง) */
const searchTel = z
  .string()
  .trim()
  .min(6, { message: "ใส่เบอร์อย่างน้อย 6 หลัก" })
  .max(20)
  .regex(/^[0-9+\-\s]+$/, { message: "เบอร์ต้องเป็นตัวเลข" });

const franchiseRef = { franchiseId: docId("franchiseId") };

// ── แฟรนไชส์ ──────────────────────────────────────────────────────────────────

/** franchise.list — รายการแฟรนไชส์ของผู้เรียก (ทีมงาน = ทั้งหมด) */
export const FranchiseListRequest = z.object({}).strict();

/** franchise.get — doc แฟรนไชส์ 1 ตัว + สิทธิ์ของผู้เรียก */
export const FranchiseGetRequest = z.object({ ...franchiseRef }).strict();

/** franchise.create — สร้างแฟรนไชส์ · ผู้สร้างเป็นสมาชิกสิทธิ์ครบ (DI-45) */
export const FranchiseCreateRequest = z
  .object({
    franchiseUUID: uuid("franchiseUUID").describe("doc id ของแฟรนไชส์ใหม่ · กดซ้ำได้ใบเดิม (FL-40)"),
    name: name("ชื่อแฟรนไชส์"),
  })
  .strict();

/** franchise.profileUpdate — แก้ชื่อ/โลโก้แบรนด์ เฉพาะช่องที่ส่ง (PR-07 เดิมเขียน 2 ช่องเสมอจากค่าใน localStorage) */
export const FranchiseProfileUpdateRequest = z
  .object({
    ...franchiseRef,
    name: name("ชื่อแฟรนไชส์").optional(),
    imageId: imageUrl.optional(),
  })
  .strict()
  .refine((r) => r.name !== undefined || r.imageId !== undefined, { message: "ต้องส่งอย่างน้อย 1 ช่อง" });

// ── หมวดคลัง ──────────────────────────────────────────────────────────────────

export const WarehouseCategoryNode = z
  .object({
    id: docId("id หมวด"),
    name: name("ชื่อหมวด", 100),
    level: z.number().int().min(1).max(10),
    aboveId: z.array(docId("aboveId")).max(9).describe("id ของหมวดแม่ไล่จากชั้น 1 (ความยาว = level-1)"),
  })
  .strict();

export const WarehouseCategoryLevel = z
  .object({
    level: z.number().int().min(1).max(10),
    value: z.array(WarehouseCategoryNode).max(500),
  })
  .strict();

/**
 * franchise.categorySave — แทนต้นหมวดทั้งต้น เมื่อต้นในฐานยังเท่าที่จอเห็น (DI-37 · WC-41 · WC-06)
 *   seenWarehouseCategory = ต้นที่จอโหลดมา · ฐานไม่เท่า = 409 category_changed (ไม่ทับของคนอื่น)
 */
export const FranchiseCategorySaveRequest = z
  .object({
    ...franchiseRef,
    warehouseCategory: z.array(WarehouseCategoryLevel).max(10),
    seenWarehouseCategory: z.array(z.unknown()).max(10),
  })
  .strict();

// ── คลังสินค้าส่วนกลาง ─────────────────────────────────────────────────────────

export const FranchisePriceLevel = z
  .object({
    qty: z.number().finite().positive().refine(atMostDecimals(4), { message: "จำนวนทศนิยมไม่เกิน 4" }),
    price: money,
  })
  .strict();

/** ช่องของฟอร์มคลัง (`fr:modal/Modal_Warehouse.js`) · ช่องอื่นของ doc server ไม่ให้แก้ */
const warehouseFields = {
  name: name("ชื่อสินค้า"),
  price: money,
  barcode: z.string().trim().max(100),
  sku: z.string().trim().max(100),
  unit: z.string().trim().max(50),
  category: z.array(docId("category")).max(10).describe("id หมวดไล่จากชั้น 1 (ST-107 · เดิมแก้แล้วเก็บเป็น object)"),
  imageId: imageUrl,
  pointStatus: z.boolean(),
  stockCountStatus: z.boolean(),
  customQtyStatus: z.boolean(),
  customPriceStatus: z.boolean(),
  priceLevelStatus: z.boolean(),
  priceLevel: z.array(FranchisePriceLevel).max(50),
};

/** franchise.warehouseList — สินค้าคลังของแฟรนไชส์ (สิทธิ์ 128) */
export const FranchiseWarehouseListRequest = z.object({ ...franchiseRef }).strict();

/**
 * franchise.warehouseSave — op create (itemUUID = doc id) · op update (itemId · แก้เฉพาะช่องที่ส่ง · WH-11)
 */
export const FranchiseWarehouseSaveRequest = z.discriminatedUnion("op", [
  z
    .object({
      ...franchiseRef,
      op: z.literal("create"),
      itemUUID: uuid("itemUUID"),
      name: warehouseFields.name,
      price: warehouseFields.price,
      barcode: warehouseFields.barcode.optional(),
      sku: warehouseFields.sku.optional(),
      unit: warehouseFields.unit.optional(),
      category: warehouseFields.category.optional(),
      imageId: warehouseFields.imageId.optional(),
      pointStatus: warehouseFields.pointStatus.optional(),
      stockCountStatus: warehouseFields.stockCountStatus.optional(),
      customQtyStatus: warehouseFields.customQtyStatus.optional(),
      customPriceStatus: warehouseFields.customPriceStatus.optional(),
      priceLevelStatus: warehouseFields.priceLevelStatus.optional(),
      priceLevel: warehouseFields.priceLevel.optional(),
    })
    .strict(),
  z
    .object({
      ...franchiseRef,
      op: z.literal("update"),
      itemId: docId("itemId"),
      name: warehouseFields.name.optional(),
      price: warehouseFields.price.optional(),
      barcode: warehouseFields.barcode.optional(),
      sku: warehouseFields.sku.optional(),
      unit: warehouseFields.unit.optional(),
      category: warehouseFields.category.optional(),
      imageId: warehouseFields.imageId.optional(),
      pointStatus: warehouseFields.pointStatus.optional(),
      stockCountStatus: warehouseFields.stockCountStatus.optional(),
      customQtyStatus: warehouseFields.customQtyStatus.optional(),
      customPriceStatus: warehouseFields.customPriceStatus.optional(),
      priceLevelStatus: warehouseFields.priceLevelStatus.optional(),
      priceLevel: warehouseFields.priceLevel.optional(),
    })
    .strict(),
]);

/** franchise.warehouseDelete — ลบสินค้าคลัง 1 ตัว · อยู่ในกลุ่มผูกอยู่ = ปัด (WH-51) */
export const FranchiseWarehouseDeleteRequest = z.object({ ...franchiseRef, itemId: docId("itemId") }).strict();

// ── ผูกรายการสินค้า (stockLink ตระกูลแฟรนไชส์ · ST-012 ทางแรก = คงเมนู) ─────────

const linkMember = z
  .object({
    id: docId("id สินค้าคลัง"),
    linkMultiply: z.number({ message: "ตัวคูณต้องเป็นตัวเลข (SL-35)" }).finite().positive({ message: "ตัวคูณต้องมากกว่า 0" }).lt(1e6),
  })
  .strict();

/** franchise.linkList — กลุ่มผูกของแฟรนไชส์ (สิทธิ์ 128) */
export const FranchiseLinkListRequest = z.object({ ...franchiseRef }).strict();

/** franchise.linkSave — op create (linkUUID) · op update (linkId · แทนชื่อและสมาชิกทั้งกลุ่ม) · สำเนาชื่อ/หน่วยมาจากคลังในฐาน (ST-139) */
export const FranchiseLinkSaveRequest = z.discriminatedUnion("op", [
  z
    .object({
      ...franchiseRef,
      op: z.literal("create"),
      linkUUID: uuid("linkUUID"),
      stockGroupName: name("ชื่อกลุ่ม"),
      members: z.array(linkMember).min(1).max(20),
    })
    .strict(),
  z
    .object({
      ...franchiseRef,
      op: z.literal("update"),
      linkId: docId("linkId"),
      stockGroupName: name("ชื่อกลุ่ม"),
      members: z.array(linkMember).min(1).max(20),
    })
    .strict(),
]);

/** franchise.linkDelete */
export const FranchiseLinkDeleteRequest = z.object({ ...franchiseRef, linkId: docId("linkId") }).strict();

// ── สาขา ──────────────────────────────────────────────────────────────────────

/** franchise.branchList — ร้านที่ `franchiseId` ตรง · คืนเฉพาะช่องที่จอใช้ (FD-B2 ไม่มีรหัสพนักงานวิ่งผ่าน network) */
export const FranchiseBranchListRequest = z.object({ ...franchiseRef }).strict();

/** franchise.branchFind — ค้นร้านจากเบอร์ (ทีมงานเท่านั้น ตามปุ่มเดิม `fr:screens/BranchScreen.js:93`) */
export const FranchiseBranchFindRequest = z.object({ ...franchiseRef, tel: searchTel }).strict();

/**
 * franchise.branchAttach — ผูกร้านเป็นสาขา (เขียน `shop.franchiseId` ช่องเดียว)
 *   ร้านอยู่แฟรนไชส์อื่นอยู่ = 409 shop_in_other_franchise · ตั้งใจย้าย = ส่ง moveFromFranchiseId ให้ตรงค่าปัจจุบัน (DI-13 · BR-28)
 */
export const FranchiseBranchAttachRequest = z
  .object({
    ...franchiseRef,
    shopId: docId("shopId").describe("doc id ของร้าน"),
    moveFromFranchiseId: docId("moveFromFranchiseId").optional(),
  })
  .strict();

// ── พนักงานแฟรนไชส์ ─────────────────────────────────────────────────────────────

/** franchise.staffFind — ค้นบัญชีจากเบอร์ · คืน id ชื่อ เบอร์ รูป เท่านั้น (SF-16 · เดิมได้ profile ทั้ง doc) · สิทธิ์ 723 */
export const FranchiseStaffFindRequest = z.object({ ...franchiseRef, tel: searchTel }).strict();

/**
 * franchise.staffSave — แก้ทีละคนใน transaction (DI-37 · SF-07 เดิมเขียนทั้ง array จากค่าเก่า)
 *   add: ต้องยังไม่อยู่ (SF-32) · ชื่อ/เบอร์คัดจาก profile ในฐาน (SF-02 เดิมคัด profile ทั้งก้อน)
 *   update: แก้สิทธิ์ · remove: เอาออก · ห้ามทำให้แฟรนไชส์ไม่เหลือคนที่มีสิทธิ์ 723 (SF-41)
 */
export const FranchiseStaffSaveRequest = z.discriminatedUnion("op", [
  z.object({ ...franchiseRef, op: z.literal("add"), staffUid: docId("staffUid"), rights: z.array(FranchiseRight).max(20) }).strict(),
  z.object({ ...franchiseRef, op: z.literal("update"), staffUid: docId("staffUid"), rights: z.array(FranchiseRight).max(20) }).strict(),
  z.object({ ...franchiseRef, op: z.literal("remove"), staffUid: docId("staffUid") }).strict(),
]);

// ── บิลของแฟรนไชส์ (Dashboard · ยอดตามร้าน · ยอดตามสินค้า) ─────────────────────

/**
 * franchise.billList — บิลที่ถือ `franchiseId` นี้ ในช่องวันธุรกิจ fromDay..toDay (รวม 2 วัน · ไม่เกิน 31 วัน)
 *   วันธุรกิจคิดตาม cutOff ของสาขาที่ขาย (WR-01 ฝั่งแฟรนไชส์) · ใบยกเลิกไม่อยู่ในรายการ นับแยก (WR-04)
 *   shopId (ไม่ส่งได้) = เฉพาะสาขานั้น · ต้องเป็นสาขาของแฟรนไชส์ตอนนี้
 */
export const FranchiseBillListRequest = z
  .object({
    ...franchiseRef,
    fromDay: dayKey,
    toDay: dayKey,
    shopId: docId("shopId").optional(),
  })
  .strict();

export type FranchiseCreateRequest = z.infer<typeof FranchiseCreateRequest>;
export type FranchiseCategorySaveRequest = z.infer<typeof FranchiseCategorySaveRequest>;
export type FranchiseWarehouseSaveRequest = z.infer<typeof FranchiseWarehouseSaveRequest>;
export type FranchiseLinkSaveRequest = z.infer<typeof FranchiseLinkSaveRequest>;
export type FranchiseStaffSaveRequest = z.infer<typeof FranchiseStaffSaveRequest>;
export type FranchiseBillListRequest = z.infer<typeof FranchiseBillListRequest>;

import { z } from "zod";

/**
 * คำขอ API คลังสินค้ากลาง `product` (ก้อน 9b · DEV-0001) · strict
 * สัญญา: `shopchamp-center/api/product.saveCentral.yaml` · รอ Pack เซ็นชุด case
 *
 * `product` = คลังบาร์โค้ดกลางที่ทุกร้านใช้ร่วม (ร้านแรกที่บันทึกบาร์โค้ดเขียนชื่อ หน่วย รูป ให้ร้านถัดไปเติมอัตโนมัติ)
 *   คนละของกับสินค้าของร้าน (`stock` · ก้อน 9a) · ทางเดิมคือ `main3:src/screens/ProductSetting.js:672-690`
 *   ตอนเพิ่มสินค้าใหม่ที่มีบาร์โค้ด: เจอ doc กลางที่ยังไม่มีรูป = เติมรูป (W1) · ไม่เจอ = `add` 9 field (W2) · ไม่ await
 *
 * บั๊กที่รูปคำขอปิด: B4 บาร์โค้ดว่าง · B10 `unit` undefined ทำบันทึกล้ม · B9 สิทธิ์ '110' (server ตรวจ)
 */

/** บาร์โค้ด: ไม่ว่าง ไม่มีช่องว่างหัวท้าย (ไม่ trim ให้ เพราะ doc เดิมเก็บดิบ · B8) · ห้าม / (ใช้ทำ key ไม่ได้) */
const Barcode = z
  .string()
  .min(1, { message: "บาร์โค้ดห้ามว่าง (B4)" })
  .max(64)
  .refine((s) => s.trim() === s && s.trim() !== "", { message: "บาร์โค้ดห้ามมีช่องว่างหัวท้าย" });

export const ProductSaveCentralRequest = z
  .object({
    shopId: z.string().min(1),
    barcode: Barcode.describe("บาร์โค้ดของสินค้าที่ร้านกำลังเพิ่ม · server ค้น `product where barcode ==` ตามเดิม"),
    name: z.string().trim().min(1).max(200).describe("ชื่อที่จะเติมให้ร้านถัดไป (เขียนเฉพาะตอนยังไม่มี doc กลาง)"),
    unit: z.string().trim().min(1).max(50).describe("หน่วยนับ · ห้ามว่าง (B7 B10 doc กลางไม่มี unit ทำเพิ่มด่วนล้ม)"),
    imageUrl: z
      .union([z.literal(""), z.url({ protocol: /^https$/ }).max(2000)])
      .describe("URL รูปที่อัปแล้ว หรือ '' · doc กลางที่ยังไม่มีรูปได้รูปนี้ (W1)"),
  })
  .strict();
export type ProductSaveCentralRequest = z.infer<typeof ProductSaveCentralRequest>;

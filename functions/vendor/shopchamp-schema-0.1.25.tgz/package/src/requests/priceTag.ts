import { z } from "zod";

/**
 * คำขอ API ป้ายราคา `priceTag` (ก้อน 9b · DEV-0001) · strict
 * สัญญา: `shopchamp-center/api/priceTag.create.yaml` · รอ Pack เซ็นชุด case
 *
 * ทางเดิม `main3:src/screens/PriceCardScreen.js:189-205`: `priceTag/{auto}.set({timestamp, shopId, uploadBy, products})`
 *   แล้วเปิดเว็บ `https://shopchamp-merchant-owner.firebaseapp.com/tag/<doc id>` · ไม่เช็กรายการว่าง · ล้มเงียบ
 * รูปแถวเท่ากับที่แอปเดิมเขียน `{name, imageId, barcode, unit, price, promotion}` (`schema/priceTag.md` §1) · เว็บอ่าน `products` อย่างเดียว
 *
 * บั๊กที่รูปคำขอปิด: PT-11 รายการว่าง · PT-06 แถวขาด field ทำทั้งชุดล้ม · PT-07 `barcode` เป็นตัวเลขทำเว็บพัง / `promotion` ไม่มี
 *   PT-05 รายการเกินขนาด doc (เพดาน 1,000 แถว + server วัดขนาดอีกชั้น) · PT-14 กดซ้ำได้ 2 doc (requestId)
 */

/** เวลา ISO 8601 ที่มีโซน · server แปลงเป็น Timestamp (เว็บอ่าน Timestamp ได้ · `web:Utility/function.js:16`) */
const IsoTime = z.iso.datetime({ offset: true, message: "ต้องเป็นเวลา ISO 8601 ที่มีโซน" });
/** ราคาในโปรของสินค้า: แม่แบบเดิมเป็น '' เมื่อยังไม่ตั้ง (`main3:src/config/initialProduct.js:16-17`) */
const NumOrBlank = z.union([z.number().min(0).max(1_000_000_000), z.literal("")]);

export const PriceTagPromotion = z
  .object({
    status: z.boolean(),
    qty: NumOrBlank,
    price: NumOrBlank,
    startDate: IsoTime,
    endDate: IsoTime,
  })
  .strict();

export const PriceTagProductRow = z
  .object({
    name: z.string().max(200),
    imageId: z.string().max(2000).describe("URL รูป หรือ '' (ชื่อ Id แต่เก็บ URL)"),
    barcode: z.string().max(64).describe("ข้อความเสมอ (PT-07 ตัวเลขทำเว็บพัง)"),
    unit: z.string().max(50),
    price: z.number().min(0).max(1_000_000_000).describe("ราคาขาย ณ ตอนกดสร้าง"),
    promotion: PriceTagPromotion.describe("ราคาชุดของสินค้า (`stock.promotion`) · ต้องมีเสมอ (PT-06 PT-07)"),
  })
  .strict();

export const PRICE_TAG_MAX_ROWS = 1000;

export const PriceTagCreateRequest = z
  .object({
    shopId: z.string().min(1),
    requestId: z.uuid().describe("รหัสการกด 1 ครั้ง = doc id ของ `priceTag` (= token ของลิงก์เว็บ) · กดซ้ำได้ลิงก์เดิม (PT-14)"),
    uploadBy: z.string().max(100).describe("ชื่อ profile ผู้กด (ของเดิม `profile.name` · ค่าเริ่ม '')"),
    products: z
      .array(PriceTagProductRow)
      .min(1, { message: "ต้องมีป้ายอย่างน้อย 1 รายการ (PT-11)" })
      .max(PRICE_TAG_MAX_ROWS, { message: `ป้ายได้ไม่เกิน ${PRICE_TAG_MAX_ROWS} รายการต่อครั้ง (PT-05)` }),
  })
  .strict();
export type PriceTagCreateRequest = z.infer<typeof PriceTagCreateRequest>;

import { z } from "zod";
import { PromotionCategoryRowWrite, PromotionProductRowWrite, PromotionWorkingDayWrite } from "../entities/promotion";

/**
 * คำขอ API โปรโมชันระดับบิล (ก้อน 9b · DEV-0001) · strict
 * สัญญา: `shopchamp-center/api/promotion.{save,delete,setStatus}.yaml` · รอ Pack เซ็นชุด case
 *
 * ทางเดิม (`lanes/dev/source/schema/promotion.md` §4 · `main3:src/redux/promotionSlice.js:15-64`):
 *   W1 สร้าง `doc.set({...current, id})` ไม่ await · W2 แก้ `update(current)` ทั้งก้อน · W3 ลบจริง · W4 สวิตช์ `{status}`
 *   ด่านก่อนบันทึกอยู่ที่จอ (`PromotionSettingScreen.js:245-293`) ดูแค่ความยาว array (P3)
 *
 * รูปเนื้อโปรในคำขอ = `PromotionWrite` (entities/promotion.ts) ยกเว้น:
 *   `id` `shopId` `timestamp` server ใส่เอง · `startDate` `endDate` เป็นข้อความเวลา ISO มีโซน (JSON ส่ง Timestamp ไม่ได้)
 * กติกาความหมายทั้งหมด (34 แบบ F09 F32 F34-F36 F41 K04 K06 P10) ตรวจที่ server ด้วย `PromotionWrite` บน doc ที่ประกอบแล้ว
 *   ⇒ ไม่เขียนกติกาซ้ำที่นี่ (แหล่งเดียว) · ที่นี่ตรวจแค่รูปและชนิด
 */

const docId = z
  .string()
  .min(1)
  .max(128)
  .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: "id ห้ามมี / หรือเป็น . .." });

/** เวลา ISO 8601 ที่มีโซน (`2026-11-01T00:00:00+07:00` หรือ `...Z`) · ไม่มีโซน = กำกวมระหว่างเครื่องไทยกับ server UTC */
const IsoTime = z.iso.datetime({ offset: true, message: "ต้องเป็นเวลา ISO 8601 ที่มีโซน" });

const Row = z.union([PromotionProductRowWrite, PromotionCategoryRowWrite]);

export const PromotionBody = z
  .object({
    name: z.string(),
    detail: z.string(),
    promotionId: z.string(),
    type: z.string(),
    rewardType: z.string(),
    tier: z.boolean(),
    tierTarget: z.array(z.string()),
    tierReward: z.array(z.string()),
    tierBox: z.array(z.unknown()),
    barcode: z.array(Row),
    slot1: z.array(Row),
    slot2: z.array(Row),
    rewardBarcode: z.array(Row),
    scope: z.array(Row),
    scopeTarget: z.string(),
    exchangePrice: z.string(),
    expireType: z.string(),
    startDate: IsoTime,
    endDate: IsoTime,
    status: z.boolean(),
    auto: z.boolean(),
    workingDays: z.array(PromotionWorkingDayWrite),
    customer: z.string(),
    channels: z.array(z.unknown()),
    specialPromotion: z.string(),
  })
  .strict();
export type PromotionBody = z.infer<typeof PromotionBody>;

export const PromotionSaveRequest = z
  .object({
    shopId: z.string().min(1),
    mode: z.enum(["create", "update"]).describe("create = โปรใหม่ · update = แก้ทั้งก้อน (แทน W1/W2)"),
    id: docId.describe("create: uuid ที่แอปสร้าง = doc id (ส่งซ้ำได้โปรเดิม ไม่ได้ 2 ใบ) · update: doc id ของโปรที่แก้"),
    baseUpdatedAt: IsoTime.optional().describe(
      "update: `updatedAt` ของ doc ตอนจอเปิดอ่าน · ไม่ตรงกับในฐาน = 409 promotion_changed (กันเครื่องค่าเก่าทับ · ไม่มีรหัสบั๊ก) · doc ที่ไม่เคยมี updatedAt ไม่ต้องส่ง",
    ),
    promotion: PromotionBody,
  })
  .strict()
  .superRefine((r, ctx) => {
    if (r.mode === "create" && !z.uuid().safeParse(r.id).success)
      ctx.addIssue({ code: "custom", path: ["id"], message: "create ต้องส่ง id เป็น uuid ที่แอปสร้าง" });
    if (r.mode === "create" && r.baseUpdatedAt !== undefined)
      ctx.addIssue({ code: "custom", path: ["baseUpdatedAt"], message: "create ไม่มี baseUpdatedAt" });
  });
export type PromotionSaveRequest = z.infer<typeof PromotionSaveRequest>;

export const PromotionDeleteRequest = z
  .object({
    shopId: z.string().min(1),
    id: docId.describe("doc id ของโปรที่ลบ (ลบจริงแบบ W3)"),
  })
  .strict();
export type PromotionDeleteRequest = z.infer<typeof PromotionDeleteRequest>;

export const PromotionSetStatusRequest = z
  .object({
    shopId: z.string().min(1),
    id: docId,
    status: z.boolean().describe("เปิด/ปิดโปร (แทน W4 `{status}`)"),
  })
  .strict();
export type PromotionSetStatusRequest = z.infer<typeof PromotionSetStatusRequest>;

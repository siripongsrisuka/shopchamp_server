import { z } from "zod";

/**
 * คำขอบันทึกการเชื่อมต่อ LINE OA ของร้าน (ก้อน 10 รอบ 2c · DEV-0001 · แถว LS-033)
 * สัญญา: `shopchamp-center/api/shop.lineSettings.yaml` · route `POST /pos/shop/line-settings`
 *
 * แทน `app:screens/LineSettingScreen.js:97-104` ที่เขียน `shop.line` ทั้งก้อนตรงจากเครื่อง (`updateFieldShop`)
 *   `shop.update` ปัดช่อง `line` (token · ก้อน 6) ⇒ เส้นนี้เป็นทางเดียวที่แก้ `line` ได้
 * decision 2026-11-06 ข้อ #12 #13 (ทาง 2): server เก็บ token เข้าที่ลับ (`lineSecrets/{shopId}` เข้ารหัส · client อ่านไม่ได้)
 *   **และ** เขียนสำเนาเดิม `shop.line` รูปเดิม ให้แอปเก่า (แอปเก่าอ่าน token จาก doc ร้านแล้วส่งให้ `/line/*` เอง) · คำตอบไม่คืน token
 *
 * รูปค่า: ฐานจริง (วัด 2026-11-07 · ร้านที่มี token 15 ร้าน) liff ไม่ขึ้นต้น https 2 ร้าน · userId ไม่ใช่รูป U+32 hex 11 ร้าน · มีช่องว่าง 1 ร้าน
 *   ⇒ ไม่ตรวจรูปแบบ ไม่ตัดช่องว่าง (เก็บตามที่พิมพ์แบบแอปเก่า) · บังคับแค่ไม่ว่างและยาวไม่เกิน
 */

const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });

export const ShopLineSettingsRequest = z
  .object({
    shopId: docId("shopId").describe("doc id ร้านของผู้เรียก · server เทียบกับตัวตนจาก token"),
    liff: z.string().min(1, { message: "กรุณาใส่ LIFF URL" }).max(2048).describe("LIFF URL ตามที่พิมพ์ (จอเดิมบังคับไม่ว่าง :86)"),
    userId: z.string().min(1, { message: "กรุณาใส่ Your user ID" }).max(200).describe("Your user ID ตามที่พิมพ์ (:88)"),
    channelAccessToken: z
      .string()
      .min(1, { message: "กรุณาใส่ Channel access token" })
      .max(4096)
      .optional()
      .describe("Channel access token · ไม่ส่ง = ใช้ token เดิม (สำเนาเดิมก่อน แล้วที่ลับ) · ไม่มีทั้งคู่ = 400 token_required"),
  })
  .strict();
export type ShopLineSettingsRequest = z.infer<typeof ShopLineSettingsRequest>;

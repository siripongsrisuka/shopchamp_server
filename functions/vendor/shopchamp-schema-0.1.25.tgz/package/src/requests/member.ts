import { z } from "zod";

/**
 * คำขอ API ชุดใหม่ของโดเมนสมาชิก · strict (field เกิน = ถูกปัด) ต่างจาก schema เอกสารที่ passthrough
 *
 * ⚠️ ร่าง: สัญญา `shopchamp-center/api/draft/member.payCredit.yaml` (ก้อน 4) รอ Pack เซ็นก่อน harness รัน
 *    (Pack เลือก 5-2 · 2026-11-06) · `payUUID` = doc id ของ `paidHistory` ที่ server เขียน (กันซ้ำแบบ receiptGuard)
 *
 * ที่มา:
 * - ทางเดิมคือ `app:Modal/Modal_CreditMember.js:40-104` เขียน `member` `paidHistory` `notification` ตรงใน transaction
 *   รับแค่ยอดที่กรอก (`pay` เป็นสตริง) ไม่บันทึกช่องทาง กะ หรือคนรับ
 * - #17 (shift SC-01): รับชำระต้องเข้ากะ บันทึกคนรับและช่องทาง ⇒ แอปส่ง `shiftId` `staffId` `staffName` `paymentId` มาเอง
 *   token บอกไม่ได้ทั้ง 2 อย่าง: `shiftId` เป็นเอกสารประจำจุดชำระเงิน ร้านหนึ่งมีหลายจุด แอปรู้จาก `currentPos`
 *   (`schema/shift.md` §A แถว 1 5) · พนักงานใช้บัญชีเครื่องร่วมกันแล้วสลับด้วยรหัสใน `shop.humanResource[]`
 *   (`schema/shop.md` §3.13) ⇒ ผู้ถือ token ไม่ใช่คนรับเงิน · รูปเดียวกับคำขอ `shift.manage` (`requests/shift.ts`)
 *   server ตรวจใน transaction ว่า `shiftId` อยู่ใน `shop.POSs[]` ของร้านนี้และกะเปิดอยู่ · `staffId` อยู่ใน `humanResource[]`
 * - member K4 (ค่าตั้งต้นตามข้อเสนอ): ยอดติดลบทำให้หนี้เพิ่ม ⇒ ยอดต้องมากกว่า 0
 * - MBB-30: หนี้เศษทศนิยมค้าง ⇒ ยอดทศนิยมไม่เกิน 2 ตำแหน่ง เท่ากับคำขอ `shift.manage`
 * - กันกดซ้ำแบบเดียวกับ `receiptUUID` ของการขาย ⇒ `payUUID` สร้างที่แอป ส่งซ้ำได้ผลเดิม
 * - ร้านและสมาชิกต้องตรงกัน (`member.shopId == shopId`) server ตรวจใน transaction ไม่ใช่หน้าที่ของ schema
 */

/** ทศนิยมไม่เกิน 2 ตำแหน่ง · เทียบผ่าน toFixed เพราะ `0.29 * 100` ไม่เป็นจำนวนเต็มใน float */
const hasAtMost2Decimals = (v: number) => Number(v.toFixed(2)) === v;

/**
 * ช่องเงินเซ็น: รุ่นปัจจุบันเป็น `3` (`app:config/initialShop.js:118` `app:screens/HomeScreen.js:403`)
 * รุ่นเก่าเป็น `'035'` (`app:screens/BillHistoryScreen.js:462` · `app:screens/HomeScreen.js:431`)
 * รับชำระหนี้เงินเซ็นด้วยช่องเงินเซ็น = หนี้ลดโดยไม่มีเงินเข้า ⇒ ปัด
 */
const CREDIT_PAYMENT_ID = 3;

/**
 * รหัสช่องรุ่นเก่า 3 หลัก (`'001'` `'009'` `'035'` `'036'` `'037'` · `srv:apis/shift.js:76-82`) ถูกแปลงเป็นเลขตอนย้ายร้าน
 * (`app:screens/HomeScreen.js:412-447`) ⇒ แอปใหม่ไม่ส่ง · ช่องที่ร้านเพิ่มเองเป็น uuid (`app:screens/PaySettingScreen.js:78`)
 */
const LEGACY_PAYMENT_CODE = /^\d{3}$/;

const shiftDocId = z
  .string()
  .min(1, { message: "shiftId ห้ามว่าง" })
  .refine((s) => !s.includes("/"), { message: "shiftId ห้ามมี /" });

export const MemberPayCreditRequest = z
  .object({
    shopId: z.string().min(1).describe("ร้าน · ด่านสิทธิ์ร้านใช้ค่านี้"),
    memberId: z.string().min(1).describe("doc id ของ `member`"),
    amount: z
      .number()
      .positive()
      .refine(hasAtMost2Decimals, { message: "ยอดรับชำระทศนิยมไม่เกิน 2 ตำแหน่ง (MBB-30)" })
      .describe("บาทที่รับชำระ · ตัวเลขจริง ไม่ใช่สตริงแบบทางเดิม · NaN Infinity 0 ค่าลบ และทศนิยมเกิน 2 ตำแหน่งถูกปัด (K4 MBB-30)"),
    paymentId: z
      .union([
        z
          .number()
          .int()
          .positive()
          .refine((n) => n !== CREDIT_PAYMENT_ID, { message: "ห้ามรับชำระหนี้เงินเซ็นด้วยช่องเงินเซ็น" }),
        z
          .string()
          .min(1)
          .refine((s) => !LEGACY_PAYMENT_CODE.test(s), { message: "รหัสช่องรุ่นเก่า แอปใหม่ไม่ส่ง" }),
      ])
      .describe("ช่องรับเงิน รูปเดียวกับ `shop.shopchampPayment[].id` · ให้กะนับเข้าเงินคาดได้ (#17)"),
    shiftId: shiftDocId
      .optional()
      .describe(
        "doc id ของ `shift` จาก `shop.POSs[].shiftId` ของจุดที่รับเงิน (#17) · ไม่ส่งได้เมื่อร้านไม่ใช้ระบบกะ (`shop.shift` ไม่ใช่ true · ก้อน 5 ข้อ ①)",
      ),
    staffId: z.string().min(1).describe("พนักงานที่รับเงิน · ห้ามว่าง (#17)"),
    staffName: z.string().describe("ชื่อพนักงาน · ต้องมีเป็น string แม้ว่าง กันเขียน `undefined` (รูปเดียวกับ `shift.manage`)"),
    payUUID: z.uuid().describe("รหัสการกด 1 ครั้ง สร้างที่แอป · กันรับชำระซ้ำเมื่อส่งซ้ำ"),
    source: z
      .enum(["app", "web"])
      .optional()
      .describe(
        "ที่มาของคำขอ (DEV-0002 · Pack เคาะ 2026-11-07) · ไม่ส่ง = `app` ทำแบบเดิมทุกอย่าง · `web` = เว็บเจ้าของร้าน: server อ่านช่องจาก `shop.shopchampPayment` เอง " +
          "ช่องที่ไม่ใช่เงินสดไม่ผูกกะ (ห้ามส่ง `shiftId`) · เงินสดในร้านที่ใช้กะต้องส่ง `shiftId` ของกะที่เปิดอยู่ · ไม่เชื่อว่าเว็บแยกช่องถูก",
      ),
  })
  .strict();

export type MemberPayCreditRequest = z.infer<typeof MemberPayCreditRequest>;

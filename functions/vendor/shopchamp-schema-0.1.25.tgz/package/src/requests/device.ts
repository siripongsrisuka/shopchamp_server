import { z } from "zod";

/**
 * คำขอลงทะเบียนเครื่องรับแจ้งเตือนของแอปรุ่นใหม่ (5.00.00 · ไม่มี OneSignal · Pack เคาะ 2026-11-07 · DEV-0001)
 * สัญญา: `shopchamp-center/api/device.registerPushToken.yaml` · `device.signOutPush.yaml`
 * แบบ: `lanes/dev/source/push-pattern-from-sibling.md` §3.1 · doc ที่เขียน = `PushDevice` (entities/pushDevice.ts)
 *
 * - `deviceKey` = ค่าดิบจาก `DeviceInfo.getUniqueId()` (คงที่ต่อการติดตั้ง) · server hash เป็น doc id `app-<sha256 32 ตัว>` เอง
 *   ⇒ ไม่เก็บค่าดิบ และแอปไม่ต้องมีโค้ด hash
 * - ร้านและคน (`shopId` `staffId` ใน doc) มาจากตัวตนที่ผ่านด่าน ไม่รับจาก body (body.shopId ใช้เทียบด่าน wrong_shop เท่านั้น)
 * - `pushToken` = FCM token ทั้ง 2 แพลตฟอร์ม (iOS ก็เป็น FCM token ไม่ใช่ hex ของ APNs) · เกณฑ์รูปยกจากบ้านพี่น้อง (20-4096 ตัว ไม่มีช่องว่าง)
 */

const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });

/** ค่าดิบจาก getUniqueId (IDFV / ANDROID_ID) · ไม่ว่าง ไม่เกิน 200 · ไม่มีช่องว่าง */
export const PushDeviceKey = z
  .string()
  .min(1, { message: "deviceKey ห้ามว่าง" })
  .max(200)
  .refine((s) => !/\s/.test(s), { message: "deviceKey ห้ามมีช่องว่าง" })
  .refine((s) => s !== "unknown", { message: "deviceKey อ่านไม่ได้ (unknown)" });

/** FCM token · 20-4096 ตัว ไม่มีช่องว่าง (เกณฑ์เดียวกับตัวส่ง) */
export const FcmToken = z
  .string()
  .min(20, { message: "pushToken สั้นเกิน" })
  .max(4096)
  .refine((s) => !/\s/.test(s), { message: "pushToken ห้ามมีช่องว่าง" });

export const PushPlatform = z.enum(["android", "ios"]);

export const DeviceRegisterPushTokenRequest = z
  .object({
    shopId: docId("shopId").describe("doc id ร้านที่เพิ่งเข้า · server เทียบกับตัวตนจาก token"),
    deviceKey: PushDeviceKey.describe("DeviceInfo.getUniqueId() ค่าดิบ"),
    pushToken: FcmToken.describe("messaging().getToken()"),
    platform: PushPlatform,
    appVersion: z.string().max(32).optional().describe("เลขรุ่นแอป เช่น 5.00.00 · ไว้ไล่ปัญหา"),
    model: z.string().max(100).optional().describe("รุ่นเครื่อง · ไว้ไล่ปัญหา"),
  })
  .strict();
export type DeviceRegisterPushTokenRequest = z.infer<typeof DeviceRegisterPushTokenRequest>;

/** ออกร้าน = 'shop' (ล้าง shopId) · ออกจากระบบ = 'all' (ล้าง staffId + shopId) */
export const DeviceSignOutPushRequest = z
  .object({
    deviceKey: PushDeviceKey,
    scope: z.enum(["shop", "all"]),
  })
  .strict();
export type DeviceSignOutPushRequest = z.infer<typeof DeviceSignOutPushRequest>;

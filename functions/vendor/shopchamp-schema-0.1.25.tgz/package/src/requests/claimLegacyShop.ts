import { z } from "zod";

/**
 * คำขอเข้าครั้งแรกของร้านรุ่นแรก (ก้อน 10 รอบ 2c · DEV-0001 · แถว LD-029)
 * สัญญา: `shopchamp-center/api/profile.claimLegacyShop.yaml` · route `POST /pos/profile/claim-legacy-shop`
 *
 * ร้านรุ่นแรก = doc ร้านที่ field `shopId` เป็น uid ของเจ้าของ และบัญชีนั้นยังไม่มี `profile/{uid}`
 *   (วัดฐานจริง 2026-11-07: 8,476 ร้าน · ทุกร้าน humanResource ว่าง POSs ว่าง · สร้างปี 2022-2023 เกือบทั้งหมด)
 * แทน `app:screens/LoadingScreen.js:156-218` ที่เขียน profile + shift + shop.humanResource/POSs ใน transaction เดียวจากเครื่อง
 *   ⇒ server ตัดสินเองว่าเป็นเจ้าของ (uid จาก token == shop.shopId) · แอปส่งแค่ข้อมูลเครื่อง
 */

export const ProfileClaimLegacyShopRequest = z
  .object({
    posId: z.uuid().describe("id จุดขายแรก สร้างที่แอป (เดิม uuid.v4 · LoadingScreen.js:179)"),
    uniqueId: z.string().min(1).max(200).describe("getUniqueId() ของเครื่อง · ผูกจุดขายแรก (:213)"),
    deviceName: z.string().max(200).optional().describe("getDeviceName() ของเครื่อง · เดิมไม่เขียน · ไม่ส่ง = ''"),
  })
  .strict();
export type ProfileClaimLegacyShopRequest = z.infer<typeof ProfileClaimLegacyShopRequest>;

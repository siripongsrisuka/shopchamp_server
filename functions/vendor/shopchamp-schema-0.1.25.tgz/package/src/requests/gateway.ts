import { z } from "zod";

/**
 * คำขอ API เกตเวย์รับเงิน (ก้อน 7 · DEV-0001) · function `pos_gateway` · strict ทุกชั้น: field เกิน = ปัด 400
 * สัญญา: `shopchamp-center/api/payment.*.yaml` (เส้นที่แอปเรียก) · เส้น webhook (`gateway.webhook*`) รับ payload ของผู้ให้บริการ ไม่ใช้ schema นี้
 *
 * หลักที่เคาะแล้ว (`progress-shopchamp-architecture-upgrade.md` 🎯 2026-11-06 · `architecture-plan.md` ก้อน 7):
 * - แอปสร้างบิลเองหลังรู้ผล (3-2) ⇒ ไม่มี `checkoutType` `receiptData` `notification` (autoCheckout ของร้านอาหารไม่ยก)
 * - แอปไม่ส่งและไม่ถือกุญแจของผู้ให้บริการ · ช่องกุญแจมาทาง `payment.testAndSave` ขาเดียว (เขียนอย่างเดียว ไม่มีทางอ่านกลับ)
 * - `shopId` = shop doc id · ต้องตรง `req.shopAccess.shopId` ไม่งั้น 403 (ด่านเดียวกับก้อน 4)
 * - ยอดเงินเป็นบาท ทศนิยม ≤ 2 · มากกว่า 0 · server แปลงเป็นสตางค์ครั้งเดียวที่ปากทาง (B-08)
 * - EDC เอาเฉพาะ NTT ผูกรายจุดคิดเงิน (Pack เลือก 2026-11-06) ⇒ `stationId`
 */

/** ทศนิยมไม่เกิน n ตำแหน่ง · เทียบผ่าน toFixed เพราะ `0.29 * 100` ไม่เป็นจำนวนเต็มใน float */
const atMostDecimals = (n: number) => (v: number) => Number(v.toFixed(n)) === v;

/** ยอดที่ขอเกตเวย์: บาท · มากกว่า 0 · ทศนิยม ≤ 2 · เพดาน 1e7 (ยอดเกตเวย์ต่อครั้ง) */
export const GatewayAmount = z
  .number()
  .finite()
  .positive({ message: "ยอดต้องมากกว่า 0" })
  .lt(1e7, { message: "ยอดเกินเพดาน" })
  .refine(atMostDecimals(2), { message: "ยอดทศนิยมไม่เกิน 2 ตำแหน่ง" });

/** doc id ทั่วไป: ห้ามว่าง ห้ามมี `/` · ≤ 128 */
const DocId = z
  .string()
  .min(1, { message: "id ห้ามว่าง" })
  .max(128)
  .refine((s) => !s.includes("/"), { message: "id ห้ามมี /" });

/** รหัสในทะเบียน (providerId · channelId · stationId): ตัวอักษร ตัวเลข `-` `_` `.` `:` · 1-64 ตัว (กัน path และ key ต้องห้ามของ Firestore) */
export const GatewayCode = z
  .string()
  .regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}$/, { message: "รหัสต้องเป็นตัวอักษร ตัวเลข - _ . : ไม่เกิน 64 ตัว" });

/** `referenceId` ที่ server ออกให้ (doc id ของ `pgWebhook`) · กัน B-19 (`/` ใน id) */
export const GatewayReferenceId = z
  .string()
  .regex(/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/, { message: "referenceId ไม่ถูกรูป" });

/** กุญแจกันกดซ้ำของแอป (รอบขาย:ช่องทาง:ยอด) · 1-128 ตัว ไม่มี `/` */
const ClientRequestId = z
  .string()
  .min(1)
  .max(128)
  .refine((s) => !s.includes("/"), { message: "clientRequestId ห้ามมี /" });

/** `payment.requestQr` · ขอ QR / สั่งเครื่อง Bolt ผ่าน server (เจ้า runtime server) */
export const PaymentRequestQrRequest = z
  .object({
    shopId: DocId,
    channelId: GatewayCode.describe("ช่องทางในทะเบียน `pos/gateway/providers` · เจ้า runtime device = 400"),
    amount: GatewayAmount.describe("ยอดบิลที่จะสร้างหลังจ่าย (บาท) · แอปส่งยอดเดียวกันให้ `sale.create`"),
    clientRequestId: ClientRequestId.optional().describe("ส่งค่าเดิมภายใน 15 นาที (ร้าน+ช่องทาง+ยอดเดิม) = ได้ QR ใบเดิม หลังถามผู้ให้บริการแล้วยังไม่จ่าย"),
  })
  .strict();

/** `payment.inquire` · ถามผู้ให้บริการว่าจ่ายแล้วไหม (แอป poll ทุก 2 วิ คู่กับฟัง `pgWebhook/{referenceId}`) */
export const PaymentInquireRequest = z.object({ shopId: DocId, referenceId: GatewayReferenceId }).strict();

/** `payment.cancelQr` · ปิดจอ QR แล้วยกเลิกที่ผู้ให้บริการ (เจ้าที่มี API) หรือประทับ `cancelRequestedAt` */
export const PaymentCancelQrRequest = z.object({ shopId: DocId, referenceId: GatewayReferenceId }).strict();

/** `payment.connectionsGet` · ทะเบียน + สถานะของร้าน · ไม่มีค่ากุญแจ · `stationId` = คืนเครื่อง EDC ของจุดคิดเงินนั้น */
export const PaymentConnectionsGetRequest = z
  .object({ shopId: DocId, stationId: GatewayCode.optional() })
  .strict();

/** ค่าช่องที่ร้านกรอก: ข้อความ ≤ 512 ตัว · ช่องที่ไม่ส่ง = ไม่แตะค่าเดิม */
const FieldValue = z.string().max(512);

/** `payment.testAndSave` · ทดสอบกับผู้ให้บริการก่อน ผ่านค่อยเขียน · ล้ม = ไม่เขียนสักช่อง */
export const PaymentTestAndSaveRequest = z
  .object({
    shopId: DocId,
    providerId: GatewayCode,
    fields: z.record(GatewayCode, FieldValue).optional().describe("{ ชื่อช่องตามทะเบียน: ค่า } · ช่องลับเข้ารหัสก่อนเก็บ"),
    channels: z.record(GatewayCode, z.boolean()).optional().describe("{ channelId: เปิด/ปิด } · ไม่ส่ง = ไม่แตะ"),
  })
  .strict();

/** `payment.channelsCheck` · ถามผู้ให้บริการว่ากระเป๋าไหนเปิด แล้วเก็บผล */
export const PaymentChannelsCheckRequest = z.object({ shopId: DocId, providerId: GatewayCode }).strict();

/** `payment.pair` · แลกรหัสบนจอเครื่อง (Beam Bolt) เป็นการเชื่อมต่อของร้าน */
export const PaymentPairRequest = z
  .object({
    shopId: DocId,
    providerId: GatewayCode,
    pairingCode: z.string().trim().min(1, { message: "ต้องใส่รหัสจับคู่" }).max(64),
  })
  .strict();

/** `payment.unpair` · เจ้าของตัดเครื่องออกจากร้าน */
export const PaymentUnpairRequest = z.object({ shopId: DocId, providerId: GatewayCode }).strict();

/** เลขจากเครื่อง EDC: ตัวอักษร ตัวเลข `-` `_` · ≤ 64 */
const EdcRef = z.string().regex(/^[A-Za-z0-9_-]{1,64}$/, { message: "เลขอ้างอิงจากเครื่องไม่ถูกรูป" });

/** `payment.deviceSaleRecord` · แอปบันทึกผลที่เครื่อง EDC อนุมัติแล้ว ก่อนสร้างบิล · ยิงซ้ำ = ใบเดิม */
export const PaymentDeviceSaleRecordRequest = z
  .object({
    shopId: DocId,
    channelId: GatewayCode.describe("ช่องทางของเจ้า runtime device (`ntt-edc`) เท่านั้น"),
    amount: GatewayAmount,
    stationId: GatewayCode.optional().describe("จุดคิดเงินที่เครื่องผูกอยู่"),
    invoiceNo: EdcRef.optional(),
    posRefNo: EdcRef.optional(),
    tradeType: z.string().max(32).optional(),
    approvalCode: z.string().max(32).optional(),
    terminalId: z.string().max(32).optional(),
    merchantId: z.string().max(32).optional(),
  })
  .strict()
  .refine((v) => v.invoiceNo !== undefined || v.posRefNo !== undefined, {
    message: "ต้องมี invoiceNo หรือ posRefNo อย่างน้อย 1 ช่อง",
    path: ["invoiceNo"],
  });

/** ที่อยู่เครื่อง NTT EDC บน LAN · IPv4 · พอร์ต 1-65535 (เครื่อง LinkPOS ใช้ 8020) */
const EdcDevice = z
  .object({
    ip: z.ipv4({ message: "IP ไม่ถูกรูป" }),
    port: z.number().int().min(1).max(65535),
    name: z.string().max(64).optional(),
  })
  .strict();

/** `payment.stationEdcSet` · ผูก/ถอดเครื่อง NTT EDC กับจุดคิดเงิน · `device: null` = ถอด */
export const PaymentStationEdcSetRequest = z
  .object({
    shopId: DocId,
    stationId: GatewayCode,
    stationName: z.string().max(64).optional(),
    device: EdcDevice.nullable(),
  })
  .strict();

/** `payment.simulate` · จำลองเงินเข้าบนร้านทดสอบเท่านั้น (ขับ webhook ตัวจริง แทนแค่การถามผู้ให้บริการ) */
export const PaymentSimulateRequest = z
  .object({
    shopId: DocId,
    referenceId: GatewayReferenceId,
    outcome: z.enum(["paid", "amount_mismatch"]).optional().describe("ไม่ส่ง = paid · amount_mismatch = ผู้ให้บริการตอบยอดต่าง 1 สตางค์"),
  })
  .strict();

export type PaymentRequestQrRequest = z.infer<typeof PaymentRequestQrRequest>;
export type PaymentInquireRequest = z.infer<typeof PaymentInquireRequest>;
export type PaymentCancelQrRequest = z.infer<typeof PaymentCancelQrRequest>;
export type PaymentConnectionsGetRequest = z.infer<typeof PaymentConnectionsGetRequest>;
export type PaymentTestAndSaveRequest = z.infer<typeof PaymentTestAndSaveRequest>;
export type PaymentChannelsCheckRequest = z.infer<typeof PaymentChannelsCheckRequest>;
export type PaymentPairRequest = z.infer<typeof PaymentPairRequest>;
export type PaymentUnpairRequest = z.infer<typeof PaymentUnpairRequest>;
export type PaymentDeviceSaleRecordRequest = z.infer<typeof PaymentDeviceSaleRecordRequest>;
export type PaymentStationEdcSetRequest = z.infer<typeof PaymentStationEdcSetRequest>;
export type PaymentSimulateRequest = z.infer<typeof PaymentSimulateRequest>;

import { z } from "zod";

/**
 * คำขอ API จัดการสมาชิก (ก้อน 9b · DEV-0001) · strict (field เกิน = ถูกปัด) ต่างจาก schema เอกสารที่ passthrough
 * สัญญา: `shopchamp-center/api/member.{create,update,redeemPoint,delete,rebuildIndex}.yaml` · รอ Pack เซ็นชุด case
 * คำขอรับชำระเงินเซ็นอยู่ที่ `requests/member.ts` (ก้อน 4) · ไฟล์นี้ไม่แตะตัวนั้น
 *
 * ทางเดิมที่แทน (แอปเขียน Firestore ตรง · `lanes/dev/source/schema/member.md` §4):
 *   สร้าง W1 + ดัชนี L1/L2 + ตัวนับ C1 (`main3:src/Modal/Modal_NewMember.js:39-118`)
 *   แก้ชื่อเบอร์ W2 (`main3:src/Modal/Modal_EditMember.js:31-37`) · ตัดแต้ม W3 (`main3:src/Modal/Modal_PointMember.js:37-50`)
 *   ลบ W9 + ดัชนี L3 + ตัวนับ C3 (`main3:src/screens/MemberScreen.js:328-356`) · ย้ายดัชนี W8 L4 (`main3:src/hook/useLocalMember.js:48-88`)
 *
 * ร้านและสมาชิกต้องตรงกัน (`member.shopId` เป็นของร้านผู้เรียก · #8 K3 ฝั่ง server) = หน้าที่ของ server ใน transaction ไม่ใช่ schema
 */

/** ทศนิยมไม่เกิน 2 ตำแหน่ง · เทียบผ่าน toFixed เพราะ `0.29 * 100` ไม่เป็นจำนวนเต็มใน float */
const hasAtMost2Decimals = (v: number) => Number(v.toFixed(2)) === v;
/** เพดานกันพิมพ์พลาดจนเลขกลายเป็น exponent (F65) · 1 พันล้าน */
const MAX_AMOUNT = 1_000_000_000;

const docId = (label: string) =>
  z
    .string()
    .min(1, { message: `${label} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${label} ห้ามมี / หรือเป็น . ..` });

/** ข้อความที่ trim แล้วต้องไม่ว่าง (F47 · F69 · ด่านเดิมของแอป `!name` `!tel`) · server เขียนค่าที่ trim แล้ว */
const requiredText = (label: string, max: number) =>
  z
    .string()
    .trim()
    .min(1, { message: `${label} ห้ามว่าง` })
    .max(max, { message: `${label} ยาวเกิน ${max} ตัวอักษร` });

/** ยอดตั้งต้นหรือแต้ม: ตัวเลขจริง ≥ 0 ทศนิยมไม่เกิน 2 (รับทศนิยมได้ · F35 ต้นเหตุอยู่ที่ช่องของจอ · F52 เศษลอย · F65 เลขใหญ่) */
const nonNegativeAmount = (label: string) =>
  z
    .number()
    .min(0, { message: `${label} ติดลบไม่ได้` })
    .max(MAX_AMOUNT)
    .refine(hasAtMost2Decimals, { message: `${label} ทศนิยมไม่เกิน 2 ตำแหน่ง` });

export const MemberCreateRequest = z
  .object({
    shopId: z.string().min(1).describe("ร้าน (shop doc id) · ด่านสิทธิ์ร้านใช้ค่านี้"),
    memberUUID: z
      .uuid()
      .describe("รหัสสมาชิกใหม่ สร้างที่แอป = doc id ของ `member` · ส่งซ้ำ (เน็ตช้า) ได้สมาชิกคนเดิม ไม่ซ้ำคนละ id (F23)"),
    name: requiredText("ชื่อสมาชิก", 100).describe("ชื่อลูกค้า · ห้ามว่าง (ด่านเดิม `Modal_NewMember.js:55`)"),
    tel: requiredText("เบอร์โทร", 30).describe("เบอร์ลูกค้า · เก็บเป็นข้อความ ไม่เสีย 0 นำหน้า (F31) · ห้ามว่าง"),
    point: nonNegativeAmount("แต้มตั้งต้น").describe(
      "แต้มตั้งต้น · > 0 ต้องมีสิทธิ์ '125' จัดการแต้ม (K11 · server ตรวจ) · ของเดิมเขียน `Number(point)`",
    ),
    credit: nonNegativeAmount("เงินเซ็นตั้งต้น").describe(
      "เงินเซ็นยกยอดตั้งต้น · > 0 ต้องมีสิทธิ์ '124' จัดการเซ็น (K11 · server ตรวจ) · ของเดิมเขียน `Number(credit)`",
    ),
  })
  .strict();
export type MemberCreateRequest = z.infer<typeof MemberCreateRequest>;

export const MemberUpdateRequest = z
  .object({
    shopId: z.string().min(1),
    memberId: docId("memberId").describe("doc id ของ `member`"),
    name: requiredText("ชื่อสมาชิก", 100).describe("ชื่อใหม่ · ห้ามว่าง (F47)"),
    tel: requiredText("เบอร์โทร", 30).describe("เบอร์ใหม่ · ห้ามว่าง"),
  })
  .strict();
export type MemberUpdateRequest = z.infer<typeof MemberUpdateRequest>;

export const MemberRedeemPointRequest = z
  .object({
    shopId: z.string().min(1),
    memberId: docId("memberId"),
    points: z
      .number()
      .positive({ message: "แต้มที่ตัดต้องมากกว่า 0 (F55)" })
      .max(MAX_AMOUNT)
      .refine(hasAtMost2Decimals, { message: "แต้มที่ตัดทศนิยมไม่เกิน 2 ตำแหน่ง (F52)" })
      .describe("แต้มที่ลูกค้าใช้แลกนอกบิล · ตัวเลขจริง ไม่ใช่ข้อความแบบทางเดิม"),
    requestId: z.uuid().describe("รหัสการกด 1 ครั้ง สร้างที่แอป = doc id ของ `pointHistory` · ส่งซ้ำไม่ตัดซ้ำ (F11)"),
    staffId: z.string().min(1).describe("พนักงานที่ทำรายการ (บัญชีเครื่องใช้ร่วมกันได้ · รูปเดียวกับ member.payCredit) · ต้อง active (B-11)"),
    staffName: z.string().max(100).describe("ชื่อพนักงาน · ต้องมีเป็น string แม้ว่าง"),
  })
  .strict();
export type MemberRedeemPointRequest = z.infer<typeof MemberRedeemPointRequest>;

export const MemberDeleteRequest = z
  .object({
    shopId: z.string().min(1),
    memberId: docId("memberId"),
  })
  .strict();
export type MemberDeleteRequest = z.infer<typeof MemberDeleteRequest>;

export const MemberRebuildIndexRequest = z
  .object({
    shopId: z.string().min(1).describe("ร้านที่จะสร้างดัชนีค้นหา `memberList` ใหม่จากสมาชิกจริง (F24-F27)"),
  })
  .strict();
export type MemberRebuildIndexRequest = z.infer<typeof MemberRebuildIndexRequest>;

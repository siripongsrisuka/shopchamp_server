import { z } from "zod";

/**
 * คำขอ API จุดขาย และการย้ายโครงร้านรุ่นแรก (ก้อน 10 รอบ 2a · DEV-0001) · strict ทุกชั้น field เกิน = ปัด
 *
 * pos.manage  `POST /pos/pos/manage` · สัญญา `shopchamp-center/api/pos.manage.yaml`
 *   แทน `app:screens/POSScreen.js:143-163` (เขียน POSs ทั้งก้อน + สร้าง/ลบ doc shift ใน transaction เดียว)
 *   และ `app:screens/PrinterPosScreen.js:49-66` (เติม id/shiftId ให้จุดขายรุ่นเก่า)
 *   ⇒ แก้ทีละแถวด้วย id (เครื่องอื่นแก้แถวอื่นไม่หาย · FN-060/061) · doc shift ของแถวสร้าง/ลบในคำขอเดียวกันเสมอ
 *   ❌ ไม่รับ shiftId · shopId ของ doc shift · เวลา จากแอป (server ตั้งเอง)
 *
 * shop.migrateLegacy  `POST /pos/shop/migrate-legacy` · สัญญา `shopchamp-center/api/shop.migrateLegacy.yaml`
 *   แทน `app:screens/HomeScreen.js:337-495` (U20 · ร้านที่ยังมีช่อง payment รุ่นแรก) · server คิดเองทั้งหมดจาก doc ร้าน
 *   แอปส่งแค่ค่าเครื่องพิมพ์ของเครื่องนี้ (มาจากเครื่อง ไม่อยู่ในฐาน: ชนิดเครื่องพิมพ์ใน profile · ความกว้าง Sunmi)
 */

const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });
const ShopIdField = docId("shopId").describe("doc id ร้านของผู้เรียก · server เทียบกับตัวตนจาก token");
const PosId = docId("id จุดขาย");
const PosName = z
  .string()
  .max(100)
  .refine((s) => s.trim() !== "", { message: "กรุณาตั้งชื่อจุดชำระเงิน" });

// ─────────────── pos.manage ───────────────

const AddOp = z
  .object({ op: z.literal("add"), id: PosId.describe("id ที่เครื่องตั้ง (uuid) · ส่งซ้ำ = ได้แถวเดิม"), name: PosName })
  .strict();
const RenameOp = z.object({ op: z.literal("rename"), id: PosId, name: PosName }).strict();
const RemoveOp = z.object({ op: z.literal("remove"), id: PosId }).strict();
const DisconnectOp = z.object({ op: z.literal("disconnect"), id: PosId.describe("ล้างเครื่องที่ผูก (uniqueId deviceName)") }).strict();
const RepairOp = z.object({ op: z.literal("repair") }).strict().describe("เติม id ให้แถวที่ไม่มี และสร้าง doc shift ให้แถวที่ไม่มี shiftId");

export const PosManageOp = z.discriminatedUnion("op", [AddOp, RenameOp, RemoveOp, DisconnectOp, RepairOp]);

export const PosManageRequest = z
  .object({
    shopId: ShopIdField,
    ops: z.array(PosManageOp).min(1).max(20).describe("ทำทั้งชุดใน transaction เดียว · ตัวไหนไม่ผ่าน = ไม่เขียนอะไรเลย"),
  })
  .strict()
  .superRefine((v, ctx) => {
    const seen = new Set<string>();
    v.ops.forEach((o, i) => {
      if (o.op === "repair") {
        if (v.ops.length > 1) ctx.addIssue({ code: "custom", path: ["ops", i], message: "repair ต้องส่งเดี่ยว" });
        return;
      }
      if (seen.has(o.id)) ctx.addIssue({ code: "custom", path: ["ops", i], message: "แก้จุดขายเดียวกันซ้ำในคำขอเดียวไม่ได้" });
      seen.add(o.id);
    });
  });
export type PosManageRequest = z.infer<typeof PosManageRequest>;

// ─────────────── shop.migrateLegacy ───────────────

const BluetoothSlot = z.object({ address: z.string().max(100), name: z.string().max(200) }).strict();

export const ShopMigrateLegacyRequest = z
  .object({
    shopId: ShopIdField,
    printer: z
      .object({
        printerType: z.enum(["bluetooth", "ethernet", "sunmi"]),
        printerSize: z.string().min(1).max(10).describe("ขนาดกระดาษ (มม.) เป็นข้อความแบบแอปเดิม เช่น '58' '80'"),
        printerBluetooth: z.object({ android: BluetoothSlot, ios: BluetoothSlot }).strict(),
      })
      .strict()
      .describe("ค่าเครื่องพิมพ์ของเครื่องนี้ (สูตรเดิม HomeScreen.js:341-386) · ใส่ให้ทุกจุดขาย"),
  })
  .strict();
export type ShopMigrateLegacyRequest = z.infer<typeof ShopMigrateLegacyRequest>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `pushDevices/{app-<sha256(deviceKey) 32 ตัว>}` — ทะเบียนเครื่องที่รับแจ้งเตือนของแอปรุ่นใหม่ (FCM ตรง · ไม่มี OneSignal · DEV-0001)
 * - server เท่านั้นที่อ่าน/เขียน (Firestore rules ปิดทั้ง collection) · แอปลงทะเบียนผ่าน `device.registerPushToken`
 * - รูปยกจากบ้านพี่น้อง (`push-pattern-from-sibling.md` §3.1) · 1 doc ต่อเครื่อง (ไม่ใช่ต่อ token)
 * - หาผู้รับด้วย `shopId` (ทั้งร้าน) · `shopId + staffId` (รายคนในร้าน) · `staffId` (คนนี้ทุกร้าน)
 * - token ตาย (FCM ตอบ not-registered / invalid) = `invalid:true` ไม่ลบ doc · ลงทะเบียนด้วย token ใหม่ = ปลด invalid
 * - ออกร้าน = `shopId:null` · ออกจากระบบ = `staffId:null shopId:null` ⇒ ไม่ถูกเลือกเป็นผู้รับ
 */
export const PushDevice = z
  .object({
    token: z.string().min(1).describe("FCM token ล่าสุดของเครื่อง"),
    platform: z.enum(["android", "ios"]),
    client: z.literal("native").describe("แอปรุ่นใหม่ (ไม่มี OneSignal SDK) · ตัวส่งส่งเฉพาะ native"),
    staffId: z.string().min(1).nullable().describe("uid ของบัญชีที่ล็อกอิน (ค่าเดียวกับ tag id เดิมของ OneSignal) · ออกจากระบบ = null"),
    shopId: z.string().min(1).nullable().describe("doc id ร้านที่เข้าอยู่ · ออกร้าน = null"),
    appVersion: z.string().nullable(),
    deviceModel: z.string().nullable(),
    invalid: z.boolean(),
    invalidReason: z.string().optional(),
    invalidAt: FirestoreTime.optional(),
    lastSeenAt: FirestoreTime,
    createdAt: FirestoreTime,
    updatedAt: FirestoreTime,
    tokenUpdatedAt: FirestoreTime.optional(),
    signedOutAt: FirestoreTime.optional(),
  })
  .strict();
export type PushDevice = z.infer<typeof PushDevice>;

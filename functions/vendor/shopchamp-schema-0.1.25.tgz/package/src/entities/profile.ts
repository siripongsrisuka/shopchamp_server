import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `profile/{uid}` — บัญชีผู้ใช้ 1 doc ต่อ 1 uid (ก้อน 9c · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/profile.md` §1 (ระดับบน 15 · ซ้อน 19) · ค่าตั้งต้น `app:config/initialProfile.js`
 *
 * - `currentLogin.shopId` = field `shop.shopId` ของร้านที่เข้าอยู่ (`''` = ไม่ได้อยู่ร้านไหน) · เป็นของบัญชี ไม่ใช่ของเครื่อง
 * - `port[]` ร้านที่บัญชีเคยเข้า · `shopId` ในแถวเป็น field `shop.shopId`
 * - `imageId` เก็บ URL ไม่ใช่ id · `gender` `birthday` เป็น `''` เสมอ (ไม่มีจอแก้)
 * - `id` `uniqueId` ติดเข้า doc โดยไม่ตั้งใจจากจอโปรไฟล์ · `printerType` `portOwner` `dateTime` มีแต่ทางอ่าน (รุ่นเก่า)
 * - `.passthrough()` เพราะแอปเก่า เว็บ care ยังเขียนตรงอยู่
 */
export const ProfilePrinter = z.object({ type: z.string().optional() }).passthrough();

export const ProfileCurrentLogin = z
  .object({
    shopId: z.string().describe("field shop.shopId · `''` = ไม่ได้อยู่ในร้าน"),
    rights: z.array(z.string()).optional(),
    printer: z.array(ProfilePrinter).optional().describe("ไม่มีตอนสร้างร้าน (W4)"),
  })
  .passthrough();

export const ProfilePort = z
  .object({
    shopId: z.string().describe("field shop.shopId"),
    shopName: z.string().optional(),
    logo: z.string().optional(),
    position: z.unknown().optional(),
    lastLogin: FirestoreTime.optional(),
    timestamp: FirestoreTime.optional(),
    printer: z.array(ProfilePrinter).optional(),
  })
  .passthrough();

export const Profile = z
  .object({
    imageId: z.string().optional().describe("URL รูปหรือ `''`"),
    timestamp: FirestoreTime.optional(),
    name: z.string().optional(),
    tel: z.string().optional().describe("ไม่ตรวจรูปแบบ ไม่ unique (DI-22)"),
    email: z.string().optional(),
    gender: z.string().optional(),
    birthday: z.unknown().optional().describe("`''` จากแอป · route เดิมคาด Timestamp"),
    port: z.array(ProfilePort).optional(),
    currentLogin: ProfileCurrentLogin.optional(),
    wallPaper: z.object({ status: z.boolean().optional(), imageId: z.string().optional() }).passthrough().optional(),
    id: z.string().optional(),
    uniqueId: z.string().optional(),
    printerType: z.string().optional(),
    portOwner: z.unknown().optional(),
    dateTime: FirestoreTime.optional(),
  })
  .passthrough();

export type Profile = z.infer<typeof Profile>;

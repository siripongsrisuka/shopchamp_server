import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `stockJournal/{shopDocId}_{YYYYMMDD}_{kind}_{part}` — สมุดเคลื่อนไหวสต๊อกรายวันต่อร้าน แยกตามชนิด (DEV-0007)
 * - server เท่านั้นที่เขียน (Firestore rules ปิดทั้ง collection) · เขียนใน transaction เดียวกับการเปลี่ยน stock
 *   ของ handler ใหม่ (`pos/sale/{create,void}` · `pos/stock/{receive,receiveEdit,adjust,requisition,productSave,productDelete,link}`)
 * - ตัวเขียน: `shopchamp_server/functions/pos/_shared/stockJournal.js` (set merge + increment · ไม่อ่าน doc สมุด)
 * - `qty[<stock doc id>]` = ผลรวมของ (stock หลังเขียน − stock ก่อนเขียน) ของ doc นั้นในวันนั้น ชนิดนั้น · หน่วยเดียวกับช่อง `stock`
 * - `day` = วันธุรกิจตาม `shop.cutOff` ของเวลา server ตอนเขียน (logic.businessDayOf) · รูปเดียวกับ `bill.billDate`
 * - แอปเก่า (เขียน stock ตรงจากเครื่อง) ไม่ลงสมุดนี้ ⇒ ยอดในสมุด = เฉพาะการเปลี่ยนที่ผ่าน server
 * - แยก doc ตามชนิด (+ part 0-3 สำหรับ receive adjust create) กันเพดาน 1 MiB ต่อ doc
 */
export const STOCK_JOURNAL_KINDS = ["sale", "void", "receive", "receiveEdit", "adjust", "requisition", "create", "delete", "link"] as const;
export const StockJournalKind = z.enum(STOCK_JOURNAL_KINDS);

export const StockJournal = z
  .object({
    shopId: z.string().min(1).describe("shop doc id (ไม่ใช่ field shop.shopId)"),
    day: z.string().regex(/^\d{8}$/).describe("วันธุรกิจ YYYYMMDD ตาม shop.cutOff"),
    kind: StockJournalKind,
    part: z.number().int().min(0).max(3),
    qty: z.record(z.string().min(1), z.number().finite()).describe("stock doc id → ผลรวมผลต่างของช่อง stock"),
    events: z.number().int().min(1).describe("จำนวน transaction ที่ลง doc นี้"),
    updateTime: FirestoreTime,
    byAdmin: z.literal(true).optional().describe("ทีมงานเคยแตะสมุดนี้"),
    adminUid: z.string().min(1).optional().describe("ทีมงานคนล่าสุดที่แตะ"),
    adminEvents: z.number().int().min(1).optional(),
  })
  .strict();
export type StockJournal = z.infer<typeof StockJournal>;

/** doc id `{shopDocId}_{YYYYMMDD}_{kind}_{part}` */
export const StockJournalDocId = z
  .string()
  .regex(new RegExp(`^[^/]+_\\d{8}_(${STOCK_JOURNAL_KINDS.join("|")})_[0-3]$`));

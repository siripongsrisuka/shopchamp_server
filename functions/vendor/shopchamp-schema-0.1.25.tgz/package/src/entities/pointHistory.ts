import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `pointHistory/{requestId}` — สมุดตัดแต้มมือ **collection ใหม่** (ก้อน 9b · DEV-0001 · K12 ข้อเสนอ "สมุดประวัติตัดแต้ม")
 *   เขียนโดย `member.redeemPoint` เท่านั้น · doc id = `requestId` ที่แอปสร้าง ⇒ ส่งซ้ำไม่ตัดซ้ำ (F11)
 *   แอปเก่าตัดแต้มตรงที่ `member.point` ไม่เขียนสมุดนี้ ⇒ ประวัติมีเฉพาะรายการจากแอปใหม่
 *   rules ก้อน 6: collection ใหม่ปิดเป็นค่าตั้งต้น (client อ่านเขียนไม่ได้ จนกว่าจะประกาศ)
 */
export const PointHistory = z
  .object({
    shopId: z.string().min(1).describe("ร้าน = `shop.shopId` (รูปเดียวกับ member.shopId)"),
    memberId: z.string().min(1),
    kind: z.literal("redeem").describe("ตัดแต้มมือ · ชนิดอื่นยังไม่มี"),
    points: z.number().positive().describe("แต้มที่ตัด"),
    pointBefore: z.number().describe("แต้มในฐานก่อนตัด (ตัดเศษลอยแล้ว)"),
    pointAfter: z.number().min(0).describe("แต้มหลังตัด = ค่าที่เขียนลง member.point"),
    requestId: z.uuid(),
    staffId: z.string().min(1),
    staffName: z.string(),
    timestamp: FirestoreTime.describe("นาฬิกา server"),
    billDate: z.string().regex(/^\d{8}$/).describe("วันไทยของ timestamp (YYYYMMDD)"),
    byAdmin: z.literal(true).optional(),
    adminUid: z.string().optional(),
  })
  .strict();
export type PointHistory = z.infer<typeof PointHistory>;

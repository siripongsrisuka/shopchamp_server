import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `franchise/{id}` — แบรนด์แฟรนไชส์ 1 doc (เว็บแฟรนไชส์เท่านั้น · แอป POS ไม่อ่าน collection นี้ · อ่านแค่ `shop.franchiseId`)
 * ที่มา: ค่าตั้งต้น `fr:configs/initialFranchise.js` · จุดเขียนเดิม `fr:screens/FranchiseListScreen.js:165-174` (สร้าง)
 *   `fr:screens/StaffScreen.js:39-72` (humanRight humanResource) · `fr:screens/WarehouseCategoryScreen.js:23-25` (warehouseCategory)
 *   `fr:screens/ProfileScreen.js:29-32` (name imageId) · `own:screens/ManualUploadScreen.js:154-170` (warehouseCategory)
 *   ตัวอ่านเดิม: `fr:redux/franchiseSlice.js:13` · `fr:screens/FranchiseListScreen.js:64-104` (`array-contains humanResource`) · rules `franchise/{fid}`
 *
 * อ่านอย่างเดียว ⇒ `.passthrough()` และทุกช่องไม่บังคับ: doc เก่าขาด `humanRight` `warehouseCategory` `timestamp` ได้ (F25 · FL-17)
 * `humanRight[]` ของเดิมมีช่องของ profile ทั้งก้อนติดมา (`birthday` `port` `currentLogin` · SF-02) ⇒ ตัวอ่านไม่ปัด แต่ API คืนแค่ช่องที่ระบุ
 */
export const FranchiseStaffRow = z
  .object({
    id: z.string().describe("uid ของ profile"),
    name: z.string().optional(),
    tel: z.string().optional(),
    email: z.string().optional(),
    imageId: z.string().optional(),
    rights: z.array(z.string()).optional().describe("รหัสเมนู (`chainStoreFranchise.js`) · ไม่มี = ไม่มีสิทธิ์"),
    status: z.string().optional().describe("ไม่มีในข้อมูลเดิม · มี และไม่ใช่ 'active' = ถือว่าไม่ใช้งาน"),
  })
  .passthrough();

export const Franchise = z
  .object({
    name: z.string().optional(),
    imageId: z.string().nullable().optional().describe("URL โลโก้ · `null` ได้จากอ่านไฟล์ล้ม (PR-17)"),
    timestamp: FirestoreTime.optional(),
    humanResource: z.array(z.string()).optional().describe("uid สมาชิก · rules และรายการใช้ช่องนี้"),
    humanRight: z.array(FranchiseStaffRow).optional(),
    warehouseCategory: z.array(z.unknown()).optional().describe("ต้นหมวดคลัง [{level, value:[{id,name,level,aboveId}]}]"),
    shopTypes: z.array(z.unknown()).optional(),
    shopCategory: z.array(z.unknown()).optional(),
    customerTypes: z.array(z.unknown()).optional(),
    createdBy: z.string().optional().describe("ใหม่ (9f) · uid ผู้สร้าง · doc เก่าไม่มี (FL-41)"),
  })
  .passthrough();

/**
 * `warehouseItem/{id}` — สินค้าคลังส่วนกลางของแฟรนไชส์ · ไม่มีระบบไหนอ่านนอกเว็บแฟรนไชส์ (ST-147 · WH-56)
 * ค่าตั้งต้น `fr:configs/initialWarehouseItem.js` · จุดเขียนเดิม `fr:screens/WarehouseScreen.js:100-118` · `own:screens/ManualUploadScreen.js:138`
 * `category` มี 2 รูปในฐาน: array ของ id (สร้างจากจอ/ไฟล์) และ array ของ object `{id,name,...}` (แก้จากจอ · ST-107) ⇒ ตัวอ่านรับทั้งคู่
 * `price` เป็นสตริงจากช่องกรอกเดิมได้ · `timestamp` ขาดได้ (ST-084)
 */
export const WarehouseItem = z
  .object({
    franchiseId: z.string(),
    name: z.string().optional(),
    price: z.union([z.number(), z.string()]).optional(),
    barcode: z.union([z.string(), z.number()]).optional(),
    sku: z.union([z.string(), z.number()]).optional(),
    unit: z.string().optional(),
    category: z.array(z.union([z.string(), z.object({ id: z.string() }).passthrough()])).optional(),
    imageId: z.string().nullable().optional(),
    priceLevel: z.array(z.unknown()).optional(),
    timestamp: FirestoreTime.optional(),
    updateTime: FirestoreTime.optional(),
    stock: z.union([z.number(), z.string()]).optional(),
  })
  .passthrough();

export type Franchise = z.infer<typeof Franchise>;
export type FranchiseStaffRow = z.infer<typeof FranchiseStaffRow>;
export type WarehouseItem = z.infer<typeof WarehouseItem>;

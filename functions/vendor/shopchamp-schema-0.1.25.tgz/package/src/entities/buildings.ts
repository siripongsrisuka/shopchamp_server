import { z } from "zod";

/**
 * `buildings/{auto id}` — ของทดลอง geo query ที่ค้างในแอป ไม่ใช่ข้อมูลร้าน (ก้อน 9c · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/buildings.md` สรุป · §1.1 (ทางเขียนเดียว `app:db/firestore.js:19` เขียนค่าคงที่ · ไม่มี shopId)
 *
 * - ไม่มี API ใหม่ของ collection นี้ (จอทดสอบไม่มีทางเข้า · ตัวค้นพัง B1 B2 · โค้ดตาย B3) ⇒ schema นี้มีไว้อ่านของเก่าเท่านั้น
 * - ❓ ของเก่าในฐานอาจมี `geohash` `lat` `lng` `location` ระดับบน (§1.2) ⇒ passthrough
 */
export const Buildings = z
  .object({
    name: z.string().optional(),
    score: z.number().optional(),
    coordinates: z.unknown().optional().describe("GeoPoint"),
    g: z.object({ geohash: z.string().optional(), geopoint: z.unknown().optional() }).passthrough().optional(),
  })
  .passthrough();

export type Buildings = z.infer<typeof Buildings>;

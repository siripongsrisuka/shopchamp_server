import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `admin/*` — ค่าตั้งของบริษัทที่ใบสั่งซื้อใช้ (ก้อน 9d DEV-0001) · ที่มา `lanes/dev/source/schema/admin.md` §2.4-§2.6
 * วัดฐานจริง 2026-11-06 (อ่านอย่างเดียว · ชนิดและจำนวนเท่านั้น):
 *   ตัวนับ 4 doc มีครบ `value` integer · `admin/package` value 5 แถว price 10 แถว id เป็นข้อความทั้งหมด price/save integer ไม่มี name ในแถว price · (วัดซ้ำ 2026-11-07) แถว price มี `day` ข้อความ "1 เดือน"/"12 เดือน" ครบ 10 แถว
 *   `admin/hardware` 18 แถว · id/price/limit ข้อความ · ไม่มี limit 1 แถว · ไม่มี status 1 แถว
 * - schema อ่านเท่านั้น (ผู้เขียนคือ care/office) · ทางเขียนของ API ใหม่แตะแค่ตัวนับ
 * - ❌ `adminConfig` ไม่อยู่ที่นี่ (profile.loading อ่านเอง · มีรายชื่อทีมงาน ห้ามออก API)
 */

/** `admin/packageNumber` `hardwareNumber` `imageNumber` `stockNumber` · §2.6 · value = เลขล่าสุดที่ออกไป ไม่รีเซ็ตรายเดือน */
export const AdminOrderCounter = z
  .object({
    value: z.number().int().nonnegative().describe("§2.6 แถว 48-51 · ไม่มี/ไม่ใช่จำนวนเต็ม = ตัวนับเสีย (B9) · server ปัด ไม่เขียน NaN"),
    timestamp: FirestoreTime.optional().describe("§2.6 แถว 52-55 · เวลาออกเลขล่าสุด · ไม่พบผู้อ่าน"),
  })
  .passthrough();
export type AdminOrderCounter = z.infer<typeof AdminOrderCounter>;

const AdminPackagePrice = z
  .object({
    id: z.union([z.string(), z.number()]).describe("§2.4 แถว 34 · รหัสที่เข้า packageOrder.packageId · ในฐานเป็นข้อความ"),
    price: z.union([z.number(), z.string()]).describe("§2.4 แถว 35 · บาท"),
    save: z.number().optional().describe("§2.4 แถว 36 · ยอดประหยัด · จอใช้แยกแท็บ (0 = รายเดือน · อื่น = รายปี) · ❌ ไม่ใช่ตัวตัดสินรอบ"),
    day: z
      .string()
      .optional()
      .describe("รอบบิลเป็นข้อความ \"1 เดือน\" / \"12 เดือน\" (วัด 2026-11-07 · 10 แถวมีครบ) · ตัวตัดสินรายปีของใบกำกับ = logic.companyPackageIsYearly"),
  })
  .passthrough();

/** `admin/package` · §2.4 */
export const AdminPackage = z
  .object({
    value: z
      .array(
        z
          .object({
            name: z.string().optional(),
            type: z.string().optional().describe("เทียบ shop.vip[].type"),
            status: z.boolean().optional().describe("ขายอยู่ · แอปกรองด้วยค่านี้"),
            price: z.array(AdminPackagePrice).describe("ราคาแต่ละรอบ"),
          })
          .passthrough(),
      )
      .describe("§2.4 แถว 22"),
    admin: z.array(z.string()).optional().describe("§2.4 แถว 23 · uid รับ push เท่านั้น"),
    payment: z.array(z.object({ value: z.number(), imageId: z.string() }).passthrough()).optional().describe("§2.4 แถว 24 · รูป QR ตามยอด"),
    packageLink: z.string().optional(),
  })
  .passthrough();
export type AdminPackage = z.infer<typeof AdminPackage>;

/** `admin/hardware` · §2.5 */
export const AdminHardware = z
  .object({
    value: z
      .array(
        z
          .object({
            id: z.string().min(1),
            name: z.string(),
            price: z.union([z.string(), z.number()]).describe("§2.5 แถว 45 · ข้อความในฐาน"),
            limit: z.union([z.string(), z.number()]).optional().describe("§2.5 แถว 46 · '' หรือไม่มี = 999 (AC-67)"),
            status: z.boolean().optional().describe("§2.5 แถว 47 · ไม่มี = ไม่ขาย"),
            categoryId: z.string().nullable().optional().describe("DEV-0003 0d · id ใน categories[] · ไม่มี/null = กลุ่ม อื่น ๆ"),
          })
          .passthrough(),
      )
      .describe("§2.5 แถว 39"),
    admin: z.array(z.string()).optional().describe("§2.5 แถว 40 · uid รับ push เท่านั้น"),
    categories: z
      .array(z.object({ id: z.string().min(1), name: z.string().max(60), active: z.boolean() }).passthrough())
      .optional()
      .describe("DEV-0003 0d (Pack 1b 2026-11-11) · หมวดอุปกรณ์ · ลำดับ array = ลำดับบนจอร้าน · office เขียน · แอปเก่า 3.12 ไม่อ่าน"),
    shipping: z
      .object({ fee: z.number().int().min(0).max(100000), freeFrom: z.number().int().min(0).max(10000000).nullable() })
      .optional()
      .describe("DEV-0003 0d (Pack 3b) · ค่าส่ง/ส่งฟรี (บาท) · ไม่มี = 100/4000 · logic.companyHardwareShipping · แอปเก่า 3.12 ไม่อ่าน"),
  })
  .passthrough();
export type AdminHardware = z.infer<typeof AdminHardware>;

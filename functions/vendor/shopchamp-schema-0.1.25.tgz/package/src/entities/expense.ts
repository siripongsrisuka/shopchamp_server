import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `expense/{auto id}` — หัวข้อค่าใช้จ่ายของร้าน (แม่แบบ ไม่ใช่รายการจ่ายจริง) (ก้อน 9c · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/expense.md` §1 (7 field) · ทางเขียน `app:redux/expenseSlice.js:44-72` · `app:screens/ExpenseScreen.js:92-117`
 *
 * - `shopId` = field `shop.shopId` (แอปเก่าเขียน `state.shop.shop.shopId` `ExpenseScreen.js:48,113`) · ใช้ query
 * - `price` เป็นข้อความจาก `twoDigitNumber` หรือ `''` · มีผลเฉพาะ `priceStatus` true (ล็อคยอด)
 * - `category` = เส้นทางหมวด (`aboveId` + id) ชี้ `shop.categoryExpense[].value[].id`
 * - `id` ใน doc เป็น `''` เสมอ (ค่าฟอร์ม) · ของจริงคือ doc id
 * - ช่องใหม่ (เพิ่มอย่างเดียว): `updatedAt` `updatedBy` (DI-16) · `byAdmin` `adminUid`
 */
export const Expense = z
  .object({
    id: z.string().optional().describe("`''` เสมอ"),
    name: z.string().optional().describe("ชื่อหัวข้อ · แอปเก่าไม่ตรวจว่าว่าง (B4)"),
    timestamp: FirestoreTime.optional().describe("เวลาสร้าง"),
    category: z.array(z.string()).optional().describe("เส้นทางหมวด"),
    price: z.union([z.string(), z.number()]).optional().describe("ยอดล็อค · ข้อความ"),
    priceStatus: z.boolean().optional().describe("ล็อคยอด = เติมยอดให้ตอนเลือกหัวข้อ"),
    shopId: z.string().describe("field shop.shopId"),
    updatedAt: FirestoreTime.optional(),
    updatedBy: z.string().optional(),
    byAdmin: z.boolean().optional(),
    adminUid: z.string().optional(),
  })
  .passthrough();

export type Expense = z.infer<typeof Expense>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `stockOrder/{id}` — ใบซื้อชุดสินค้าพร้อมขาย แนบสลิป (ก้อน 9a · DEV-0001) · ที่มา `lanes/dev/source/schema/stockOrder.md` §1 (12 แถว)
 * `id` = รหัสชุด (number 2-6) ไม่ใช่ doc id · `status` order → paid | cancel (care) · ทางเขียนใหม่ = `stock.orderCreate`
 */
export const StockOrder = z
  .object({
    shopId: z.string(),
    shopName: z.string().optional(),
    profileId: z.string().optional(),
    profileName: z.string().optional(),
    timestamp: FirestoreTime,
    imageId: z.string(),
    status: z.string().describe("`order` `paid` `cancel`"),
    orderNumber: z.string(),
    id: z.number().describe("รหัสชุดสินค้า ไม่ใช่ doc id"),
    price: z.number(),
    qty: z.number(),
    tel: z.string().optional().describe("care อ่านแต่ไม่มีคนเขียน"),
    orderUUID: z.string().optional(),
  })
  .passthrough();
export type StockOrder = z.infer<typeof StockOrder>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `uploadProduct/{id}` — ตั๋วเปิดหน้าเว็บนำเข้าสินค้า (ก้อน 9a · DEV-0001) · ที่มา `lanes/dev/source/schema/uploadProduct.md` §1 (3 field)
 * `barcodes` แอปเก่าใส่ทุกค่าใน latestStocks ไม่กรองซ้ำ (`''` ได้ · U7) · ทางเขียนใหม่ = `stock.uploadOpen` (string ไม่ซ้ำ ไม่ว่าง)
 */
export const UploadProduct = z
  .object({
    shopId: z.string(),
    timestamp: FirestoreTime.optional(),
    barcodes: z.array(z.union([z.string(), z.number()])),
    createdBy: z.string().optional(),
  })
  .passthrough();
export type UploadProduct = z.infer<typeof UploadProduct>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `deletedUser/{id}` — บันทึกการลบบัญชี (ก้อน 9d DEV-0001 · #25) · ที่มา `lanes/dev/source/schema/deletedUser.md` §1 (5 field · ไม่มีผู้อ่าน)
 * นับฐาน 2026-11-06: 2 doc (รุ่นเก่า · ทางแอปปัจจุบันเขียนไม่ถึงเพราะ B1 B2)
 * - ทางเดิม doc id อัตโนมัติ · ทางใหม่ doc id = uid (ลบซ้ำได้ผลเดิม) + field ใหม่ optional `status` `profileDeleted` `authDeleted` `requestedAt` `finishedAt`
 * - `isDeleteSuccess` ทางใหม่เขียน false ก่อน แล้วค่อยเป็น true หลังลบ Auth สำเร็จจริง (B4 เดิมเขียน true ก่อนลบ)
 */
export const DeletedUser = z
  .object({
    authenBy: z.string().optional().describe("§1 · ผู้ให้บริการ login · ทางเดิมเป็น undefined (B2) · ทางใหม่จาก token firebase.sign_in_provider"),
    deleteReason: z.string().optional().describe("§1 · เหตุผล · ทางเดิมว่างเสมอ (B5)"),
    deletedAt: FirestoreTime.optional().describe("§1 · เวลาขอลบ"),
    isDeleteSuccess: z.boolean().optional().describe("§1 · ลบ Auth สำเร็จจริงไหม"),
    uid: z.string().describe("§1 · บัญชีที่ถูกลบ · ทางเดิมว่างได้ (ฐานจริง 1 ใน 2 doc uid เป็น \"\" · วัด 2026-11-06) · ทางใหม่ = uid จาก token เสมอ"),
    status: z.enum(["pending", "done", "auth_failed"]).optional().describe("ใหม่ · ขั้นที่ถึง"),
  })
  .passthrough();
export type DeletedUser = z.infer<typeof DeletedUser>;

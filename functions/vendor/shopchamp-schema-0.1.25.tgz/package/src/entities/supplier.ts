import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `supplier/{id}` — คู่ค้าของร้าน (ก้อน 9a · DEV-0001) · ที่มา `lanes/dev/source/schema/supplier.md` §1 (8 field)
 * อ่านจากฐาน = passthrough (แอปเก่า · route clone ยังเขียนตรง) · ทางเขียนใหม่ = `stock.supplier` (`requests/stock.ts` StockSupplierRequest)
 * `dateTime` ไม่บังคับ: แอปเก่าแก้แล้วเขียนค่าที่อ่านมากลับ (Timestamp หรือ Date) · ❓ ยังไม่ได้วัด doc ร้านลูกค้า
 */
export const Supplier = z
  .object({
    vender_Name: z.string().describe("§1 แถว 1 · ชื่อคู่ค้า · UI ตรวจไม่ว่าง"),
    sale_Name: z.string().optional(),
    tel: z.string().optional(),
    lineId: z.string().optional(),
    detail: z.string().optional(),
    shopId: z.string().describe("§1 แถว 6 · ร้านเจ้าของ ใช้ query"),
    dateTime: z.union([FirestoreTime, z.string(), z.literal("")]).optional().describe("§1 แถว 7 · แอปเพิ่ม = Date · `''` จาก initialSupplier"),
    id: z.string().optional().describe("§1 แถว 8 · สำเนา doc id ไม่เชื่อถือ (add เดิม `''`)"),
  })
  .passthrough();
export type Supplier = z.infer<typeof Supplier>;

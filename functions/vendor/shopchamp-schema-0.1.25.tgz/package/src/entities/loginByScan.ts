import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `loginByScan/{autoId}` — ห้องรอเข้าเว็บเจ้าของร้านด้วย QR ของเว็บรุ่นเดิม (ก้อน 9d DEV-0001)
 * ที่มา `lanes/dev/source/schema/loginByScan.md` §1 (3 field) · นับฐาน 2026-11-06: 13,515 doc (ไม่มีตัวลบ · B6)
 * - เว็บสร้าง `{uid:'', docId, timestamp}` · แอปเขียน `uid` · เว็บเห็นแล้วขอ token ทาง `/users/scan` (route เดิม ไม่แตะ)
 * - ทางใหม่เขียนเพิ่ม `approvedAt` `approvedBy:'pos'` (เพิ่มอย่างเดียว · เว็บเดิมดูแค่ `uid`)
 * - ทางที่ปลอดภัยจริง (session ใช้ครั้งเดียว + secret ไม่อยู่ใน QR) เป็นงาน DEV-0004 · ไม่ใช่ collection นี้
 */
export const LoginByScan = z
  .object({
    docId: z.string().optional().describe("§1 แถว 1 · สำเนา doc id ให้ where"),
    uid: z.string().describe("§1 แถว 2 · '' จนกว่าจะสแกน"),
    timestamp: FirestoreTime.optional().describe("§1 แถว 3 · นาฬิกาเครื่องเว็บ · ทาง /scan ไม่เขียน"),
    approvedAt: FirestoreTime.optional().describe("ใหม่ · เวลา server ตอนแอปใหม่อนุญาต"),
  })
  .passthrough();
export type LoginByScan = z.infer<typeof LoginByScan>;

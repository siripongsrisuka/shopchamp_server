import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `notification/{autoId}` — ประวัติแจ้งเตือนของร้าน (จอ NotificationHistory) · ก้อน 9d DEV-0001
 * ที่มา: `lanes/dev/source/schema/notification.md` §1.1 (5 field · ทุกทางสร้างเขียนครบ 16/16) · §1.2 field ที่ care อ่านแต่ไม่มีใครเขียน
 * - ไม่มีทางไหลกลับเข้ายอดเงิน (§5) · ทางเขียนใหม่ทุกตัวใน `pos/**` เขียนรูปเดิม + `byAdmin` `adminUid` เมื่อทีมงานทำ
 * - `.passthrough()` เพราะแอปเก่ายังเขียนตรงอยู่ (14 จุด) · ในฐานมี 442,398 ใบ (นับ 2026-11-06)
 * - `timestamp` ในเครื่องเป็น `null` ได้ระหว่างรอ server (NB-10) ⇒ schema นี้เป็นรูปในฐาน ไม่ใช่รูปใน cache ของแอป
 */
export const NOTIFICATION_CATEGORY = Object.freeze({
  CANCEL_BILL: 1,
  SHIFT: 2,
  CHECK_IN: 3,
  CREDIT_PAY: 4,
  PRICE: 5,
  STOCK: 6,
  REQUISITION: 7,
  COMPANY_ORDER: 99,
});

export const Notification = z
  .object({
    heading: z.string().describe("§1.1 แถว 1 · หัวข้อ"),
    shopId: z.string().min(1).describe("§1.1 แถว 2 · ร้าน · 13 จุดเขียน field shop.shopId · 3 จุดเขียน doc id (§1.3) · query เดียวกรองด้วยค่านี้"),
    notificationContent: z.string().describe("§1.1 แถว 3 · ข้อความสำเร็จรูป · ยอดเงิน ชื่อคน อยู่ในข้อความนี้เท่านั้น"),
    categoryId: z.number().int().describe("§1.4 · 1-7 ตามแท็บ · 99 = ใบสั่งซื้อของบริษัท (เห็นในแท็บทั้งหมดเท่านั้น)"),
    timestamp: FirestoreTime.describe("§1.1 แถว 5 · เวลาสร้าง · ทุก query เรียงด้วยค่านี้"),
    byAdmin: z.literal(true).optional().describe("ใหม่ (ก้อน 4) · ทีมงาน Shopchamp ทำแทนร้าน"),
    adminUid: z.string().min(1).optional().describe("ใหม่ (ก้อน 4) · uid ทีมงาน"),
  })
  .passthrough();
export type Notification = z.infer<typeof Notification>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * ใบสั่งซื้อฝั่งบริษัท 3 ชนิด (ก้อน 9d DEV-0001) · รอทีมงานอนุมัติ (ฝั่งอนุมัติเป็นงาน DEV-0003)
 *   `packageOrder` (`schema/packageOrder.md` §1.1 17 field) · `hardwareOrder` (`schema/hardwareOrder.md`) · `imageOrder` (`schema/imageOrder.md`)
 *   นับฐาน 2026-11-06: packageOrder 2,135 · hardwareOrder 69 · imageOrder 2,013
 * - `.passthrough()` เพราะแอปเก่าและเว็บยังสร้างตรง · care เขียนผลอนุมัติเพิ่ม
 * - field ใหม่ของ API ใหม่ (optional เท่านั้น): `orderUUID` (= doc id) · `source:'pos'` · `byAdmin` `adminUid`
 * - `status`: packageOrder/imageOrder = order|success|cancel · hardwareOrder เพิ่ม checked|sending (นับฐาน) ⇒ ข้อความ ไม่ใช่ enum
 */
const common = {
  shopId: z.string().min(1).describe("ร้าน · packageOrder/hardwareOrder = doc id (แอป) · imageOrder = field shop.shopId · ดู PO-02"),
  shopName: z.string().optional(),
  profileId: z.string().optional().describe("ผู้กดซื้อ · care ส่ง push หาค่านี้"),
  profileName: z.string().optional(),
  timestamp: FirestoreTime.describe("เวลาซื้อ · ทางใหม่ = นาฬิกา server (AC-63)"),
  imageId: z.string().optional().describe("URL สลิป (ชื่อว่า Id แต่เก็บ URL)"),
  net: z.union([z.number(), z.string()]).optional().describe("ยอดรวม · ทางใหม่คิดที่ server ปัดสตางค์"),
  status: z.string().describe("สถานะใบ · ทางสร้าง = 'order'"),
  orderNumber: z.string().optional().describe("YYYYMM + ลำดับ 6 หลักจากตัวนับ `admin/<x>Number`"),
  orderUUID: z.string().optional().describe("ใหม่ · รหัสการกดจากแอป = doc id · กันใบซ้ำ"),
  source: z.literal("pos").optional().describe("ใหม่ · สร้างผ่าน API ใหม่"),
  byAdmin: z.literal(true).optional(),
  adminUid: z.string().optional(),
};

export const PackageOrder = z
  .object({
    ...common,
    packageId: z.array(z.union([z.string(), z.number()])).describe("§1.1 แถว 12 · id ของ admin/package.price[]"),
    vat: z.boolean().optional().describe("ทางเดิม false เสมอ (ไม่มีปุ่ม) · ทาง API true ได้เฉพาะใบแพ็กเกจรายปีที่ขอใบกำกับ (DEV-0002)"),
    vatAmount: z.number().optional().describe("DEV-0002 · มีเมื่อ vat true · 7% ของ totalPrice ปัดสตางค์ · ชื่อเดียวกับใบอุปกรณ์ (care destructure ไว้แล้ว)"),
    vatDetail: z.string().optional().describe("DEV-0002 · มีเมื่อ vat true · ข้อมูลออกใบกำกับ ข้อความเดียวรูปเดียวกับใบอุปกรณ์"),
    totalPrice: z.number().optional().describe("DEV-0002 · มีเมื่อ vat true · ยอดก่อน VAT · net = totalPrice + vatAmount"),
    email: z.string().optional(),
    tel: z.string().optional(),
    approveId: z.string().optional(),
    approveName: z.string().optional(),
  })
  .passthrough();
export type PackageOrder = z.infer<typeof PackageOrder>;

export const HardwareOrder = z
  .object({
    ...common,
    product: z.array(z.object({ id: z.string(), qty: z.number(), totalPrice: z.number() }).passthrough()).describe("แถวอุปกรณ์ + qty totalPrice"),
    totalPrice: z.number().optional(),
    deliveryFee: z.number().optional(),
    vat: z.boolean().optional(),
    vatDetail: z.string().optional(),
    vatAmount: z.number().optional(),
    address: z.string().optional(),
    nameSername: z.string().optional(),
    tel: z.string().optional(),
  })
  .passthrough();
export type HardwareOrder = z.infer<typeof HardwareOrder>;

export const ImageOrder = z
  .object({
    ...common,
    qty: z.number().int().positive().describe("จำนวนรูปที่ซื้อ (1000-5000)"),
  })
  .passthrough();
export type ImageOrder = z.infer<typeof ImageOrder>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `checkIn/{shop doc id + profileId}` — ใบเข้างานที่ยังไม่ออก 1 doc ต่อ 1 คนต่อ 1 ร้าน (ก้อน 9c · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/checkIn.md` §1 (8 field) · §2 ทางสร้างทางเดียว `app:screens/CheckInScreen.js:108`
 *
 * - doc id = `shop.id` (doc id ร้าน) ต่อ `profileId` ตรง ๆ ไม่มีตัวคั่น ⇒ แอปเก่าและ API ใหม่ต้องใช้ id เดียวกัน
 * - `shopId` ในนี้คือ **doc id ร้าน** (แอปเก่าเขียน `shop.id` `CheckInScreen.js:27,111`) ไม่ใช่ field `shop.shopId`
 * - `id` เป็น `''` เสมอ (ค่าจากฟอร์ม · ของจริงคือ doc id) · `clockOut` ในใบที่ยังไม่ออกเป็นค่าขยะจากตอนโหลดโมดูล · `clockOutImage` `''`
 * - ช่องใหม่ของ API (เพิ่มอย่างเดียว · แอปเก่าไม่อ่าน): `requestId` (กันกดซ้ำ) · `staffName` · `byAdmin` `adminUid`
 * - `.passthrough()` เพราะแอปเก่ายังเขียนตรงอยู่
 */
export const CheckIn = z
  .object({
    clockIn: FirestoreTime.describe("เวลาเข้างาน (เวลา server)"),
    clockOut: FirestoreTime.optional().describe("ค่าขยะในใบที่ยังไม่ออก · ถูกทับตอนย้ายไป checkInHistory"),
    shopId: z.string().describe("doc id ร้าน (ไม่ใช่ field shop.shopId)"),
    profileId: z.string().describe("uid ของบัญชีที่ลงเวลา"),
    clockInImage: z.string().optional().describe("URL รูปตอนเข้างาน"),
    clockOutImage: z.string().optional().describe("`''` เสมอในใบที่ยังไม่ออก"),
    id: z.string().optional().describe("`''` เสมอ · อย่าใช้แทน doc id"),
    billDate: z.string().optional().describe("`YYYYMMDD` · แอปเก่าใช้นาฬิกาเครื่อง (DI-83) · API ใหม่ใช้วันไทยของเวลา server"),
    requestId: z.string().optional().describe("ใหม่ · id ของการกดเข้างาน · ส่งซ้ำได้ผลเดิม"),
    staffName: z.string().optional().describe("ใหม่ · ชื่อจาก profile ตอนเข้างาน"),
    byAdmin: z.boolean().optional(),
    adminUid: z.string().optional(),
  })
  .passthrough();

export type CheckIn = z.infer<typeof CheckIn>;

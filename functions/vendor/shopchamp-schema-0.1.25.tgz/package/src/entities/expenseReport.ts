import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `expenseReport/{shop.shopId + YYYYMM}` — รายงานค่าใช้จ่ายรายเดือน (ก้อน 9c · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/expenseReport.md` §1 · ทางเขียน `app:screens/ExpenseReportScreen.js:111-124` (สร้างตอนกดดู)
 *   · `app:screens/ExpenseReportDetail.js:117-172` (เพิ่ม แก้ ลบแถวใน transaction)
 *
 * - doc id = field `shop.shopId` ต่อ `month` · `shopId` = field ร้าน (ไม่ใช่ doc id ร้าน)
 * - `expenses[]` รูปดิบ (แถวจริง) · ⚠️ doc ที่สร้างจากทาง "กดดู" ของแอปเก่าอาจมี `expenses` รูปสรุป `{id,name,price}` (B6)
 *   ⇒ แถวรับทั้ง 2 รูป (ช่องแถวจริงเป็น optional) · ผู้อ่านต้องดู `expenseId` ก่อนรวมยอด
 * - `totalExpense` ค้าง 0 ตลอด (B7) · ยอดจริงคิดด้วย `@shopchamp/logic` › summarizeExpenses
 * - ช่องใหม่ (เพิ่มอย่างเดียว): แถว `updatedAt` `updatedBy` (B8 · DI-16) · `deleted[]` แถวที่ถูกลบพร้อม `deletedAt` `deletedBy` (แอปเก่าไม่อ่าน)
 */
export const ExpenseReportRow = z
  .object({
    id: z.string().describe("uuid แถว · ใช้หาแถวตอนแก้ ลบ"),
    expenseId: z.string().optional().describe("doc id ของหัวข้อ `expense`"),
    expenseName: z.string().optional().describe("ชื่อหัวข้อ ณ ตอนบันทึก"),
    expenseCategory: z.array(z.string()).optional(),
    price: z.union([z.string(), z.number()]).optional().describe("ข้อความจาก twoDigitNumber หรือ `''` (B5)"),
    note: z.string().optional(),
    createdby: z.string().optional().describe("ชื่อคนบันทึก (profile.name) ไม่ใช่ uid"),
    timestamp: FirestoreTime.optional(),
    name: z.string().optional().describe("รูปสรุปของทางกดดู (B6)"),
    createdByUid: z.string().optional().describe("ใหม่"),
    updatedAt: FirestoreTime.optional().describe("ใหม่"),
    updatedBy: z.string().optional().describe("ใหม่ · ชื่อคนแก้ล่าสุด"),
    updatedByUid: z.string().optional().describe("ใหม่"),
  })
  .passthrough();

export const ExpenseReport = z
  .object({
    id: z.string().optional().describe("ซ้ำ doc id"),
    shopId: z.string().describe("field shop.shopId"),
    month: z.string().describe("`YYYYMM`"),
    name: z.string().optional().describe("ป้ายเดือน เช่น `พ.ย. 2569   `"),
    timestamp: FirestoreTime.optional(),
    expenses: z.array(ExpenseReportRow),
    totalExpense: z.union([z.number(), z.string()]).optional().describe("ค้าง 0 (B7)"),
    deleted: z
      .array(ExpenseReportRow.extend({ deletedAt: FirestoreTime.optional(), deletedBy: z.string().optional(), deletedByUid: z.string().optional() }).passthrough())
      .optional()
      .describe("ใหม่ · ร่องรอยแถวที่ลบ"),
  })
  .passthrough();

export type ExpenseReport = z.infer<typeof ExpenseReport>;
export type ExpenseReportRow = z.infer<typeof ExpenseReportRow>;

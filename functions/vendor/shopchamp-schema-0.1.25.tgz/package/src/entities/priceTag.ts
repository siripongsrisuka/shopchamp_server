import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `priceTag/{id}` — ชุดป้ายราคาที่เว็บ `/tag/<id>` เปิดทำ PDF (ก้อน 9b · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/priceTag.md` §1 (ทางเขียนเดียว `main3:src/screens/PriceCardScreen.js:193`)
 *   doc id = token ของลิงก์ · ไม่มีใครอ่าน `timestamp` `shopId` `uploadBy` · เว็บอ่าน `products` อย่างเดียว
 *   วันที่ในโปรของแถวในฐานมี 2 รูป: Timestamp หรือ map `{seconds,nanoseconds}` (ผ่าน JSON ของ MMKV) ⇒ อ่านรับทั้งคู่
 *
 * `PriceTag` = รูปที่อ่านจากฐาน · passthrough · `PriceTagWrite` = รูปที่ server ใหม่เขียน · strict
 */

const TimeLike = z.union([FirestoreTime, z.object({ seconds: z.number(), nanoseconds: z.number() }).passthrough(), z.string()]);

export const PriceTagRow = z
  .object({
    name: z.string().optional(),
    imageId: z.string().optional(),
    barcode: z.union([z.string(), z.number()]).optional().describe("ตัวเลขทำเว็บพัง (PT-07) · ของเก่าอาจมี"),
    unit: z.string().optional(),
    price: z.union([z.number(), z.string()]).optional(),
    promotion: z
      .object({
        status: z.boolean().optional(),
        qty: z.union([z.number(), z.string()]).optional(),
        price: z.union([z.number(), z.string()]).optional(),
        startDate: TimeLike.optional(),
        endDate: TimeLike.optional(),
      })
      .passthrough()
      .nullable()
      .optional(),
  })
  .passthrough();

export const PriceTag = z
  .object({
    timestamp: FirestoreTime.optional(),
    shopId: z.string().optional(),
    uploadBy: z.string().optional(),
    products: z.array(PriceTagRow),
  })
  .passthrough();
export type PriceTag = z.infer<typeof PriceTag>;

export const PriceTagRowWrite = z
  .object({
    name: z.string(),
    imageId: z.string(),
    barcode: z.string(),
    unit: z.string(),
    price: z.number(),
    promotion: z
      .object({
        status: z.boolean(),
        qty: z.union([z.number(), z.literal("")]),
        price: z.union([z.number(), z.literal("")]),
        startDate: FirestoreTime,
        endDate: FirestoreTime,
      })
      .strict(),
  })
  .strict();

export const PriceTagWrite = z
  .object({
    timestamp: FirestoreTime,
    shopId: z.string().min(1),
    uploadBy: z.string(),
    products: z.array(PriceTagRowWrite).min(1),
    byAdmin: z.literal(true).optional(),
    adminUid: z.string().optional(),
  })
  .strict();
export type PriceTagWrite = z.infer<typeof PriceTagWrite>;

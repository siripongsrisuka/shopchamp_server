import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";
import { StockJournalKind } from "./stockJournal";

/**
 * `stockMove/{shopDocId}_{stockId}_{kind}_{เวลา ms}` — รายการเคลื่อนไหวสต๊อกทีละครั้ง ต่อสินค้า 1 ตัว (DEV-0008 · premium)
 * - server เท่านั้นที่เขียน (rules ปิด) · เขียนใน transaction เดียวกับการเปลี่ยน stock และสมุดรายวัน (`_shared/stockJournal.js`)
 * - เขียนเฉพาะร้านที่ premium ยังไม่หมด ณ เวลา server (`_shared/premium.js`) · ร้านไม่ premium ไม่มี doc นี้เลย
 * - 1 doc = สินค้า 1 ตัว ใน transaction 1 ครั้ง (บิลเดียวขายตัวเดิม 2 บรรทัด = รวมเป็น 1)
 * - before/after = ช่อง stock ก่อนและหลังเขียน (หน่วยของ doc นั้น) · ชนิด delete ไม่มีการเขียนช่อง stock ⇒ after 0
 * - expireAt = เวลา server + 90 วัน · Firestore TTL ลบเอง (ตั้ง policy ที่ field นี้)
 */
export const STOCK_MOVE_KEEP_DAYS = 90;

export const StockMove = z
  .object({
    shopId: z.string().min(1).describe("shop doc id"),
    stockId: z.string().min(1).describe("stock doc id"),
    kind: StockJournalKind,
    day: z.string().regex(/^\d{8}$/).describe("วันธุรกิจ YYYYMMDD (เท่ากับ day ของสมุดรายวัน)"),
    delta: z.number().finite().describe("after − before"),
    before: z.number().finite(),
    after: z.number().finite(),
    time: FirestoreTime.describe("เวลา commit (serverTimestamp)"),
    byUid: z.string().describe("uid ผู้ทำ (จากด่าน auth) · ว่างได้"),
    byName: z.string().max(200).describe("ชื่อผู้ทำ: staffName ที่แอปส่ง ไม่มีใช้ชื่อใน shop.humanResource"),
    refId: z.string().max(128).describe("doc อ้างอิง: บิล · ใบรับเข้า · ใบเบิก · กลุ่มผูก · ว่างได้ (ปรับยอด)"),
    refNo: z.string().max(64).describe("เลขที่แสดง เช่นเลขใบเสร็จ · ว่างได้"),
    note: z.string().max(500).describe("เหตุผล/หมายเหตุ · ว่างได้"),
    expireAt: FirestoreTime.describe("TTL ลบเองหลัง 90 วัน"),
    byAdmin: z.literal(true).optional().describe("ทีมงาน Shopchamp ทำ"),
  })
  .strict();
export type StockMove = z.infer<typeof StockMove>;

/** doc id `{shopDocId}_{stockId}_{kind}_{ms}` */
export const StockMoveDocId = z
  .string()
  .max(1500)
  .regex(/^[^/]+_[^/]+_(sale|void|receive|receiveEdit|adjust|requisition|create|delete|link)_\d{10,}$/);

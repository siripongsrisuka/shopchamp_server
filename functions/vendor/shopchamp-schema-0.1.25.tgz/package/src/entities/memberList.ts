import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `memberList/{letter + shop.shopId}` — ดัชนีค้นหาสมาชิกของจอขาย (ก้อน 9b · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/memberList.md` §1 · `schema/member.md` §1.4
 *   doc id = ตัวอักษร (`A`-`Z` จากแอป · `A`+`A`-`Z` จากเว็บอัปไฟล์) + `shop.shopId` (field ของร้าน ไม่ใช่ doc id เสมอไป · ร้าน S5)
 *   แอปเดิมเขียน 5 ทาง (W1-W5) · server ใหม่เขียนใน `member.create` `member.update` `member.delete` `member.rebuildIndex`
 *   จอขายดึงด้วย `shopId ==` + `updateTime >` แล้วเก็บทั้งก้อนลง MMKV (`main3:src/hook/useLocalMember.js:113-118`)
 *     ⇒ ทุกครั้งที่เขียนต้องตั้ง `updateTime` ใหม่ ไม่งั้นเครื่องอื่นไม่เห็น (F28)
 *
 * `MemberList` = รูปที่อ่านจากฐาน · passthrough · แถวรูปเก่าอาจไม่มี name/tel (F25 ทางย้ายของเดิมใส่ undefined แล้วล้ม)
 * `MemberListWrite` = รูปที่ server เขียน · strict
 */

export const MemberListRow = z
  .object({
    id: z.string().describe("doc id ของ `member`"),
    name: z.union([z.string(), z.number(), z.boolean()]).optional().describe("ชื่อตอนสร้าง · ของเดิมไม่ตามเมื่อแก้ (F28)"),
    tel: z.union([z.string(), z.number()]).optional().describe("เบอร์ตอนสร้าง · อัปไฟล์ได้ตัวเลข"),
  })
  .passthrough();

export const MemberList = z
  .object({
    shopId: z.string().describe("ร้าน = `shop.shopId` · query ของจอขายใช้ค่านี้"),
    members: z.array(MemberListRow).describe("แถวสมาชิกของตัวอักษรนี้"),
    updateTime: FirestoreTime.optional().describe("เวลาเขียนล่าสุด · จอขายดึงเฉพาะที่ใหม่กว่าที่เคยดึง"),
  })
  .passthrough();
export type MemberList = z.infer<typeof MemberList>;

export const MemberListRowWrite = z
  .object({
    id: z.string().min(1),
    name: z.string(),
    tel: z.string(),
  })
  .strict();

export const MemberListWrite = z
  .object({
    shopId: z.string().min(1),
    members: z.array(MemberListRowWrite),
    updateTime: FirestoreTime,
  })
  .strict();
export type MemberListWrite = z.infer<typeof MemberListWrite>;

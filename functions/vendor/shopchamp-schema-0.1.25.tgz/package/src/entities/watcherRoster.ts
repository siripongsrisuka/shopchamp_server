import { z } from "zod";

/**
 * `watcher/roster` — ทะเบียนทีมงาน Shopchamp (DEV-0001 watcher · Pack เคาะ 2026-11-07 ข้อ 1-9) · server เท่านั้น (rules ปัด client ทุกคน)
 * ผู้เขียน 2 ทาง (ส่งทั้งชุด แทนที่ทั้ง doc เสมอ):
 *   - `shopchamp-center/gate/watcher-publish.js --write` (Pack รัน · via `center-script`)
 *   - shopchampoffice › Watcher Console → `POST /pos/office/roster-save` (root + passkey · via `office`) (DEV-0003)
 * ตัวตัดสินฝั่ง server (`pos/_shared/watcherRoster.js`) อ่าน `uids` กับ `rootUids` อย่างเดียว · `people` ไว้ให้คนอ่านและ audit
 *
 * ด่านเดียวกับ `watcher-publish.js` › parseRosterFile (ห้ามแยกกันเดิน · เทส `pos/office/rosterCore.test.js` เทียบ 2 ตัวนี้):
 *   uid = [A-Za-z0-9] 20-128 ตัว · ไม่ซ้ำ · level = watcher | root · root ไม่เกิน 10 · root ⊆ watcher (root อยู่ใน uids ด้วย)
 */
export const WATCHER_ROOT_MAX = 10;
export const WATCHER_ROSTER_MAX = 500;

export const WatcherUid = z.string().regex(/^[A-Za-z0-9]{20,128}$/, { message: "uid ผิดรูป (ตัวอักษรอังกฤษ/ตัวเลข 20-128 ตัว)" });
export const WatcherLevel = z.enum(["watcher", "root"]);

/** 1 คนในทะเบียน (ช่อง `people[]`) · อีเมลมาจาก Firebase Auth ตอนเขียน · ว่างได้ (บัญชีเบอร์โทร) */
export const WatcherRosterPerson = z
  .object({
    uid: WatcherUid,
    email: z.string().max(254),
    name: z.string().max(120),
    level: WatcherLevel,
  })
  .strict();

/** doc ทั้งก้อนที่จะเขียน (ยังไม่รวม publishedAt ที่ใส่ตอนเขียน) · เขียนผิดรูป = ไม่เขียน */
export const WatcherRosterDoc = z
  .object({
    uids: z.array(WatcherUid).max(WATCHER_ROSTER_MAX),
    rootUids: z.array(WatcherUid).max(WATCHER_ROOT_MAX),
    people: z.array(WatcherRosterPerson).max(WATCHER_ROSTER_MAX),
    count: z.number().int().nonnegative(),
    rootCount: z.number().int().min(0).max(WATCHER_ROOT_MAX),
    rosterSha: z.string().regex(/^[0-9a-f]{64}$/),
    publishedBy: z.string().min(1).max(254),
    publishedByUid: z.string().min(1).max(128).optional().describe("ใหม่ (DEV-0003) · uid ของ root ที่กดบันทึกจาก office · center-script ไม่มี"),
    via: z.enum(["center-script", "office"]),
    gitHead: z.string().max(64).optional(),
    publishedAt: z.unknown().optional(),
  })
  .strict()
  .superRefine((d, ctx) => {
    const uids = new Set(d.uids);
    if (uids.size !== d.uids.length) ctx.addIssue({ code: "custom", path: ["uids"], message: "uid ซ้ำ" });
    if (d.count !== d.uids.length) ctx.addIssue({ code: "custom", path: ["count"], message: "count ไม่ตรงจำนวน uids" });
    if (d.rootCount !== d.rootUids.length) ctx.addIssue({ code: "custom", path: ["rootCount"], message: "rootCount ไม่ตรงจำนวน rootUids" });
    if (new Set(d.rootUids).size !== d.rootUids.length) ctx.addIssue({ code: "custom", path: ["rootUids"], message: "root ซ้ำ" });
    for (const r of d.rootUids) if (!uids.has(r)) ctx.addIssue({ code: "custom", path: ["rootUids"], message: `root ${r} ไม่อยู่ใน uids (root ⊆ watcher)` });
    if (d.people.length !== d.uids.length || d.people.some((p, i) => p.uid !== d.uids[i])) ctx.addIssue({ code: "custom", path: ["people"], message: "people ต้องเรียงตรงกับ uids" });
    const roots = new Set(d.rootUids);
    for (const p of d.people) if ((p.level === "root") !== roots.has(p.uid)) ctx.addIssue({ code: "custom", path: ["people"], message: `ระดับของ ${p.uid} ไม่ตรง rootUids` });
  });

/**
 * `officePasskeys/{credentialId}` — กุญแจยืนยันตัว (WebAuthn) ของคนใช้ shopchampoffice (DEV-0003) · server เท่านั้น
 * publicKey = base64url ของ COSE key · counter = ตัวนับของ authenticator (กันกุญแจถูกโคลน)
 */
export const OfficePasskey = z
  .object({
    uid: z.string().min(1),
    publicKey: z.string().min(1),
    counter: z.number().int().nonnegative(),
    transports: z.array(z.string()).optional(),
    deviceType: z.string().optional(),
    backedUp: z.boolean().optional(),
    label: z.string().max(60),
    rpID: z.string().min(1),
    createdAt: z.unknown(),
    lastUsedAt: z.unknown().optional(),
  })
  .passthrough();

/** `officePasskeyChallenges/{uid}` — challenge ค้าง 1 ใบต่อคน · ใช้ครั้งเดียว (อ่านแล้วลบใน transaction เดียว) · หมดอายุ 5 นาที */
export const OfficePasskeyChallenge = z
  .object({
    challenge: z.string().min(1),
    type: z.enum(["register", "auth"]),
    origin: z.string().min(1),
    createdAt: z.unknown(),
  })
  .passthrough();

/** `officeAudit/{auto}` — รอยการกระทำใน shopchampoffice ทุกครั้งที่เปลี่ยนของ หรือถูกปัดหลังยืนยันตัวแล้ว (DEV-0003) */
export const OfficeAuditEntry = z
  .object({
    action: z.string().min(1).describe("watcher.roster.save | passkey.register"),
    result: z.enum(["ok", "rejected"]),
    actorUid: z.string().min(1),
    actorEmail: z.string().nullable(),
    passkeyCredentialId: z.string().nullable(),
    at: z.unknown(),
    rejectCode: z.string().optional(),
  })
  .passthrough();

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `requisition/{id}` — ใบเบิกสินค้าใช้ในร้าน (ก้อน 9a · DEV-0001) · ที่มา `lanes/dev/source/schema/requisition.md` §1.1-§1.2
 * อ่านจากฐาน = passthrough · `currentCarts[].qty` แอปเก่าเขียนเป็นสตริง (`''` `'1.'` ได้) · `cost` `''`/null ได้
 * ทางเขียนใหม่ = `stock.requisition` (qty เป็นเลข + `requisitionUUID` `moves` อย่างเดียว)
 */
export const RequisitionCart = z
  .object({
    name: z.unknown().optional(),
    id: z.string(),
    qty: z.union([z.number(), z.string()]),
    cost: z.union([z.number(), z.string(), z.null()]).optional(),
    totalCost: z.union([z.number(), z.nan(), z.null()]).optional(),
    unit: z.unknown().optional(),
  })
  .passthrough();

export const Requisition = z
  .object({
    shopId: z.string(),
    timestamp: FirestoreTime,
    profileName: z.string().optional(),
    profileId: z.string().optional(),
    currentCarts: z.array(RequisitionCart).optional(),
    billDate: z.string(),
    reason: z.string().optional(),
    requisitionUUID: z.string().optional(),
    moves: z.array(z.object({ id: z.string(), qty: z.number() }).passthrough()).optional().describe("ใหม่ · ตัวที่ถูกตัดจริง (ST-010)"),
  })
  .passthrough();
export type Requisition = z.infer<typeof Requisition>;

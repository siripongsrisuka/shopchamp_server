import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `promotion/{id}` — โปรโมชันระดับบิลของร้าน 1 doc ต่อ 1 โปร
 * ที่มา: `lanes/dev/source/schema/promotion.md` §1 (ระดับบน 28 field · `workingDays[]` 6 field · แถวรายการ 2 รูป)
 * คนละของกับ `stock.promotion` (ราคาชุดสินค้า) และ `bill.campaign[]` (ผลคำนวณที่ลงบิล)
 *
 * มี 2 schema:
 * - `Promotion` = รูปที่ **อ่านจากฐาน** · `.passthrough()` ทุกชั้น เพราะแอปเก่ายังเขียนตรงอยู่
 *   และฐานมีเอกสาร 2 รุ่น (ไล่จาก git ของ repo แอป · ไม่ได้อยู่ใน §1):
 *   · รุ่น 1 (`PromotionSettingScreen.js` ที่ `1b20384a` และก่อนหน้า · 2024-05 ถึง 2025-02):
 *     `id barcode type slot reward startDate endDate status detail name target shopId box`
 *     `barcode` เป็น array ของ **สตริง id** ไม่ใช่ map · ไม่มี `workingDays` `auto` `timestamp` `tier*`
 *   · รุ่น 2 (`f2ce0aa8` 2025-03 ถึง `804ba8ff`): 28 field ตาม §1
 *   ⇒ บังคับเฉพาะ field ที่มีทั้ง 2 รุ่น · ที่เหลือ optional · field เฉพาะรุ่น 1 (`slot` `reward` `target` `box`)
 *     ไม่ประกาศ แต่ passthrough เก็บไว้ · ตัวอ่านใหม่ต้องเติมค่าตั้งต้นเอง (DI-48 · F41)
 * - `PromotionWrite` = รูปที่ **โค้ดใหม่ต้องเขียน** ตามที่ Pack เคาะ "แก้" (F09 · F34 · F35 · F36 · F41 · DI-53 · F28 ทางเขียน)
 *   ⇒ ปิดบั๊กได้จริงเมื่อจุดเขียนของแอปใหม่ parse ด้วยตัวนี้ก่อนเขียน (ยังไม่ได้ต่อ)
 *   ตัวเลขยังเก็บเป็นสตริง ตาม `architecture-plan.md` หัวข้อ 3 (ห้ามเปลี่ยนชนิด field เดิม) · §1 แถว 9 10 18 เป็นสตริง
 *   ❓ ยังไม่ได้ตรวจว่าแอปเก่าล้มไหมถ้าเจอ number: ค่าจาก doc ไปที่ `value` ของ `OutlinedTextField`
 *   (`app:component/InputNumber.js:23`) · `twoDigitNumber` รับแค่ข้อความที่ผู้ใช้พิมพ์ (`app:screens/PromotionSettingScreen.js:635`)
 *   วันที่เทียบเป็นวันไทย (UTC+7) ตายตัว ไม่ใช้โซนของเครื่อง เพราะ server รันเป็น UTC (ผลตรวจ ผ1)
 *
 * - doc id ไม่อยู่ใน schema · `id` เป็นสำเนา ตัวอ่านเดิมทับด้วย `doc.id` (§1 แถว 1)
 * - ไม่มี field ใหม่ของก้อน 4 (`receiptUUID` `soldAt` `offline`) เพราะเป็นของบิล · โปรลงบิลเป็นสำเนาใน
 *   `bill.campaign[]` (§3) ⇒ ไม่มีคำขอ API ของ entity นี้ในก้อน 4 · API แก้โปรอยู่ก้อน 9b
 */

// ── อ่าน ───────────────────────────────────────────────────────────

/** ค่าเงื่อนไขและรางวัล: โค้ดเดิมเขียนสตริงจาก `twoDigitNumber` (§1 แถว 9 10 18) · รับ number ด้วยเผื่อทางที่ยังไม่เห็น */
const NumTextRead = z.union([z.string(), z.number()]);

/**
 * §1.1 แถวรายการ 1 แถว ตามที่อ่านจากฐาน · 2 รูปปนกันได้ใน field เดียว (P7 · F35)
 * แถวสินค้า `{barcode,name}` (`app:Modal/Modal_ProductPromotion.js:67`) · แถวหมวด `{id,name}` (`app:Modal/Modal_Selected.js:55`)
 * ทุก key optional เพราะสินค้าที่ไม่มีบาร์โค้ด (`stock.barcode` optional) ทำให้แถวไม่มี `barcode`
 */
export const PromotionRow = z
  .object({
    barcode: z.string().optional().describe("§1.1 แถวสินค้า · บาร์โค้ด ณ ตอนเลือก · แก้บาร์โค้ดแล้วโปรหลุด (P11 · F39)"),
    id: z.string().optional().describe("§1.1 แถวหมวด · id หมวดระดับ 1"),
    name: z.string().optional().describe("§1.1 · สำเนาชื่อ ณ ตอนเลือก ไม่ตามชื่อที่แก้ทีหลัง"),
  })
  .passthrough();

/** §1.1 `workingDays[]` 1 วัน ตามที่อ่านจากฐาน · ทุกตัวมาจากค่าคงที่ `days` (`app:config/initialPromotion.js:2`) */
export const PromotionWorkingDay = z
  .object({
    id: z.number().describe("§1.1 · 0-6 ตรงกับ `getDay()` · 0 = อาทิตย์"),
    name: z.string().describe("§1.1 · ชื่อวันของ UI ถูกเก็บลงเอกสาร"),
    color: z.string().describe("§1.1 · สีของ UI ถูกเก็บลงเอกสาร"),
    status: z.boolean().describe("§1.1 · เปิดวันนี้ไหม"),
    allDay: z.boolean().describe("§1.1 · `true` ตลอด ไม่มีจอแก้ (D2)"),
    period: z.array(z.number()).describe("§1.1 · ชั่วโมงที่ทำงาน · `[]` ตลอด (D2)"),
  })
  .passthrough();

/** §1 doc `promotion` ตามที่อ่านจากฐาน */
export const Promotion = z
  .object({
    id: z.string().describe("§1 แถว 1 · สำเนา doc id · ตัวอ่านใช้ `doc.id`"),
    shopId: z.string().describe("§1 แถว 2 · ร้านเจ้าของ · field เดียวที่ query"),
    name: z.string().describe("§1 แถว 3 · ชื่อโปร ลงบิลและใบเสร็จ · ตรวจแค่ที่ UI"),
    detail: z.string().describe("§1 แถว 4 · แสดงในจอตั้งค่าเท่านั้น"),
    promotionId: z
      .string()
      .optional()
      .describe("§1 แถว 5 · เลขแบบโปร `'1'`-`'34'` หรือ `''` (P10) · ไม่ใช่ doc id · รุ่น 1 ไม่มี"),
    type: z
      .string()
      .describe("§1 แถว 6 · เงื่อนไขรับสิทธิ์ · รับทุกสตริง เพราะ `''` (P10) และ `sale` ของรุ่น 1 (P15 · F28) มีอยู่จริงได้"),
    rewardType: z.string().optional().describe("§1 แถว 7 · ชนิดรางวัล · `''` ได้ (P10) · รุ่น 1 เก็บใน `reward.type`"),
    tier: z.boolean().optional().describe("§1 แถว 8 · ขั้นบันได · UI เขียน `false` เสมอ · `true` ทำจอขายล้ม (P19 · F32)"),
    tierTarget: z
      .array(NumTextRead)
      .optional()
      .describe("§1 แถว 9 · ค่าเงื่อนไขช่อง `[0]` · `['']` ผ่าน UI เดิมได้ (P3 · F09)"),
    tierReward: z.array(NumTextRead).optional().describe("§1 แถว 10 · ค่ารางวัลช่อง `[0]` · ว่างหรือ 0 ได้ (F36)"),
    tierBox: z.array(z.unknown()).optional().describe("§1 แถว 11 · ว่างเสมอ ไม่มีผู้อ่าน (D2)"),
    barcode: z
      .array(z.union([z.string(), PromotionRow]))
      .describe("§1 แถว 12 · สินค้าหรือหมวดเงื่อนไข · รุ่น 1 เป็นสตริง id · รุ่น 2 เป็นแถว 2 รูปปนได้ (P7 · F35)"),
    slot1: z.array(PromotionRow).optional().describe("§1 แถว 13 · กลุ่ม 1 ของ type `items`"),
    slot2: z.array(PromotionRow).optional().describe("§1 แถว 14 · กลุ่ม 2 ของ type `items`"),
    rewardBarcode: z.array(PromotionRow).optional().describe("§1 แถว 15 · สินค้าแถมหรือแลกซื้อ"),
    scope: z.array(PromotionRow).optional().describe("§1 แถว 16 · ขอบเขตของ `percent` · ทับ field อื่นได้ (P7)"),
    scopeTarget: z.string().optional().describe("§1 แถว 17 · `onInvoice` `menu` `category`"),
    exchangePrice: NumTextRead.optional().describe("§1 แถว 18 · ราคาแลกซื้อต่อชิ้น · `''` เมื่อไม่ใช้"),
    expireType: z.string().optional().describe("§1 แถว 19 · `infinity` `limit` · ไม่มี = ตัวอ่านเดิมเช็กช่วงวัน"),
    startDate: FirestoreTime.describe("§1 แถว 20 · Timestamp · มีค่าเสมอแม้ `infinity`"),
    endDate: FirestoreTime.describe("§1 แถว 21 · Timestamp · เทียบระดับวัน รวมวันสุดท้าย"),
    status: z.boolean().describe("§1 แถว 22 · เปิดปิดโปร"),
    auto: z
      .boolean()
      .optional()
      .describe("§1 แถว 23 · `true` คิดเอง · `false` แคชเชียร์กด · รุ่น 1 ไม่มี ⇒ ตัวอ่านเดิมไม่ใช้ทั้ง 2 ทาง"),
    workingDays: z
      .array(PromotionWorkingDay)
      .optional()
      .describe("§1 แถว 24 · วันที่ทำงาน · รุ่น 1 ไม่มี ⇒ reducer เดิมโยน ทั้งร้านไม่มีโปร (P16 · F41)"),
    customer: z.string().optional().describe("§1 แถว 25 · `all` เสมอ ไม่มีผู้อ่าน (D2)"),
    channels: z.array(z.unknown()).optional().describe("§1 แถว 26 · ว่างเสมอ ไม่มีผู้อ่าน (D2)"),
    specialPromotion: z
      .string()
      .optional()
      .describe("§1 แถว 27 · `none` · ไม่ใช่ `none` หรือไม่มี = ซ่อนจากจอรายการแต่ขายยังใช้ (P8 · K17)"),
    timestamp: FirestoreTime.optional().describe("§1 แถว 28 · เวลาสร้าง ใช้เรียงจอรายการ · รุ่น 1 ไม่มี"),
  })
  .passthrough();

// ── เขียน (รูปที่โค้ดใหม่ต้องเขียน) ───────────────────────────────

/**
 * 34 แบบโปรที่ UI เลือกได้ (`app:screens/PromotionSettingScreen.js:29` ถึง `:68`) · ทุกแบบ `tier:false` (D1)
 * ใช้บังคับว่า `promotionId` `type` `rewardType` ต้องเป็นชุดเดียวกันในตารางนี้ (P10 · DI-53)
 */
const CONDITION_TYPES = ["anySale", "minimumSale", "item", "itemSale", "category", "categorySale", "items"] as const;
const FULL_REWARDS = ["discount", "percent", "gift", "exchange", "doubleFortune", "tripleFortune"] as const;
const ITEM_REWARDS = ["discount", "percent", "gift", "exchange"] as const;

export const PROMOTION_OPTIONS: ReadonlyArray<{ promotionId: string; type: string; rewardType: string }> = (() => {
  const out: { promotionId: string; type: string; rewardType: string }[] = [];
  let n = 1;
  for (const type of CONDITION_TYPES) {
    const rewards = type === "anySale" || type === "minimumSale" ? FULL_REWARDS : ITEM_REWARDS;
    for (const rewardType of rewards) out.push({ promotionId: String(n++), type, rewardType });
  }
  out.push({ promotionId: String(n++), type: "sameItem", rewardType: "gift" });
  out.push({ promotionId: String(n++), type: "sameItem", rewardType: "exchange" });
  return out;
})();

/** ตัวเลขบวกในรูปสตริงที่ `twoDigitNumber` สร้าง (ทศนิยมไม่เกิน 2) · ปัด `''` `'12.'` `'.5'` `'1e5'` (F31) */
const DECIMAL_TEXT = /^\d+(\.\d{1,2})?$/;
const PositiveText = z
  .string()
  .regex(DECIMAL_TEXT, { message: "ต้องเป็นตัวเลข ทศนิยมไม่เกิน 2 ตำแหน่ง" })
  .refine((s) => Number(s) > 0, { message: "ต้องมากกว่า 0 (F09 · F36)" });
const NonNegativeText = z.string().regex(DECIMAL_TEXT, { message: "ต้องเป็นตัวเลขไม่ติดลบ ทศนิยมไม่เกิน 2 ตำแหน่ง" });

/** แถวสินค้าที่โค้ดใหม่เขียน · `id` = doc id ใน `stock` ใส่ได้เพื่อผูกด้วย id แทนบาร์โค้ด (F39 · ยังไม่เคาะรูป) */
export const PromotionProductRowWrite = z
  .object({
    barcode: z.string().min(1, { message: "แถวสินค้าต้องมีบาร์โค้ด" }),
    name: z.string(),
    id: z.string().min(1).optional(),
  })
  .strict();

/** แถวหมวดที่โค้ดใหม่เขียน (หมวดระดับ 1) */
export const PromotionCategoryRowWrite = z
  .object({
    id: z.string().min(1, { message: "แถวหมวดต้องมี id" }),
    name: z.string(),
  })
  .strict();

/** 1 วันที่โค้ดใหม่เขียน · ค่าเดียวกับ `days` เดิม เพื่อให้แอปเก่าอ่านได้ */
export const PromotionWorkingDayWrite = z
  .object({
    id: z.number().int().min(0).max(6),
    name: z.string(),
    color: z.string(),
    status: z.boolean(),
    allDay: z.boolean(),
    period: z.array(z.number().int().min(0).max(23)),
  })
  .strict();

const Row = z.union([PromotionProductRowWrite, PromotionCategoryRowWrite]);

const isProductRow = (r: object) => "barcode" in r;
/** วันไทยของเวลา `d` เป็นเลข YYYYMMDD · Asia/Bangkok ไม่มีเวลาออมแสง ⇒ บวก 7 ชั่วโมงแล้วอ่านแบบ UTC ได้ตรงทุกวัน */
const TH_OFFSET_MS = 7 * 60 * 60 * 1000;
const ymd = (d: Date) => {
  const t = new Date(d.getTime() + TH_OFFSET_MS);
  return t.getUTCFullYear() * 10000 + (t.getUTCMonth() + 1) * 100 + t.getUTCDate();
};
const toDate = (v: Date | { toDate: () => Date }) => (v instanceof Date ? v : v.toDate());

/** doc ที่โค้ดใหม่เขียน (สร้างหรือแก้ทั้งก้อน) */
export const PromotionWrite = z
  .object({
    id: z.string().min(1, { message: "ต้องมี id (สำเนา doc id)" }),
    shopId: z.string().min(1, { message: "ต้องระบุร้าน" }),
    name: z.string().trim().min(1, { message: "ชื่อโปรห้ามว่าง" }),
    detail: z.string(),
    promotionId: z.string(),
    type: z.string(),
    rewardType: z.string(),
    tier: z.literal(false, { message: "ทุกแบบโปรเป็นขั้นเดียว (D1 · F32)" }),
    tierTarget: z.array(PositiveText),
    tierReward: z.array(PositiveText),
    tierBox: z.array(z.unknown()).max(0),
    barcode: z.array(Row),
    slot1: z.array(Row),
    slot2: z.array(Row),
    rewardBarcode: z.array(Row),
    scope: z.array(Row),
    scopeTarget: z.enum(["onInvoice", "menu", "category"]),
    exchangePrice: z.union([z.literal(""), NonNegativeText]),
    expireType: z.enum(["infinity", "limit"]),
    startDate: FirestoreTime,
    endDate: FirestoreTime,
    status: z.boolean(),
    auto: z.boolean(),
    workingDays: z.array(PromotionWorkingDayWrite).length(7, { message: "ต้องมีครบ 7 วัน (F41 · P16)" }),
    customer: z.literal("all"),
    channels: z.array(z.unknown()).max(0),
    specialPromotion: z.literal("none", { message: "ค่าอื่นทำให้โปรหายจากจอรายการแต่ขายยังใช้ (P8 · K17)" }),
    timestamp: FirestoreTime,
    // ก้อน 9b (เพิ่มอย่างเดียว · แอปเก่าไม่อ่าน · `update(current)` ของแอปเก่าส่งค่าเดิมกลับ ⇒ ไม่ขยับเมื่อแอปเก่าแก้):
    updatedAt: FirestoreTime.optional().describe("เวลาที่ server ใหม่เขียนล่าสุด · ใช้กันเครื่องค่าเก่าทับผ่าน baseUpdatedAt"),
    updatedBy: z.string().optional().describe("uid ผู้แก้ล่าสุดผ่าน API ใหม่"),
    byAdmin: z.boolean().optional().describe("true = ทีมงาน Shopchamp เขียนล่าสุด (Pack เคาะ 3-2) · false = คนในร้านแก้ต่อหลังทีมงาน"),
    adminUid: z.string().nullable().optional().describe("uid ทีมงานที่เขียนล่าสุด · null = ล้างเมื่อคนในร้านแก้ต่อ"),
  })
  .strict()
  .superRefine((doc, ctx) => {
    const issue = (path: string, message: string) => ctx.addIssue({ code: "custom", path: [path], message });

    // P10 · DI-53: แบบโปรต้องเป็นชุดใน 34 แบบ
    const opt = PROMOTION_OPTIONS.find((o) => o.promotionId === doc.promotionId);
    if (!opt || opt.type !== doc.type || opt.rewardType !== doc.rewardType) {
      issue("promotionId", "promotionId type rewardType ต้องตรงกับแบบโปรใน 34 แบบ (P10 · DI-53)");
      return;
    }
    const { type, rewardType } = doc;
    const fortune = rewardType === "doubleFortune" || rewardType === "tripleFortune";
    const giftLike = rewardType === "gift" || rewardType === "exchange";

    // F09: เงื่อนไขต้องมี 1 ค่าที่ > 0 · แบบที่ไม่ใช้เงื่อนไขต้องว่าง (F35 กันค่าค้างจากแบบเดิม)
    const needTarget = type !== "anySale" && type !== "items";
    if (needTarget && doc.tierTarget.length !== 1) issue("tierTarget", "แบบนี้ต้องมีค่าเงื่อนไข 1 ค่า (F09 · P3)");
    if (!needTarget && doc.tierTarget.length !== 0) issue("tierTarget", "แบบนี้ไม่ใช้ค่าเงื่อนไข ต้องว่าง (F35)");

    // F36: รางวัลต้องมี 1 ค่าที่ > 0 ยกเว้นเลขนำโชค
    if (!fortune && doc.tierReward.length !== 1) issue("tierReward", "ต้องมีค่ารางวัล 1 ค่า (F36)");
    if (fortune && doc.tierReward.length !== 0) issue("tierReward", "เลขนำโชคไม่ใช้ค่ารางวัล ต้องว่าง (F35)");
    // K04 · P9: เปอร์เซ็นต์เกิน 100 ไม่มีความหมายใดที่ถูก · logic ตัดยอดที่ 0 ก็จริง แต่โปรเกิน 100% = บิลฟรีทุกบิล
    if (rewardType === "percent" && doc.tierReward.some((s) => Number(s) > 100))
      issue("tierReward", "ส่วนลดเปอร์เซ็นต์ต้องไม่เกิน 100 (K04 · P9)");

    // F34 · F35 · DI-53: รูปแถวต้องตรงกับแบบ · field ที่แบบนี้ไม่ใช้ต้องว่าง
    const productCond = type === "item" || type === "itemSale" || type === "sameItem";
    const categoryCond = type === "category" || type === "categorySale";
    if (productCond || categoryCond) {
      if (doc.barcode.length === 0) issue("barcode", "ต้องเลือกสินค้าหรือหมวดของเงื่อนไข (P11)");
      if (!doc.barcode.every((r) => isProductRow(r) === productCond))
        issue("barcode", "รูปแถวไม่ตรงกับแบบโปร: สินค้าใช้ {barcode,name} · หมวดใช้ {id,name} (F34 · F35)");
    } else if (doc.barcode.length !== 0) issue("barcode", "แบบนี้ไม่ใช้ barcode ต้องว่าง (F35)");

    for (const k of ["slot1", "slot2"] as const) {
      if (type === "items") {
        if (doc[k].length === 0) issue(k, "แบบ 2 กลุ่มต้องมีสินค้าทั้ง 2 กลุ่ม");
        if (!doc[k].every(isProductRow)) issue(k, "กลุ่มสินค้าต้องเป็นแถวสินค้า (P7 · F34)");
      } else if (doc[k].length !== 0) issue(k, "แบบนี้ไม่ใช้กลุ่มสินค้า ต้องว่าง (F35)");
    }

    const needRewardItems = giftLike && type !== "sameItem";
    if (needRewardItems) {
      if (doc.rewardBarcode.length === 0) issue("rewardBarcode", "ต้องเลือกสินค้าแถมหรือแลกซื้อ");
      if (!doc.rewardBarcode.every(isProductRow)) issue("rewardBarcode", "ของรางวัลต้องเป็นแถวสินค้า (F34)");
    } else if (doc.rewardBarcode.length !== 0) issue("rewardBarcode", "แบบนี้ไม่ใช้สินค้ารางวัล ต้องว่าง (F35)");

    if (rewardType === "percent" && doc.scopeTarget !== "onInvoice") {
      if (doc.scope.length === 0) issue("scope", "ต้องเลือกขอบเขตส่วนลด");
      if (!doc.scope.every((r) => isProductRow(r) === (doc.scopeTarget === "menu")))
        issue("scope", "รูปแถวขอบเขตไม่ตรงกับ scopeTarget (P7 · F34)");
    } else if (doc.scope.length !== 0) issue("scope", "ไม่ใช้ขอบเขต ต้องว่าง (F35)");

    if (rewardType === "exchange" && doc.exchangePrice === "") issue("exchangePrice", "ต้องใส่ราคาแลกซื้อ");
    if (rewardType !== "exchange" && doc.exchangePrice !== "") issue("exchangePrice", "แบบนี้ไม่ใช้ราคาแลกซื้อ ต้องว่าง (F35)");

    // F41 · K06: ครบ 7 วันไม่ซ้ำ · โปรที่เปิดต้องมีวันทำงานอย่างน้อย 1 วัน · ช่วงวันที่ไม่กลับหัว (เทียบวันไทย)
    const ids = doc.workingDays.map((d) => d.id);
    if (new Set(ids).size !== ids.length) issue("workingDays", "วันซ้ำกัน ต้องเป็น 0-6 วันละ 1 แถว (F41)");
    // วันที่ขายลดได้จริง = เปิด และ (ทั้งวัน หรือมีชั่วโมงใน period) · แอปเก่าลดเมื่อ `allDay || period.includes(hour)` (promotionSlice.js:76-92)
    if (doc.status && !doc.workingDays.some((d) => d.status && (d.allDay || d.period.length > 0)))
      issue("workingDays", "โปรที่เปิดต้องมีวันทำงานที่มีชั่วโมงขายอย่างน้อย 1 วัน ไม่งั้นขึ้นว่าเปิดแต่ขายไม่ลด (K06)");
    if (doc.expireType === "limit" && ymd(toDate(doc.startDate)) > ymd(toDate(doc.endDate)))
      issue("endDate", "วันสิ้นสุดก่อนวันเริ่ม โปรไม่มีวันทำงาน (K06)");
  });

export type Promotion = z.infer<typeof Promotion>;
export type PromotionRow = z.infer<typeof PromotionRow>;
export type PromotionWorkingDay = z.infer<typeof PromotionWorkingDay>;
export type PromotionWrite = z.infer<typeof PromotionWrite>;

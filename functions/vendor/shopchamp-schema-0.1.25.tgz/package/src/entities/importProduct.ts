import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `importProduct/{id}` — ใบรับสินค้า (ก้อน 9a · DEV-0001) · ที่มา `lanes/dev/source/schema/importProduct.md` §1.1-§1.4
 * อ่านจากฐาน = passthrough · แอปเก่าและเว็บเจ้าของร้าน (`Modal_Inbound.js`) ยังเขียนตรง
 * - `product[].qty` `cost` เป็น number หรือสตริงหลังแก้ใบ (C3) · `exp` เป็น `''` Timestamp ISO หรือ map (C1)
 * - รุ่น 2023 ไม่มี `date` (§2) · ก่อน 2025-03-23 ไม่มี `createName` · `createBy` รุ่นแรกเป็นชื่อ
 * ทางเขียนใหม่ = `stock.receive` · `stock.receiveEdit` (เพิ่ม `receiveUUID` `vatIncluded` `lastEdit` อย่างเดียว)
 */
const NumOrString = z.union([z.number(), z.string()]);
const ExpValue = z.union([z.literal(""), FirestoreTime, z.string(), z.object({ seconds: z.number() }).passthrough()]);

export const ImportProductLine = z
  .object({
    id: z.string().describe("doc id ของ `stock`"),
    name: z.string().optional(),
    qty: NumOrString.describe("หน่วยของสินค้าตัวนี้ · สตริงหลังแก้ใบด้วยแอปเก่า (C3)"),
    cost: NumOrString.describe("ต้นทุนต่อหน่วย · สตริงหลังแก้ใบ (C3)"),
    exp: ExpValue.optional(),
    lot: z.string().optional(),
  })
  .passthrough();

export const ImportProduct = z
  .object({
    shopId: z.string(),
    dateTime: FirestoreTime.optional(),
    supplier: z.object({ vender_Name: z.string().optional(), id: z.string().optional() }).passthrough().optional(),
    billNumber: z.string().optional(),
    product: z.array(ImportProductLine),
    createBy: z.string().optional(),
    createName: z.string().optional(),
    totalQty: z.union([z.number(), z.nan()]).optional(),
    totalCost: z.union([z.number(), z.nan()]).optional(),
    date: z.string().optional().describe("YYYYMMDD · รุ่น 2023 ไม่มี (B14)"),
    receiveUUID: z.string().optional().describe("ใหม่ ก้อน 9a · = doc id เมื่อสร้างผ่าน API"),
    vatIncluded: z.boolean().optional(),
    lastEdit: z.record(z.string(), z.unknown()).optional(),
  })
  .passthrough();
export type ImportProduct = z.infer<typeof ImportProduct>;

import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * `checkInHistory/{auto id หรือ requestId ของการออกงาน}` — ประวัติเข้าออกงานที่จบแล้ว (ก้อน 9c · DEV-0001)
 * ที่มา: `lanes/dev/source/schema/checkInHistory.md` · ทางเขียน W1 `app:screens/CheckInScreen.js:95` (ยกเนื้อ checkIn มาทั้ง doc)
 *
 * - `id` = doc id ของใบ checkIn เดิม (`shop doc id + profileId`) · เป็นตัวที่แอปค้นประวัติของตัวเอง (`where('id','==',…)`)
 * - `shopId` `billDate` = ตัวค้นของรายงานเว็บ (`own:redux/checkInSlice.js:32-34`) · `shopId` เป็น doc id ร้านตามที่แอปเขียน
 * - ช่องใหม่ (เพิ่มอย่างเดียว): `clockInRequestId` `clockOutRequestId` · `autoClosed` ('staff_removed' = ระบบปิดให้ตอนถอดพนักงาน · 'staff_inactive' = ตอนปิดใช้งานพนักงาน) · `closedBy`
 */
export const CheckInHistory = z
  .object({
    id: z.string().describe("doc id ของใบ checkIn เดิม · ตัวค้นของแอป"),
    shopId: z.string().describe("doc id ร้าน"),
    profileId: z.string(),
    clockIn: FirestoreTime,
    clockOut: FirestoreTime,
    clockInImage: z.string().optional(),
    clockOutImage: z.string().optional(),
    billDate: z.string().optional().describe("`YYYYMMDD` วันของการเข้างาน"),
    requestId: z.string().optional().describe("ใหม่ · id ของการกดเข้างาน (ติดมาจากใบ checkIn)"),
    clockOutRequestId: z.string().optional().describe("ใหม่ · id ของการกดออกงาน = doc id ของใบนี้เมื่อออกผ่าน API"),
    staffName: z.string().optional(),
    autoClosed: z.enum(["staff_removed", "staff_inactive"]).optional().describe("ใหม่ · ระบบปิดใบให้ ไม่ได้กดออกเอง"),
    closedBy: z.string().optional().describe("ใหม่ · uid ของคนที่ทำให้ใบปิด (ถอดพนักงาน)"),
    byAdmin: z.boolean().optional(),
    adminUid: z.string().optional(),
  })
  .passthrough();

export type CheckInHistory = z.infer<typeof CheckInHistory>;

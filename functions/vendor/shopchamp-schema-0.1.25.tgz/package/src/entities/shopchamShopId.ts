import { z } from "zod";

/**
 * `shopchamShopId/numOfStore` — ตัวนับเลขร้านรวมทั้งระบบ (ก้อน 9d DEV-0001) · ที่มา `lanes/dev/source/schema/shopchamShopId.md` §1
 * - `total` = เลขล่าสุดที่แจกไปแล้ว (ไม่ใช่จำนวนร้านปัจจุบัน) · สร้างร้าน = +1 แล้วเขียน `shop.scShopId` ใน transaction เดียวกัน
 * - วัดฐาน 2026-11-06: มี doc เดียว · `total` integer · ไม่มีทางสร้าง doc ใน repo (B3) ⇒ server ไม่สร้างเอง ไม่มี = ปัด 500 counter_missing
 */
export const ShopchamShopId = z
  .object({
    total: z.number().int().nonnegative().describe("§1 แถว 1 · ไม่ใช่จำนวนเต็ม = ตัวนับเสีย (B4) · server ปัด ไม่เดาเลข"),
  })
  .passthrough();
export type ShopchamShopId = z.infer<typeof ShopchamShopId>;

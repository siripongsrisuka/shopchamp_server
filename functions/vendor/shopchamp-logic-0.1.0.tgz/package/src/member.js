// member — แต้มสมาชิก · ใช้แต้ม · ยกเลิกบิลคืนแต้ม · เงินเซ็น (ใบ DEV-0001 · ก้อน 3)
//
// Pack เคาะ 2026-11-06: server เชื่อยอดจากแอป ⇒ สูตรฝั่งแอปต้องถูกเอง · ทุกฟังก์ชันเป็นฟังก์ชันล้วน ไม่แตะฐาน
// ไม่ throw · ค่าที่อ่านไม่ได้ผ่าน money.toNumber จุดเดียว · ไม่แก้ของที่ส่งเข้ามา
//
// ปิดบั๊ก (ฝั่งสูตร · ตาม lanes/dev/source/bug-decisions/member-point-credit.md · index.md ข้อ 7 · 16):
//   #16 K1  ยกเลิกบิลคืนแต้มที่ใช้แลก · แต้มต่ำสุด 0
//   #7  K2  จ่ายเงินเซ็นต้องมีสมาชิก (ปัดด้วยรหัส CREDIT_NEEDS_MEMBER)
//   K4 F2 F55  ยอดรับชำระติดลบ · ว่าง · 0 · ขยะ = ปัด (PAY_NOT_POSITIVE) · "1,000" อ่านเป็น 1000
//   K5      ยกเลิกบิลเซ็นที่ชำระบางส่วนหรือครบแล้ว = คืนยอดที่ชำระแล้วเป็น `refundCash` (ข้อเสนอทางแรก: คืนเป็นเงินสด)
//           ยอดที่ชำระ = ยอดที่ตัดจากแถวหนี้ของบิลนั้น (ส่วนที่ตัดจาก credit ตั้งต้นก่อน ไล่บิลไม่ได้ ไม่นับ)
//   F22     รับชำระครบแล้วแถวหนี้ไม่หาย (เก็บไว้ remainCredit 0) ⇒ ประวัติเซ็นเห็นบิลที่ชำระครบ และยกเลิกบิลนั้นคืนเงินได้
//   K6      ยกเลิกบิลเซ็นแบบเก่า (ช่อง '035') credit ต่ำสุด 0 ส่วนเกินเป็น `refundCash` · credit ติดลบไม่กลบหนี้รายบิล
//   K7      ตัดแต้มจนติดลบ = ปัดบิล (POINT_INSUFFICIENT · ข้อเสนอทางแรก: ปฏิเสธบิล)
//   K8      จ่ายเซ็นตอนปิด creditPoint ยังหักแต้มที่แลก
//   K9      หนี้เงินเซ็นไม่เกินยอดบิล
//   K10     รางวัล 0 แต้ม (รวม '0' '00') แลกไม่ได้ (REWARD_POINT_NOT_POSITIVE)
//   K16     แต้มคิดด้วยทศนิยมจริง ไม่ขาด 1 จาก floor บนเลขลอย (4.35 × 100 = 435 ไม่ใช่ 434)
//   F1      ยอดซื้อต่อแต้มว่าง · 0 · ติดลบ หรือแต้มต่อรอบ ≤ 0 = ได้ 0 แต้ม ไม่เป็น Infinity/NaN
//   F3      point · credit · ตัวคูณที่เป็น NaN/ขยะ = 0 ไม่ลามเป็น NaN
//   F4      แลกแต้มโดยไม่มีสมาชิก = ปัด (REDEEM_NEEDS_MEMBER)
//   F15     เดือนของ `bought` ผูกกับวันขายของบิล (`soldAt` ตอนขาย · `bill.dateTime` ตอนยกเลิก · ปฏิทินไทย UTC+7)
//           ไม่ใช่เดือนที่ซิงก์ · ยกเลิกแล้ว time และ buy ต่ำสุด 0
//   F16     สมาชิกไม่มี `bought` ยกเลิกบิลได้ · สมาชิกถูกลบ ยกเลิกบิลต่อได้ (ok:true · update:null = ไม่ต้องเขียนสมาชิก)
//   แลกส่วนลดเกินยอดที่ต้องจ่าย = ปัด (DISCOUNT_OVER_REMAIN · ยกด่านเดิม CheckoutScreen.js:359-363 มาไว้ในสูตร)
//   F52 F57 เศษลอยของแต้มและหนี้ถูกปัดทิ้ง (แต้ม 6 ตำแหน่ง · เงินเป็นสตางค์)
//   F60     แถวหนี้ที่ไม่มี remainCredit = 0 ไม่ทำให้แถวถัดไปหาย · แถวนั้นคงไว้ตามเดิม
//   F45     `paid` เป็นตัวเลข ไม่ใช่สตริงที่พิมพ์
//
// คงเดิมโดยตั้งใจ:
//   C1   แต้มคิดจาก `net` ของสินค้าที่ `pointStatus` (ก่อนส่วนลดท้ายบิล)
//   K15  วันที่และวันในสัปดาห์ของตัวคูณ ผู้เรียกส่งเข้ามา (ข้อเสนอทางแรก = วันปฏิทิน) · ไม่อ่านนาฬิกาเครื่องเอง
//   K19  ตัวคูณ < 1 ยอมให้ลดแต้ม · ค่า falsy (0 · '' · ไม่มี) ไม่คูณ เหมือนเดิม
//   ตะกร้า `net` ติดลบ = แต้มติดลบได้เหมือนเดิม (ไม่มีรหัสบั๊ก) · แต่ถ้าทำให้แต้มคงเหลือติดลบ ปัดด้วย K7
//
// สูตรเดิม (lanes/dev/source/compare/old-logic/member.js):
//   แต้มที่ได้ CheckoutScreen.js:726-746 · แลก :307-330 · เขียนสมาชิก :629-681 · ยกเลิก BillHistoryScreen.js:442-467
//   รับชำระ Modal_CreditMember.js:41-43 · 52-86
//
// สัญญา (export):
//   pointMultiplier(smartPoint, { date, day }) → number  ผลคูณตัวคูณวันที่ (1-31) กับวันในสัปดาห์ (0-6)
//   earnPoints({ smartPoint, cart, date, day }) → number  แต้มจำนวนเต็มที่ได้จากบิล
//   usedPointOf(pointToDiscount, pointToItem) → number    แต้มที่ใช้แลกในบิล
//   canRedeem({ memberPoint, usedPoint, reward, remainMoney }) → { ok, reason, remain, lessPoint }
//     reward ที่มี `value` (แลกส่วนลด) ต้องส่ง `remainMoney` = ยอดที่ยังต้องจ่าย · ไม่ส่ง = 0 = ปัด
//   saleMemberEffect({ hasMember, creditAmount, creditPoint, earned, usedPoint, moneyMustPaid })
//     → { ok, error, gainPoint, usedPoint, pointDelta, creditDebt }
//   boughtMonthOf(soldAt) → { yearMonth, year } | null   เดือนปฏิทินไทยของวันขาย (Date · ms · Timestamp)
//   applySaleToMember(member, { pointDelta, creditDebt, moneyMustPaid, soldAt, yearMonth, year, billId, receiptNumber, receiptUUID, now })
//     เดือนของ bought = boughtMonthOf(soldAt) · ไม่มี soldAt ที่อ่านได้ ใช้ yearMonth year ที่ส่งมา
//     → { ok, error, update, existPoint }   `update` = field ที่ต้องเขียนลง member doc
//   applyVoidToMember(member, { id, gainPoint, usedPoint, moneyMustPaid, payment, dateTime }, { yearMonth })
//     → { ok, error, update, refundCash }   เดือน = boughtMonthOf(bill.dateTime) · อ่านไม่ได้ใช้ ctx.yearMonth
//     member ไม่มี (ถูกลบ) = { ok:true, error:null, update:null, refundCash:0 }
//   totalCredit(member) → number บาท  หนี้รวม = credit (ต่ำสุด 0) + remainCredit รายบิล (ต่ำสุด 0)
//   applyCreditPayment(member, pay) → { ok, error, update, paid, existCredit }

const { toNumber } = require("./money");
const { SHOP_UTC_OFFSET_MIN } = require("./businessDay");

// ───────── ตัวช่วย ─────────

// ทศนิยมจริงจาก number ที่ finite: { n: BigInt, s: จำนวนหลักหลังจุด } · String(n) ให้ทศนิยมสั้นสุดที่ย้อนกลับได้
function dec(v) {
  const x = toNumber(v);
  const m = String(x).match(/^(-?)(\d+)(?:\.(\d+))?(?:e([+-]\d+))?$/);
  if (!m) return { n: 0n, s: 0 };
  const frac = m[3] || "";
  let n = BigInt(m[2] + frac);
  let s = frac.length - Number(m[4] || 0);
  if (s < 0) { n *= 10n ** BigInt(-s); s = 0; }
  return { n: m[1] ? -n : n, s };
}
const mulD = (a, b) => ({ n: a.n * b.n, s: a.s + b.s });
function addD(a, b) {
  const s = Math.max(a.s, b.s);
  return { n: a.n * 10n ** BigInt(s - a.s) + b.n * 10n ** BigInt(s - b.s), s };
}
// floor(a / b) แบบตรงทุกหลัก · b ต้องไม่เป็น 0
function floorDiv(a, b) {
  let num = a.n, den = b.n;
  const shift = a.s - b.s;
  if (shift > 0) den *= 10n ** BigInt(shift);
  else if (shift < 0) num *= 10n ** BigInt(-shift);
  if (den < 0n) { num = -num; den = -den; }
  let q = num / den;
  if (num % den !== 0n && num < 0n) q -= 1n;
  return Number(q);
}

// แต้ม: ตัดเศษลอยที่ 6 ตำแหน่ง (F52) · -0 เป็น 0
const cleanPoint = (x) => {
  const r = Math.round(Number((x * 1e6).toPrecision(15))) / 1e6;
  return r === 0 ? 0 : r;
};
// เงิน: บาท ↔ สตางค์จำนวนเต็ม (F57)
function toSatang(v) {
  const s = Math.round(Number((toNumber(v) * 100).toPrecision(15)));
  return Number.isSafeInteger(s) ? s : 0;
}
const toBaht = (s) => (s === 0 ? 0 : s / 100);
const isObj = (o) => o !== null && typeof o === "object" && !Array.isArray(o);
const list = (a) => (Array.isArray(a) ? a : []);
// อ่านเป็นตัวเลขได้จริง (ไม่ใช่ขยะที่ toNumber ตีเป็น 0)
const isNumberLike = (v) =>
  (typeof v === "number" && Number.isFinite(v)) ||
  (typeof v === "string" && Number.isFinite(Number(v.trim().replace(/,/g, ""))) && v.trim() !== "");

// ───────── เดือนของ bought (F15) ─────────

function instantMs(t) {
  if (t instanceof Date) return t.getTime();
  if (typeof t === "number") return t;
  if (isObj(t)) {
    if (typeof t.toMillis === "function") return t.toMillis();
    if (typeof t.toDate === "function") return t.toDate().getTime();
    const sec = t.seconds !== undefined ? t.seconds : t._seconds;
    const ns = t.nanoseconds !== undefined ? t.nanoseconds : t._nanoseconds;
    if (typeof sec === "number") return sec * 1000 + Math.floor((typeof ns === "number" ? ns : 0) / 1e6);
  }
  return NaN;
}

function boughtMonthOf(soldAt) {
  const ms = instantMs(soldAt);
  if (!Number.isFinite(ms)) return null;
  const d = new Date(ms + SHOP_UTC_OFFSET_MIN * 60000);
  if (Number.isNaN(d.getTime())) return null;
  const year = String(d.getUTCFullYear()).padStart(4, "0");
  return { yearMonth: year + String(d.getUTCMonth() + 1).padStart(2, "0"), year };
}

// ───────── แต้มที่ได้ ─────────

function multiplierParts(smartPoint, when) {
  const sp = isObj(smartPoint) ? smartPoint : {};
  const w = isObj(when) ? when : {};
  const parts = [];
  // ค่า falsy ไม่คูณ (เหมือนเดิม) · ค่าที่อ่านเป็นตัวเลขไม่ได้ ไม่คูณ (F3 · เดิมได้ NaN) · '0' ยังคูณ 0 เหมือนเดิม
  const pick = (arr, id) => {
    const row = list(arr).find((a) => a && a.id === id);
    const v = row ? row.value : undefined;
    if (v && isNumberLike(v)) parts.push(dec(v));
  };
  pick(sp.date, w.date);
  pick(sp.days, w.day);
  return parts;
}

function pointMultiplier(smartPoint, when) {
  const d = multiplierParts(smartPoint, when).reduce(mulD, { n: 1n, s: 0 });
  return Number(d.n) / 10 ** d.s;
}

function earnPoints(args) {
  const a = isObj(args) ? args : {};
  const sp = isObj(a.smartPoint) ? a.smartPoint : {};
  const rate = dec(sp.rate);
  const point = dec(sp.point);
  if (rate.n <= 0n || point.n <= 0n) return 0; // F1 · K17 (0 = ไม่ให้แต้ม)
  const base = list(a.cart)
    .filter((p) => p && p.pointStatus)
    .reduce((acc, p) => addD(acc, dec(p.net)), { n: 0n, s: 0 });
  const m = multiplierParts(sp, { date: a.date, day: a.day }).reduce(mulD, { n: 1n, s: 0 });
  const r = floorDiv(mulD(mulD(m, base), point), rate); // K16
  return r === 0 ? 0 : r;
}

// ───────── ใช้แต้ม ─────────

function usedPointOf(pointToDiscount, pointToItem) {
  const sum = [...list(pointToDiscount), ...list(pointToItem)].reduce((acc, r) => acc + toNumber(r && r.point), 0);
  return cleanPoint(sum);
}

function canRedeem(args) {
  const a = isObj(args) ? args : {};
  const rewardPoint = toNumber(isObj(a.reward) ? a.reward.point : undefined);
  const remain = cleanPoint(toNumber(a.memberPoint) - toNumber(a.usedPoint));
  const lessPoint = cleanPoint(rewardPoint - remain);
  if (!(rewardPoint > 0)) return { ok: false, reason: "REWARD_POINT_NOT_POSITIVE", remain, lessPoint }; // K10
  if (remain < rewardPoint) return { ok: false, reason: "POINT_INSUFFICIENT", remain, lessPoint };
  // แลกส่วนลดเกินยอดที่ยังต้องจ่าย = ปัด (เดิม CheckoutScreen.js:359-363) · ไม่อย่างนั้นส่วนลดถูกตัดทิ้งแต่แต้มถูกหักเต็ม
  if (a.reward.value && toSatang(a.reward.value) > Math.max(0, toSatang(a.remainMoney))) {
    return { ok: false, reason: "DISCOUNT_OVER_REMAIN", remain, lessPoint };
  }
  return { ok: true, reason: null, remain, lessPoint };
}

// ───────── ผลของการขายต่อสมาชิก ─────────

function saleMemberEffect(args) {
  const a = isObj(args) ? args : {};
  const hasMember = !!a.hasMember;
  const credit = toNumber(a.creditAmount);
  const used = toNumber(a.usedPoint);
  const fail = (error) => ({ ok: false, error, gainPoint: 0, usedPoint: used, pointDelta: 0, creditDebt: 0 });
  if (credit > 0 && !hasMember) return fail("CREDIT_NEEDS_MEMBER"); // #7 K2
  if (used > 0 && !hasMember) return fail("REDEEM_NEEDS_MEMBER"); // F4
  if (!hasMember) return { ok: true, error: null, gainPoint: 0, usedPoint: used, pointDelta: 0, creditDebt: 0 };
  const earnsPoint = credit === 0 || !!a.creditPoint;
  const gainPoint = earnsPoint ? toNumber(a.earned) : 0;
  const pointDelta = cleanPoint(gainPoint - used); // K8: หักแต้มที่แลกเสมอ
  const creditDebt = credit > 0 ? toBaht(Math.min(toSatang(credit), Math.max(0, toSatang(a.moneyMustPaid)))) : 0; // K9
  return { ok: true, error: null, gainPoint, usedPoint: used, pointDelta, creditDebt };
}

function applySaleToMember(member, sale) {
  if (!isObj(member)) return { ok: false, error: "MEMBER_NOT_FOUND", update: null, existPoint: null };
  const s = isObj(sale) ? sale : {};
  const delta = toNumber(s.pointDelta);
  const point = cleanPoint(toNumber(member.point) + delta); // F3 · F52
  if (delta < 0 && point < 0) return { ok: false, error: "POINT_INSUFFICIENT", update: null, existPoint: null }; // K7
  const money = toNumber(s.moneyMustPaid);
  const bm = boughtMonthOf(s.soldAt);
  const yearMonth = bm ? bm.yearMonth : s.yearMonth;
  const year = bm ? bm.year : s.year;
  const bought = list(member.bought).map((r) => (isObj(r) ? { ...r } : r));
  const row = bought.find((r) => isObj(r) && r.yearMonth === yearMonth);
  if (row) {
    row.buy = toNumber(row.buy) + money;
    row.time = toNumber(row.time) + 1;
  } else {
    bought.push({ yearMonth, buy: money, time: 1, year });
  }
  const update = { point, bought, lastTime: s.now };
  const debt = toBaht(Math.max(0, toSatang(s.creditDebt)));
  if (debt > 0) {
    const entry = { receiptNumber: s.receiptNumber, billId: s.billId, totalCredit: debt, remainCredit: debt, timestamp: s.now };
    if (s.receiptUUID !== undefined) entry.receiptUUID = s.receiptUUID;
    update.creditArray = [...list(member.creditArray), entry];
  }
  return { ok: true, error: null, update, existPoint: point };
}

// ───────── ยกเลิกบิล ─────────

function applyVoidToMember(member, bill, ctx) {
  // F16: สมาชิกถูกลบ ยกเลิกบิลต่อได้ · ไม่มีอะไรให้เขียนลงสมาชิก
  if (!isObj(member)) return { ok: true, error: null, update: null, refundCash: 0 };
  const b = isObj(bill) ? bill : {};
  const c = isObj(ctx) ? ctx : {};
  const bm = boughtMonthOf(b.dateTime); // F15: เดือนเดียวกับที่บวกไว้ตอนขาย
  const yearMonth = bm ? bm.yearMonth : c.yearMonth;
  const money = toNumber(b.moneyMustPaid);
  // #16 K1: คืนแต้มที่ใช้แลก · ต่ำสุด 0
  const point = Math.max(0, cleanPoint(toNumber(member.point) - toNumber(b.gainPoint) + toNumber(b.usedPoint)));
  // F16: ไม่มี bought = ไม่มีแถวให้ลด · F15: ต่ำสุด 0
  const bought = list(member.bought).map((r) =>
    isObj(r) && r.yearMonth === yearMonth
      ? { ...r, time: Math.max(0, toNumber(r.time) - 1), buy: Math.max(0, toNumber(r.buy) - money) }
      : r,
  );
  let refund = 0;
  const creditArray = [];
  for (const r of list(member.creditArray)) {
    if (isObj(r) && r.billId === b.id) {
      refund += Math.max(0, toSatang(r.totalCredit) - Math.max(0, toSatang(r.remainCredit))); // K5 · รวมแถวที่ชำระครบ (F22)
    } else creditArray.push(r);
  }
  const update = { point, bought, creditArray };
  const old = list(b.payment).find((p) => p && p.id === "035");
  if (old) {
    const next = toSatang(member.credit) - toSatang(old.amount);
    if (next < 0) refund += -next; // K6
    update.credit = toBaht(Math.max(0, next));
  }
  return { ok: true, error: null, update, refundCash: toBaht(refund) };
}

// ───────── เงินเซ็น ─────────

function creditParts(member) {
  const m = isObj(member) ? member : {};
  const credit = Math.max(0, toSatang(m.credit)); // K6 · F3
  const rows = list(m.creditArray);
  const remains = rows.map((r) => Math.max(0, toSatang(isObj(r) ? r.remainCredit : 0))); // F60 · F57
  return { credit, rows, remains };
}

function totalCredit(member) {
  const { credit, remains } = creditParts(member);
  return toBaht(remains.reduce((a, x) => a + x, credit));
}

function applyCreditPayment(member, pay) {
  const p0 = toSatang(pay);
  const fail = (error) => ({ ok: false, error, update: null, paid: 0, existCredit: totalCredit(member) });
  if (!isObj(member)) return { ...fail("MEMBER_NOT_FOUND"), existCredit: 0 };
  if (p0 <= 0) return fail("PAY_NOT_POSITIVE"); // K4 · F2 · F55
  const { credit, rows, remains } = creditParts(member);
  const total = remains.reduce((a, x) => a + x, credit);
  if (p0 > total) return fail("PAY_OVER_TOTAL");
  let left = p0;
  const fromCredit = Math.min(credit, left);
  left -= fromCredit;
  const creditArray = [];
  rows.forEach((r, i) => {
    if (!isObj(r)) return;
    if (!isNumberLike(r.remainCredit)) { creditArray.push(r); return; } // F60: แถวเก่าไม่มียอดค้าง คงไว้ตามเดิม
    const take = Math.min(remains[i], left);
    left -= take;
    creditArray.push({ ...r, remainCredit: toBaht(remains[i] - take) }); // F22 · K5: ชำระครบแล้วแถวยังอยู่ (remainCredit 0)
  });
  const update = { credit: toBaht(credit - fromCredit), creditArray };
  return { ok: true, error: null, update, paid: toBaht(p0), existCredit: toBaht(total - p0) };
}

module.exports = {
  pointMultiplier,
  earnPoints,
  usedPointOf,
  canRedeem,
  saleMemberEffect,
  applySaleToMember,
  applyVoidToMember,
  boughtMonthOf,
  totalCredit,
  applyCreditPayment,
};

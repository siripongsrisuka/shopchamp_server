// shift — ยอดกะ · เงินสดที่คาดไว้ · ผลต่างตอนปิดกะ · บิลเข้ากะไหน (ใบ DEV-0001 · ก้อน 3)
//
// Pack เคาะ 2026-11-06: server เชื่อยอดจากแอป ⇒ สูตรต้องถูกเอง · ไฟล์นี้คือสูตรนั้น (JS ล้วน ไม่แตะ Firebase)
// server (ก้อน 4 `shift.manage`) อ่านเอกสารใน transaction แล้วส่งเข้าฟังก์ชันพวกนี้ · ❌ ไม่เก็บยอดที่คิดไว้ก่อนมาใช้ตอนปิด
//
// ปิดบั๊ก (ฝั่งสูตร · ตาม lanes/dev/source/bug-decisions/shift-cash.md · กลุ่ม "ต้องเคาะ" ใช้ทางแรกในช่องข้อเสนอ ตาม index.md §ที่เหลือ):
//   #17 SC-01  รับชำระเงินเซ็นไม่เข้ากะ ⇒ paidHistory ที่มี shiftId + paymentId เงินสด นับเข้าเงินคาด (creditCash)
//              ใบจากแอปเก่าที่ไม่มี 2 ค่านี้ไม่นับ (ตามข้อเสนอ #17) แต่นับจำนวนไว้ใน legacyIgnored
//   #18 SC-02  บิลมาช้า (ซิงก์หลังปิดกะ) ไม่เข้ากะไหน ⇒ แบบ `architecture-plan.md:103-105`: บิลแอปใหม่มีป้าย
//              `shiftId` + `shiftOpenTime` ⇒ เข้ารอบที่ openTime เท่าป้าย แม้รอบนั้นปิดแล้ว และนับแยกเป็น `late`
//              (มาถึงหลังเวลาปิดรอบ = ยอด lateSales) · ป้ายไม่ตรงรอบไหน = UNASSIGNED (shiftUnassigned)
//              บิลแอปเก่า (ไม่มีป้าย) ใช้กติกาเดิม `shiftId` ตรง + เวลา > openTime และไม่ได้รับผลจากแบบใหม่
//              (`architecture-plan.md:295`) ⇒ มาถึงหลังรอบปิด = ไม่ย้ายเข้ารอบนั้น รายงานใน outside เป็น LEGACY_LATE
//   SC-04      เงินทอนลงช่องที่ไม่ใช่เงินสด เงินคาดสูงเกิน ⇒ เงินทอนทั้งบิลหักจากเงินสด · ช่องอื่นนับเต็มยอดที่รับ
//   SC-07      บิลรหัสเงินสด '001' ไม่เข้าเงินคาด ⇒ เงินสด = id 1 หรือ '001'
//   SC-13      ขอบรอบกะเทียบนาฬิกาคนละเครื่อง ⇒ บิลที่มีป้ายผูกรอบด้วยป้าย ไม่เทียบนาฬิกาเครื่องเลย
//              (นาฬิกาช้า/เร็วแค่ไหนก็เข้ารอบที่ป้ายบอก) · บิลแอปเก่ายังเทียบนาฬิกาแบบเดิม (แก้ไม่ได้ฝั่งสูตร)
//   SC-14      ยอดปิดกะเป็นค่าตอนเปิดจอ ⇒ closeShift ไม่รับเงินคาดที่คิดไว้ก่อน รับบิลกับเอกสารดิบแล้วคิดใหม่ทุกครั้ง
//              (ส่วนอ่านเอกสารล่าสุดใน transaction ตอนกดปิด = งานก้อน 4)
//   SC-26      ถอน/นำเงินออกเกินที่มี ⇒ เตือน ไม่บล็อก (WITHDRAW_OVER · CASH_OUT_OVER) ตามข้อเสนอ
//   พ่วง (เพราะอยู่ในสูตรเดียวกัน · ไม่ใช่เป้าหลักของหน่วย):
//     SC-28 เงินคาดของประวัติกะเก่า = นับได้ − ผลต่าง (historyExpectedCash) · ตัวใหม่เขียน currentCash จริง (shiftHistoryFields)
//     SC-29 ยอดรายช่องที่เขียนลง shiftHistory ไม่พา change ติดไป · SC-30 เลขกะคิดจากเวลาที่กด (nextShiftCount)
//     SC-25 ปิดกะไม่กรอกยอด ⇒ CLOSE_CASH_EMPTY · SC-46 เงินเข้าออกซ้ำจาก transaction รันซ้ำ ⇒ entryId ซ้ำนับครั้งเดียว
//     SC-51 ค่าเก่าเป็นขยะได้ NaN ⇒ อ่านไม่ได้ = 0 · SC-58 ผลต่าง -0.00 ⇒ 0 · money F08 ทศนิยมลอย ⇒ คิดเป็นสตางค์
//     SC-60 กะไม่มี openId ได้ยอด 0 ⇒ สูตรไม่ดู openId (รอบมาจาก server)
//
// สูตรเดิม (lanes/dev/source/compare/old-logic/shift.js):
//   srv:apis/shift.js manageSummary + ตัวกรอง /test (function `shift` ที่ live = nodejs_2022 `f985509`)
//   app:screens/ShiftScreen.js:91-110 (เงินคาด/ผลต่าง) @804ba8ff
//
// รูปข้อมูล
//   bill        = เอกสาร `bill` + `id` + `arrivedAt?` (server ใส่จาก createTime ของ doc · ใช้นับ late เท่านั้น)
//                 ป้ายรอบ = `shiftOpenTime` (แอปใหม่) · ไม่มีป้าย: เวลาขาย = `soldAt` ถ้าอ่านได้ ไม่งั้น `dateTime`
//   paidHistory = เอกสาร `paidHistory` + `id` · ใหม่: `shiftId` `paymentId` `shiftOpenTime?` (ก้อน 4) · ป้ายก่อน · ไม่มีป้าย: เวลา = `soldAt` ถ้ามี ไม่งั้น `timestamp` เทียบ [openTime, closeTime)
//   round       = { roundId, shiftId, openTime, closeTime }  · closeTime ว่าง/null = รอบที่ยังเปิด
//                 shiftId = doc `shift` ประจำจุดขาย (ไม่ใช่รหัสรอบ) · server ประกอบจาก doc shift (รอบเปิด) + shiftHistory (รอบที่ปิด)
//   เวลา        = Date · Timestamp (toMillis) · {seconds,nanoseconds} · {_seconds,_nanoseconds} · ms · ข้อความวันที่
//   เงิน        = number หรือข้อความ (อ่านด้วย money.toNumber) · คิดเป็นสตางค์จำนวนเต็ม · คืนเป็นบาททศนิยมไม่เกิน 2 ตำแหน่ง
//
// สัญญา (ทุกฟังก์ชันไม่แก้ของที่ส่งเข้ามา · ❌ ไม่ throw)
//   isCashChannel(id)                         → boolean
//   toMillis(t)                               → number | null
//   roundOf(item, rounds, { POSs }?)          → { roundId|null, reason: OK|NO_SHIFT|NO_TIME|NO_ROUND|OUTSIDE_ROUNDS|UNASSIGNED }
//        POSs = `shop.POSs` · ใช้ผูกบิลแอปก่อน f95d0366 ที่ไม่มี shiftId (posId = uniqueId ของจุดที่ drawer === true · live-fit.md §8)
//   summarizeShiftBills(bills, { smartCategory }?)
//        → { billQty, voidQty, totalNet, totalPrice, saleRate, totalRounding, totalChange, totalManualDiscount, totalPointDiscount,
//            totalProductDiscount, totalVat, cashSales, payments[{id,name,amount,qty}], campaigns[{id,name,qty,discount}],
//            cashiers[{cashierId,cashierName,amount}], products[{id,name,qty,count,totalPrice}], categories[{id,name,qty,totalPrice}] }
//   duringTotals(duringShift)                 → { cashIn, cashOut, entries, ignored }
//   creditCashReceived(paidHistory, roundId, rounds) → { creditCash, payments[{id,amount,qty}], legacyIgnored }
//   roundSummary({ roundId, rounds, bills, paidHistory, openCash, duringShift, smartCategory?, POSs? })
//        duringShift รับ type 1/2 และข้อความ 'เติมเงิน'/'ถอนเงิน' ของแอปก่อน f95d0366 · บิลยกเลิก = billState.isVoidedBill
//        → { ...summarizeShiftBills, openCash, cashIn, cashOut, creditCash, creditPayments, expectedCash,
//            late{billQty,totalNet,cash}, outside[{id,reason: ของ roundOf | LEGACY_LATE}], legacyCreditIgnored }
//   closeShift({ ...ของ roundSummary, closeCash, closeWithDraw })
//        → { summary, expectedCash, closeCash, closeWithDraw, closeDiff, cashRemain, canClose, errors[], warnings[] }
//          errors: CLOSE_CASH_EMPTY · CLOSE_CASH_BAD · WITHDRAW_BAD · ROUND_NOT_FOUND · warnings: WITHDRAW_OVER
//   checkDuringEntry({ type, amount, expectedCash }) → { ok, amount, errors[], warnings[] }
//          errors: TYPE_BAD · AMOUNT_EMPTY · AMOUNT_BAD · warnings: CASH_OUT_OVER
//   shiftHistoryFields(closeResult)            → field ชื่อเดิมของ shiftHistory (thisPayment ... thisVat) + currentCash closeDiff | null
//   historyExpectedCash({ closeCash, closeDiff }) → number | null
//   nextShiftCount({ shiftCount, lastShiftDate, now }) → { ok, count, shiftDate, errors: NOW_BAD }

const { toNumber } = require("./money");
const { isVoidedBill } = require("./billState");

const CASH_IDS = Object.freeze([1, "001"]);
// ชื่อช่องเมื่อบิลไม่มี name · ตาม paymentNameMaps ของ server เดิม + id 1 2 3 ตาม payment.PAYMENT_CHANNEL
const PAYMENT_NAMES = Object.freeze({ 1: "เงินสด", 2: "พร้อมเพย์", 3: "เงินเซ็น", "001": "เงินสด", "009": "พร้อมเพย์", "036": "พร้อมเพย์(static)", "035": "เงินเซ็น", "037": "บัตรสวัสดิการ" });
const NO_PAYMENT = Object.freeze({ id: "noId", name: "No Payment Type" });

function isCashChannel(id) {
  return CASH_IDS.includes(id);
}

// บาท → สตางค์จำนวนเต็ม · toPrecision(15) ตัดเศษฐานสองก่อนปัด · ครึ่งปัดออกจากศูนย์ · เกินช่วงนับแม่น = 0
function sat(v) {
  const n = toNumber(v);
  const x = Number((Math.abs(n) * 100).toPrecision(15));
  const s = Math.round(x);
  if (!Number.isSafeInteger(s)) return 0;
  return n < 0 ? -s || 0 : s;
}
const baht = (s) => (s === 0 ? 0 : s / 100);
const objs = (arr) => (Array.isArray(arr) ? arr.filter((x) => x && typeof x === "object") : []);

function toMillis(t) {
  if (t instanceof Date) {
    const m = t.getTime();
    return Number.isFinite(m) ? m : null;
  }
  if (typeof t === "number") return Number.isFinite(t) ? t : null;
  if (typeof t === "string") {
    const m = Date.parse(t); // "" และช่องว่างได้ NaN
    return Number.isFinite(m) ? m : null;
  }
  if (t && typeof t === "object") {
    if (typeof t.toMillis === "function") {
      try {
        const m = t.toMillis();
        return typeof m === "number" && Number.isFinite(m) ? m : null;
      } catch {
        return null;
      }
    }
    const s = "seconds" in t ? t.seconds : t._seconds;
    const ns = "seconds" in t ? t.nanoseconds : t._nanoseconds;
    if (typeof s === "number" && Number.isFinite(s)) return s * 1000 + (typeof ns === "number" && Number.isFinite(ns) ? ns / 1e6 : 0);
  }
  return null;
}

const saleTimeOf = (bill) => {
  const s = toMillis(bill.soldAt);
  return s !== null ? s : toMillis(bill.dateTime);
};
const paidTimeOf = (row) => {
  const s = toMillis(row.soldAt);
  return s !== null ? s : toMillis(row.timestamp);
};

function normRounds(rounds) {
  const out = [];
  for (const r of objs(rounds)) {
    const ok = (typeof r.roundId === "string" && r.roundId !== "") || typeof r.roundId === "number";
    if (!ok || typeof r.shiftId !== "string" || r.shiftId === "") continue;
    const open = toMillis(r.openTime);
    if (open === null) continue;
    const close = r.closeTime === undefined || r.closeTime === null || r.closeTime === "" ? null : toMillis(r.closeTime);
    if (close !== null && close <= open) continue; // รอบเพี้ยน (ปิดก่อนเปิด) ไม่ใช้ตัดสิน
    if (close === null && r.closeTime !== undefined && r.closeTime !== null && r.closeTime !== "") continue; // ปิดแล้วแต่อ่านเวลาไม่ได้
    out.push({ roundId: r.roundId, shiftId: r.shiftId, open, close });
  }
  return out;
}

// ป้ายรอบของบิล/ใบรับชำระ (แบบ #18): `shiftOpenTime` = openTime ของรอบที่เปิดอยู่ตอนขาย · ไม่มีค่า = ของจากแอปเก่า
//   { has:false } ไม่มีป้าย · { has:true, m } มีป้าย (m = null ถ้าอ่านเวลาไม่ได้)
function labelOf(item) {
  const v = item.shiftOpenTime;
  if (v === undefined || v === null || v === "") return { has: false, m: null };
  return { has: true, m: toMillis(v) };
}
// เวลาเดียวกัน · เทียบถึงไมโครวินาที (Timestamp ของ Firestore ละเอียดถึง µs · ns/1e6 ได้เศษ ms)
const sameInstant = (a, b) => Math.round(a * 1000) === Math.round(b * 1000);

// จุดขายที่ใช้ผูกบิลแอปรุ่นก่อน f95d0366 (ไม่มี shiftId) · รับ `shop.POSs` ตรง ๆ
//   แอปเก่าผูกเงินสดเข้ากะตอนชำระ: `@1b20384a` › src/screens/PayScreen.js:714-720
//     POSs.find(item => item.uniqueId === uniqueId && item.drawer === true) → cashShift({ doc: shiftId }) · บิลเก็บ posId:uniqueId (:670)
//   ⇒ เฉพาะจุดที่ drawer === true เท่านั้น · ตัวแรกที่ตรง (find)
function normPos(POSs) {
  const out = [];
  for (const p of objs(POSs)) {
    if (p.drawer !== true || typeof p.uniqueId !== "string" || p.uniqueId === "") continue;
    out.push({ uniqueId: p.uniqueId, shiftId: typeof p.shiftId === "string" ? p.shiftId : "" });
  }
  return out;
}
// shiftId ของบิล · มีในบิล = ใช้ค่านั้น · ไม่มี + มีจุดขาย = shiftId ของจุดขายที่ uniqueId = posId (แบบแอปเก่า) · ไม่งั้น ""
function shiftIdOf(item, pos) {
  if (typeof item.shiftId === "string" && item.shiftId !== "") return { shiftId: item.shiftId, viaPos: false };
  if (pos && pos.length && (item.shiftId === undefined || item.shiftId === null || item.shiftId === "") && typeof item.posId === "string" && item.posId !== "") {
    const p = pos.find((x) => x.uniqueId === item.posId);
    if (p && p.shiftId !== "") return { shiftId: p.shiftId, viaPos: true };
  }
  return { shiftId: "", viaPos: false };
}

// เลือกรอบ · คืน { roundId, reason, by, shiftId }  by = "label" ผูกด้วยป้าย · "clock" ผูกด้วยเวลา
//   มีป้าย  ⇒ รอบที่ shiftId ตรงและ openTime เท่าป้าย · ไม่เทียบนาฬิกาเครื่อง (SC-13) · หาไม่เจอ = UNASSIGNED (shiftUnassigned)
//   ไม่มีป้าย ⇒ เทียบเวลาในช่วงรอบ · legacy = true ใช้กติกาเดิมของบิลแอปเก่า: เวลา > openTime (เข้ม · `srv:apis/shift.js:249`)
//             legacy = false (ใบรับชำระ) ใช้ [openTime, closeTime)
//   ไม่มี shiftId (แอปก่อน f95d0366) + ส่ง POSs ⇒ shiftId จากจุดขาย แล้วใช้กติกาเวลาแบบบิลแอปเก่า
//     ❓ บิลที่ขายช่วงกะปิด (ระหว่างรอบ) แอปเก่าบวกเข้า doc กะแล้วอาจไปโผล่รอบถัดไป ขึ้นกับค่าใน redux ตอนเปิดกะ ⇒ ไม่เดา = OUTSIDE_ROUNDS
function pickRound(item, t, rs, legacy, pos) {
  const { shiftId, viaPos } = shiftIdOf(item, pos);
  if (shiftId === "") return { roundId: null, reason: "NO_SHIFT", by: null, shiftId: null };
  // บิลที่ผูกผ่านจุดขาย = แอปรุ่นก่อน f95d0366 ไม่มีป้าย ⇒ ใช้กติกาเวลาแบบบิลแอปเก่า (ไม่อ่านป้ายแม้มี)
  if (viaPos) {
    const p = clockRound(rs.filter((r) => r.shiftId === shiftId), t, true);
    return { ...p, shiftId };
  }
  return { ...pickByShift(item, t, rs, legacy, shiftId), shiftId };
}

function clockRound(mine, t, legacy) {
  if (t === null) return { roundId: null, reason: "NO_TIME", by: "clock" };
  if (mine.length === 0) return { roundId: null, reason: "NO_ROUND", by: "clock" };
  let best = null;
  for (const r of mine) {
    const afterOpen = legacy ? t > r.open : t >= r.open;
    if (afterOpen && (r.close === null || t < r.close) && (!best || r.open > best.open)) best = r;
  }
  return best ? { roundId: best.roundId, reason: "OK", by: "clock" } : { roundId: null, reason: "OUTSIDE_ROUNDS", by: "clock" };
}

function pickByShift(item, t, rs, legacy, shiftId) {
  const mine = rs.filter((r) => r.shiftId === shiftId);
  const lab = labelOf(item);
  if (lab.has) {
    const r = lab.m === null ? null : mine.find((x) => sameInstant(x.open, lab.m));
    return r ? { roundId: r.roundId, reason: "OK", by: "label" } : { roundId: null, reason: "UNASSIGNED", by: "label" };
  }
  return clockRound(mine, t, legacy);
}

// opts.POSs = `shop.POSs` (ไม่ส่ง = บิลไม่มี shiftId ได้ NO_SHIFT ตามเดิม)
function roundOf(item, rounds, opts) {
  if (!item || typeof item !== "object") return { roundId: null, reason: "NO_SHIFT" };
  const pos = opts && typeof opts === "object" ? normPos(opts.POSs) : [];
  const p = pickRound(item, saleTimeOf(item), normRounds(rounds), true, pos);
  return { roundId: p.roundId, reason: p.reason };
}

// จำนวนชิ้น (อาจเป็นทศนิยมของสินค้าชั่งน้ำหนัก) · ตัดเศษฐานสองที่ 12 หลัก · ไม่มี -0
const qtyAdd = (a, b) => Number((a + toNumber(b)).toPrecision(12)) || 0;

function summarizeShiftBills(bills, opts) {
  const smart = opts && typeof opts === "object" ? opts.smartCategory : undefined;
  const catNames = Array.isArray(smart) && smart[0] && Array.isArray(smart[0].value) ? objs(smart[0].value) : [];
  let billQty = 0, voidQty = 0, net = 0, rounding = 0, changeAll = 0;
  let price = 0, manual = 0, point = 0, prodDisc = 0, vat = 0;
  const groups = [], campaigns = [], cashiers = [], products = [], categories = [];
  const groupOf = (id, name) => {
    let g = groups.find((x) => x.id === id);
    if (!g) {
      g = { id, name: (typeof name === "string" && name) || PAYMENT_NAMES[id] || "", amount: 0, qty: 0 };
      groups.push(g);
    }
    return g;
  };
  for (const b of objs(bills)) {
    if (isVoidedBill(b)) { voidQty++; continue; } // ตัวเดียวกับ docNumber (billState.js)
    billQty++;
    const must = sat(b.moneyMustPaid);
    net += must;
    rounding += sat(b.rounding);
    manual += sat(b.manualDiscount);
    point += sat(b.pointDiscount && typeof b.pointDiscount === "object" ? b.pointDiscount.value : 0);
    prodDisc += sat(b.productDiscount);
    vat += sat(b.vatAmount);
    // แคชเชียร์ · จัดกลุ่มด้วย cashierId แบบเดิม · ไม่มีค่า = "" ตาม initialCheckOut ของ server เดิม (`srv:apis/shift.js:76`)
    const cid = b.cashierId === undefined || b.cashierId === null ? "" : b.cashierId;
    let k = cashiers.find((x) => x.cashierId === cid);
    if (!k) { k = { cashierId: cid, cashierName: typeof b.cashierName === "string" ? b.cashierName : "", amount: 0 }; cashiers.push(k); }
    k.amount += must;
    // แคมเปญ · แบบเดิม: ไม่มี id = แถวใหม่ทุกครั้ง
    for (const c of objs(b.campaign)) {
      const f = c.id ? campaigns.find((x) => x.id === c.id) : null;
      if (f) { f.discount += sat(c.discount); f.qty++; }
      else campaigns.push({ id: c.id === undefined ? null : c.id, name: typeof c.name === "string" ? c.name : "", qty: 1, discount: sat(c.discount) });
    }
    // สินค้า และหมวดชั้นแรก (ชื่อหมวดจาก smartCategory[0].value แบบเดิม)
    for (const p of objs(b.product)) {
      const tp = sat(p.totalPrice);
      price += tp;
      const f = p.id ? products.find((x) => x.id === p.id) : null;
      if (f) { f.qty = qtyAdd(f.qty, p.qty); f.totalPrice += tp; f.count++; }
      else products.push({ id: p.id === undefined ? null : p.id, name: typeof p.name === "string" ? p.name : "", qty: qtyAdd(0, p.qty), count: 1, totalPrice: tp });
      const cats = Array.isArray(p.category) ? p.category : [];
      const cat = cats.length === 0 ? "id" : cats[0];
      const fc = cat ? categories.find((x) => x.id === cat) : null;
      if (fc) { fc.qty = qtyAdd(fc.qty, p.qty); fc.totalPrice += tp; }
      else {
        const nm = cats.length === 0 ? "No Category" : (catNames.find((x) => x.id === cat) || {}).name;
        categories.push({ id: cat === undefined ? null : cat, name: typeof nm === "string" && nm ? nm : "UnKnow Category", qty: qtyAdd(0, p.qty), totalPrice: tp });
      }
    }
    const channels = objs(b.payment);
    if (channels.length === 0) {
      const g = groupOf(NO_PAYMENT.id, NO_PAYMENT.name);
      g.amount += must;
      g.qty++;
      continue;
    }
    let change = 0;
    let cashId = null;
    for (const c of channels) {
      const g = groupOf(c.id, c.name);
      g.amount += sat(c.amount);
      g.qty++;
      change += Math.max(0, sat(c.change));
      if (cashId === null && isCashChannel(c.id)) cashId = c.id;
    }
    if (change > 0) {
      groupOf(cashId === null ? 1 : cashId).amount -= change; // SC-04: ทอนจากลิ้นชักเสมอ
      changeAll += change;
    }
  }
  const cash = groups.filter((g) => isCashChannel(g.id)).reduce((a, g) => a + g.amount, 0);
  return {
    billQty,
    voidQty,
    totalNet: baht(net),
    totalPrice: baht(price),
    saleRate: billQty > 0 ? baht(Math.sign(net) * Math.round(Math.abs(net) / billQty) || 0) : 0,
    totalRounding: baht(rounding),
    totalChange: baht(changeAll),
    totalManualDiscount: baht(manual),
    totalPointDiscount: baht(point),
    totalProductDiscount: baht(prodDisc),
    totalVat: baht(vat),
    cashSales: baht(cash),
    payments: groups.map((g) => ({ id: g.id, name: g.name, amount: baht(g.amount), qty: g.qty })),
    campaigns: campaigns.map((c) => ({ ...c, discount: baht(c.discount) })),
    cashiers: cashiers.map((c) => ({ ...c, amount: baht(c.amount) })),
    products: products.map((p) => ({ ...p, totalPrice: baht(p.totalPrice) })),
    categories: categories.map((c) => ({ ...c, totalPrice: baht(c.totalPrice) })),
  };
}

// แถวเงินเข้าออกของแอปรุ่นก่อน f95d0366 เก็บ type เป็นข้อความ (live-fit.md H2 · วัด 400 แถวมีแค่ 2 ค่านี้)
//   ทางเขียน `@1b20384a` › src/screens/ShiftScreen.js:248 `'ถอนเงิน'` · :260 `'เติมเงิน'` · ผู้อ่านเดิม :143 `'เติมเงิน'` = บวก นอกนั้นลบ
//   ⇒ map 2 ค่าที่มีจริงเป็น 1/2 · ข้อความอื่นยังไม่นับ (ไม่เดาความหมายของค่าที่ไม่เคยเกิด)
const DURING_TYPE_TEXT = Object.freeze({ "เติมเงิน": 1, "ถอนเงิน": 2 });

function duringSat(duringShift) {
  let cin = 0, cout = 0, entries = 0, ignored = 0;
  const seen = new Set();
  for (const e of Array.isArray(duringShift) ? duringShift : []) {
    if (!e || typeof e !== "object") { ignored++; continue; }
    if (typeof e.entryId === "string" && e.entryId !== "") {
      if (seen.has(e.entryId)) { ignored++; continue; } // SC-46
      seen.add(e.entryId);
    }
    const a = sat(e.amount);
    const type = typeof e.type === "string" && Object.prototype.hasOwnProperty.call(DURING_TYPE_TEXT, e.type) ? DURING_TYPE_TEXT[e.type] : e.type;
    if (a < 0 || (type !== 1 && type !== 2)) { ignored++; continue; }
    entries++;
    if (type === 1) cin += a;
    else cout += a;
  }
  return { cin, cout, entries, ignored };
}

function duringTotals(duringShift) {
  const d = duringSat(duringShift);
  return { cashIn: baht(d.cin), cashOut: baht(d.cout), entries: d.entries, ignored: d.ignored };
}

function creditSat(paidHistory, roundId, rs) {
  let cash = 0, legacyIgnored = 0;
  const groups = [];
  for (const row of objs(paidHistory)) {
    const hasPid = row.paymentId !== undefined && row.paymentId !== null && row.paymentId !== "";
    if (typeof row.shiftId !== "string" || row.shiftId === "" || !hasPid) { legacyIgnored++; continue; }
    const a = sat(row.paid);
    if (a <= 0) continue;
    const p = pickRound(row, paidTimeOf(row), rs, false);
    if (p.roundId === null || p.roundId !== roundId) continue;
    let g = groups.find((x) => x.id === row.paymentId);
    if (!g) { g = { id: row.paymentId, amount: 0, qty: 0 }; groups.push(g); }
    g.amount += a;
    g.qty++;
    if (isCashChannel(row.paymentId)) cash += a;
  }
  return { cash, groups, legacyIgnored };
}

function creditCashReceived(paidHistory, roundId, rounds) {
  const c = creditSat(paidHistory, roundId, normRounds(rounds));
  return { creditCash: baht(c.cash), payments: c.groups.map((g) => ({ id: g.id, amount: baht(g.amount), qty: g.qty })), legacyIgnored: c.legacyIgnored };
}

function roundSat(input) {
  const o = input && typeof input === "object" ? input : {};
  const rs = normRounds(o.rounds);
  const round = rs.find((r) => r.roundId === o.roundId) || null;
  const pos = normPos(o.POSs);
  const mine = [], late = [], outside = [];
  for (const b of objs(o.bills)) {
    const p = pickRound(b, saleTimeOf(b), rs, true, pos);
    const id = b.id === undefined ? null : b.id;
    if (round && p.roundId === round.roundId) {
      const arrived = toMillis(b.arrivedAt);
      const isLate = round.close !== null && arrived !== null && arrived > round.close;
      // บิลแอปเก่า (ไม่มีป้าย) ที่มาถึงหลังรอบปิด ไม่ได้รับผลจากแบบใหม่ (architecture-plan §3 แถว #18) ⇒ ไม่ย้ายเข้ารอบที่ปิดแล้ว
      if (isLate && p.by !== "label") { outside.push({ id, reason: "LEGACY_LATE" }); continue; }
      mine.push(b);
      if (isLate) late.push(b);
    } else if (p.reason !== "OK" && round && p.shiftId === round.shiftId) {
      outside.push({ id, reason: p.reason });
    }
  }
  const s = summarizeShiftBills(mine, o);
  const l = summarizeShiftBills(late, o);
  const d = duringSat(o.duringShift);
  const c = creditSat(o.paidHistory, round ? round.roundId : null, rs);
  const open = Math.max(0, sat(o.openCash));
  const expected = open + sat(s.cashSales) + d.cin - d.cout + c.cash;
  return {
    round,
    expected,
    out: {
      ...s,
      openCash: baht(open),
      cashIn: baht(d.cin),
      cashOut: baht(d.cout),
      creditCash: baht(c.cash),
      creditPayments: c.groups.map((g) => ({ id: g.id, amount: baht(g.amount), qty: g.qty })),
      expectedCash: baht(expected),
      late: { billQty: l.billQty, totalNet: l.totalNet, cash: l.cashSales },
      outside,
      legacyCreditIgnored: c.legacyIgnored,
    },
  };
}

function roundSummary(input) {
  return roundSat(input).out;
}

const ZERO_TEXT = /^[+-]?(0+\.?0*|\.0+)(e[+-]?\d+)?$/i;
// ช่องเงินที่ส่งมาจากคำขอ → { kind: empty|bad|ok, s }
// ทศนิยมจริงเกิน 2 ตำแหน่ง = bad ไม่ปัดเงียบ (เหมือน money.parseMoney) · เศษฐานสองแบบ 0.1+0.2 ไม่นับว่าเกิน
function readInput(v) {
  if (v === undefined || v === null) return { kind: "empty", s: 0 };
  let n;
  if (typeof v === "number") {
    if (!Number.isFinite(v)) return { kind: "bad", s: 0 };
    n = v;
  } else if (typeof v === "string") {
    const t = v.trim();
    if (t === "") return { kind: "empty", s: 0 };
    n = toNumber(t);
    if (n === 0 && !ZERO_TEXT.test(t)) return { kind: "bad", s: 0 };
  } else {
    return { kind: "bad", s: 0 };
  }
  if (n < 0) return { kind: "bad", s: 0 };
  const s = sat(n);
  if (Math.abs(s / 100 - n) > 1e-9 * Math.max(1, Math.abs(n))) return { kind: "bad", s: 0 };
  return { kind: "ok", s };
}

function closeShift(input) {
  const o = input && typeof input === "object" ? input : {};
  const r = roundSat(o);
  const errors = [], warnings = [];
  if (!r.round) errors.push("ROUND_NOT_FOUND");
  const cc = readInput(o.closeCash);
  if (cc.kind === "empty") errors.push("CLOSE_CASH_EMPTY");
  else if (cc.kind === "bad") errors.push("CLOSE_CASH_BAD");
  const wd = readInput(o.closeWithDraw);
  if (wd.kind === "bad") errors.push("WITHDRAW_BAD");
  const ok = errors.length === 0;
  if (ok && wd.s > cc.s) warnings.push("WITHDRAW_OVER");
  return {
    summary: r.out,
    expectedCash: r.out.expectedCash,
    closeCash: ok ? baht(cc.s) : null,
    closeWithDraw: ok ? baht(wd.s) : null,
    closeDiff: ok ? baht(cc.s - r.expected) : null,
    cashRemain: ok ? baht(cc.s - wd.s) : null,
    canClose: ok,
    errors,
    warnings,
  };
}

// สรุปกะในชื่อ field เดิมที่ `shiftHistory` และแอปเก่าอ่าน (`srv:apis/shift.js:218-236` · `app:screens/ShiftScreen.js:272-281` เก็บด้วย `...thisSummary`)
//   รับผลของ closeShift ที่ canClose · ไม่งั้น null
//   ต่างจากเดิมโดยตั้งใจ: thisPayment ไม่พา `change` ติดไป (SC-29 แอปเก่าหักซ้ำ) · thisTotalCash รวม '001' และหักเงินทอนทั้งบิล (SC-07 SC-04)
//   currentCash เขียนค่าจริง (SC-28 · เดิมค้าง 0) · closeDiff เป็นตัวเลข · field ใหม่ (lateSales ฯลฯ) server เติมเองในก้อน 4
function shiftHistoryFields(closeResult) {
  if (!closeResult || typeof closeResult !== "object" || closeResult.canClose !== true || !closeResult.summary) return null;
  const s = closeResult.summary;
  return {
    thisPayment: s.payments.map((p) => ({ id: p.id, name: p.name, amount: p.amount, qty: p.qty })),
    thisProduct: s.products.map((p) => ({ id: p.id, name: p.name, thisQty: p.qty, count: p.count, thisTotalPrice: p.totalPrice })),
    thisCategory: s.categories.map((c) => ({ id: c.id, thisQty: c.qty, thisTotalPrice: c.totalPrice, name: c.name })),
    thisSelectedQty: s.billQty,
    thisVoidQty: s.voidQty,
    saleRate: s.saleRate,
    thisTotalNet: s.totalNet,
    thisTotalPrice: s.totalPrice,
    thisRounding: s.totalRounding,
    thisTotalCash: s.cashSales,
    thisTotalChange: s.totalChange,
    thisCampaign: s.campaigns.map((c) => ({ name: c.name, qty: c.qty, discount: c.discount, id: c.id })),
    totalManualDiscount: s.totalManualDiscount,
    totalPointDiscount: s.totalPointDiscount,
    totalProductDiscount: s.totalProductDiscount,
    thisCashier: s.cashiers.map((c) => ({ cashierId: c.cashierId, cashierName: c.cashierName, amount: c.amount })),
    thisVat: s.totalVat,
    currentCash: closeResult.expectedCash,
    closeDiff: closeResult.closeDiff,
  };
}

// SC-28 · เงินคาดของประวัติกะ = นับได้ − ผลต่าง (doc เก่าเก็บ currentCash ค้าง 0 · ข้อเสนอ `แก้`)
//   closeDiff ไม่มีค่า = บอกไม่ได้ ⇒ null · ค่าข้อความอ่านแบบเดิม (Number('') = 0 ตอนปิดกะเดิม)
function historyExpectedCash(doc) {
  if (!doc || typeof doc !== "object") return null;
  const d = doc.closeDiff;
  if (d === undefined || d === null || d === "") return null;
  if (typeof d === "number" && !Number.isFinite(d)) return null;
  return baht(sat(doc.closeCash) - sat(d));
}

// D1 · SC-30 · เลขกะ: วันเดียวกับ lastShiftDate = กะถัดไป · คนละวัน = 1 (`app:screens/ShiftScreen.js:113-125`)
//   วันคิดจาก `now` ที่ส่งเข้ามาตอนกดเปิดกะ (ไม่อ่านนาฬิกาเอง · เดิมค้างค่าใน useMemo ข้ามเที่ยงคืน)
//   วัน = YYYYMMDD ปฏิทินเวลาไทย (รูปเดียวกับ stringYMDHMS3 เดิมบนเครื่องในไทย) · ไม่ใช่วันธุรกิจตาม cutOff (คงตามเดิม)
//   shiftCount เป็นข้อความหรือขยะได้ (เดิม Number(ขยะ)+1 = NaN) ⇒ อ่านไม่ได้ = 0
function nextShiftCount(input) {
  const o = input && typeof input === "object" ? input : {};
  const now = toMillis(o.now);
  if (now === null) return { ok: false, count: null, shiftDate: null, errors: ["NOW_BAD"] };
  const d = new Date(now + 7 * 3600000);
  const shiftDate = String(d.getUTCFullYear()).padStart(4, "0") + String(d.getUTCMonth() + 1).padStart(2, "0") + String(d.getUTCDate()).padStart(2, "0");
  const last = o.lastShiftDate === undefined || o.lastShiftDate === null ? "" : String(o.lastShiftDate);
  const prev = Math.max(0, Math.trunc(toNumber(o.shiftCount)));
  return { ok: true, count: last === shiftDate ? prev + 1 : 1, shiftDate, errors: [] };
}

function checkDuringEntry(input) {
  const o = input && typeof input === "object" ? input : {};
  const errors = [], warnings = [];
  if (o.type !== 1 && o.type !== 2) errors.push("TYPE_BAD");
  const a = readInput(o.amount);
  if (a.kind === "empty") errors.push("AMOUNT_EMPTY");
  else if (a.kind === "bad" || a.s === 0) errors.push("AMOUNT_BAD");
  if (errors.length === 0 && o.type === 2 && o.expectedCash !== undefined && o.expectedCash !== null && a.s > sat(o.expectedCash)) {
    warnings.push("CASH_OUT_OVER");
  }
  return { ok: errors.length === 0, amount: errors.length === 0 ? baht(a.s) : null, errors, warnings };
}

module.exports = {
  CASH_IDS,
  isCashChannel,
  toMillis,
  roundOf,
  summarizeShiftBills,
  duringTotals,
  creditCashReceived,
  roundSummary,
  closeShift,
  checkDuringEntry,
  shiftHistoryFields,
  historyExpectedCash,
  nextShiftCount,
};

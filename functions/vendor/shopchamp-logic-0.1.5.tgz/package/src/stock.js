// stock — แผนตัด/คืนสต๊อกที่รวมกลุ่มผูก (stockLink) และต้นทุนถัวเฉลี่ยถ่วงน้ำหนัก (ใบ DEV-0001 · ก้อน 3)
// ฟังก์ชันล้วน ไม่แตะ Firebase · ผู้เรียก (แอป/API) อ่าน doc สดใน transaction แล้วส่งเข้ามา และเขียนผลเอง
//
// รูปข้อมูลของแอปเดิมที่สูตรนี้ต้องเคารพ (✅ อ่านจาก app @804ba8ff · lanes/dev/source/compare/old-logic/stock.js):
//   - สินค้าเดี่ยว: `stock` = จำนวนในหน่วยของตัวเอง · `cost` = ต้นทุนต่อหน่วยของตัวเอง
//   - กลุ่มผูก: ทุกตัวในกลุ่มเก็บ `stock` = ยอดรวมในหน่วยเล็กสุดค่าเดียวกัน · `cost` = ต้นทุนต่อหน่วยเล็กสุด × `linkMultiply` ของตัวนั้น
//     `linkDetail` = สมาชิกทั้งกลุ่ม เรียงตัวคูณมากไปน้อย (StockLinkSettingScreen4.js:46 · sort.js normalSort)
//   - ขาย 1 ชิ้นของสินค้าผูก = ตัด qty × linkMultiply ออกจากทุก doc ในกลุ่ม (CheckoutScreen.js:787-799)
//
// ปิดบั๊ก (ฝั่งสูตร · ตาม lanes/dev/source/bug-decisions/):
//   #22 K05 / ST-053  รับสินค้าตัวเดิมซ้ำในร่าง เฉลี่ย (เดิม+ใหม่)/2 ⇒ ถ่วงด้วยจำนวน (mergeReceiveLines)
//   #22 K05 / F16 / ST-032  แก้ใบรับ เอาผลต่างมูลค่าทั้งใบลงสต๊อกที่เหลือ ได้ทุนติดลบ ⇒ ถ้าของก่อนใบนี้ขายหมดแล้ว ทุน = ทุนแถวใหม่ · ผลติดลบ = คงทุนเดิม (applyReceiveEdit)
//   #22 K05 / ST-059  ผูกกลุ่มที่ยอดรวม 0 หรือติดลบ ได้ทุน 0 หรือติดลบ ⇒ ถ่วงเฉพาะตัวที่ยอด > 0 · ไม่มีเลย = เฉลี่ยทุนต่อหน่วยเล็กสุด (buildLinkGroup)
//   ST-005  ยกเลิกบิลคืนตามค่าตั้งปัจจุบัน ⇒ บิลใหม่เก็บ `stockSnapshot` ตอนขาย (stockSnapshotOf) แล้วคืนตามนั้น · บิลเก่าไม่มีค่านี้ คืนแบบเดิม
//           และ qty/totalCost ของแถวบิลไม่ถูกค่าของสินค้าปัจจุบันทับ
//   ST-029 ST-030  แก้ใบรับด้วยค่าว่าง/ไม่ใช่ตัวเลข ⇒ ปัด ไม่ถือเป็น 0
//   ST-039  ตัวคูณเก็บเป็นสตริง ⇒ อ่านเป็นเลขก่อนเรียง/คำนวณ · ตัวใหม่คืนเป็นเลข
//   ST-040 ST-058  ตัวคูณ '0' · < 1 · ทศนิยม · 1 ซ้ำ · ไม่มีเพดาน ⇒ ด่านใน buildLinkGroup · ตอนขาย ตัวคูณพัง = ตัดตัวเองและแจ้ง issue
//   ST-044  จำนวนเบิกว่างหรือ 0 ⇒ ปัดแถว (planStockDeduction ตัวเลือก requirePositiveQty)
//   ST-051 ST-117 ST-118  ค่าหาย/ผิดรูป ทำ stock หรือ cost เป็น NaN ⇒ อ่านผ่าน money.toNumber จุดเดียว · ทุนที่คิดไม่ได้ = คงทุนเดิม
//   ST-057  เลิกผูกตอนยอดติดลบหรือมีเศษ ยอดหาย ⇒ เศษและยอดติดลบไปอยู่หน่วยเล็กสุด (spreadLinkStock)
//   ST-058 ST-119  ทศนิยมลอย ⇒ ปัด 4 ตำแหน่ง "จุดเดียวตอนคืนค่า" ไม่ปัดระหว่างสะสม
//   ST-060 ST-061 ST-088 ST-019 ST-056  กลุ่มว่าง · นับสต๊อกไม่เหมือนกัน · ตัวซ้ำ · อยู่กลุ่มอื่นแล้ว · ถูกลบแล้ว ⇒ ด่านใน buildLinkGroup
//   ST-093  จำนวน/ทุนเป็นสตริง ('5' ต่อเป็น '05') ⇒ อ่านเป็นเลขก่อนบวก
//   ST-120  สินค้ามีตัวคูณแต่ไม่มี linkDetail แล้วล้มทั้งใบ ⇒ ตัดตัวเอง qty × ตัวคูณ (doc เก็บยอดหน่วยเล็กสุด) และแจ้ง issue ไม่ throw
//   ST-088  linkDetail มี id ซ้ำ เดิมตัด/รับเข้าตัวนั้น 2 เท่า ⇒ นับครั้งเดียว + issue duplicate_link_member
//           สมาชิกที่ตัวคูณพังยังถูกตัด/คืน/รับเข้าเหมือนเดิม + issue bad_member_multiply · แก้ใบรับที่ตัวคูณพังทั้ง doc และ linkDetail = ปัด
//   ST-118 ST-119 (ใบเบิก)  ทุนรวมแถวเบิก: ทุนหาย = null ไม่ใช่ 0 · ปัด 4 ตำแหน่ง (requisitionLineCost)
//   ST-009 (ต้องเคาะ · ยึดทางแรกตาม bug-decisions/index.md "ที่เหลือ")  ลบสมาชิกในกลุ่ม ⇒ ยอดย้ายไปหน่วยที่เหลือ (spreadLinkStock removeId)
//
// ❌ ไม่เปลี่ยนจากเดิม (ตั้งใจ):
//   - ST-011 (ต้องเคาะ ยังไม่มีทาง): รับเข้าตอนสต๊อกเดิม ≤ 0 ใช้ทุนของที่รับเข้าทั้งก้อน ตามเดิม
//   - ST-117: สูตรคืนต้นทุนตอนยกเลิกบิลคงเดิม เพิ่มแค่ด่านกัน NaN
//   - ST-140 ST-146 (คงเดิม): ตัด/เบิกจนติดลบได้ · ไม่ตัดยอดติดลบออก
//   - ST-148 (คงเดิม): เลิกผูกไม่คืนทุนก่อนผูก
//   - ขายด้วยจำนวน ≤ 0 ยังตัดตามจำนวนนั้นเหมือนเดิม (ไม่มีรหัสบั๊ก)
//
// ยกแบบจากแอปพี่น้อง: การปัด 4 ตำแหน่งที่จุดออก ไม่ปัดระหว่างสะสม (packages/logic/src/bom.js roundBomValue)
//
// สัญญา (ทุกตัว ❌ ไม่ throw · ❌ ไม่แก้ของที่ส่งเข้ามา · ตัวเลขที่คืน finite เสมอ):
//   roundStock(n) → ปัด 4 ตำแหน่งแบบสมมาตร (-2.00005 → -2.0001) · ไม่ใช่เลข finite = 0 · ไม่มี -0
//   readLinkMultiply(v) → เลข > 0 หรือ null (รับสตริงเก่า)
//   normalizeLinkDetail(linkDetail) → สำเนาแถวที่มี id และตัวคูณ > 0 · ตัวคูณเป็นเลข · ตัด id ซ้ำ (ตัวแรกชนะ) · เรียงมากไปน้อย (เท่ากันคงลำดับ)
//     ใช้แจกยอดตอนเลิกผูก (spreadLinkStock) เท่านั้น · การตัด/คืน/รับเข้า/แก้ใบรับใช้ linkMembers (ภายใน) ที่ไม่ทิ้งสมาชิกตัวคูณพัง
//   stockSnapshotOf(product) → { stockCountStatus, linkMultiply, linkIds } สำหรับเก็บในแถวบิลตอนขาย
//   planStockDeduction(lines, { requirePositiveQty }) → { moves:[{id, qty}], soldIds, issues:[{index, id, code, member?}] }
//     - qty ใน moves = หน่วยของ doc (กลุ่มผูก = หน่วยเล็กสุด) · เรียงตามที่เจอครั้งแรก
//   stockAfterMove(stock, delta) → stock + delta (ขาย/เบิก = -qty · คืน = +qty)
//   planVoidReturn(lines, getProduct) → { moves:[{id, qty, totalCost}], issues } · totalCost = null เมื่อมีแถวที่ไม่รู้ทุน
//   restoreOnVoid(doc, move) → { stock, cost }
//   mergeReceiveLines(lines) → { rows, issues } · row เดี่ยว { id, qty, cost, totalCost, exps } · row ผูก { id, linkId, totalStock, totalCost, exps }
//   requisitionLineCost(qty, cost) → ทุนรวมของแถวเบิก หรือ null เมื่อไม่รู้ทุน
//   applyReceive(doc, row) → { stock, cost }
//   applyReceiveEdit(editedDoc, groupDocs, edit) → { ok, error, updates:[{id, stock, cost}], updateStock }
//   buildLinkGroup(products, { upgrade }) → { ok, errors, stock, averageCost, linkDetail, members }
//   spreadLinkStock(total, linkDetail, { removeId }) → [{ id, stock }] ใหญ่ไปเล็ก

const { toNumber } = require("./money");

const ROUND_DP = 4;
const SCALE = 10 ** ROUND_DP;
const MAX_LINK_MULTIPLY = 100000; // ❓ เพดานตัวคูณ (ST-058 "ไม่มีเพดาน") · ค่าที่เลือกเอง ยังไม่ได้เทียบข้อมูลจริง

function roundStock(n) {
  if (typeof n !== "number" || !Number.isFinite(n)) return 0;
  const scaled = Math.abs(n) * SCALE;
  if (scaled >= 2 ** 52) return n; // ใหญ่เกินกว่าทศนิยม 4 ตำแหน่งจะมีความหมาย ⇒ คืนตามเดิม
  const r = Math.round(Number(scaled.toPrecision(15))) / SCALE;
  const out = n < 0 ? -r : r;
  return out === 0 ? 0 : out;
}

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const idOf = (v) => (typeof v === "string" && v ? v : null);

function readLinkMultiply(v) {
  const n = toNumber(v);
  return n > 0 ? n : null;
}

function normalizeLinkDetail(linkDetail) {
  if (!Array.isArray(linkDetail)) return [];
  const seen = new Set();
  const out = [];
  for (const row of linkDetail) {
    if (!isObj(row)) continue;
    const id = idOf(row.id);
    const m = readLinkMultiply(row.linkMultiply);
    if (!id || m === null || seen.has(id)) continue;
    seen.add(id);
    out.push({ ...row, id, linkMultiply: m });
  }
  return out
    .map((r, i) => [r, i])
    .sort((a, b) => b[0].linkMultiply - a[0].linkMultiply || a[1] - b[1])
    .map(([r]) => r);
}

// สมาชิกทุกตัวในกลุ่มตามลำดับที่เก็บ (ไม่ทิ้งตัวที่ตัวคูณพัง) · id ซ้ำ = นับครั้งเดียว · ทั้ง 2 กรณีแจ้ง issue
//   ใช้กับการตัด/คืน/รับเข้า: ทุก doc ในกลุ่มเก็บยอดรวมค่าเดียวกัน ⇒ ต้องขยับทุกตัว แม้ตัวคูณของตัวนั้นอ่านไม่ได้
//   ไม่งั้นยอดของตัวนั้นห่างจากกลุ่มเงียบ ๆ (ผลตรวจ ผิด-3) · ตัวคูณของสมาชิก = null เมื่ออ่านไม่ได้
function linkMembers(linkDetail) {
  const rows = [];
  const issues = [];
  if (!Array.isArray(linkDetail)) return { rows, issues };
  const seen = new Set();
  for (const row of linkDetail) {
    if (!isObj(row)) continue;
    const id = idOf(row.id);
    if (!id) continue;
    if (seen.has(id)) { issues.push({ code: "duplicate_link_member", member: id }); continue; }
    seen.add(id);
    const m = readLinkMultiply(row.linkMultiply);
    if (m === null) issues.push({ code: "bad_member_multiply", member: id });
    rows.push({ id, linkMultiply: m });
  }
  return { rows, issues };
}

// สินค้า 1 แถวตัด doc ไหนบ้าง คูณเท่าไร · ความหมาย "ผูก" ใช้ truthy แบบเดิม (CheckoutScreen.js:788 `if(linkMultiply)`)
//   ST-120 มีตัวคูณแต่ไม่มี linkDetail ⇒ ตัด qty × ตัวคูณ จากตัวเอง: ตัวคูณที่ truthy ถูกเขียนคู่กับ linkId และ linkDetail
//   ตอนผูกเท่านั้น (StockLinkSettingScreen4.js:105-113) · เลิกผูก/ลบสมาชิกล้างเป็น '' (StockLinkScreen.js:129-141 · useLocalStock.js:162-172)
//   ⇒ doc นี้เก็บยอดเป็นหน่วยเล็กสุด · ตัดแค่ qty = ขาดไปเท่าตัวคูณ (ผลตรวจ ผิด-2)
function resolveTargets(line) {
  const id = idOf(line.id);
  const self = id ? [id] : [];
  if (!line.linkMultiply) return { multiply: 1, targets: self, link: false, issues: id ? [] : [{ code: "missing_id" }] };
  const m = readLinkMultiply(line.linkMultiply);
  if (m === null) return { multiply: 1, targets: self, link: false, issues: [{ code: "bad_link_multiply" }] };
  const g = linkMembers(line.linkDetail);
  if (g.rows.length) return { multiply: m, targets: g.rows.map((r) => r.id), link: true, issues: g.issues };
  return { multiply: m, targets: self, link: Boolean(id), issues: [{ code: "missing_link_detail" }] };
}

const pushIssues = (issues, index, id, list) => { for (const x of list) issues.push({ index, id, ...x }); };

function stockSnapshotOf(product) {
  const p = isObj(product) ? product : {};
  const r = resolveTargets(p);
  return {
    stockCountStatus: Boolean(p.stockCountStatus),
    linkMultiply: r.link ? r.multiply : 0,
    linkIds: r.link ? r.targets.slice() : [],
  };
}

function planStockDeduction(lines, options) {
  const requirePositiveQty = Boolean(isObj(options) && options.requirePositiveQty);
  const rows = Array.isArray(lines) ? lines : [];
  const acc = new Map();
  const soldIds = [];
  const issues = [];
  rows.forEach((line, index) => {
    if (!isObj(line) || !line.stockCountStatus) return;
    const id = idOf(line.id);
    const qty = toNumber(line.qty);
    if (requirePositiveQty && !(qty > 0)) {
      issues.push({ index, id, code: "bad_qty" });
      return;
    }
    const r = resolveTargets(line);
    pushIssues(issues, index, id, r.issues);
    if (!r.targets.length) return;
    if (id && !soldIds.includes(id)) soldIds.push(id);
    const base = qty * r.multiply;
    for (const t of r.targets) acc.set(t, (acc.get(t) || 0) + base);
  });
  return {
    moves: Array.from(acc, ([id, q]) => ({ id, qty: roundStock(q) })),
    soldIds,
    issues,
  };
}

function stockAfterMove(stock, delta) {
  return roundStock(toNumber(stock) + toNumber(delta));
}

function planVoidReturn(lines, getProduct) {
  const rows = Array.isArray(lines) ? lines : [];
  const lookup = typeof getProduct === "function" ? getProduct : () => undefined;
  const acc = new Map();
  const issues = [];
  rows.forEach((line, index) => {
    if (!isObj(line)) return;
    const id = idOf(line.id);
    const snap = isObj(line.stockSnapshot) ? line.stockSnapshot : null;
    let src;
    if (snap) {
      const linkIds = Array.isArray(snap.linkIds) ? snap.linkIds : [];
      src = {
        id,
        stockCountStatus: snap.stockCountStatus,
        linkMultiply: snap.linkMultiply,
        linkDetail: linkIds.map((x) => ({ id: x, linkMultiply: 1 })),
      };
    } else {
      // บิลเก่าไม่มี snapshot ⇒ ใช้ค่าตั้งของสินค้าปัจจุบันแบบเดิม (BillHistoryScreen.js:347-352)
      let product;
      try { product = id ? lookup(id) : undefined; } catch (e) { product = undefined; }
      if (!isObj(product)) {
        if (!line.stockCountStatus) issues.push({ index, id, code: "unknown_product" });
        product = {};
      }
      src = { ...line, ...product, id };
    }
    if (!src.stockCountStatus) return;
    const r = resolveTargets(src);
    pushIssues(issues, index, id, r.issues);
    if (!r.targets.length) return;
    const base = toNumber(line.qty) * r.multiply;
    // ทุนรวมของแถวหาย/อ่านไม่ได้ = ไม่รู้ทุน (null) ไม่ใช่ทุน 0 ⇒ restoreOnVoid คงทุนเดิม (ST-117)
    const value = strictNumber(line.totalCost);
    if (value === null) issues.push({ index, id, code: "missing_total_cost" });
    for (const t of r.targets) {
      const cur = acc.get(t) || { qty: 0, totalCost: 0 };
      acc.set(t, { qty: cur.qty + base, totalCost: cur.totalCost === null || value === null ? null : cur.totalCost + value });
    }
  });
  return {
    moves: Array.from(acc, ([id, v]) => ({ id, qty: roundStock(v.qty), totalCost: v.totalCost === null ? null : roundStock(v.totalCost) })),
    issues,
  };
}

function restoreOnVoid(doc, move) {
  const d = isObj(doc) ? doc : {};
  const m0 = isObj(move) ? move : {};
  const oldStock = toNumber(d.stock);
  const prevCost = toNumber(d.cost);
  const qty = toNumber(m0.qty);
  const value = strictNumber(m0.totalCost); // null = ไม่รู้ทุน ⇒ ได้ NaN แล้วด่านข้างล่างคงทุนเดิม
  const totalStock = oldStock + qty;
  let newCost = value === null ? NaN : value / qty;
  if (value === null) {
    // ไม่รู้ทุน ⇒ คืนจำนวน แต่คงทุนเดิม
  } else if (d.linkId) {
    const mult = toNumber(d.linkMultiply);
    newCost = (value * mult) / qty;
    if (totalStock > 0 && oldStock > 0) newCost = (value * mult + prevCost * oldStock) / totalStock;
  } else if (totalStock > 0 && oldStock > 0) {
    newCost = (oldStock * prevCost + value) / totalStock;
  }
  if (!Number.isFinite(newCost)) newCost = prevCost;
  return { stock: roundStock(totalStock), cost: roundStock(newCost) };
}

function mergeReceiveLines(lines) {
  const rows = Array.isArray(lines) ? lines : [];
  const acc = new Map();
  const issues = [];
  const pushExp = (row, exp) => { if (exp) row.exps.push(exp); };
  rows.forEach((item, index) => {
    if (!isObj(item)) return;
    const id = idOf(item.id);
    if (!id) { issues.push({ index, id, code: "missing_id" }); return; }
    const qty = toNumber(item.qty);
    const cost = toNumber(item.cost);
    if (item.linkId) {
      // ตัวคูณของตัวที่รับ: จาก linkDetail ก่อนแบบเดิม (ImportProductScreen.js:375) · อ่านไม่ได้ใช้ของแถว
      // ไม่มีตัวเองใน linkDetail แต่แถวมีตัวคูณ (ST-120) ⇒ ลงตัวเองตัวเดียวเป็นหน่วยเล็กสุด
      const g = linkMembers(item.linkDetail);
      const own = g.rows.find((a) => a.id === id);
      const em = (own && own.linkMultiply) || readLinkMultiply(item.linkMultiply);
      const targets = own ? g.rows : [{ id }];
      if (em !== null) {
        if (own) pushIssues(issues, index, id, g.issues);
        else issues.push({ index, id, code: "missing_link_detail" });
        const totalStock = qty * em;
        const totalCost = qty * cost;
        for (const a of targets) {
          const key = "L:" + a.id;
          const cur = acc.get(key) || { id: a.id, linkId: item.linkId, totalStock: 0, totalCost: 0, exps: [] };
          cur.totalStock += totalStock;
          cur.totalCost += totalCost;
          pushExp(cur, item.exp);
          acc.set(key, cur);
        }
        return;
      }
      issues.push({ index, id, code: own ? "bad_link_multiply" : "missing_link_detail" });
    }
    const key = "S:" + id;
    const cur = acc.get(key) || { id, qty: 0, totalCost: 0, firstCost: cost, exps: [] };
    cur.qty += qty;
    cur.totalCost += qty * cost;
    pushExp(cur, item.exp);
    acc.set(key, cur);
  });
  const out = [];
  for (const r of acc.values()) {
    if (r.linkId !== undefined) {
      out.push({ id: r.id, linkId: r.linkId, totalStock: roundStock(r.totalStock), totalCost: roundStock(r.totalCost), exps: r.exps });
    } else {
      const unit = r.qty > 0 ? r.totalCost / r.qty : r.firstCost;
      out.push({ id: r.id, qty: roundStock(r.qty), cost: roundStock(unit), totalCost: roundStock(r.totalCost), exps: r.exps });
    }
  }
  return { rows: out, issues };
}

// ทุนรวมของแถวเบิก (RequisitionScreen.js:86,90) · ST-118: ทุนว่าง/null/อ่านไม่ได้ = ไม่รู้ทุน (null) ไม่ใช่ 0 · ST-119: ปัด 4 ตำแหน่ง
function requisitionLineCost(qty, cost) {
  const c = strictNumber(cost);
  if (c === null) return null;
  return roundStock(toNumber(qty) * c);
}

function applyReceive(doc, row) {
  const d = isObj(doc) ? doc : {};
  const r = isObj(row) ? row : {};
  const oldStock = toNumber(d.stock);
  const prevCost = toNumber(d.cost);
  let newStock;
  let newCost;
  if (r.linkId) {
    const mult = toNumber(d.linkMultiply);
    const add = toNumber(r.totalStock);
    const value = toNumber(r.totalCost);
    newStock = oldStock + add;
    newCost = (value * mult) / add;
    if (newStock > 0 && oldStock > 0) newCost = (value * mult + prevCost * oldStock) / newStock;
  } else {
    const add = toNumber(r.qty);
    const unit = toNumber(r.cost);
    const value = r.totalCost === undefined ? add * unit : toNumber(r.totalCost);
    newStock = oldStock + add;
    newCost = unit;
    if (newStock > 0 && oldStock > 0) newCost = (oldStock * prevCost + value) / newStock;
  }
  if (!Number.isFinite(newCost)) newCost = prevCost;
  return { stock: roundStock(newStock), cost: roundStock(newCost) };
}

// ค่าที่ผู้ใช้กรอก: ว่าง · null · undefined · ไม่ใช่ตัวเลขทั้งก้อน = null (ไม่ใช่ 0) · ST-029 ST-030
function strictNumber(v) {
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  if (typeof v !== "string" || v.trim() === "") return null;
  const n = toNumber(v);
  return n !== 0 || /^[+-]?0*(\.0*)?$/.test(v.trim().replace(/,/g, "")) ? n : null;
}

// แก้แถวในใบรับ · ทุกค่าเป็นหน่วยเล็กสุด · S = คงเหลือตอนนี้ · a = ทุนเฉลี่ยตอนนี้
//   - ของที่เหลือยังมีส่วนที่มาก่อนใบนี้ (S − oldQ > 0): ถอนมูลค่าแถวเดิม ลงมูลค่าแถวใหม่ = สูตรเดิมทุกอย่าง
//     (a·S − oldV + newV) / (S − oldQ + newQ)
//   - ของก่อนใบนี้ขายหมดแล้ว (S − oldQ ≤ 0): ที่เหลือมาจากแถวนี้ล้วน ⇒ ทุน = ทุนต่อหน่วยของแถวใหม่ (K05 · ไม่เอาผลต่างทั้งใบลงของที่เหลือ)
//   - คงเหลือหลังแก้ ≤ 0 · ผลติดลบ · คิดไม่ได้ ⇒ คงทุนเดิม (F16 · ST-032)
function reverseThenApply(S, a, oldQ, oldV, newQ, newV) {
  const S1 = S - oldQ;
  const S2 = S1 + newQ;
  let c = a;
  if (S2 > 0) {
    if (S1 > 0) c = (a * S - oldV + newV) / S2;
    else if (newQ > 0) c = newV / newQ;
  }
  if (!Number.isFinite(c) || c < 0) c = a;
  return { stock: S2, cost: c };
}

function applyReceiveEdit(editedDoc, groupDocs, edit) {
  const fail = (error) => ({ ok: false, error, updates: [], updateStock: 0 });
  const d = isObj(editedDoc) ? editedDoc : null;
  const e = isObj(edit) ? edit : {};
  if (!d) return fail("missing_doc");
  const nq = strictNumber(e.nextQty);
  const nc = strictNumber(e.nextCost);
  if (nq === null || nq < 0) return fail("bad_next_qty");
  if (nc === null || nc < 0) return fail("bad_next_cost");
  const pq = toNumber(e.prevQty);
  const pc = toNumber(e.prevCost);
  const id = idOf(e.id);
  const updates = [];
  let updateStock = 0;
  if (d.linkId) {
    const links = linkMembers(d.linkDetail).rows;
    const own = links.find((a) => a.id === id);
    if (!own) return fail("missing_link_detail");
    const docs = isObj(groupDocs) ? groupDocs : {};
    const em = own.linkMultiply || readLinkMultiply(d.linkMultiply);
    if (em === null) return fail("bad_link_multiply:" + id);
    for (const a of links) {
      const g = docs[a.id];
      if (!isObj(g)) return fail("missing_doc:" + a.id);
      // สมาชิกที่ตัวคูณอ่านไม่ได้ทั้งใน doc และ linkDetail ⇒ ปัดทั้งใบ ไม่ข้ามตัวนั้นเงียบ ๆ (ผลตรวจ ผิด-3)
      const m = readLinkMultiply(g.linkMultiply) || a.linkMultiply;
      if (m === null) return fail("bad_link_multiply:" + a.id);
      const r = reverseThenApply(toNumber(g.stock), toNumber(g.cost) / m, pq * em, pq * pc, nq * em, nq * nc);
      updates.push({ id: a.id, stock: roundStock(r.stock), cost: roundStock(r.cost * m) });
      if (a.id === id) updateStock = roundStock(r.stock / m);
    }
  } else {
    const r = reverseThenApply(toNumber(d.stock), toNumber(d.cost), pq, pq * pc, nq, nq * nc);
    updates.push({ id, stock: roundStock(r.stock), cost: roundStock(r.cost) });
    updateStock = roundStock(r.stock);
  }
  return { ok: true, error: null, updates, updateStock };
}

function buildLinkGroup(products, options) {
  const upgrade = Boolean(isObj(options) && options.upgrade);
  const list = Array.isArray(products) ? products : [];
  const errors = [];
  const bad = (code, id) => errors.push(id ? { code, id } : { code });
  if (list.length < 2) bad("too_few_members");
  const ids = new Set();
  const mults = new Set();
  const counts = new Set();
  const members = [];
  for (const p of list) {
    if (!isObj(p)) { bad("bad_member"); continue; }
    const id = idOf(p.id);
    if (!id) { bad("missing_id"); continue; }
    if (ids.has(id)) bad("duplicate_id", id);
    ids.add(id);
    if (p.deleted) bad("deleted_member", id);
    if (p.linkId) bad("already_linked", id);
    const m = toNumber(p.linkMultiply);
    if (!Number.isInteger(m) || m < 1 || m > MAX_LINK_MULTIPLY) { bad("bad_link_multiply", id); continue; }
    if (mults.has(m)) bad("duplicate_multiply", id);
    mults.add(m);
    counts.add(Boolean(p.stockCountStatus));
    members.push({ p, id, m });
  }
  if (members.length && !mults.has(1)) bad("missing_base_unit");
  if (counts.size > 1) bad("mixed_stock_count");
  if (errors.length) return { ok: false, errors, stock: 0, averageCost: 0, linkDetail: [], members: [] };

  let total = 0;
  let wBase = 0;
  let wValue = 0;
  for (const { p, m } of members) {
    const s = toNumber(p.stock);
    const c = strictNumber(p.cost); // ทุนว่าง/อ่านไม่ได้ = ไม่รู้ทุน ไม่ใช่ทุน 0 (ST-059) ⇒ ไม่เอาไปถ่วง
    total += s * m;
    if (s > 0 && c !== null && c >= 0) { wBase += s * m; wValue += s * c; }
  }
  let avg = 0;
  if (wBase > 0) avg = wValue / wBase;
  else {
    const per = members.map(({ p, m }) => (strictNumber(p.cost) || 0) / m).filter((x) => x > 0);
    if (per.length) avg = per.reduce((a, b) => a + b, 0) / per.length;
  }
  const linkDetail = members
    .map(({ p, id, m }) => ({ linkMultiply: m, unit: p.unit, id }))
    .sort((a, b) => b.linkMultiply - a.linkMultiply);
  const stock = roundStock(total);
  const out = members.map(({ id, m }) => {
    let linkNext = "";
    let linkQty = 0;
    if (upgrade) {
      const next = linkDetail.filter((a) => a.linkMultiply > m).pop();
      if (next) { linkNext = next.id; linkQty = roundStock(next.linkMultiply / m); }
    }
    return { id, stock, cost: roundStock(avg * m), linkMultiply: m, linkNext, linkQty, linkDetail };
  });
  return { ok: true, errors: [], stock, averageCost: roundStock(avg), linkDetail, members: out };
}

function spreadLinkStock(total, linkDetail, options) {
  const removeId = isObj(options) ? options.removeId : undefined;
  const links = normalizeLinkDetail(linkDetail).filter((r) => r.id !== removeId);
  if (!links.length) return [];
  let x = toNumber(total);
  const last = links.length - 1;
  return links.map((link, i) => {
    if (i === last) return { id: link.id, stock: roundStock(x / link.linkMultiply) };
    if (x <= 0) return { id: link.id, stock: 0 };
    const q = Math.floor(roundStock(x / link.linkMultiply));
    x = roundStock(x - q * link.linkMultiply);
    return { id: link.id, stock: q };
  });
}

module.exports = {
  roundStock,
  readLinkMultiply,
  normalizeLinkDetail,
  stockSnapshotOf,
  planStockDeduction,
  stockAfterMove,
  planVoidReturn,
  restoreOnVoid,
  mergeReceiveLines,
  requisitionLineCost,
  applyReceive,
  applyReceiveEdit,
  buildLinkGroup,
  spreadLinkStock,
  MAX_LINK_MULTIPLY,
};

// businessDay — วันธุรกิจของร้านตามเวลาตัดรอบ (`shop.cutOff`) · ฟังก์ชันล้วน ไม่แตะฐาน ไม่อ่านนาฬิกา (ก้อน 3 · DEV-0001)
//
// แทนสูตรเดิมในแอป shopcham_merchant_2025@804ba8ff:
//   · `Utility/function.js:424-437` startCutoff · `:451-464` endCutoff · `:766-772` manageCutOff (ช่วงวันของรายงาน)
//   · `screens/BillHistoryScreen.js:240-241` (และ `:307-308` `:579-580`) ส่งช่วงนั้นให้ `/bill/summary`
//   · `screens/CheckoutScreen.js:755` billDate = วันปฏิทินของเครื่อง (เว็บรายงานค้นด้วยค่านี้)
//   · `redux/shopSlice.js:58` อ่าน cutOff ด้วย formatTime
//   สำเนาคำต่อคำของสูตรเดิมอยู่ที่ `lanes/dev/source/compare/old-logic/businessDay.js` · ตัวเทียบอยู่ใน `test/businessDay.test.js`
//   นิยามยกแบบจากบ้านพี่น้อง (`packages/logic/src/businessDay.js` + `date.js` startCutoff/endCutoff ตัวที่ไม่อ่านนาฬิกา)
//
// 🔒 นิยามเดียวทั้งบ้าน:  วันธุรกิจ D = (D@cutOff , D+1@cutOff]
//   เปิดแบบ `>` ปิดแบบ `<=` ตรงกับที่ server เดิมค้นบิล (`shopchamp_server/functions/apis/bill.js:71-72`)
//   ⇒ ปลายวัน D = ต้นวัน D+1 พอดี · วันต่อกันสนิท ไม่มีรู ไม่ซ้อน · ไม่มีกรณีพิเศษของ "วันนี้"
//   ⇒ "วันธุรกิจที่กำลังขายอยู่" = businessDayOf(เวลาตอนนี้) · ก่อนถึงเวลาตัดรอบ = วันปฏิทินเมื่อวาน
//
// 🌏 โซนเวลา: ร้าน Shopchamp อยู่ไทยทั้งหมด ⇒ ขีดเส้นวันบน Asia/Bangkok (UTC+7 ไม่มีเวลาออมแสง) เสมอ
//   ไม่ใช้โซนของเครื่องที่รัน ⇒ server (UTC) แอป และเว็บที่เปิดจากต่างประเทศได้วันเดียวกันทุกไบต์
//   ⚠️ เงื่อนไขของคำนี้: วันที่ผู้ใช้เลือก (businessDayRange) ต้องส่งเป็นคีย์ 'YYYYMMDD' / 'YYYY-MM-DD' เท่านั้น
//   ค่าเวลา (Date · number · Timestamp) ไม่รับเป็นวันที่ เพราะ Date เที่ยงคืนจาก DatePicker เป็นเที่ยงคืนของเครื่อง
//   เครื่องโซนตะวันออกของไทย (Tokyo · Sydney) เที่ยงคืนวันที่ 6 = เวลาไทยวันที่ 5 ⇒ ถ้ารับจะได้ยอดผิดวันเงียบ ๆ
//   ⇒ ผู้เรียกแปลงวันที่บนจอเป็นคีย์เองจากเลขวันที่ที่ผู้ใช้เห็น (getFullYear/getMonth/getDate ของเครื่อง) แล้วส่งคีย์
//
// บั๊กที่ไฟล์นี้ปิด (ฝั่งสูตร · รหัสตาม `lanes/dev/source/bug-decisions/`):
//   WR-01/#24  วันของบิลตาม cutOff ไม่ใช่เที่ยงคืนปฏิทิน (businessDayOf · คีย์รูปเดียวกับ billDate)
//   SC-38      ก่อน cutOff "วันนี้" ไม่ถูกเลื่อนไปเป็นช่วงของเมื่อวาน (ไม่อ่านนาฬิกา)
//   WR-34      (กลไกเดียวกันในเว็บเจ้าของร้าน `own:Utility/function.js:287-323 @db0833f`) ก่อน cutOff แถววันนี้ไม่เป็นบิลชุดเดียวกับเมื่อวาน
//   WR-35      ไม่เทียบแค่เลขวันที่ (getDate) หรือวันในสัปดาห์ (getDay) ⇒ ย้อน 7/14/21 วันไม่ว่าง · ไม่ได้ช่วง 2 วัน
//   SC-53/WR-63 ขอบช่วงตั้งวินาทีและมิลลิวินาทีเป็น 0 เสมอ ไม่ติดวินาทีของวันที่ที่เลือก (ฝั่งสูตรของแอปและเว็บ ·
//              การเทียบสตริงวินาทีในจอเว็บเป็นของจอ ไม่ใช่ของไฟล์นี้)
//   G-32       cutOff เป็น null ไม่กลายเป็น 07:00 (เดิม new Date(null) = ปี 1970 เวลาไทย 07:00)
//   DI-77      cutOff ไม่มีค่า ไม่กลายเป็นเวลาที่เปิดแอป (เดิม formatTime() ไม่ใส่ค่า = new Date())
//   F113       cutOff อ่านไม่ได้ ไม่ได้ช่วง Invalid Date
//
// พฤติกรรมเดิมที่คงไว้โดยตั้งใจ (ไม่มีรหัสบั๊ก ⇒ เปลี่ยน = ผลต่างที่อธิบายไม่ได้):
//   ① ใช้แค่ชั่วโมงกับนาทีของ cutOff · วันที่ของ cutOff ไม่มีความหมาย (ค่าตั้งต้นในฐานคือ 2011-01-01 00:00 เวลาไทย)
//   ② ร้านที่ cutOff = 00:00 ได้ช่วงเท่าวันปฏิทิน (เปิด `>` ตามเดิม)
//
// ❌ ไม่ throw · ค่าที่อ่านไม่ได้คืน { ok:false, reason } · cutOff ที่อ่านไม่ได้ใช้เที่ยงคืน (บิลต้องลงวันได้เสมอ) และบอกด้วย isDefault

const SHOP_UTC_OFFSET_MIN = 420; // Asia/Bangkok · ไม่มีเวลาออมแสง ⇒ บวกลบคงที่ได้ตรงทุกวัน
const OFFSET_MS = SHOP_UTC_OFFSET_MIN * 60000;
const DAY_MS = 86400000;

// เวลาแบบ ISO ต้องมีโซนกำกับ (Z หรือ ±hh:mm) · ไม่มีโซน = ขึ้นกับเครื่องที่อ่าน ⇒ ไม่รับ
const ISO_INSTANT = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,3})?)?(?:Z|[+-](\d{2}):(\d{2}))$/;
// คีย์วัน: รูปเดียวกับ bill.billDate (YYYYMMDD) หรือ YYYY-MM-DD
const DAY_KEY = /^(\d{4})(\d{2})(\d{2})$|^(\d{4})-(\d{2})-(\d{2})$/;

function validYmd(y, m, d) {
  if (y < 1970 || y > 9999 || m < 1 || m > 12 || d < 1) return false;
  const t = new Date(Date.UTC(y, m - 1, d));
  return t.getUTCFullYear() === y && t.getUTCMonth() === m - 1 && t.getUTCDate() === d;
}

// ค่าเวลาทุกรูปที่ไหลอยู่ในระบบ → มิลลิวินาที | null
//   Date · Firestore Timestamp (มี toDate · {seconds,nanoseconds} · {_seconds,_nanoseconds}) · number · ISO ที่มีโซน
//   ≤ 0 = null (ค่า 0 คือร่องรอยของ new Date(null) ไม่ใช่เวลาจริง) · สตริงตัวเลขหรือรูป exponent ("1e12") = null
function instantMs(raw) {
  if (raw instanceof Date) {
    const t = raw.getTime();
    return Number.isFinite(t) && t > 0 ? t : null;
  }
  if (typeof raw === "number") {
    const t = new Date(raw).getTime(); // ทศนิยมของมิลลิวินาทีถูกตัดทิ้งแบบเดียวกับ Date · NaN/Infinity = NaN
    return Number.isFinite(t) && t > 0 ? t : null;
  }
  if (typeof raw === "string") {
    const m = ISO_INSTANT.exec(raw.trim());
    if (!m) return null;
    const [y, mo, d, h, mi, s] = [m[1], m[2], m[3], m[4], m[5], m[6] || "0"].map(Number);
    if (!validYmd(y, mo, d) || h > 23 || mi > 59 || s > 59) return null;
    if (m[7] !== undefined && (Number(m[7]) > 23 || Number(m[8]) > 59)) return null;
    const t = Date.parse(raw.trim());
    return Number.isFinite(t) && t > 0 ? t : null;
  }
  if (raw && typeof raw === "object") {
    if (typeof raw.toDate === "function") {
      let d;
      try { d = raw.toDate(); } catch { return null; }
      return d instanceof Date ? instantMs(d) : null;
    }
    const s = raw.seconds !== undefined ? raw.seconds : raw._seconds;
    const ns = raw.seconds !== undefined ? raw.nanoseconds : raw._nanoseconds;
    if (typeof s !== "number" || !Number.isFinite(s)) return null;
    const nsNum = ns === undefined ? 0 : ns;
    if (typeof nsNum !== "number" || !Number.isFinite(nsNum) || nsNum < 0) return null;
    return instantMs(s * 1000 + Math.floor(nsNum / 1e6));
  }
  return null;
}

// วันปฏิทินไทยของเวลาหนึ่ง (เลขวันนับจาก 1970-01-01 ไทย)
function thaiDayNumber(ms) {
  return Math.floor((ms + OFFSET_MS) / DAY_MS);
}

function keyOfDayNumber(n) {
  const t = new Date(n * DAY_MS);
  return String(t.getUTCFullYear()).padStart(4, "0") +
    String(t.getUTCMonth() + 1).padStart(2, "0") +
    String(t.getUTCDate()).padStart(2, "0");
}

// ต้นวัน D (มิลลิวินาที) = D@cutOff เวลาไทย วินาที 0
function openMs(dayNumber, cut) {
  return dayNumber * DAY_MS - OFFSET_MS + (cut.hours * 60 + cut.minutes) * 60000;
}

/**
 * normalizeCutOff — อ่านเวลาตัดรอบของร้านเป็นชั่วโมง:นาทีบนนาฬิกาไทย
 * @param {*} raw `shop.cutOff` รูปใดก็ได้ (Firestore Timestamp · Date · number · ISO ที่มีโซน)
 * @returns {{hours:number, minutes:number, isDefault:boolean}}
 *   อ่านไม่ได้ ไม่มีค่า null หรือ ≤ 0 = เที่ยงคืน และ isDefault:true · วินาทีของ cutOff ไม่ใช้ (SC-53)
 */
function normalizeCutOff(raw) {
  const ms = instantMs(raw);
  if (ms === null) return { hours: 0, minutes: 0, isDefault: true };
  const minuteOfDay = Math.floor(((ms + OFFSET_MS) % DAY_MS) / 60000);
  return { hours: Math.floor(minuteOfDay / 60), minutes: minuteOfDay % 60, isDefault: false };
}

// วันที่ผู้ใช้เลือก → เลขวัน · รับเฉพาะคีย์ YYYYMMDD / YYYY-MM-DD (วันนั้นตรง ๆ) · อย่างอื่น = null
//   ค่าเวลาไม่รับ: เวลาหนึ่งเป็นวันที่ต่างกันตามโซนของเครื่องที่สร้างมัน (ดูหัวไฟล์ 🌏)
function dayNumberOf(day) {
  if (typeof day !== "string") return null;
  const m = DAY_KEY.exec(day.trim());
  if (!m) return null;
  const [y, mo, d] = (m[1] !== undefined ? [m[1], m[2], m[3]] : [m[4], m[5], m[6]]).map(Number);
  return validYmd(y, mo, d) ? Math.round(Date.UTC(y, mo - 1, d) / DAY_MS) : null;
}

/**
 * businessDayRange — ช่วงเวลาของวันธุรกิจ D
 * @param {string} day วันที่เลือก: คีย์ 'YYYYMMDD' / 'YYYY-MM-DD' เท่านั้น (ช่องว่างหัวท้ายตัดได้)
 *   Date · number · Timestamp = day-invalid (เที่ยงคืนของเครื่องโซนอื่นเป็นคนละวันไทย · หัวไฟล์ 🌏)
 * @param {*} cutOff `shop.cutOff` (ผ่าน normalizeCutOff)
 * @returns {{ok:true, key:string, start:Date, end:Date} | {ok:false, reason:'day-invalid'}}
 *   บิลอยู่ในวัน D เมื่อ start < เวลาบิล <= end · end - start = 24 ชั่วโมงเสมอ · ไม่อ่านนาฬิกา (SC-38 · WR-35)
 */
function businessDayRange(day, cutOff) {
  const n = dayNumberOf(day);
  if (n === null) return { ok: false, reason: "day-invalid" };
  const cut = normalizeCutOff(cutOff);
  const start = openMs(n, cut);
  return { ok: true, key: keyOfDayNumber(n), start: new Date(start), end: new Date(start + DAY_MS) };
}

/**
 * businessDayOf — บิล/เหตุการณ์ ณ เวลานี้เป็นยอดของวันธุรกิจไหน
 * @param {*} timestamp เวลาของบิล (Firestore Timestamp · Date · number · ISO ที่มีโซน)
 * @param {*} cutOff `shop.cutOff`
 * @returns {{ok:true, key:string} | {ok:false, reason:'timestamp-invalid'}}
 *   key รูปเดียวกับ bill.billDate (YYYYMMDD) · ตรงเวลาตัดรอบพอดี = ยังเป็นวันก่อนหน้า (WR-01)
 */
function businessDayOf(timestamp, cutOff) {
  const ms = instantMs(timestamp);
  if (ms === null) return { ok: false, reason: "timestamp-invalid" };
  const cut = normalizeCutOff(cutOff);
  const n = thaiDayNumber(ms);
  return { ok: true, key: keyOfDayNumber(ms > openMs(n, cut) ? n : n - 1) };
}

module.exports = { normalizeCutOff, businessDayRange, businessDayOf, SHOP_UTC_OFFSET_MIN };

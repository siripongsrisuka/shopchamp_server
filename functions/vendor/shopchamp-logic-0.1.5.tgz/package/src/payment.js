// payment — รับเงิน · เงินทอน · ช่องจ่ายหลายช่อง (ใบ DEV-0001 · ก้อน 2)
//
// Pack เคาะ 2026-11-06: server เชื่อยอดจากแอป ⇒ สูตรฝั่งแอปต้องถูกเอง · ไฟล์นี้คือสูตรนั้น (JS ล้วน ไม่แตะ Firebase)
//
// ปิดบั๊ก (ฝั่งสูตร · ตาม lanes/dev/source/bug-decisions/ · กลุ่ม "ต้องเคาะ" ใช้ทางแรกในช่องข้อเสนอ ตาม index.md §ที่เหลือ):
//   money K09   ช่องที่ไม่ใช่เงินสดรับเกินแล้วทอนเงินสด ⇒ ทอนได้เฉพาะเงินสด · ช่องอื่นรวมกันเกินยอด = ปิดบิลไม่ได้ (NON_CASH_OVER)
//   money K10   หลายช่องเกตเวย์เก็บแค่ช่องแรก ⇒ จำกัด 1 ช่องเกตเวย์ต่อบิล (MULTI_GATEWAY)
//   money K27   ยอดรวมหัวข้อชำระ ≠ ผลบวกแถว ⇒ บิลที่ปิดได้ Σ(amount − change) = moneyMustPaid เป๊ะถึงสตางค์
//   money F06   เปลี่ยนยอดหลังรับเงิน เงินทอนค้าง ⇒ เงินทอนไม่เก็บในรายการช่อง · คิดใหม่จากยอดปัจจุบันทุกครั้งที่เรียก settle
//   money F07   เงินทอนซ้อนเมื่อเพิ่ม/เอาช่องออก ⇒ เหตุเดียวกับ F06 · เงินทอนมีที่เดียวคือช่องเงินสด
//   money F08   ทศนิยมลอยในยอดชำระ/เงินทอน ⇒ คิดเป็นสตางค์จำนวนเต็ม ปัดจุดเดียวตอนรับค่าเข้า
//   money F21   ยืนยันแป้นโดยไม่พิมพ์แล้วช่องหาย ⇒ ค่า undefined/null = ไม่เปลี่ยนอะไร (ส่วนจอล่มเป็นงานจอ)
//   money F23   amount×100 ไม่เป็นจำนวนเต็มส่งผู้ให้บริการ ⇒ `gateway.amountSatang` เป็นจำนวนเต็มเสมอ
//   money F29   ไม่มีช่องเปิด / เงินเซ็นขึ้นก่อน ⇒ pickDefaultChannel ไม่เลือกช่องที่ปิด · ไม่เลือกเงินเซ็นถ้าไม่มีสมาชิก · settle ปัดช่องที่ปิด (CHANNEL_CLOSED)
//   money F55   ยอด 0 ในช่องลงบิล / เปิดลิ้นชัก ⇒ ยอด 0 = เอาช่องออก · ช่องยอด 0 ไม่ลงบิล
//   money F56   ช่องเงินไม่มีเพดาน ได้ Infinity ⇒ ยอดต่อช่องเกิน MAX_BAHT = ไม่รับ
//   money K04   (ฝั่งรับเงิน) ยอดต้องจ่ายติดลบ ⇒ ถือเป็น 0 · ไม่ทอนเกินเงินที่รับ
//               ยอดต้องจ่ายที่อ่านไม่ได้ (NaN · undefined · ว่าง · {} · เกิน MAX_BAHT) ≠ ติดลบ ⇒ ปิดบิลไม่ได้ (MUST_PAID_INVALID · ต้นทางพัง ห้ามเดาเป็น 0)
//   shift SC-07 (ฝั่งรับเงิน) รหัสเงินสดเดิม '001' ⇒ นับเป็นเงินสดเหมือน 1 (ชุดเดียวกับ shift.CASH_IDS)
//   member K9   จ่ายเงินเซ็นเกินยอด หนี้รวมส่วนทอน ⇒ หนี้เท่าส่วนที่ยังขาดเท่านั้น (ตัดส่วนเกินคืนใน `creditTrimmed`)
//   member K2 / #7 (ฝั่งรับเงิน) เงินเซ็นไม่มีสมาชิก ⇒ ปิดบิลไม่ได้ (CREDIT_NEEDS_MEMBER) · ฝั่งลงหนี้อยู่หน่วย member
//   shift SC-04 (ฝั่งรับเงิน) เงินทอนลงช่องที่ไม่ใช่เงินสด ⇒ change อยู่ช่องเงินสดเท่านั้น · ฝั่งรวมกะอยู่หน่วย shift
//
// สูตรเดิม (lanes/dev/source/compare/old-logic/payment.js): plusReceive · plusReceive2 · perfectPayment · ด่าน diff>=0
//   (app:screens/CheckoutScreen.js:969-1035,914-923,487-500 @804ba8ff)
//
// รูปข้อมูล
//   channels = [{ id, name, amount, ...อื่น }]  ← ยอดที่รับต่อช่อง (บาท) · ❌ ไม่มี change (คิดใน settle)
//   id ของช่อง: 1 เงินสด · 2 พร้อมเพย์ · 3 เงินเซ็น · ช่องที่ร้านเพิ่มเองเป็น uuid (ตาม shop.shopchampPayment)
//
// สัญญา (ทุกฟังก์ชันไม่แก้ของที่ส่งเข้ามา · ❌ ไม่ throw)
//   setChannelAmount(channels, { id, name, amount }) → channels ใหม่    · แทนที่ยอดของช่อง (แป้นตัวเลข / ยืนยันแป้น)
//   addChannelAmount(channels, { id, name, amount }) → channels ใหม่    · บวกยอดเข้าช่อง (ปุ่มแบงก์)
//   payExact(channels, { id, name }, moneyMustPaid)  → channels ใหม่    · บวกยอดที่ยังขาดเข้าช่อง (ปุ่ม `ชำระพอดี`)
//   removeChannel(channels, id)                       → channels ใหม่
//     ยอด: number หรือข้อความ (ผ่าน money.toNumber) · ปัดเป็นสตางค์ครั้งเดียว (ครึ่งปัดออกจากศูนย์)
//       - undefined / null                  = ไม่เปลี่ยน
//       - '' หรือ 0 (set)                    = เอาช่องออก · (add) = ไม่เปลี่ยน
//       - ติดลบ · อ่านไม่ได้ · เกิน MAX_BAHT   = ไม่เปลี่ยน (ไม่เดา)
//   settle(channels, moneyMustPaid, opts) → ผลตอนกดยืนยัน
//     opts = { shopchampPayment?: [{id,status,paymentGateway}], memberId? }
//     คืน { moneyMustPaid, moneyReceived, remain, diff, change, editable, canClose, errors[],
//           payment[{...ช่อง, amount, change}], currentCredit, creditTrimmed, drawer, gateway{id,amount,amountSatang}|null }
//       - ทุกยอดเป็นบาทที่ทศนิยมไม่เกิน 2 ตำแหน่ง
//       - errors: MUST_PAID_INVALID · UNDERPAID · NON_CASH_OVER · MULTI_GATEWAY · CHANNEL_CLOSED · CREDIT_NEEDS_MEMBER · canClose = errors ว่าง
//       - ยอดต้องจ่าย: ติดลบ = 0 (K04) · อ่านไม่ได้ = 0 + MUST_PAID_INVALID (ปิดไม่ได้)
//   pickDefaultChannel(shopchampPayment, { memberId }) → ช่องตั้งต้น | null

const { toNumber } = require("./money");

const PAYMENT_CHANNEL = Object.freeze({ CASH: 1, PROMPTPAY: 2, CREDIT: 3 });
const MAX_BAHT = 99999999.99; // เพดานต่อช่อง (F56) · ยังเป็นจำนวนเต็มที่ปลอดภัยเมื่อคิดเป็นสตางค์
const MAX_SATANG = Math.round(MAX_BAHT * 100);
// รหัสเงินสด: 1 + รหัสระบบเดิม '001' (SC-07 · ต้องตรงกับ shift.CASH_IDS)
const CASH_IDS = Object.freeze([PAYMENT_CHANNEL.CASH, "001"]);

// บาท → สตางค์จำนวนเต็ม · toPrecision(15) กันเศษลอยแบบ 1.005*100 = 100.49999999999999 · ครึ่งปัดออกจากศูนย์
function toSatang(n) {
  const x = Number((n * 100).toPrecision(15));
  return Math.sign(x) * Math.round(Math.abs(x));
}
const toBaht = (s) => (s === 0 ? 0 : s / 100);

const ZERO_TEXT = /^[+-]?(0+\.?0*|\.0+)(e[+-]?\d+)?$/i;

// อ่านยอดที่ร้านกรอก → { kind: 'none'|'zero'|'ok'|'bad', satang }
function readAmount(v) {
  if (v === undefined || v === null) return { kind: "none", satang: 0 };
  if (typeof v === "string") {
    const s = v.trim().replace(/,/g, "");
    if (s === "") return { kind: "zero", satang: 0 };
    if (ZERO_TEXT.test(s)) return { kind: "zero", satang: 0 };
  } else if (typeof v !== "number") {
    return { kind: "bad", satang: 0 };
  }
  const n = toNumber(v);
  if (n === 0) return typeof v === "number" && v === 0 ? { kind: "zero", satang: 0 } : { kind: "bad", satang: 0 };
  const satang = toSatang(n);
  if (satang < 0 || satang > MAX_SATANG) return { kind: "bad", satang: 0 };
  if (satang === 0) return { kind: "zero", satang: 0 }; // เล็กกว่าครึ่งสตางค์ เช่น 4.44e-16
  return { kind: "ok", satang };
}

const list = (channels) => (Array.isArray(channels) ? channels.filter((c) => c && typeof c === "object") : []);
const sameId = (a, b) => a === b;

function upsert(channels, { id, name }, satang) {
  const src = list(channels);
  const found = src.some((c) => sameId(c.id, id));
  if (satang <= 0) return src.filter((c) => !sameId(c.id, id));
  if (found) return src.map((c) => (sameId(c.id, id) ? { ...c, amount: toBaht(satang) } : { ...c }));
  return [...src.map((c) => ({ ...c })), { id, name, amount: toBaht(satang) }];
}

function channelSatang(channels, id) {
  return list(channels)
    .filter((c) => sameId(c.id, id))
    .reduce((s, c) => s + Math.max(0, readAmount(c.amount).satang), 0);
}

function setChannelAmount(channels, channel) {
  const ch = channel || {};
  const r = readAmount(ch.amount);
  if (r.kind === "none" || r.kind === "bad") return list(channels).map((c) => ({ ...c }));
  return upsert(channels, ch, r.satang);
}

function addChannelAmount(channels, channel) {
  const ch = channel || {};
  const r = readAmount(ch.amount);
  if (r.kind !== "ok") return list(channels).map((c) => ({ ...c }));
  const next = channelSatang(channels, ch.id) + r.satang;
  if (next > MAX_SATANG) return list(channels).map((c) => ({ ...c }));
  return upsert(channels, ch, next);
}

// ยอดต้องจ่าย → { ok, satang } · ติดลบ = 0 แบบ ok (K04) · ว่าง/อ่านไม่ได้/เกินเพดาน = ok:false (ต้นทางพัง)
function readMustPaid(v) {
  if (typeof v === "string" && v.trim() === "") return { ok: false, satang: 0 };
  const r = readAmount(v);
  if (r.kind === "ok" || r.kind === "zero") return { ok: true, satang: r.satang };
  if (r.kind === "bad" && (typeof v === "number" || typeof v === "string") && toNumber(v) < 0) return { ok: true, satang: 0 };
  return { ok: false, satang: 0 };
}
const mustPaidSatang = (v) => readMustPaid(v).satang;

function payExact(channels, channel, moneyMustPaid) {
  const ch = channel || {};
  const received = list(channels).reduce((s, c) => s + Math.max(0, readAmount(c.amount).satang), 0);
  const remain = mustPaidSatang(moneyMustPaid) - received;
  if (remain <= 0) return list(channels).map((c) => ({ ...c }));
  return upsert(channels, ch, channelSatang(channels, ch.id) + remain);
}

function removeChannel(channels, id) {
  return list(channels).filter((c) => !sameId(c.id, id)).map((c) => ({ ...c }));
}

// รวมช่อง id ซ้ำ · ตัดยอด ≤ 0 · ตัด field `type` `imageId` แบบ leanPaymentChannel เดิม
function normalize(channels) {
  const out = [];
  for (const c of list(channels)) {
    const r = readAmount(c.amount);
    if (r.kind !== "ok") continue;
    const prev = out.find((o) => sameId(o.id, c.id));
    if (prev) {
      prev.satang += r.satang;
      continue;
    }
    const { type, imageId, change, amount, ...rest } = c; // eslint-disable-line no-unused-vars
    out.push({ rest, id: c.id, satang: r.satang });
  }
  return out;
}

function settle(channels, moneyMustPaid, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const mustRead = readMustPaid(moneyMustPaid);
  const must = mustRead.satang;
  const rows = normalize(channels);
  const config = Array.isArray(o.shopchampPayment) ? o.shopchampPayment.filter((c) => c && typeof c === "object") : null;
  const errors = [];

  const isCash = (r) => CASH_IDS.includes(r.id);
  const isCredit = (r) => sameId(r.id, PAYMENT_CHANNEL.CREDIT);

  // เงินเซ็น: หนี้เท่าส่วนที่ยังขาดหลังช่องอื่นเท่านั้น (member K9)
  const nonCredit = rows.filter((r) => !isCredit(r)).reduce((s, r) => s + r.satang, 0);
  let creditTrimmed = 0;
  for (const r of rows) {
    if (!isCredit(r)) continue;
    const room = Math.max(0, must - nonCredit);
    if (r.satang > room) {
      creditTrimmed += r.satang - room;
      r.satang = room;
    }
  }
  const kept = rows.filter((r) => r.satang > 0);

  const received = kept.reduce((s, r) => s + r.satang, 0);
  const cash = kept.filter(isCash).reduce((s, r) => s + r.satang, 0);
  const nonCash = received - cash;

  if (!mustRead.ok) errors.push("MUST_PAID_INVALID");
  if (received < must) errors.push("UNDERPAID");
  if (nonCash > must) errors.push("NON_CASH_OVER"); // K09: ทอนได้เฉพาะเงินสด

  const credit = kept.filter(isCredit).reduce((s, r) => s + r.satang, 0);
  if (credit > 0 && !o.memberId) errors.push("CREDIT_NEEDS_MEMBER");

  let gatewayRows = [];
  if (config) {
    const byId = (id) => config.find((c) => sameId(c.id, id));
    if (kept.some((r) => !(byId(r.id) && byId(r.id).status))) errors.push("CHANNEL_CLOSED");
    gatewayRows = kept.filter((r) => byId(r.id) && byId(r.id).paymentGateway);
    if (gatewayRows.length > 1) errors.push("MULTI_GATEWAY");
  }

  // เงินทอนอยู่ช่องเงินสดเท่านั้น และไม่เกินเงินสดที่รับ
  const changeSatang = Math.max(0, Math.min(received - must, cash));
  const payment = kept.map((r) => ({
    ...r.rest,
    id: r.id,
    amount: toBaht(r.satang),
    change: isCash(r) ? toBaht(changeSatang) : 0,
  }));

  const g = gatewayRows[0];
  return {
    moneyMustPaid: toBaht(must),
    moneyReceived: toBaht(received),
    remain: toBaht(Math.max(0, must - received)),
    diff: toBaht(received - must),
    change: toBaht(changeSatang),
    editable: received < must,
    canClose: errors.length === 0,
    errors,
    payment,
    currentCredit: toBaht(credit),
    creditTrimmed: toBaht(creditTrimmed),
    drawer: cash > 0,
    gateway: g ? { id: g.id, amount: toBaht(g.satang), amountSatang: g.satang } : null,
  };
}

function pickDefaultChannel(shopchampPayment, opts) {
  const o = opts && typeof opts === "object" ? opts : {};
  const active = (Array.isArray(shopchampPayment) ? shopchampPayment : []).filter((c) => c && typeof c === "object" && c.status);
  const first = active.find((c) => !sameId(c.id, PAYMENT_CHANNEL.CREDIT));
  if (first) return { ...first };
  const credit = active.find((c) => sameId(c.id, PAYMENT_CHANNEL.CREDIT));
  return credit && o.memberId ? { ...credit } : null;
}

module.exports = {
  PAYMENT_CHANNEL,
  MAX_BAHT,
  setChannelAmount,
  addChannelAmount,
  payExact,
  removeChannel,
  settle,
  pickDefaultChannel,
};

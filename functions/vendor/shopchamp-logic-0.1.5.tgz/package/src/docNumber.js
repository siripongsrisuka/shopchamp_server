// docNumber — เลขใบเสร็จ · เลขใบกำกับภาษี · รหัสใบรับเงินชั่วคราว · ฟังก์ชันล้วน ไม่แตะฐาน (ก้อน 3 · DEV-0001)
//
// แทนสูตรเดิมในแอป shopcham_merchant_2025@804ba8ff:
//   · `Utility/dateTime.js:245-252` stringReceiptNumber (หัว YYYYMM + ลำดับ 6 หลัก)
//   · `screens/CheckoutScreen.js:500-518` getCurrentDateInfo · getStringReceipt · stringReceiptNumberDay
//   · `screens/CheckoutScreen.js:544-594` ตัวนับ billId/billDayId ทางขายออนไลน์ · `:531-535` เลข `Offline`
//   · `Utility/function.js:204-218` ตัวนับทางซิงก์ (runSafeCheckout)
//   · `screens/BillHistoryScreen.js:508-538` ตัวนับ taxId ตอนออกใบกำกับ
//   สำเนาคำต่อคำของสูตรเดิมอยู่ที่ `lanes/dev/source/compare/old-logic/docNumber.js` · ตัวเทียบอยู่ใน `test/docNumber.test.js`
//   แบบที่ยกมา: บ้านพี่น้อง `functions/claude/_shared/billClock.js` (หัวเลขจากผนังนาฬิกาของร้าน)
//              และ `_shared/docNumber.js` (เทียบรอบด้วยเลขที่เรียงได้ · เลขไม่ถอยหลัง) · คัดลอกท่าแล้วเขียนใหม่ ไม่ผูก package
//
// ใครเรียก: server `sale.create` (ใน transaction เดียวกับบิล) และทางออกใบกำกับ · แอปใช้แค่ `nextOfflineRef`
//   ⇒ `now` ที่ส่งเข้ามาต้องเป็นเวลา server (Pack เคาะ 2026-11-06 · `architecture-plan.md` ข้อ #19)
//
// 🔑 ตัวนับใช้ doc เดิมร่วมกับแอปรุ่นเก่า (`billId/{shop.id}` · `billDayId/{shop.id}` · `taxId/{shop.shopId}`)
//   แอปเก่ายังเขียน `{month|date, receipts}` ด้วยนาฬิกาเครื่องต่อไป ⇒ ตัวใหม่
//   ① เขียน `month`/`date` และ `receipts` ในความหมายเดิมทุกครั้ง (แอปเก่าอ่านแล้วนับต่อได้)
//   ② เพิ่ม `serverKey` (รอบที่ server ออกเลขล่าสุด YYYYMM หรือ YYYYMMDD) + `serverRun` (ลำดับที่ server ออกล่าสุด)
//      = บันทึกของ server เองที่แอปเก่าไม่แตะ (update ของแอปเก่าไม่ลบ field อื่น) ⇒ เลขที่ server ออกไม่ซ้ำเลขที่ server เคยออก
//      ไม่ว่าแอปเก่าจะเขียน `month` เพี้ยนแค่ไหน · ผู้เรียกต้องเขียนด้วย merge เพื่อไม่ลบ field ที่ไม่รู้จัก
//
// บั๊กที่ไฟล์นี้ปิด (รหัสตาม `lanes/dev/source/bug-decisions/`):
//   RT-01/#19 (ฝั่งสูตร) หัวเลขและการขึ้นรอบใหม่มาจาก `now` ที่ผู้เรียกส่ง (เวลา server) ไม่ใช่นาฬิกาเครื่อง
//              + เลขที่ server ออกเดินหน้าอย่างเดียวตาม serverKey/serverRun แม้แอปเก่ารีเซ็ตตัวนับสลับ
//   RT-12  (ฝั่งสูตร) อ่านนาฬิกาครั้งเดียว ใช้ทั้งตัดสินรอบและหัวเลข · ไม่มีค่าค้างนอก transaction (ฟังก์ชันล้วน รันซ้ำได้ผลเดิม)
//   RT-13 · P-12  เทียบรอบด้วยปีด้วย (serverKey) · ร้านที่ว่างครบปี/ครบเดือนเริ่ม 1 ตามรอบใหม่
//   RT-14 · S-10 (ฝั่งสูตร) ทางขายออนไลน์และทางซิงก์ใช้ `nextCounter` ตัวเดียวและเลือกรูปตาม `receiptPattern`
//   RT-28  (ฝั่งสูตร) ผนังนาฬิกาของร้านคิดด้วย tz ไม่ใช้ getter ของเครื่อง ⇒ server ที่รัน UTC ได้วันเดียวกับร้าน
//   RT-42  ไม่มีตัวแปรที่ไม่ประกาศ (ไฟล์นี้ strict)
//   RT-03 (ฝั่งสูตร) บิลที่มีเลขใบกำกับแล้ว = ใช้เลขเดิม ไม่ออกใหม่ (`planTaxNumber` อ่านบิลใน transaction)
//   RT-02 · P-04 (ฝั่งสูตร) เครื่องพิมพ์ไม่พร้อม = ไม่ออกเลข (ตัดสินก่อนแตะตัวนับ)
//   RT-05 (ฝั่งสูตร เฉพาะส่วนออกเลข) บิลยกเลิกไม่ได้เลขใบกำกับใหม่ · "ยกเลิก" ตัดสินด้วย `billState.isVoidedBill` (truthy แบบแอปเก่า · รวม void object ของบิลรุ่นแรก)
//   S-06 (ฝั่งสูตร) ตอนออฟไลน์ใบมีรหัส `T<yymmdd>-<เครื่อง 4 ตัว>-<nn>` แทนคำว่า `Offline` (Pack เคาะ 2026-11-06 ข้อ 2-1)
//   DI-56 (ฝั่งสูตร) อ่านได้ทั้งสองชนิด: `receipts` / `month` / `date` ที่เป็นข้อความตัวเลขล้วน ("5" · "11") อ่านเป็นตัวเลข
//              แล้วเขียนกลับเป็น number (เดิมต่อสตริง "5"+1 = "51" · `"11" !== 11` รีเซ็ตเป็น 1)
//   C01   `receipts` เพี้ยนจนอ่านไม่ได้ (ว่าง · 0 · ติดลบ · ทศนิยม · "1e3") ในรอบนี้ = ไม่เดาลำดับ (เดิม null+1 = 1 ซ้ำ · NaN)
//              ⇒ คืน `counter-broken` ให้ผู้เรียกหา `floorRun` (ลำดับสูงสุดจากบิลของรอบนี้) แล้วเรียกใหม่ · ได้เลขต่อ ไม่ล้มการขาย
//   ร้านผสม (ตรวจอิสระ ผิด-1) บันทึกของ server ที่ค้างจากรอบเก่าจะถูกตัดทิ้งก็ต่อเมื่อ `month`/`date` ใน doc ยังเป็นค่าที่ server เขียนไว้
//              ⇒ แอปเก่าที่รีเซ็ตแล้วออก 1..n ในรอบนี้ ไม่ถูกตีความเป็นของเก่าของ server (เดิมของคนทำ: server ออก …000001 ซ้ำ)
//
// พฤติกรรมเดิมที่คงไว้โดยตั้งใจ (ไม่มีรหัสบั๊ก ⇒ เปลี่ยน = ผลต่างที่อธิบายไม่ได้):
//   ① รูปเลข: เดือน = YYYYMM + ลำดับ 6 หลัก (12 หลัก) · วัน = YYYYMMDD + ลำดับ 6 หลัก (14 หลัก) · เกิน 999,999 เลขยาวขึ้น ไม่ตัด
//   ② รูปแบบร้าน: `'month'` และไม่ส่ง = รายเดือน (ค่าตั้งต้นเดิม `CheckoutScreen.js:142`) · ค่าอื่นทุกค่า = รายวัน (`:544-546`)
//   ③ ไม่มี doc ตัวนับ = เริ่ม 1 · รอบเดียวกัน = ลำดับเดิม + 1 · รอบอื่น = 1 (ข้อความตัวเลขอ่านเป็นตัวเลขตาม DI-56)
//   ④ เลขใบกำกับใช้รูปรายเดือนเสมอ (`BillHistoryScreen.js:518-536`)
//   ⑤ doc ที่ยังไม่มี serverKey (ทุกร้านวันนี้) ตัดสินด้วย `month`/`date` แบบเดิมเป๊ะ จนกว่า server เขียนครั้งแรก
//
// ข้อจำกัดที่รู้ตัว (ไม่ใช่สิ่งที่ฟังก์ชันล้วนปิดได้):
//   · แอปเก่าที่นาฬิกาเพี้ยนยังออกเลขซ้ำของมันเองได้ (RT-01 ฝั่งแอปเก่า · แผนรับไว้: ทำรายการเลขซ้ำให้ร้านรู้)
//     และถ้า server ไม่ได้ออกเลขในรอบนี้เลย ขณะที่แอปเก่าเครื่องหนึ่งเขียน `month` เพี้ยนทับ server จะเริ่ม 1 ซ้ำกับเลขที่แอปเก่าออกไปแล้ว
//   · กรณีกำกวม: server ออกลำดับ 1 ไว้แล้วไม่มีใครออกอีกครบรอบปี (หรือเดือน) และ `receipts` = 1 ตรงกัน
//     แยกไม่ออกว่าแอปเก่ารีเซ็ตในรอบนี้หรือเป็นของเก่า ⇒ เลือกนับต่อ (ได้ 2 แทน 1 = เรื่องความสวย) ไม่เลือกรีเซ็ต (= เสี่ยงเลขซ้ำ)
//   · กรณีกำกวมที่เหลือ: server ออกถึง n ไว้ในรอบเก่าที่ `month`/`date` เดียวกัน (เดือนเดียวกันปีก่อน · วันที่เดียวกันเดือนก่อน)
//     แล้วแอปเก่าออกในรอบนี้ถึง n พอดีเท่ากัน ⇒ แยกไม่ออกจาก doc ⇒ ตัดทิ้งตาม RT-13 (โอกาสต่ำ · ผู้เรียกส่ง `floorRun` จากบิลรอบนี้ได้เสมอเพื่อปิดช่องนี้)
//   · หัวเลขของ Asia/Bangkok ตั้งแต่ 1 เม.ย. 1920 คิดด้วย UTC+7 ตรง (ไทยไม่มีเวลาออมแสง) ไม่ใช้ Intl
//     ⇒ `nextOfflineRef` ที่รันในแอป (Hermes) ไม่พึ่ง Intl + timeZone · โซนอื่นยังใช้ Intl และถ้า Intl ใช้ไม่ได้ = ตกไป Asia/Bangkok
//
// หน่วย: ❌ ไม่ throw · ล้ม = `{ok:false, reason}` ⇒ ผู้เรียกต้องไม่ออกเลขด้วย input นั้น
//   `counter-broken` = ผู้เรียกหา `floorRun` จากบิลของรอบนี้แล้วเรียกใหม่ (ไม่ใช่ยกเลิกการขาย)
"use strict";

const { isVoidedBill } = require("./billState");

const DEFAULT_TZ = "Asia/Bangkok";
const RUN_WIDTH = 6;
const OFFLINE_REF_PREFIX = "T";

const pad = (n, w) => String(n).padStart(w, "0");
const isPosInt = (x) => typeof x === "number" && Number.isSafeInteger(x) && x >= 1;
// อ่านเลขใน doc ตัวนับได้ทั้งสองชนิด (DI-56): number ตามเดิม · ข้อความตัวเลขล้วน "5" = 5 · อย่างอื่นคืนตามเดิม (ไปตกด่านเอง)
const readInt = (x) => (typeof x === "string" && /^\d{1,15}$/.test(x) ? Number(x) : x);

// ── นาฬิกา ──────────────────────────────────────────────────────────────

// ไทยใช้ UTC+7 คงที่ตั้งแต่ 1 เม.ย. 1920 (ก่อนนั้นเวลาท้องถิ่น +6:42:04) · ใช้ขอบ 00:00 UTC ของวันนั้น = หลังเปลี่ยนแล้วแน่
const BKK_OFFSET_MS = 7 * 3600e3;
const BKK_FIXED_FROM_MS = Date.UTC(1920, 3, 1);
// 0001-01-02 00:00 UTC · ก่อนนี้บางโซนเป็นปีก่อน ค.ศ. 1 ⇒ ปัดทั้งหมด (ไม่พึ่งตัวเลือก era ของ Intl)
const MIN_MS = -62135596800000 + 86400e3;

const fmtCache = new Map();
function formatterOf(tz) {
  let f = fmtCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", { timeZone: tz, year: "numeric", month: "numeric", day: "numeric" });
    fmtCache.set(tz, f);
  }
  return f;
}

/** โซนของร้าน · ไม่ส่ง/ว่าง/Intl ไม่รู้จัก = Asia/Bangkok (ร้าน Shopchamp ไม่มี field โซนในฐาน · ไม่ทำให้การขายล้ม) */
function resolveTz(tz) {
  if (typeof tz !== "string" || tz.trim() === "" || tz.trim() === DEFAULT_TZ) return DEFAULT_TZ;
  try {
    formatterOf(tz.trim());
    return tz.trim();
  } catch (_) {
    return DEFAULT_TZ;
  }
}

// `now` = Date ที่ใช้ได้ หรือ ms ที่เป็นตัวเลขจริง · ❌ ไม่รับข้อความ (รวมรูป "1e12") เพราะต้องเป็นเวลา server ที่ผู้เรียกถือเอง
function instantOf(now) {
  if (now instanceof Date) return Number.isFinite(now.getTime()) ? now.getTime() : null;
  if (typeof now === "number" && Number.isFinite(now)) {
    const t = new Date(now).getTime(); // ms ทศนิยมถูกตัดแบบเดียวกับ Date
    return Number.isFinite(t) ? t : null;
  }
  return null;
}

// ปี เดือน วัน บนผนังนาฬิกาของร้าน (ไม่ขึ้นกับโซนของเครื่องที่รัน)
//   null = ก่อน ค.ศ. 1 หรือคิดไม่ได้ (เวลาเพี้ยน ไม่ออกเลข)
function wallYmd(ms, tz) {
  if (ms < MIN_MS) return null;
  const fixed = (offset) => {
    const d = new Date(ms + offset);
    return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate() };
  };
  if (tz === DEFAULT_TZ && ms >= BKK_FIXED_FROM_MS) return fixed(BKK_OFFSET_MS);
  let parts;
  try {
    parts = formatterOf(tz).formatToParts(new Date(ms));
  } catch (_) {
    return null; // Intl ใช้ไม่ได้กับเวลานี้ (โซนที่ไม่ใช่ไทย resolveTz ผ่าน Intl มาแล้ว · ไทยก่อน 1920 = ไม่ใช่เวลาขายจริง)
  }
  const num = (t) => {
    const p = parts.find((x) => x.type === t);
    return p ? Number(p.value) : NaN;
  };
  const w = { y: num("year"), m: num("month"), d: num("day") };
  return Number.isSafeInteger(w.y) && Number.isSafeInteger(w.m) && Number.isSafeInteger(w.d) ? w : null;
}

// ── รูปแบบร้าน · รอบ ──────────────────────────────────────────────────────

/** รูปแบบเลข: 'month' และไม่ส่ง = รายเดือน · ค่าอื่น = รายวัน (ตามแอปเดิม ข้อ ②) */
const typeOf = (receiptPattern) => (receiptPattern === undefined || receiptPattern === "month" ? "month" : "day");
const fieldNameOf = (type) => (type === "month" ? "month" : "date");

function validKey(type, key) {
  if (!Number.isSafeInteger(key) || key <= 0) return false;
  if (type === "month") {
    const y = Math.floor(key / 100), m = key % 100;
    return y >= 1 && y <= 9999 && m >= 1 && m <= 12;
  }
  const y = Math.floor(key / 10000), m = Math.floor(key / 100) % 100, d = key % 100;
  return y >= 1 && y <= 9999 && m >= 1 && m <= 12 && d >= 1 && d <= 31;
}

// ค่า `month`/`date` ที่แอปเก่าเขียนคู่กับรอบนี้ = 2 หลักท้ายของ key ทั้ง 2 รูป (MM ของ YYYYMM · DD ของ YYYYMMDD)
const fieldValueOfKey = (key) => key % 100;

/**
 * periodOf — รอบของเลขเอกสาร ณ เวลา `now` บนผนังนาฬิกาของร้าน
 * @param {'month'|'day'|string|undefined} receiptPattern
 * @param {Date|number} now เวลา server
 * @param {string} [tz]
 * @returns {{ok:true, type:'month'|'day', key:number, field:'month'|'date', fieldValue:number, tz:string}
 *          | {ok:false, reason:'now-invalid'}}
 *   key = YYYYMM (รายเดือน) หรือ YYYYMMDD (รายวัน) เป็นตัวเลขที่เรียงได้ · fieldValue = ค่าที่แอปเก่าเก็บใน `month`/`date`
 */
function periodOf(receiptPattern, now, tz) {
  const type = typeOf(receiptPattern);
  const zone = resolveTz(tz);
  const ms = instantOf(now);
  if (ms === null) return { ok: false, reason: "now-invalid" };
  const w = wallYmd(ms, zone);
  if (!w || w.y > 9999) return { ok: false, reason: "now-invalid" };
  const key = type === "month" ? w.y * 100 + w.m : w.y * 10000 + w.m * 100 + w.d;
  return { ok: true, type, key, field: fieldNameOf(type), fieldValue: type === "month" ? w.m : w.d, tz: zone };
}

/**
 * formatDocNumber — หัวรอบ + ลำดับ 6 หลัก
 * @param {'month'|'day'|string|undefined} receiptPattern
 * @param {number} key YYYYMM หรือ YYYYMMDD
 * @param {number} run ลำดับ ≥ 1 จำนวนเต็ม
 * @returns {string|null} null เมื่อ key หรือ run ใช้ไม่ได้ (ไม่ต่อเป็น "NaN"/"0" ลงเอกสาร)
 */
function formatDocNumber(receiptPattern, key, run) {
  const type = typeOf(receiptPattern);
  if (!validKey(type, key) || !isPosInt(run)) return null;
  const head = type === "month" ? pad(Math.floor(key / 100), 4) + pad(key % 100, 2) : pad(Math.floor(key / 10000), 4) + pad(Math.floor(key / 100) % 100, 2) + pad(key % 100, 2);
  return head + pad(run, RUN_WIDTH);
}

// ── ตัวนับ ───────────────────────────────────────────────────────────────

/**
 * nextCounter — เลขถัดไปจาก doc ตัวนับที่อ่านได้ใน transaction
 * @param {object} p
 * @param {'month'|'day'|string} [p.receiptPattern] `shop.receiptPattern` (ใบกำกับส่ง 'month')
 * @param {object|null|undefined} p.stored `doc.data()` ของ `billId`/`billDayId`/`taxId` · ไม่มี doc = null/undefined
 * @param {Date|number} p.now เวลา server
 * @param {string} [p.tz] โซนร้าน (ไม่ส่ง = Asia/Bangkok)
 * @param {number} [p.floorRun] ลำดับสูงสุดที่ผู้เรียกหาได้จากบิลของรอบนี้ (จำนวนเต็ม ≥ 0 · 0 = รอบนี้ยังไม่มีบิล)
 *   ส่งเมื่อได้ `counter-broken` · ส่งตอนไหนก็ได้ เลขที่ได้จะมากกว่า floorRun เสมอ · ค่าที่ไม่ใช่จำนวนเต็ม ≥ 0 = ถือว่าไม่ส่ง
 * @returns {{ok:true, type, receiptNumber:string, key:number, run:number, reset:boolean, write:object, tz:string}
 *          | {ok:false, reason:'now-invalid'|'counter-invalid'|'counter-broken'}}
 *   `write` = ค่าที่ต้องเขียนกลับด้วย merge: `{month|date, receipts, serverKey, serverRun}`
 *   `counter-broken` = `receipts` ของรอบนี้อ่านไม่ได้และไม่ได้ส่ง floorRun ⇒ หา floorRun แล้วเรียกใหม่ (ไม่ยกเลิกการขาย)
 */
function nextCounter({ receiptPattern, stored, now, tz, floorRun } = {}) {
  const p = periodOf(receiptPattern, now, tz);
  if (!p.ok) return p;
  const { type, field } = p;
  if (stored !== undefined && stored !== null && (typeof stored !== "object" || Array.isArray(stored))) {
    return { ok: false, reason: "counter-invalid" };
  }
  const s = stored || null;
  const floor = Number.isSafeInteger(floorRun) && floorRun >= 0 ? floorRun : null;

  // บันทึกของ server เอง (เชื่อเมื่อรูปถูกครบทั้งคู่)
  const stamp = s && validKey(type, s.serverKey) && isPosInt(s.serverRun) ? { key: s.serverKey, run: s.serverRun } : null;
  const printKey = stamp && stamp.key > p.key ? stamp.key : p.key; // นาฬิกาถอย (เปลี่ยนโซน) = หัวเลขไม่ถอยตาม
  const printField = fieldValueOfKey(printKey);

  const runs = [];
  if (stamp && stamp.key === printKey) runs.push(stamp.run);
  if (floor !== null && floor > 0) runs.push(floor);
  if (s && readInt(s[field]) === printField) {
    // `receipts` ที่แอปเก่า (หรือ server) เขียนในรอบที่ `month`/`date` ตรงกับรอบนี้
    const rec = readInt(s.receipts);
    // ของเก่าของ server ที่ `month`/`date` ตรงกันโดยบังเอิญ (RT-13) = server เขียนรอบเก่ากว่า
    //   และ doc ยังเป็นค่าที่ server เขียนครบทั้ง `month`/`date` และ `receipts` · ค่าใน doc ต่างจากที่ server เขียน = แอปเก่าเขียนทับในรอบนี้
    //   ยกเว้น `receipts` = 1 ซึ่งแอปเก่าอาจเพิ่งรีเซ็ตในรอบนี้ ⇒ นับต่อ (ข้อจำกัดที่รู้ตัว)
    const staleOwn = stamp && stamp.key < printKey && fieldValueOfKey(stamp.key) === printField && rec === stamp.run && rec !== 1;
    if (!staleOwn) {
      if (isPosInt(rec)) runs.push(rec);
      else if (floor === null) return { ok: false, reason: "counter-broken" };
    }
  }
  const run = runs.length ? Math.max(...runs) + 1 : 1;
  const receiptNumber = formatDocNumber(type, printKey, run);
  if (receiptNumber === null) return { ok: false, reason: "counter-broken" };
  return {
    ok: true,
    type,
    receiptNumber,
    key: printKey,
    run,
    reset: runs.length === 0,
    write: { [field]: printField, receipts: run, serverKey: printKey, serverRun: run },
    tz: p.tz,
  };
}

// ── ใบกำกับ ──────────────────────────────────────────────────────────────

/**
 * planTaxNumber — ตัดสินก่อนแตะตัวนับ `taxId` ว่าบิลนี้ต้องออกเลขใบกำกับใหม่ไหม
 * @param {object} p
 * @param {object} p.bill บิลที่อ่าน **ใน transaction** (ไม่ใช่ค่าบนจอ)
 * @param {boolean} p.printerReady ผู้เรียกตรวจแล้วว่าเครื่องพิมพ์ที่ตั้งไว้พิมพ์ใบกำกับได้
 * @returns {{action:'reuse', taxNumber:string} | {action:'issue'} | {action:'refuse', reason:'bill-missing'|'bill-void'|'printer-not-ready'}}
 *   ลำดับ: มีเลขแล้ว = ใช้เลขเดิมเสมอ (พิมพ์ซ้ำไม่เผาเลข) → บิลยกเลิก → เครื่องพิมพ์ → ออกใหม่ ด้วย `nextCounter({receiptPattern:'month'})`
 */
function planTaxNumber({ bill, printerReady } = {}) {
  if (!bill || typeof bill !== "object") return { action: "refuse", reason: "bill-missing" };
  if (bill.taxNumber) return { action: "reuse", taxNumber: String(bill.taxNumber) };
  if (isVoidedBill(bill)) return { action: "refuse", reason: "bill-void" }; // void object ของบิลรุ่นแรกก็ยกเลิก (billState.js)
  if (printerReady !== true) return { action: "refuse", reason: "printer-not-ready" };
  return { action: "issue" };
}

// ── ใบรับเงินชั่วคราวตอนออฟไลน์ ──────────────────────────────────────────

/** รหัสเครื่องย่อ 4 ตัว (ท้าย deviceId · เฉพาะ A-Z/0-9) · ไม่มี = 'POS' */
function deviceTag(deviceId) {
  const clean = String(deviceId === undefined || deviceId === null ? "" : deviceId).toUpperCase().replace(/[^A-Z0-9]/g, "");
  return clean.slice(-4) || "POS";
}

/**
 * nextOfflineRef — รหัสบนใบรับเงินชั่วคราว `T<yymmdd>-<เครื่อง 4 ตัว>-<nn>` นับต่อเครื่อง ต่อวันของร้าน
 *   ❌ ไม่ใช่เลขใบเสร็จ · เลขจริงออกที่ server ตอนซิงก์ (Pack เคาะ 2026-11-06 ข้อ 2-1)
 * @param {object} p
 * @param {{day?:string, n?:number}|null} p.saved ตัวนับที่เครื่องเก็บไว้
 * @param {Date|number} p.now เวลาเครื่อง (ตอนออฟไลน์ไม่มีเวลา server)
 * @param {string} [p.tz]
 * @param {string} [p.deviceId]
 * @returns {{ok:true, ref:string, save:{day:string, n:number}} | {ok:false, reason:'now-invalid'}}
 *   ผู้เรียกต้องเก็บ `save` ให้ได้ก่อนพิมพ์ · เก็บไม่ได้ = ไม่พิมพ์รหัส (ไม่มีรหัสดีกว่ารหัสซ้ำ)
 */
function nextOfflineRef({ saved, now, tz, deviceId } = {}) {
  const p = periodOf("day", now, tz);
  if (!p.ok) return p;
  const day = String(p.key);
  const last = saved && typeof saved === "object" && saved.day === day && isPosInt(saved.n) ? saved.n : 0;
  const n = last + 1;
  return { ok: true, ref: `${OFFLINE_REF_PREFIX}${day.slice(2)}-${deviceTag(deviceId)}-${pad(n, 2)}`, save: { day, n } };
}

module.exports = { periodOf, formatDocNumber, nextCounter, planTaxNumber, nextOfflineRef };

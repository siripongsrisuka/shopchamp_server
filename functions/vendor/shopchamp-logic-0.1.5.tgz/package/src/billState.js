// billState — สถานะของบิลที่หลายสูตรต้องตัดสินตรงกัน (ใบ DEV-0001 · live-fit.md §7 B7 · §8)
//
// isVoidedBill(bill) → boolean
//   ยกเลิก = ค่า `void` เป็น truthy · เท่าที่แอปเก่าทุกรุ่นตัดสิน:
//     first-gen `@5d69306d` › src/screens/HistoryScreen.js:64 `!!item.void` (บิลรุ่นแรกเก็บ void เป็น object `{dateTime, remark, user, userId}`)
//     main3 `@804ba8ff` › src/redux/billSlice.js:68-69 `filter(a=>!a.void)` · server `functions/apis/shift.js:261-262`
//   ใช้ทั้ง shift (นับบิลยกเลิก) และ docNumber (ไม่ออกเลขใบกำกับให้บิลยกเลิก) · เดิม 2 ตัวตอบต่างกันที่ void object
//   ของที่ไม่ใช่ object = ไม่ใช่บิล = false · ❌ ไม่ throw
"use strict";

function isVoidedBill(bill) {
  return !!(bill && typeof bill === "object" && bill.void);
}

module.exports = { isVoidedBill };

// company — สูตรของใบสั่งซื้อฝั่งบริษัท (แพ็กเกจ · อุปกรณ์ · พื้นที่รูป) และเลขใบสั่งซื้อ (DEV-0001 ก้อน 9d)
//
// เทียบกับสูตรเดิมของแอป main3 แล้ว: `lanes/dev/source/compare/old-logic/company.js` · ตาราง `test/company.golden.txt`
// ทุกแถวที่ผลต่างจากของเดิมชี้รหัสบั๊กใน `lanes/dev/source/bug-decisions/` หรือ `schema/*.md` (เทสบังคับ)
//
// หลัก
//   - ราคามาจากเอกสารของบริษัท (`admin/package` · `admin/hardware` · ตารางพื้นที่รูปในโค้ด) ไม่ใช่จากเครื่องผู้ซื้อ
//     (care AC-07 ค่าตั้งต้นที่ agent เลือก · ดู `lanes/dev/source/chunk9/9d-company.md` คำถามข้อ 1)
//     ⚠️ ไม่ขัด decision 2-2 (server เชื่อยอดขายของร้าน) เพราะนี่คือยอดที่ร้านจ่ายให้บริษัท ไม่ใช่ยอดขายของร้าน
//   - เงินคิดเป็นสตางค์จำนวนเต็มด้วย ./money แล้วหาร 100 จุดเดียว ⇒ ไม่มี 105.00000000000001 (hardwareOrder B6)
//   - เลขใบสั่งซื้อ = YYYYMM ตามนาฬิกาไทยของ server + ลำดับ 6 หลัก (AC-63 ใช้เวลา server · ตัวนับไม่รีเซ็ตรายเดือนเหมือนเดิม)
//   - ❌ ไม่ throw ทุกฟังก์ชัน · ผิด = {ok:false, error:<รหัสตัวใหญ่>, ...}
//
// ฟังก์ชัน
//   companyOrderNumber(stored, now)            ตัวนับ `admin/<x>Number` ที่อ่านได้ → {ok, orderNumber, value}
//   companyPackageQuote(packageDoc, ids)       แพ็กเกจที่เลือก → {ok, items[{id,name,price,save,type}], net}
//   companyHardwareQuote(hardwareDoc, lines, vat) ตะกร้าอุปกรณ์ → {ok, product[], totalPrice, deliveryFee, vatAmount, net}
//   companyImageQuote(optionId)                ตัวเลือกพื้นที่รูป → {ok, qty, net}
//   companyBahtText(v)                         ตัวเลข → "1,234.00" (แทน useToLocale ของแอป)
//   companyPackageNotiText(items) · companyHardwareNotiText(product) · companyImageNotiHeading(qty)  ข้อความ notification รูปเดิม
//   COMPANY_IMAGE_OPTIONS · COMPANY_HARDWARE_LIMIT_DEFAULT · COMPANY_DELIVERY_FREE_FROM · COMPANY_DELIVERY_FEE · COMPANY_ORDER_PENDING_TEXT
"use strict";

const money = require("./money");
const { periodOf } = require("./docNumber");

// ตารางพื้นที่รูปของแอปเดิม (main3 src/screens/ImageLimitScreen.js:27-33) · คัดตามตัว
const COMPANY_IMAGE_OPTIONS = Object.freeze([
  Object.freeze({ id: 1, image: 1000, price: 100 }),
  Object.freeze({ id: 2, image: 2000, price: 200 }),
  Object.freeze({ id: 3, image: 3000, price: 300 }),
  Object.freeze({ id: 4, image: 4000, price: 400 }),
  Object.freeze({ id: 5, image: 5000, price: 500 }),
]);
// จำนวนสั่งสูงสุดเมื่ออุปกรณ์ไม่ได้ตั้ง limit (main3 src/screens/HardwareScreen.js:82 `{limit:999,...a}`)
const COMPANY_HARDWARE_LIMIT_DEFAULT = 999;
// ค่าส่งอุปกรณ์ (main3 src/screens/HardwareSummaryScreen.js:64) · ยอดก่อน VAT ≥ 4000 ส่งฟรี ไม่งั้น 100
const COMPANY_DELIVERY_FREE_FROM = 4000;
const COMPANY_DELIVERY_FEE = 100;
const COMPANY_VAT_RATE_PERMILLE = 70; // 7% · คิดบนสตางค์ (0.07 ของเดิมเป็นทศนิยมลอยตัว · B6)
// ท้ายข้อความ notification ของใบสั่งซื้อทุกชนิด (PayScreen.js:157 · HardwareSummaryScreen.js:152 · ImageLimitScreen.js:140)
const COMPANY_ORDER_PENDING_TEXT = "สถานะ : รอตรวจสอบ\n*รอตรวจสอบยืนยันการชำระเงิน ภายใน 24 ชั่วโมง";
const RUN_WIDTH = 6;

const isObj = (o) => o !== null && typeof o === "object" && !Array.isArray(o);
const isNonEmptyString = (v) => typeof v === "string" && v !== "";

/**
 * companyOrderNumber(stored, now) — เลขใบถัดไปจาก `admin/packageNumber` `hardwareNumber` `imageNumber` (`stockNumber` ใช้ได้ด้วย)
 * @param {object|null|undefined} stored data ของ doc ตัวนับ · ไม่มี doc = null/undefined
 * @param {Date|number} now เวลา server
 * @returns {{ok:true, orderNumber:string, value:number, created:boolean} | {ok:false, error:'COUNTER_BROKEN'|'NOW_INVALID'}}
 *   ไม่มี doc = เริ่ม 1 และผู้เรียกต้องสร้าง doc (created:true · AC-38 เดิมไม่สร้าง ⇒ ทุกใบได้เลข ...000001)
 *   มี doc แต่ value ไม่ใช่จำนวนเต็ม ≥ 0 = COUNTER_BROKEN (เดิม undefined+1 = NaN ถูกเขียนกลับ · admin B9) · ไม่เดาเลข
 *   ตัวนับไม่รีเซ็ตรายเดือน (เหมือนเดิม) · หัว YYYYMM ตามนาฬิกาไทยของ server (เดิมนาฬิกาเครื่อง · AC-63)
 */
function companyOrderNumber(stored, now) {
  const p = periodOf("month", now);
  if (!p.ok) return { ok: false, error: "NOW_INVALID" };
  let value;
  let created = false;
  if (stored === null || stored === undefined) {
    value = 1;
    created = true;
  } else {
    const v = isObj(stored) ? stored.value : undefined;
    if (typeof v !== "number" || !Number.isSafeInteger(v) || v < 0 || !Number.isSafeInteger(v + 1)) return { ok: false, error: "COUNTER_BROKEN" };
    value = v + 1;
  }
  const head = String(Math.floor(p.key / 100)).padStart(4, "0") + String(p.key % 100).padStart(2, "0");
  return { ok: true, orderNumber: head + String(value).padStart(RUN_WIDTH, "0"), value, created };
}

/**
 * ราคาจากเอกสารบริษัท → สตางค์ · รับ number ที่ finite ≥ 0 หรือข้อความทศนิยมธรรมดา ("1500" "1500.50" · ราคาอุปกรณ์เก็บเป็นข้อความ)
 *   อย่างอื่น ("" "abc" "1e3" ค่าลบ NaN) = null ⇒ ผู้เรียกปัดรายการนั้น (เดิม Number('abc') = NaN ไหลเข้ายอด)
 */
function priceOf(v) {
  if (typeof v === "number") return Number.isFinite(v) && v >= 0 ? money.toSatang(v) : null;
  if (typeof v === "string" && /^\s*\d+(\.\d+)?\s*$/.test(v)) return money.toSatang(v.trim());
  return null;
}

/**
 * companyPackageQuote(packageDoc, ids) — ราคาแพ็กเกจที่ร้านเลือก จาก `admin/package`
 *   แถวที่ขายได้ = `value[]` ที่ `status` truthy (main3 PackageScreen.js:44 `value.filter(a=>a.status)`)
 *   หา `price[]` ด้วย `id` (ในฐานเป็นข้อความทั้ง 10 แถว · วัด 2026-11-06) เทียบแบบ String ⇒ รับได้ทั้งเลขและข้อความ
 *   ชื่อ = ชื่อแถว `value[].name` (แถว price ไม่มี name ในฐาน · main3 PackageScreen.js:60 `{name, ...price}`)
 *   net = ผลรวมราคา (แอปไม่มีปุ่ม VAT ของแพ็กเกจ · `vat` เป็น false เสมอ · packageOrder §1.1 แถว 9)
 * @returns {{ok:true, items, net, netSatang} | {ok:false, error:'PACKAGE_DOC_INVALID'|'NO_PACKAGE'|'DUPLICATE_PACKAGE'|'PACKAGE_UNAVAILABLE'|'PACKAGE_PRICE_INVALID', id?}}
 */
function companyPackageQuote(packageDoc, ids) {
  if (!isObj(packageDoc) || !Array.isArray(packageDoc.value)) return { ok: false, error: "PACKAGE_DOC_INVALID" };
  if (!Array.isArray(ids) || ids.length === 0) return { ok: false, error: "NO_PACKAGE" };
  const seen = new Set();
  const items = [];
  let netSatang = 0;
  for (const raw of ids) {
    const id = String(raw);
    if (seen.has(id)) return { ok: false, error: "DUPLICATE_PACKAGE", id };
    seen.add(id);
    let found = null;
    for (const row of packageDoc.value) {
      if (!isObj(row) || !row.status || !Array.isArray(row.price)) continue;
      const pr = row.price.find((p) => isObj(p) && p.id !== undefined && p.id !== null && String(p.id) === id);
      if (pr) { found = { row, pr }; break; }
    }
    if (!found) return { ok: false, error: "PACKAGE_UNAVAILABLE", id };
    const s = priceOf(found.pr.price);
    if (s === null || s === 0) return { ok: false, error: "PACKAGE_PRICE_INVALID", id };
    netSatang += s;
    items.push({
      id: found.pr.id,
      name: typeof found.row.name === "string" ? found.row.name : "",
      price: money.fromSatang(s),
      save: typeof found.pr.save === "number" ? found.pr.save : null,
      type: typeof found.row.type === "string" ? found.row.type : null,
    });
  }
  return { ok: true, items, net: money.fromSatang(netSatang), netSatang };
}

/** limit ของอุปกรณ์ · ไม่มี key · '' · ข้อความที่ไม่ใช่จำนวนเต็มบวก = ค่าตั้งต้น 999 (AC-67 · hardwareOrder/admin B12 เดิม '' สั่งได้ชิ้นเดียว) */
function limitOf(v) {
  if (typeof v === "number" && Number.isSafeInteger(v) && v >= 1) return v;
  if (typeof v === "string" && /^\s*\d+\s*$/.test(v)) {
    const n = Number(v.trim());
    if (Number.isSafeInteger(n) && n >= 1) return n;
  }
  return COMPANY_HARDWARE_LIMIT_DEFAULT;
}

/**
 * companyHardwareQuote(hardwareDoc, lines, vat) — ตะกร้าอุปกรณ์จาก `admin/hardware` ที่อ่านตอนสั่ง (ไม่ใช่ราคาที่ค้างในเครื่อง · B14)
 *   lines = [{id, qty}] · qty จำนวนเต็ม ≥ 1 · id ซ้ำ = ปัด
 *   แถวที่ขายได้ = `status === true` (main3 HardwareScreen.js:82 `.filter(b=>b.status)` · B19 ปิดขายแล้วยังค้างในตะกร้า)
 *   qty เกิน limit = QTY_OVER_LIMIT (เดิมกันที่ปุ่มบวกบนจออย่างเดียว · AC-67)
 *   totalPrice = Σ ราคา × qty · ค่าส่ง 0 เมื่อ totalPrice ≥ 4000 ไม่งั้น 100 · vat = 7% ของ totalPrice ปัดสตางค์ (B6)
 *   net = totalPrice + vatAmount + deliveryFee (รูปเดิม `1.07*totalPrice + deliveryFee`)
 *   product[] = แถวของบริษัท + {qty, totalPrice} (รูปเดิม `{...item, qty, totalPrice}` main3 HardwareScreen.js:57 · equipmentSlice.js:18)
 * @returns {{ok:true, product, totalPrice, deliveryFee, vatAmount, net} | {ok:false, error, id?, limit?}}
 */
function companyHardwareQuote(hardwareDoc, lines, vat) {
  if (!isObj(hardwareDoc) || !Array.isArray(hardwareDoc.value)) return { ok: false, error: "HARDWARE_DOC_INVALID" };
  if (!Array.isArray(lines) || lines.length === 0) return { ok: false, error: "EMPTY_CART" };
  const seen = new Set();
  const product = [];
  let totalSatang = 0;
  for (const line of lines) {
    if (!isObj(line) || !isNonEmptyString(line.id)) return { ok: false, error: "LINE_INVALID" };
    const qty = line.qty;
    if (typeof qty !== "number" || !Number.isSafeInteger(qty) || qty < 1) return { ok: false, error: "LINE_INVALID", id: line.id };
    if (seen.has(line.id)) return { ok: false, error: "DUPLICATE_HARDWARE", id: line.id };
    seen.add(line.id);
    const row = hardwareDoc.value.find((r) => isObj(r) && r.id === line.id);
    if (!row || row.status !== true) return { ok: false, error: "HARDWARE_UNAVAILABLE", id: line.id };
    const s = priceOf(row.price);
    if (s === null || s === 0) return { ok: false, error: "HARDWARE_PRICE_INVALID", id: line.id };
    const limit = limitOf(row.limit);
    if (qty > limit) return { ok: false, error: "QTY_OVER_LIMIT", id: line.id, limit };
    const lineSatang = s * qty;
    if (!Number.isSafeInteger(lineSatang)) return { ok: false, error: "HARDWARE_PRICE_INVALID", id: line.id };
    totalSatang += lineSatang;
    product.push({ ...row, qty, totalPrice: money.fromSatang(lineSatang) });
  }
  const vatSatang = vat === true ? Math.round((totalSatang * COMPANY_VAT_RATE_PERMILLE) / 1000) : 0;
  const feeSatang = totalSatang >= COMPANY_DELIVERY_FREE_FROM * 100 ? 0 : COMPANY_DELIVERY_FEE * 100;
  return {
    ok: true,
    product,
    totalPrice: money.fromSatang(totalSatang),
    deliveryFee: money.fromSatang(feeSatang),
    vatAmount: money.fromSatang(vatSatang),
    net: money.fromSatang(totalSatang + vatSatang + feeSatang),
  };
}

/** companyImageQuote(optionId) — ตัวเลือกพื้นที่รูป 1-5 → {ok, qty(=จำนวนรูป), net} · อื่น = IMAGE_OPTION_UNKNOWN */
function companyImageQuote(optionId) {
  const o = COMPANY_IMAGE_OPTIONS.find((x) => x.id === optionId);
  if (!o) return { ok: false, error: "IMAGE_OPTION_UNKNOWN" };
  return { ok: true, qty: o.image, net: o.price };
}

/** companyBahtText(v) — "1,234.00" แบบ useToLocale ของแอป (main3 src/Utility/function.js:752) · ไม่ใช่ตัวเลข = '' */
function companyBahtText(v) {
  if (typeof v !== "number" || !Number.isFinite(v)) return "";
  return v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** ข้อความ notification ของใบแพ็กเกจ · รูปเดิม main3 PayScreen.js:157 */
function companyPackageNotiText(items) {
  const list = Array.isArray(items) ? items : [];
  return `แพ็กเกจ\n${list.map((a) => `   ${a.name} (${companyBahtText(a.price)} บาท)`).join("\n")}\n${COMPANY_ORDER_PENDING_TEXT}`;
}

/** ข้อความ notification ของใบอุปกรณ์ · รูปเดิม main3 HardwareSummaryScreen.js:152 */
function companyHardwareNotiText(product) {
  const list = Array.isArray(product) ? product : [];
  return `อุปกรณ์\n${list.map((a) => `   ${a.name} x ${a.qty} (${companyBahtText(a.totalPrice)} บาท)`).join("\n")}\n${COMPANY_ORDER_PENDING_TEXT}`;
}

/** หัวข้อ notification ของใบพื้นที่รูป · คำผิด "พิ้นที่" คงตามเดิม (main3 ImageLimitScreen.js:138) ให้จอเก่าแสดงเหมือนเดิม */
function companyImageNotiHeading(qty) {
  return `ซื้อพิ้นที่เก็บรูปภาพ ${qty} รายการ`;
}

module.exports = {
  companyOrderNumber,
  companyPackageQuote,
  companyHardwareQuote,
  companyImageQuote,
  companyBahtText,
  companyPackageNotiText,
  companyHardwareNotiText,
  companyImageNotiHeading,
  COMPANY_IMAGE_OPTIONS,
  COMPANY_HARDWARE_LIMIT_DEFAULT,
  COMPANY_DELIVERY_FREE_FROM,
  COMPANY_DELIVERY_FEE,
  COMPANY_ORDER_PENDING_TEXT,
};

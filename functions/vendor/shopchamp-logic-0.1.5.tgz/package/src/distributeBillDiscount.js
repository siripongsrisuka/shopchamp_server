// distributeBillDiscount — กระจายส่วนลดท้ายบิลลงรายสินค้าตามสัดส่วน (ใบ DEV-0001 · ก้อน 2)
//
// ปิดบั๊ก (ฝั่งสูตร · ตาม lanes/dev/source/bug-decisions/):
//   #23 WR-02  ส่วนลดท้ายบิลไม่กระจายลงสินค้า ⇒ กระจายตามสัดส่วน `net` รายแถว · คิดตอนอ่านได้ (บิลเก่าไม่มีค่าที่กระจายแล้ว)
//   #5  K04    ส่วนลดเกินยอด / ส่วนลดติดลบ ⇒ ยอดต่ำสุด 0 ตัดส่วนเกินทิ้ง (คืน `excess` ให้เห็น) · ส่วนลดติดลบ = 0
//   F08        ทศนิยมลอย ⇒ คิดเป็นสตางค์จำนวนเต็ม ผลรวมส่วนแบ่งเท่าส่วนลดที่ใช้จริงเป๊ะ
//   F30 F31    ค่าว่าง · NaN · ข้อความ · รูป exponent ⇒ ผ่าน money.toNumber จุดเดียว ไม่ throw ไม่ได้ NaN
//
// สูตรเดิม (lanes/dev/source/compare/old-logic/distributeBillDiscount.js): ไม่กระจายเลย
//   หักส่วนลดที่ moneyMustPaid ระดับบิล (app:screens/CheckoutScreen.js:399-400) แล้วลง product[] จากตะกร้าตรง (:760)
//
// สัญญา:
//   billDiscountTotal(bill) → { manual, point, campaign, total } เป็นบาท ทศนิยม 2 ตำแหน่ง
//     - ส่วนลดท้ายบิล = ลดมือ `manualDiscount` + แลกแต้ม `pointDiscount.value` + แคมเปญ `campaign[].discount`
//     - แต่ละส่วนที่ติดลบ ว่าง หรืออ่านไม่ได้ = 0 · `bill` ว่าง/undefined = ทุกช่อง 0
//     - ❌ ไม่นับ `rounding` (ปัดเศษ ไม่ใช่ส่วนลด) · ❌ ไม่นับ `productDiscount` (อยู่ใน `net` รายแถวแล้ว)
//   distributeBillDiscount(products, discount) → { lines, base, applied, excess }
//     - `lines` = สำเนาแถวเดิมทุก field + `billDiscountShare` + `netAfterBillDiscount` · ❌ ไม่แก้ของที่ส่งเข้ามา
//     - ฐานของสัดส่วน = `net` รายแถว (หลังลดรายสินค้าแล้ว) · แถวที่ `net` ≤ 0 หรืออ่านไม่ได้ ไม่รับส่วนแบ่ง
//     - `base` = ผลรวม `net` ของแถวที่รับส่วนแบ่ง (ตัวหารของสัดส่วน)
//     - `applied` = min(ส่วนลด, ผลรวม `net` ทุกแถวรวมแถวติดลบ, base) ต่ำสุด 0 · `excess` = ส่วนที่ตัดทิ้ง
//       ⇒ ยอดบิลหลังลด (ผลรวม `netAfterBillDiscount` ทุกแถว) ไม่ติดลบเพราะส่วนลด (#5 K04)
//       เช่น net 100 กับ -20 ลด 90 ⇒ ใช้ได้ 80 · excess 10 · ยอดรวม 0 (เดิมก่อนแก้ได้ -10)
//       ยอดรวมติดลบอยู่แล้วก่อนลด (แถวติดลบมากกว่าแถวบวก) = ไม่ลดเลย ยอดคงเดิม ส่วนลดเป็น excess ทั้งหมด
//     - ผลรวม `billDiscountShare` = `applied` เป๊ะถึงสตางค์ · แถวที่รับส่วนแบ่งได้ไม่เกิน `net` ของตัวเอง
//     - แถวที่ไม่รับส่วนแบ่ง `netAfterBillDiscount` = `net` ปัดสตางค์ (ติดลบคงติดลบ · อ่านไม่ได้ = 0)
//     - เศษสตางค์ให้แถวที่เศษมากสุดก่อน เท่ากันให้แถวที่มาก่อน ⇒ input เดิมได้ผลเดิมเสมอ
//     - `products` ไม่ใช่ array = ไม่มีแถว · ส่วนลดทั้งหมดเป็น `excess`
//   บาท↔สตางค์ใช้ `money.toSatang` / `money.fromSatang` ตัวเดียวกับทุกหน่วย (ค่าลบปัดออกจากศูนย์ · ไม่คืน -0
//   · เกินช่วงที่นับสตางค์ได้แม่นเช่น "1e17" = อ่านไม่ได้ = 0)
//
// ⚠️ ผลต่อ VAT ที่หน่วยนี้ไม่ได้แก้ (ส่งต่อหน่วย vat · รอ Pack เคาะ):
//   หน่วยนี้แจกส่วนลดท้ายบิลให้ทุกแถวตามสัดส่วน รวมแถวยกเว้น VAT
//   แต่ `vat.computeVat` หักส่วนลดจากส่วนที่มี VAT ก่อน (คงแบบเดิม `CheckoutScreen.js:402` · vat.js หัวไฟล์ ข้อ ①)
//   ⇒ บิลที่มีแถวยกเว้น VAT + ส่วนลดท้ายบิล: VAT ที่คิดจากยอดรายแถวหลังกระจาย ≠ VAT ของบิล
//   ⇒ ห้ามคิด VAT รายแถวจาก `netAfterBillDiscount` จนกว่าจะเคาะว่าใช้กติกาไหนทั้งสองที่
//   (บิลเก่าก็ไม่มีข้อมูลให้คิด: `leanProduct` ไม่เก็บ `vatExemption` · function.js:610-625)
//
// ⚠️ ส่วนลดแคมเปญที่มีขอบเขต (percent รายเมนู/หมวด · gift · exchange · function.js:1843-1930) ถูกแจกลงทุกแถว
//   ไม่ใช่เฉพาะสินค้าในโปร · บิลเก่าไม่เก็บขอบเขตโปร (`campaign[]` มีแค่ name id rights discount promotionId)
//   ⇒ รอ Pack เคาะแยกบิลเก่ากับบิลใหม่ (ดูผลตรวจ chunk1-3-verify/logic-distributeBillDiscount.md ข้อ ข2)

const { toSatang, fromSatang: toBaht } = require("./money");

function billDiscountTotal(bill) {
  const b = bill && typeof bill === "object" ? bill : {};
  const pos = (v) => Math.max(0, toSatang(v));
  const manual = pos(b.manualDiscount);
  const pd = b.pointDiscount;
  const point = pos(pd && typeof pd === "object" ? pd.value : pd);
  const campaign = Array.isArray(b.campaign)
    ? b.campaign.reduce((acc, c) => acc + pos(c && c.discount), 0)
    : 0;
  return {
    manual: toBaht(manual),
    point: toBaht(point),
    campaign: toBaht(campaign),
    total: toBaht(manual + point + campaign),
  };
}

function distributeBillDiscount(products, discount) {
  const rows = Array.isArray(products) ? products : [];
  const want = Math.max(0, toSatang(discount));
  const weights = rows.map((p) => Math.max(0, toSatang(p && p.net)));
  const base = weights.reduce((a, w) => a + w, 0);
  // แถวติดลบหักออกจากเพดาน ไม่งั้นยอดบิลหลังลดติดลบได้ (#5 K04)
  const billNet = rows.reduce((a, p) => a + toSatang(p && p.net), 0);
  const applied = Math.max(0, Math.min(want, base, billNet));

  // ส่วนแบ่งเต็ม = floor(applied × w / base) ด้วย BigInt (กันล้นเมื่อยอดใหญ่) · เศษเก็บไว้แจกทีละสตางค์
  const shares = weights.map(() => 0);
  if (applied > 0) {
    const A = BigInt(applied), B = BigInt(base);
    const rem = [];
    let given = 0;
    weights.forEach((w, i) => {
      if (w === 0) return;
      const num = A * BigInt(w);
      const q = num / B;
      shares[i] = Number(q);
      given += shares[i];
      rem.push({ i, r: num - q * B });
    });
    rem.sort((x, y) => (x.r === y.r ? x.i - y.i : x.r > y.r ? -1 : 1));
    for (let k = 0; given < applied; k++, given++) shares[rem[k].i] += 1;
  }

  const lines = rows.map((p, i) => {
    const src = p && typeof p === "object" ? p : {};
    const net = toSatang(src.net);
    return {
      ...src,
      billDiscountShare: toBaht(shares[i]),
      netAfterBillDiscount: toBaht(net - shares[i]),
    };
  });

  return { lines, base: toBaht(base), applied: toBaht(applied), excess: toBaht(want - applied) };
}

module.exports = { billDiscountTotal, distributeBillDiscount };

// promotion — โปรโมชันระดับบิล (collection `promotion`) · ฟังก์ชันล้วน ไม่แตะฐาน ไม่อ่านนาฬิกาเองถ้าส่ง `now`
//
// ใบ DEV-0001 ก้อน 2 · Pack เคาะ 2026-11-06: server เชื่อยอดที่แอปส่งมา ⇒ ส่วนลดโปรต้องถูกตั้งแต่ฝั่งนี้
// ตัวเดิมในแอป: `Utility/function.js` manageCampaign · manageFortune · `redux/promotionSlice.js` handleExistPromotion (@804ba8ff)
//   สำเนาคำต่อคำอยู่ที่ `lanes/dev/source/compare/old-logic/promotion.js` · เทียบกันใน `test/promotion.test.js`
// ยกแบบจากบ้านพี่น้อง (คัดลอกแล้วเขียนใหม่ ไม่ผูก package): divideInput ที่กันตัวหาร ≤ 0 · ราคาฐานของแถม/แลกซื้อ = net · clamp แลกซื้อที่ 0
//
// สิ่งที่ต่างจากสูตรเดิมโดยตั้งใจ (ทุกข้อชี้รหัสใน `lanes/dev/source/bug-decisions/`):
//   F09  เงื่อนไข (tierTarget) ว่าง / 0 / ติดลบ / ไม่ใช่ตัวเลข = ไม่ได้สิทธิ์ · เดิมได้ Infinity สิทธิ์ หรือ minimumSale ลดทุกบิล
//   F32  โปร tier:true คิดได้ (เดิม divideInput ไม่มีนิยาม → ReferenceError ทั้งจอ)
//        divideInput ยกแบบจากบ้านพี่น้อง (ขั้นใหญ่ก่อน · ตัวหาร ≤ 0 = 0 สิทธิ์) · แถวรางวัล tier ที่ถึงขั้น rights = 1 ทุกแบบรางวัล
//        (เดิมแบบ gift exchange เลขนำโชค ใส่ตัวแปร rights ของแบบไม่ tier ซึ่งเป็น 0 ⇒ เลขนำโชคแบบ tier ไม่ออกเลขหลังแก้ F33)
//   F33  เลขนำโชคออกเฉพาะเมื่อได้สิทธิ์ (rights > 0) · เดิมออกทุกบิล
//   F37  แลกซื้อ: ส่วนลดต่อชิ้นอยู่ในช่วง 0 ถึงราคาชิ้นนั้น · เดิมติดลบแล้วไปหักของแพง หรือเกินราคาของ
//   F38  ของแถมเรียงราคาเป็นตัวเลข (ถูกสุดก่อน) · เดิมเรียงแบบข้อความ '100' มาก่อน '5'
//   K15  ฐานของ percent / gift / exchange = net (ยอดหลังราคาโปรรายสินค้าหรือราคาส่ง) · เดิมใช้ราคาป้าย แต่หักจาก net
//   K04  ส่วนลด percent ไม่เกิน 100% · ผลรวมส่วนลดโปรทั้งบิลไม่เกิน Σ net (ตัดส่วนเกินจากแถวท้าย) · ยอดก่อน VAT
//   F08  เงื่อนไขเงินเทียบเป็นสตางค์ · ส่วนลดแต่ละแถวปัดเป็นสตางค์ (ปัดครึ่งขึ้น) · เดิม 29.999999999999996 ไม่ถึง 30
//   F24  แถวในตะกร้าที่จำนวน ≤ 0 ไม่เข้าเป็นของแถม/แลกซื้อ · เดิม totalPrice/0 ได้ NaN แล้วทั้งโปรหาย
//   F56  ค่ารางวัลที่ไม่ finite (เช่น '1e999') ไม่ให้รางวัล · เดิมได้ส่วนลด Infinity
//   DI-48 category ของสินค้าที่ไม่ใช่ array ไม่ทำล้ม (ข้อความ 1 ตัว = หมวดเดียว · อื่น = ไม่มีหมวด) · schema P14
//   F41  เอกสารไม่มี workingDays ไม่ทำโปรทั้งร้านหาย · ตัวนั้นถือว่าไม่ทำงาน
//   ฟิลด์รายการที่หาย (barcode slot1 slot2 rewardBarcode scope) = รายการว่าง ไม่ throw · ❓ ยังไม่มีรหัสบั๊กตรงตัว
//
// คงเดิมโดยตั้งใจ (ยังไม่มี decision ให้เปลี่ยน):
//   - เงื่อนไขยอดเงิน (minimumSale sale itemSale categorySale) ยังนับจาก totalPrice (ราคาป้าย) ไม่ใช่ net
//   - K16 สินค้าตัวเดียวนับเข้าได้ทั้ง slot1 และ slot2 · ของแถมนับจากชิ้นที่เป็นเงื่อนไขได้ (ต้องเคาะ · ไม่มีข้อเสนอทางแรก)
//   - percent ไม่คูณจำนวนสิทธิ์ · discount คูณ · items ได้สิทธิ์ = min(qty กลุ่ม 1, qty กลุ่ม 2) ไม่ปัด
//   - tier:true ให้รางวัลของขั้นสูงสุดที่ถึง **ครั้งเดียว** ไม่คูณจำนวนสิทธิ์ของขั้นนั้น (ตามที่สูตรเดิมเขียนไว้ และเหมือนบ้านพี่น้อง)
//     ⇒ sameItem ซื้อ 2 แถม 1 ซื้อ 6 ชิ้น: แบบไม่ tier ฟรี 2 · แบบ tier ฟรี 1 · ❓ ยังไม่มี decision ว่าแบบนี้คือที่ร้านต้องการ (ยกถาม Pack แล้ว)
//   - items กับ tier:true ไม่ให้รางวัล (สูตรเดิมไม่มีขั้นของ items · คงเดิม)
//   - ผูกสินค้าด้วย barcode เทียบตรงชนิด (F39 ยังเปิด) · วันและชั่วโมงของโปรใช้นาฬิกาเครื่องตามปฏิทิน (member K15 ยังไม่เคาะ)
//   - specialPromotion ไม่มีผลกับการขาย (K17 ทางแรก = ให้จอแสดง ไม่ตัดออกจากการขาย)
//
// สัญญาค่าที่ป้อน:
//   products[] แถวตะกร้า { barcode, qty, price, totalPrice, net, category[] } · ตัวเลขที่ไม่ finite นับเป็น 0
//   promotions[] เอกสาร promotion (ดู `lanes/dev/source/schema/promotion.md` §1) · ไม่ throw ทุกรูป

const FORTUNE_IDS = new Set(["5", "6", "11", "12"]);
const PROMO_TYPES = ["anySale", "minimumSale", "sale", "item", "itemSale", "category", "categorySale", "items", "sameItem"];
const REWARD_TYPES = ["discount", "percent", "gift", "exchange", "doubleFortune", "tripleFortune"];
const TARGET_FREE_TYPES = new Set(["anySale", "items"]);
const LISTED_TYPES = new Set(["item", "itemSale", "category", "categorySale", "sameItem"]);
const SCOPE_TARGETS = ["menu", "onInvoice", "category"];
const FIX_CODES = ["F09", "F32", "F33", "F37", "F38", "K15", "K04", "F08", "F24", "F56"];
const ALL_FIXES = Object.freeze(Object.fromEntries(FIX_CODES.map((c) => [c, true])));

// ── ตัวช่วย ─────────────────────────────────────────────────────────
// ค่าในเอกสารโปรเก็บเป็นข้อความ ⇒ แปลงด้วย Number แบบเดียวกับสูตรเดิม ('' → 0 · '1e2' → 100 · '1,000' → NaN)
const N = (v) => Number(v);
// ค่าในตะกร้า: ไม่ finite = 0
const amt = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};
const list = (v) => (Array.isArray(v) ? v.filter((x) => x && typeof x === "object") : []);
const cats = (v) => (Array.isArray(v) ? v : typeof v === "string" && v !== "" ? [v] : []);
// ปัดเป็นสตางค์ ครึ่งขึ้น · toFixed(6) ตัดเศษลอยก่อนปัด (2.675*100 = 267.49999999999997)
const toSatang = (x) => Math.round(Number((x * 100).toFixed(6)));
const roundSatang = (x) => toSatang(x) / 100;
// floor ที่ไม่หล่นเพราะเศษลอย: 0.9999999999999998 → 1
const floorDiv = (a, b) => Math.floor(Number((a / b).toFixed(9)));

// ตัวเทียบเดียวกับ reverseSort ของแอปเดิม (ชื่อหลอก = น้อยไปมาก) · Array.sort ของ V8 เสถียร ⇒ ลำดับเท่ากันคงลำดับตะกร้า
const ascBy = (key) => (a, b) => (a[key] < b[key] ? -1 : a[key] > b[key] ? 1 : 0);

function toDate(v) {
  if (v instanceof Date) return v;
  if (v && typeof v === "object") {
    if (typeof v.toDate === "function") return v.toDate();
    if ("seconds" in v) return new Date(Number(v.seconds) * 1000 + Number(v.nanoseconds || 0) / 1e6);
    if ("_seconds" in v) return new Date(Number(v._seconds) * 1000 + Number(v._nanoseconds || 0) / 1e6);
    return new Date(NaN);
  }
  if (typeof v === "number" || typeof v === "string") return new Date(v);
  return new Date(NaN);
}
// เลขวันแบบ 20261106 ตามนาฬิกาเครื่อง (เท่า NumberYMD เดิม) · วันที่อ่านไม่ออก = NaN
function ymd(v) {
  const d = toDate(v);
  if (Number.isNaN(d.getTime())) return NaN;
  return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
}

// ── divideInput ────────────────────────────────────────────────────
/**
 * แตกยอดเป็นจำนวนสิทธิ์ต่อขั้น (ขั้นใหญ่สุดก่อน) · index ตรงกับ divisors
 * ตัวหารที่ไม่ใช่ตัวเลขบวก = 0 สิทธิ์ในขั้นนั้น (กัน Infinity / NaN · F09)
 * @param {number} input
 * @param {Array<number|string>} divisors
 * @returns {number[]}
 */
function divideInput(input, divisors) {
  return divide(input, divisors, ALL_FIXES);
}
// ปิด F09 = แบบบ้านพี่น้องเป๊ะ (ตัวหาร Infinity / NaN ทำยอดที่เหลือเป็น NaN) · ปิด F08 = Math.floor ตรง ๆ
function divide(input, divisors, fx) {
  const ds = (Array.isArray(divisors) ? divisors : []).map(N);
  const out = new Array(ds.length).fill(0);
  let rest = fx.F09 ? amt(input) : input;
  for (let i = ds.length - 1; i >= 0; i--) {
    const d = ds[i];
    if (fx.F09) {
      if (!(Number.isFinite(d) && d > 0)) continue;
      const q = Math.max(0, floorDiv(rest, d));
      out[i] = q;
      rest -= q * d;
    } else {
      const q = d > 0 ? (fx.F08 ? floorDiv(rest, d) : Math.floor(rest / d)) : 0;
      out[i] = q;
      rest -= q * d;
    }
  }
  return out;
}

// ── โปรไหนทำงานตอนนี้ ──────────────────────────────────────────────
/**
 * โปรทำงาน ณ เวลา now ไหม · เท่าเงื่อนไขเดิม: status · วันในสัปดาห์ · ช่วงวันที่ (รวมปลายทั้งคู่) · ชั่วโมง
 * ต่างจากเดิม: workingDays หาย/ไม่ใช่ array = ไม่ทำงาน (F41) · วันที่อ่านไม่ออก = ไม่ทำงาน · ไม่ throw
 * @param {object} promo
 * @param {Date} [now]
 */
function isPromotionActive(promo, now = new Date()) {
  if (!promo || typeof promo !== "object" || !promo.status) return false;
  const at = toDate(now);
  if (Number.isNaN(at.getTime())) return false;
  const day = at.getDay();
  const hour = at.getHours();
  const wd = Array.isArray(promo.workingDays) ? promo.workingDays.find((a) => a && a.id === day) : undefined;
  if (!wd || !wd.status) return false;
  if (promo.expireType !== "infinity") {
    const today = ymd(at);
    if (!(today >= ymd(promo.startDate) && today <= ymd(promo.endDate))) return false;
  }
  return Boolean(wd.allDay) || (Array.isArray(wd.period) && wd.period.includes(hour));
}

/**
 * แยกโปรที่ทำงานตอนนี้เป็น auto (คิดเอง) และ manual (แคชเชียร์กด) · ตัวเดิมเก็บใน redux autoPromotions / manualPromotions
 * @returns {{auto: object[], manual: object[]}}
 */
function availablePromotions(promotions, now = new Date()) {
  const active = list(promotions).filter((p) => isPromotionActive(p, now));
  return { auto: active.filter((p) => p.auto), manual: active.filter((p) => !p.auto) };
}

// ── คิดส่วนลด ──────────────────────────────────────────────────────
function normalizeCart(products) {
  return list(products).map((p) => ({
    barcode: p.barcode,
    qty: amt(p.qty),
    price: p.price,
    totalPrice: amt(p.totalPrice),
    net: amt(p.net),
    category: cats(p.category),
  }));
}

function rightsOf(promo, cart, billTotalPrice, fx) {
  const { type, tier } = promo;
  const tierTarget = Array.isArray(promo.tierTarget) ? promo.tierTarget : [];
  const tierReward = Array.isArray(promo.tierReward) ? promo.tierReward : [];
  const t0 = N(tierTarget[0]);
  const targetOk = (t) => !fx.F09 || (Number.isFinite(t) && t > 0);
  const per = (metric, t) => (!targetOk(t) ? 0 : fx.F08 ? floorDiv(metric, t) : Math.floor(metric / t));
  const byBarcode = (rows) => new Set(rows.map((a) => a.barcode));
  const byId = (rows) => new Set(rows.map((a) => a.id));
  const sum = (pred, key) => cart.reduce((acc, l) => (pred(l) ? acc + l[key] : acc), 0);

  let metric = null; // ค่าที่เอาไปหาร tierTarget (แบบมาตรฐาน)
  switch (type) {
    case "anySale":
      return { rights: 1, divided: [] };
    case "minimumSale": {
      if (!targetOk(t0)) return { rights: 0, divided: [] };
      const hit = fx.F08 ? toSatang(t0) <= toSatang(billTotalPrice) : t0 <= billTotalPrice;
      return { rights: hit ? 1 : 0, divided: [] };
    }
    case "items": {
      const s1 = byBarcode(list(promo.slot1));
      const s2 = byBarcode(list(promo.slot2));
      const q1 = sum((l) => s1.has(l.barcode), "qty");
      const q2 = sum((l) => s2.has(l.barcode), "qty");
      return { rights: Math.min(q1, q2), divided: [] };
    }
    case "sameItem": {
      const set = byBarcode(list(promo.barcode));
      const qty = sum((l) => set.has(l.barcode), "qty");
      if (tier) {
        // เดิม parseInt(target) + parseInt(reward) ('1e2' → 1 · '1.5' → 1 · '' → NaN) · แก้ F09 = Number แบบเดียวกับแบบไม่ tier
        const ds = fx.F09
          ? tierTarget.map((t, i) => (targetOk(N(t)) ? N(t) + N(tierReward[i]) : NaN))
          : tierTarget.map((t, i) => parseInt(t) + parseInt(tierReward[i]));
        return { rights: 0, divided: divide(qty, ds, fx) };
      }
      if (!targetOk(t0)) return { rights: 0, divided: [] };
      // ซื้อ t แถม r = ต้องมีครบ t + r ชิ้นต่อ 1 สิทธิ์
      const d = t0 + N(tierReward[0]);
      if (fx.F09 && !(Number.isFinite(d) && d > 0)) return { rights: 0, divided: [] };
      return { rights: fx.F08 ? floorDiv(qty, d) : Math.floor(qty / d), divided: [] };
    }
    case "sale":
      metric = billTotalPrice;
      break;
    case "item": {
      const set = byBarcode(list(promo.barcode));
      metric = sum((l) => set.has(l.barcode), "qty");
      break;
    }
    case "itemSale": {
      const set = byBarcode(list(promo.barcode));
      metric = sum((l) => set.has(l.barcode), "totalPrice");
      break;
    }
    case "category": {
      const ids = byId(list(promo.barcode));
      metric = sum((l) => l.category.some((c) => ids.has(c)), "qty");
      break;
    }
    case "categorySale": {
      const ids = byId(list(promo.barcode));
      metric = sum((l) => l.category.some((c) => ids.has(c)), "totalPrice");
      break;
    }
    default:
      return { rights: 0, divided: [] };
  }
  if (tier) return { rights: 0, divided: divide(metric, tierTarget.map((t) => (targetOk(N(t)) ? t : NaN)), fx) };
  return { rights: per(metric, t0), divided: [] };
}

function rewardPool(promo, cart, fx) {
  const src = promo.type === "sameItem" ? promo.barcode : promo.rewardBarcode;
  const set = new Set(list(src).map((a) => a.barcode));
  return cart.filter((l) => set.has(l.barcode) && (!fx.F24 || l.qty > 0));
}

function _computeCampaign(products, promotions, fx = ALL_FIXES) {
  const cart = normalizeCart(products);
  const billTotalPrice = cart.reduce((a, l) => a + l.totalPrice, 0);
  const rows = [];

  for (const promo of list(promotions)) {
    const { name, id, promotionId, rewardType, tier } = promo;
    const tierReward = Array.isArray(promo.tierReward) ? promo.tierReward : [];
    const { rights, divided } = rightsOf(promo, cart, billTotalPrice, fx);

    let lastIndex = -1;
    for (let i = divided.length - 1; i >= 0; i--) {
      if (divided[i] > 0) {
        lastIndex = i;
        break;
      }
    }
    const tierHit = Boolean(tier) && lastIndex > -1;
    const flatHit = !tier && rights > 0;
    const rewardOk = (x) => !fx.F56 || Number.isFinite(x);
    const push = (discount, r) => rows.push({ name, id, rights: r, discount, promotionId });
    // แถว tier ที่ถึงขั้น = 1 สิทธิ์ (F32) · เดิม gift exchange เลขนำโชค ใช้ rights ของแบบไม่ tier (= 0)
    const tierRights = tierHit && fx.F32 ? 1 : rights;

    switch (rewardType) {
      case "doubleFortune":
      case "tripleFortune":
        if (!fx.F33 || flatHit || tierHit || (tier && rights > 0)) push(0, tierRights);
        break;
      case "discount": {
        const r = tierHit ? N(tierReward[lastIndex]) : N(tierReward[0]);
        if (!rewardOk(r)) break;
        if (tierHit) push(r, 1);
        else if (flatHit) push(r * rights, rights);
        break;
      }
      case "percent": {
        let pct = tierHit ? N(tierReward[lastIndex]) : N(tierReward[0]);
        if (!rewardOk(pct)) break;
        if (fx.K04) pct = Math.min(pct, 100);
        const base = fx.K15 ? "net" : "totalPrice";
        const scope = list(promo.scope);
        let sumPrice = 0;
        switch (promo.scopeTarget) {
          case "menu": {
            const ids = new Set(scope.map((a) => a.barcode));
            sumPrice = cart.reduce((s, l) => (ids.has(l.barcode) ? s + l[base] : s), 0);
            break;
          }
          case "onInvoice":
            sumPrice = fx.K15 ? cart.reduce((s, l) => s + l.net, 0) : billTotalPrice;
            break;
          case "category": {
            const ids = new Set(scope.map((a) => a.id));
            sumPrice = cart.reduce((s, l) => (l.category.some((c) => ids.has(c)) ? s + l[base] : s), 0);
            break;
          }
          default:
            break;
        }
        if (tierHit) push((pct * sumPrice) / 100, 1);
        else if (flatHit) push((pct * sumPrice) / 100, rights);
        break;
      }
      case "gift": {
        if (!tierHit && !flatHit) break;
        let quota = tierHit ? N(tierReward[lastIndex]) : N(tierReward[0]) * rights;
        if (!rewardOk(quota)) break;
        const pool = rewardPool(promo, cart, fx).map((l) => ({
          qty: l.qty,
          unit: fx.K15 ? l.net / l.qty : fx.F38 ? N(l.price) : l.price,
        }));
        pool.sort(ascBy("unit"));
        let discount = 0;
        for (const { qty, unit } of pool) {
          if (quota <= 0) break;
          const q = Math.min(quota, qty);
          discount += q * N(unit);
          quota -= q;
        }
        push(discount, tierRights);
        break;
      }
      case "exchange": {
        if (!tierHit && !flatHit) break;
        let quota = tierHit ? N(tierReward[lastIndex]) : N(tierReward[0]) * rights;
        if (!rewardOk(quota)) break;
        const ex = N(promo.exchangePrice);
        const pool = rewardPool(promo, cart, fx).map((l) => ({
          qty: l.qty,
          unit: (fx.K15 ? l.net : l.totalPrice) / l.qty,
        }));
        pool.sort(ascBy("unit"));
        let discount = 0;
        for (const { qty, unit } of pool) {
          if (quota <= 0) break;
          const q = Math.min(quota, qty);
          const each = fx.F37 ? Math.min(unit, Math.max(0, unit - ex)) : unit - ex;
          discount += q * each;
          quota -= q;
        }
        push(discount, tierRights);
        break;
      }
      default:
        break;
    }
  }

  let out = rows;
  if (fx.F08) out = out.map((r) => ({ ...r, discount: Number.isFinite(r.discount) ? roundSatang(r.discount) : r.discount }));
  out = out.filter((a) => a.discount > 0 || FORTUNE_IDS.has(a.promotionId));
  if (fx.K04) out = capCampaign(out, cart.reduce((a, l) => a + l.net, 0));
  return out;
}

/**
 * ส่วนลดจากโปรทุกตัวที่ส่งเข้ามา (ไม่กรองเวลา · ส่ง auto หรือ manual ที่ทำงานแล้ว) → แถวที่ลง `bill.campaign`
 * @param {object[]} products แถวตะกร้า
 * @param {object[]} promotions เอกสารโปร
 * @returns {{name, id, rights:number, discount:number, promotionId}[]} discount เป็นสตางค์ ≥ 0 · ผลรวม ≤ Σ net
 */
function computeCampaign(products, promotions) {
  return _computeCampaign(products, promotions, ALL_FIXES);
}

/**
 * ตัดส่วนลดรวมไม่ให้เกิน limit (K04 ทางแรก: ยอดต่ำสุด 0 ตัดส่วนลดส่วนเกินทิ้ง) · ตัดจากแถวท้ายขึ้นมา
 * ใช้ซ้ำได้ตอนรวมโปร auto กับ manual ที่คิดแยกกัน · แถวที่เหลือ 0 ถูกทิ้ง ยกเว้นแถวเลขนำโชค
 * เทียบเป็นสตางค์ · แถวที่ไม่ถูกตัดคงค่าเดิม (ปัดสตางค์จุดเดียวที่ computeCampaign) · แถวที่ถูกตัดได้ค่าสตางค์ที่เหลือ
 * @param {object[]} rows แถว campaign
 * @param {number} limit ยอดสูงสุดที่ลดได้ (ปกติ = Σ net ก่อน VAT)
 */
function capCampaign(rows, limit) {
  let remain = Math.max(0, toSatang(amt(limit)));
  const out = [];
  for (const r of list(rows)) {
    const want = Math.max(0, toSatang(amt(r.discount)));
    const got = Math.min(want, remain);
    remain -= got;
    if (got > 0 || FORTUNE_IDS.has(r.promotionId)) out.push({ ...r, discount: got === want ? Math.max(0, amt(r.discount)) : got / 100 });
  }
  return out;
}

/**
 * เลขนำโชคของบิล (ลง `bill.lucky`) · 2 หลักถ้ามีโปร 5 หรือ 11 · 3 หลักถ้ามีโปร 6 หรือ 12
 * นับเฉพาะแถวที่ได้สิทธิ์ (rights > 0 · F33) · rng ส่งเข้ามาได้เพื่อเทส
 * @returns {string[]}
 */
function luckyNumbers(campaign, rng = Math.random) {
  const ok = list(campaign).filter((a) => amt(a.rights) > 0);
  const has = (ids) => ok.some((a) => ids.includes(a.promotionId));
  const draw = (max, digits) => {
    const n = Math.min(max - 1, Math.max(0, Math.floor(amt(rng()) * max)));
    return n.toString().padStart(digits, "0");
  };
  return [...(has(["5", "11"]) ? [draw(100, 2)] : []), ...(has(["6", "12"]) ? [draw(1000, 3)] : [])];
}

/**
 * ด่านก่อนบันทึกโปร (สูตรของจอตั้งค่า) · คืนรายการปัญหา [] = บันทึกได้
 * @returns {{field: string, bug: string}[]}
 *   DI-53 ไม่เลือกแบบโปร/รางวัล · รายการสินค้า/หมวดที่โปรต้องใช้ว่าง (barcode slot1 slot2 rewardBarcode scope · schema P11)
 *         · scopeTarget ของ percent ไม่ใช่ menu onInvoice category
 *   F09 เงื่อนไขว่าง/≤0 · F36 รางวัลว่าง/≤0 · K04 percent เกิน 100 · F37 ราคาแลกซื้อว่าง/ติดลบ/ไม่ใช่ตัวเลข
 *   (ราคาแลกซื้อว่าง = เดิม Number('') = 0 ⇒ ของฟรีทั้งชิ้น · ร้านที่ตั้งใจให้ฟรีกรอก 0 เอง)
 */
function validatePromotion(promo) {
  const p = promo && typeof promo === "object" ? promo : {};
  const out = [];
  const pos = (v) => Number.isFinite(N(v)) && N(v) > 0 && !(typeof v === "string" && v.trim() === "");
  const arr = (v) => (Array.isArray(v) ? v : []);
  if (!PROMO_TYPES.includes(p.type)) out.push({ field: "type", bug: "DI-53" });
  if (!REWARD_TYPES.includes(p.rewardType)) out.push({ field: "rewardType", bug: "DI-53" });
  const targets = p.tier ? arr(p.tierTarget) : arr(p.tierTarget).slice(0, 1);
  if (PROMO_TYPES.includes(p.type) && !TARGET_FREE_TYPES.has(p.type) && (targets.length === 0 || !targets.every(pos))) {
    out.push({ field: "tierTarget", bug: "F09" });
  }
  if (["discount", "percent", "gift", "exchange"].includes(p.rewardType)) {
    const rewards = p.tier ? arr(p.tierReward) : arr(p.tierReward).slice(0, 1);
    if (rewards.length === 0 || !rewards.every(pos)) out.push({ field: "tierReward", bug: "F36" });
    else if (p.rewardType === "percent" && rewards.some((r) => N(r) > 100)) out.push({ field: "tierReward", bug: "K04" });
  }
  if (p.rewardType === "exchange") {
    const ex = N(p.exchangePrice);
    const blank = p.exchangePrice == null || (typeof p.exchangePrice === "string" && p.exchangePrice.trim() === "");
    if (blank || !(Number.isFinite(ex) && ex >= 0)) out.push({ field: "exchangePrice", bug: "F37" });
  }
  // รายการที่หาย = โปรไม่ให้อะไรเงียบ ๆ (คลาสเดียวกับ F36) · ตรวจเฉพาะ field ที่แบบนั้นใช้จริงใน computeCampaign
  const empty = (k) => list(p[k]).length === 0;
  if (LISTED_TYPES.has(p.type) && empty("barcode")) out.push({ field: "barcode", bug: "DI-53" });
  if (p.type === "items") {
    if (empty("slot1")) out.push({ field: "slot1", bug: "DI-53" });
    if (empty("slot2")) out.push({ field: "slot2", bug: "DI-53" });
  }
  if ((p.rewardType === "gift" || p.rewardType === "exchange") && PROMO_TYPES.includes(p.type) && p.type !== "sameItem" && empty("rewardBarcode")) {
    out.push({ field: "rewardBarcode", bug: "DI-53" });
  }
  if (p.rewardType === "percent") {
    if (!SCOPE_TARGETS.includes(p.scopeTarget)) out.push({ field: "scopeTarget", bug: "DI-53" });
    else if (p.scopeTarget !== "onInvoice" && empty("scope")) out.push({ field: "scope", bug: "DI-53" });
  }
  return out;
}

module.exports = {
  divideInput,
  isPromotionActive,
  availablePromotions,
  computeCampaign,
  capCampaign,
  luckyNumbers,
  validatePromotion,
  PROMOTION_FORTUNE_IDS: FORTUNE_IDS,
};
// ทางเข้าของเทสตัวเทียบเท่านั้น (ปิดทีละข้อแก้ เพื่อพิสูจน์ว่าผลต่างทุกแถวมาจากข้อแก้) · ไม่นับใน spread ของ index
Object.defineProperty(module.exports, "_computeCampaign", { value: _computeCampaign, enumerable: false });
Object.defineProperty(module.exports, "_FIX_CODES", { value: FIX_CODES, enumerable: false });

// vat — สูตร VAT ของบิลขายปลีก · ฟังก์ชันล้วน ไม่แตะฐาน (ก้อน 2 · DEV-0001)
//
// แทนสูตรเดิมในแอป shopcham_merchant_2025@804ba8ff:
//   · `screens/CheckoutScreen.js:397-431` (useMemo คิด VAT และ moneyMustPaid) + `:441-452` (รวม noVatAmount จากตะกร้า)
//   · `hook/usePrintAction.js:56` (Before VAT ใบกำกับแลน) + `:267-290` (ใบกำกับ Sunmi)
//   · `screens/PaySettingScreen.js:179` + `Utility/function.js:1448` (ช่องอัตรา VAT)
//   สำเนาคำต่อคำของสูตรเดิมอยู่ที่ `lanes/dev/source/compare/old-logic/vat.js` · ตัวเทียบอยู่ใน `test/vat.test.js`
//
// Pack เคาะ 2026-11-06: server เชื่อยอดที่แอปส่ง ⇒ สูตรนี้คือที่เดียวที่ยอด VAT ถูกคิด ต้องถูกเอง
//
// บั๊กที่ไฟล์นี้ปิด (รหัสตาม `lanes/dev/source/bug-decisions/`):
//   F08    คิดเป็นสตางค์จำนวนเต็ม ปัดจุดเดียว (เดิม toFixed บนทศนิยมลอยตัว · moneyMustPaid ไม่ปัด)
//   K04/#5 ส่วนลดติดลบไม่นับ · ส่วนลดเกินยอดตัดทิ้ง ยอดต่ำสุด 0
//          ⚠️ ร้าน Exclude: ตัวใหม่ให้ลดได้ถึงยอดก่อน VAT · ข้อเสนอ K04 (`money.md:41`) ยังเปิดว่า "ก่อนหรือหลัง VAT"
//          ⇒ ข้อนี้ยัง **ต้องเคาะ** ไม่ใช่ปิดแล้ว · ที่เลือกไว้คือทางที่ใกล้แอปเดิมที่สุด (เดิมส่วนลดเกินยอดก่อน VAT ได้ VAT ติดลบ ยอดติดลบ)
//   RT-23  ฐาน VAT ต่ำสุด 0 ⇒ VAT ไม่ติดลบ ไม่ลดยอดลูกค้า · บิลเก่าที่ vatAmount ติดลบแล้ว `vatDocOf` ปัด ไม่ออกใบกำกับ
//   RT-08  อัตรา VAT ต้องเป็นเลขฐานสิบ 0-100 · "7.5" ได้ 7.5 (เดิมได้ 75) · ว่าง/เกิน 100 = ปัด ไม่คิดเป็น 0
//   RT-38  (ฝั่งสูตร) ไม่ได้รับค่าตั้ง VAT = ปัด `vat-config-missing` ไม่เดา 7%
//          กลไกเดิม: `redux/shopSlice.js:26` รวม `initialShop` (`config/initialShop.js:146-152` เปิด 7% Include) ทุกครั้ง
//          ⇒ ทั้ง doc ที่ไม่มี field และ `fetchShop` ที่ล้มแล้วคืน `{}` (`shopSlice.js:91-102`) ได้ 7% Include เหมือนกัน แยกไม่ออก
//          ตัวใหม่แยก 2 กรณีที่ผู้โหลดร้าน: doc โหลดสำเร็จแต่ไม่มี field = ส่ง `DEFAULT_SHOP_VAT` (ผลเท่าแอปเดิม · `schema/shop.md:128`)
//          · โหลดล้ม = ไม่ส่งอะไร ⇒ สูตรปัด ไม่ขายด้วยค่าตั้งต้น · ⚠️ ตัวโหลดร้านไม่อยู่ในหน่วยนี้ · รอแม่/Pack เคาะว่าจอขายปัดหรือเติมค่าตั้งต้น
//   RT-09 · RT-19 · RT-07 (ฝั่งสูตร) คืน `noVatAmount` แยกจาก `beforeVat` ⇒ beforeVat + noVatAmount + vatAmount = total ทุกใบ
//          และใบกำกับทุกท่อใช้ `vatDocOf` ตัวเดียว
//   RT-46 (ฝั่งสูตร) บิลเก่าขาด field ไม่ได้ NaN
//
// พฤติกรรมเดิมที่คงไว้โดยตั้งใจ (ไม่มีรหัสบั๊ก ⇒ เปลี่ยน = ผลต่างที่อธิบายไม่ได้):
//   ① ส่วนลดท้ายบิลหักจากส่วนที่คิด VAT ก่อน ส่วนเกินจึงไปกินสินค้ายกเว้น VAT (`CheckoutScreen.js:402`)
//   ② ชนิดที่ไม่ใช่ 'Include' ทุกค่า (รวมไม่มี type) = บวก VAT เพิ่มแบบ Exclude (`:406-410`)
//   ③ `status` ตัดสินแบบ truthy (`:405`) · ไม่มี status / 0 / '' = ปิด · 1 / 'true' / 'false' (ข้อความไม่ว่าง) = เปิด
//   ④ ปัดเศษท้ายบิลไม่อยู่ในไฟล์นี้ · ผู้เรียกบวกหลัง `total` ตามลำดับเดิม (`:413-417`)
//   ⑤ noVatAmount ติดลบ (แถวยกเว้น VAT ราคาติดลบ · ต้นเหตุคือ F50 ราคาไม่ตรวจก่อนเขียน) = ฐาน VAT ใหญ่ขึ้นตามเดิม ไม่ตัดที่ 0
//
//
// ยังไม่ปิด (อย่าอ้างว่าปิด):
//   RT-24  ร้านปิด VAT ยังออกใบกำกับ · บิล VAT 0 เขียน vatType · รายงานไม่กรอง — `ต้องเคาะ` (กฎภาษี)
//          สูตรให้สัญญาณไว้แล้ว: `computeVat` คืน `enabled:false` และ `type:null` เมื่อปิด VAT ⇒ ผู้เขียนบิลไม่ควรเขียน vatType
//          แต่ `vatDocOf` ยังออกตัวเลขใบกำกับให้บิลที่ VAT 0 ได้ เพราะยังไม่มีคำตัดสินว่าต้องปัด
//   K04 ฝั่ง Exclude (ดูบนสุด) · K14 VAT ใบรับสินค้า · RT-33 RT-68 VAT แพ็กเกจ/อุปกรณ์ · RT-07 RT-21 ตัววาดใบ = นอกหน่วยนี้
//
// หน่วย: รับบาท (number หรือข้อความ) · คืนบาทที่ลงตัวสตางค์เสมอ · ❌ ไม่ throw

// แปลงบาท↔สตางค์ใช้ของ money ตัวเดียว (ปัดครึ่งออกจากศูนย์ตามค่าทศนิยมที่คนเห็น · อ่านไม่ได้ = 0)
const { toSatang: satangOf, fromSatang: bahtOf } = require("./money");

const RATE_TEXT = /^(\d+\.?\d*|\.\d+)$/;

/**
 * DEFAULT_SHOP_VAT — ค่าตั้ง VAT ของร้านที่ doc ไม่มี `shopchampVat` (เท่า `config/initialShop.js:146-152` ของแอปเดิม)
 * ให้ผู้โหลดร้านใช้เฉพาะตอนโหลด doc สำเร็จแต่ไม่มี field · ❌ ห้ามใช้ตอนโหลดร้านล้ม (RT-38)
 */
const DEFAULT_SHOP_VAT = Object.freeze({ status: true, value: Object.freeze({ type: "Include", amount: "7" }) });

/**
 * parseVatRate — แปลงค่าช่องอัตรา VAT
 * @param {number|string} input ค่าที่ร้านกรอกหรือที่อยู่ใน `shop.shopchampVat.value.amount`
 * @returns {{ok:true, rate:number} | {ok:false, reason:'rate-missing'|'rate-not-decimal'|'rate-out-of-range'}}
 *   รับเลขฐานสิบล้วน 0-100 · ❌ ไม่รับรูป exponent จุลภาค หรือเครื่องหมาย (ร้านไม่ได้พิมพ์แบบนั้น อ่านแล้วอาจได้คนละค่า)
 */
function parseVatRate(input) {
  let rate;
  if (typeof input === "number") {
    if (!Number.isFinite(input)) return { ok: false, reason: "rate-not-decimal" };
    rate = input;
  } else if (typeof input === "string") {
    const s = input.trim();
    if (s === "") return { ok: false, reason: "rate-missing" };
    if (!RATE_TEXT.test(s)) return { ok: false, reason: "rate-not-decimal" };
    rate = Number(s);
  } else {
    return { ok: false, reason: "rate-missing" };
  }
  if (rate < 0 || rate > 100) return { ok: false, reason: "rate-out-of-range" };
  return { ok: true, rate };
}

/**
 * resolveVatConfig — อ่านค่าตั้ง VAT ของร้าน (`shop.shopchampVat`)
 * @param {{status?:boolean, value?:{type?:string, amount?:string|number}}} config
 * @returns {{ok:true, enabled:boolean, type:'Include'|'Exclude'|null, rate:number}
 *          | {ok:false, reason:string}}
 *   ไม่มีค่าตั้ง = `vat-config-missing` (ผู้เรียกต้องโหลดร้านใหม่ ห้ามเดา 7% · doc ไม่มี field ให้ส่ง DEFAULT_SHOP_VAT) · ปิด VAT = ไม่ดูอัตรา
 */
function resolveVatConfig(config) {
  if (!config || typeof config !== "object") return { ok: false, reason: "vat-config-missing" };
  if (!config.status) return { ok: true, enabled: false, type: null, rate: 0 };
  const value = config.value && typeof config.value === "object" ? config.value : {};
  const parsed = parseVatRate(value.amount);
  if (!parsed.ok) return parsed;
  return { ok: true, enabled: true, type: value.type === "Include" ? "Include" : "Exclude", rate: parsed.rate };
}

/**
 * computeVat — VAT และยอดก่อนปัดเศษของบิล 1 ใบ
 * @param {object} p
 * @param {number|string} p.net ผลรวม `net` ของแถวในตะกร้า (หลังส่วนลดรายสินค้า)
 * @param {number|string} p.noVatAmount ผลรวม `net` ของแถวที่ `vatExemption` เป็นจริง
 * @param {number|string} p.discount ส่วนลดท้ายบิลรวม (แต้ม + กดเอง + โปร)
 * @param {object} p.vat `shop.shopchampVat`
 * @returns {{ok:true, enabled:boolean, type:'Include'|'Exclude'|null, rate:number,
 *            discount:number, vatableAmount:number, noVatAmount:number,
 *            beforeVat:number, vatAmount:number, total:number}
 *          | {ok:false, reason:string}}
 *   - `discount` = ส่วนลดที่ใช้จริง (0 ถึง net)
 *   - `vatableAmount` = ฐานที่คิด VAT (Include: รวม VAT อยู่แล้ว · Exclude: ก่อน VAT)
 *   - `noVatAmount` = ส่วนที่ยกเว้น VAT หลังหักส่วนลด
 *   - สมการปิดเสมอ: beforeVat + vatAmount + noVatAmount = total
 */
function computeVat({ net, noVatAmount, discount, vat } = {}) {
  const config = resolveVatConfig(vat);
  if (!config.ok) return config;

  const netS = Math.max(0, satangOf(net));
  const exemptS = Math.min(netS, satangOf(noVatAmount));
  const discountS = Math.min(netS, Math.max(0, satangOf(discount)));
  const preVatS = netS - discountS;
  const vatableS = Math.max(0, netS - exemptS - discountS);
  const exemptLeftS = preVatS - vatableS;

  let vatS = 0;
  if (config.enabled) {
    const share = config.type === "Include" ? config.rate / (100 + config.rate) : config.rate / 100;
    vatS = Math.round(Number((vatableS * share).toPrecision(12)));
  }
  const beforeVatS = config.type === "Include" ? vatableS - vatS : vatableS;
  const totalS = config.type === "Exclude" ? preVatS + vatS : preVatS;

  return {
    ok: true,
    enabled: config.enabled,
    type: config.type,
    rate: config.rate,
    discount: bahtOf(discountS),
    vatableAmount: bahtOf(vatableS),
    noVatAmount: bahtOf(exemptLeftS),
    beforeVat: bahtOf(beforeVatS),
    vatAmount: bahtOf(vatS),
    total: bahtOf(totalS),
  };
}

/**
 * vatDocOf — ตัวเลขบนใบกำกับภาษีจากบิลที่บันทึกแล้ว · ทุกท่อพิมพ์ (แลน · Sunmi) และรายงานใช้ตัวนี้ตัวเดียว
 * @param {object} bill เอกสาร `bill` ดิบจากฐาน
 * @returns {{ok:true, type:'Include'|'Exclude', net:number, rounding:number, vatAmount:number,
 *            noVatAmount:number, beforeVat:number}
 *          | {ok:false, reason:'bill-missing'|'net-missing'|'vat-negative'}}
 *   - สมการปิดเสมอ: beforeVat + noVatAmount + vatAmount + rounding = net
 *   - บิลรุ่นเก่าไม่มี `noVatAmount` = ถือ 0 (เท่าที่แอปเดิมพิมพ์) · ไม่มี `vatAmount`/`rounding` = 0
 *   - ไม่มี `moneyMustPaid` = ปัด (ไม่เติม 999 หรือ 0 ให้ · RT-48)
 *   - ไม่มี `vatType` = 'Include' ตามแอปเดิม (`usePrintAction.js:202`)
 *   - `vatAmount` ติดลบ (บิลเก่าที่เกิดจาก RT-23) = ปัด `vat-negative` ไม่พิมพ์ VAT ติดลบ และ Before VAT ที่เกินยอด
 *   - ❗ RT-24 ยังไม่ปิด: บิลที่ VAT 0 ยังได้ตัวเลขใบกำกับ (ดูหัวไฟล์)
 */
function vatDocOf(bill) {
  if (!bill || typeof bill !== "object") return { ok: false, reason: "bill-missing" };
  const m = bill.moneyMustPaid;
  if (m === undefined || m === null || m === "") return { ok: false, reason: "net-missing" };
  const netS = satangOf(m);
  const roundingS = satangOf(bill.rounding);
  const vatS = satangOf(bill.vatAmount);
  if (vatS < 0) return { ok: false, reason: "vat-negative" };
  const exemptS = satangOf(bill.noVatAmount);
  return {
    ok: true,
    type: bill.vatType === "Exclude" ? "Exclude" : "Include",
    net: bahtOf(netS),
    rounding: bahtOf(roundingS),
    vatAmount: bahtOf(vatS),
    noVatAmount: bahtOf(exemptS),
    beforeVat: bahtOf(netS - roundingS - vatS - exemptS),
  };
}

module.exports = { DEFAULT_SHOP_VAT, parseVatRate, resolveVatConfig, computeVat, vatDocOf };

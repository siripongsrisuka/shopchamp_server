// cartTotals — ราคาต่อแถวในตะกร้า · ยอดรวมตะกร้า · ส่วนลดท้ายบิล จนถึงยอดก่อน VAT (ใบ DEV-0001 ก้อน 2)
//
// ที่มาของสูตร (แอปเดิม @804ba8ff · สำเนาคำต่อคำ `lanes/dev/source/compare/old-logic/cartTotals.js`):
//   linePrice            ← `hook/useUpdateCart.js:35-77` (PriceChoice · progress)
//   cartTotals           ← `screens/CheckoutScreen.js:439-454` (รวมตะกร้าตอนเปิดจอชำระ) + ราคาต่อแถวจาก linePrice
//   billDiscount         ← `screens/CheckoutScreen.js:397-403` (ส่วนลดรวม · ยอดก่อน VAT · ฐาน VAT)
//   manualDiscountAmount ← `screens/CheckoutScreen.js:949-966` (manageDiscount)
//
// ขอบเขต: จบที่ "ยอดหลังส่วนลดท้ายบิล ก่อน VAT" · ❌ ไม่คิด VAT ปัดเศษ เงินรับ เงินทอน (เป็นของหน่วย vat · payment)
//          ❌ ไม่กระจายส่วนลดลงแถว (หน่วย distributeBillDiscount) · ❌ ไม่คิดโปรท้ายบิล (หน่วย promotion · รับมาเป็นยอดเท่านั้น)
//
// Pack เคาะ 2026-11-06: server เชื่อยอดที่แอปส่งมา ⇒ สูตรนี้ต้องถูกเอง · ผลต่างจากสูตรเดิมทุกจุดชี้รหัสบั๊กได้ (ดูเทส)
//
// หลักที่ใช้ทั้งไฟล์:
//   - คิดเงินเป็นสตางค์จำนวนเต็ม แล้วแปลงกลับเป็นบาท 2 ตำแหน่งตอนคืนค่า (F08)
//     ยอดแถวปัดเป็นสตางค์จุดเดียว คือหลังคูณราคากับจำนวนแล้ว ❌ ไม่ปัดราคาต่อหน่วยก่อนคูณ
//     (ราคา 12.345 × 10 = 123.45 ไม่ใช่ 12.35 × 10 = 123.50 · ราคาเกิน 2 ตำแหน่งเกิดได้จริงตาม F15)
//   - เพดาน F56: ทุกค่าที่รับ · ยอดแถว (ราคา × จำนวน · ต้นทุน × จำนวน) · ยอดรวมตะกร้า ต้องไม่เกิน MAX_BAHT
//     เกิน = ปัญหา ไม่ใช่ตัดเงียบ ⇒ สตางค์ที่บวกกันอยู่ในช่วงจำนวนเต็มที่ปลอดภัยเสมอ
//   - ค่าว่าง ≠ 0: ราคา/จำนวนที่ว่างหรืออ่านไม่ออก = ปัญหา ไม่ใช่ 0 (F15 · F24)
//   - ❌ ไม่ throw · ของผิดรูปรายงานใน `problems[]` และ `ok:false` · ผู้เรียกต้องไม่ปิดบิลเมื่อ ok เป็น false
//   - ข้อความตัวเลข: รับรูปฐานสิบ · exponent (`1e2`) · จุลภาคเฉพาะคั่นหลักพันที่ถูกรูป (`1,500`) ·
//     จุลภาคกำกวม (`1,5`) = อ่านไม่ออก (K23 ทางแรกของข้อเสนอ: ปฏิเสธแทนเดา)
//   - pure: ไม่อ่านนาฬิกาเครื่อง เว้นผู้เรียกไม่ส่ง `now` และแถวไม่มี `pricedAt`

// เพดาน F56 (บาท) ใช้ทั้งต่อค่าที่รับ ต่อยอดแถว และต่อยอดรวมตะกร้า · 1e10 บาท = 1e12 สตางค์
// ⇒ บวกยอดแถวที่ผ่านเพดานได้ราว 9,000 แถวก่อนพ้น Number.MAX_SAFE_INTEGER และยอดรวมถูกปัดตั้งแต่เกิน 1e12 สตางค์แล้ว
const MAX_BAHT = 1e10;
const DECIMAL = /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i;
const GROUPED = /^[+-]?\d{1,3}(,\d{3})+(\.\d*)?$/;

// อ่านค่าตัวเลขแบบแยก "ว่าง" กับ "อ่านไม่ออก" ออกจาก 0 · คืน { state: 'ok'|'blank'|'bad', value }
function readNumber(v) {
  if (v === undefined || v === null) return { state: "blank", value: 0 };
  if (typeof v === "number") {
    if (!Number.isFinite(v) || Math.abs(v) > MAX_BAHT) return { state: "bad", value: 0 };
    return { state: "ok", value: v };
  }
  if (typeof v !== "string") return { state: "bad", value: 0 };
  let s = v.trim();
  if (s === "") return { state: "blank", value: 0 };
  if (s.includes(",")) {
    if (!GROUPED.test(s)) return { state: "bad", value: 0, reason: "comma" };
    s = s.replace(/,/g, "");
  }
  if (!DECIMAL.test(s)) return { state: "bad", value: 0 };
  const n = Number(s);
  if (!Number.isFinite(n) || Math.abs(n) > MAX_BAHT) return { state: "bad", value: 0 };
  return { state: "ok", value: n };
}

// บาท → สตางค์จำนวนเต็ม ปัดครึ่งขึ้น (ห่างศูนย์) · อ่านจากรูปทศนิยม 10 ตำแหน่ง เพื่อให้ 1.005 ได้ 101 ไม่ใช่ 100
// (1.005 * 100 = 100.49999999999999 ในเลขฐานสอง) · ค่าเข้ามาผ่าน readNumber แล้ว ⇒ |baht| ≤ MAX_BAHT
function toSatang(baht) {
  const n = Number(baht);
  if (n === 0 || !Number.isFinite(n)) return 0;
  const [int, dec] = Math.abs(n).toFixed(10).split(".");
  const r = Number(int) * 100 + Number(dec.slice(0, 2)) + (Number(dec[2]) >= 5 ? 1 : 0);
  return r === 0 ? 0 : Math.sign(n) * r; // ไม่คืน -0
}

const toBaht = (satang) => (satang === 0 ? 0 : satang / 100);

// วันที่จาก Firestore Timestamp · {seconds,nanoseconds} · {_seconds,_nanoseconds} · Date · ms · ข้อความ
function toTime(d) {
  if (d instanceof Date) return d.getTime();
  if (d && typeof d === "object") {
    if (typeof d.toDate === "function") return d.toDate().getTime();
    if ("seconds" in d) return Number(d.seconds) * 1000 + (Number(d.nanoseconds) || 0) / 1e6;
    if ("_seconds" in d) return Number(d._seconds) * 1000 + (Number(d._nanoseconds) || 0) / 1e6;
    return NaN;
  }
  if (typeof d === "number" || typeof d === "string") return new Date(d).getTime();
  return NaN;
}

// จำนวนชิ้นรวม: ปัด 4 ตำแหน่งกันเศษลอย (0.1+0.2) · ของชั่งน้ำหนักได้ถึง 4 ตำแหน่ง
// (Pack เคาะเครื่องชั่งข้อ ② 2026-11-06 · ตรงกับ stock.roundStock · `scale-pattern-from-sibling.md`)
const roundQty = (q) => Math.round(q * 10000) / 10000;

/**
 * linePrice — ราคาสุทธิของ 1 แถว (ราคาปกติ · ราคาโปรชุด · ราคาส่งตามขั้น เลือกที่ถูกที่สุด)
 * @param {object} product  แถวในตะกร้าหรือสินค้า: price · promotion{status,qty,price,startDate,endDate} ·
 *                          priceLevelStatus · priceLevel[{qty,price}] · customPriceStatus
 * @param {number|string} qty
 * @param {{now?: Date|number}} [opts]  เวลาที่ใช้ตัดสินว่าโปรยังอยู่ไหม
 * @returns {{ok:boolean, net:number, totalPrice:number, priceType:string, problems:Array<{code:string,bug:string}>}}
 *
 * ต่างจากสูตรเดิม (ทุกข้อมีรหัสบั๊ก):
 *   - ราคาว่าง/อ่านไม่ออก/ติดลบ = ปัญหา (F15) · เดิม `''*qty` = 0 ขายฟรี
 *   - จำนวนว่าง/0/ติดลบ = ปัญหา (F24)
 *   - ราคาโปรหรือราคาส่งที่ ≤ 0 หรือว่าง = ไม่ใช้ขั้นนั้น (K25 · ทำทางปลอดภัยไว้ก่อน รอ Pack ยืนยัน) ·
 *     เดิม: โปรราคา '' หรือ 0 ขายครบชุดฟรี · ราคาส่ง 0 (number) ตกไปราคาปกติ แต่ '0' (ข้อความ) ขายฟรี
 *   - แถวราคากำหนดเอง ไม่เอาโปร/ราคาส่งมาทับ (K08 ส่วน "PriceChoice ทับ priceType")
 *     ❓ K08 เป็นข้อ "ต้องเคาะ" ที่ Pack ยังไม่เคาะ (`bug-decisions/money.md` K08 · ข้อเสนอคือเด้งถามราคาทุกครั้ง ไม่มีค่าตั้งต้น)
 *     ส่วนที่ทำที่นี่เป็นแค่ทางที่ผมเลือกเอง: ราคาที่แคชเชียร์กำหนดไม่ถูกโปรทับ · ส่วน "เด้งถามราคา" เป็นของจอ ไม่อยู่ในหน่วยนี้
 *   - คิดเป็นสตางค์ ปัดจุดเดียวหลังคูณ (F08) · ยอดแถวเกินเพดาน = ปัญหา LINE_TOO_LARGE (F56)
 * เหมือนเดิม: โปรต้องเปิดและอยู่ในช่วงวัน · เท่ากันเลือกโปร · ไม่ถูกกว่าปกติ = ราคาปกติ ·
 *   ขั้นราคาส่งเลือกขั้นที่ qty ≤ จำนวนซื้อและ qty สูงสุด (ขั้นซ้ำ qty ใช้ตัวหลัง)
 */
function linePrice(product, qty, opts = {}) {
  const p = product && typeof product === "object" ? product : {};
  const problems = [];
  const price = readNumber(p.price);
  const q = readNumber(qty);
  if (price.state !== "ok" || toSatang(price.value) < 0) {
    problems.push({ code: "PRICE_INVALID", bug: price.reason === "comma" ? "K23" : "F15" });
  }
  if (q.state !== "ok" || q.value <= 0) problems.push({ code: "QTY_INVALID", bug: "F24" });
  const fail = () => ({ ok: false, net: 0, totalPrice: 0, priceType: "ราคาขายทั่วไป", problems });
  if (problems.length) return fail();

  const n = q.value;
  const rawNormal = price.value * n;
  if (rawNormal > MAX_BAHT) { problems.push({ code: "LINE_TOO_LARGE", bug: "F56" }); return fail(); }
  const normal = toSatang(rawNormal); // ปัดจุดเดียว หลังคูณ (F08)

  if (p.customPriceStatus) return { ok: true, net: toBaht(normal), totalPrice: toBaht(normal), priceType: "ราคากำหนดเอง", problems };

  const now = opts.now === undefined ? Date.now() : toTime(opts.now);

  let promo = Infinity;
  const pr = p.promotion;
  if (pr && pr.status) {
    const start = toTime(pr.startDate);
    const end = toTime(pr.endDate);
    const setQty = readNumber(pr.qty);
    const setPrice = readNumber(pr.price);
    if (start <= now && end >= now && setQty.state === "ok" && setQty.value > 0 && setPrice.state === "ok" && setPrice.value > 0) {
      const sets = Math.floor(n / setQty.value);
      const rest = n - sets * setQty.value;
      const rawPromo = sets * setPrice.value + rest * price.value;
      // ปัดจุดเดียว หลังรวมชุดกับเศษ · ไม่ต้องตั้งเพดาน: ยอดนี้ถูกใช้เฉพาะเมื่อต่ำกว่า normal ซึ่งผ่านเพดานแล้ว
      promo = toSatang(rawPromo);
    }
  }

  let level = Infinity;
  if (p.priceLevelStatus && Array.isArray(p.priceLevel)) {
    let best = null;
    for (const lv of p.priceLevel) {
      if (!lv) continue;
      const lq = readNumber(lv.qty);
      if (lq.state !== "ok" || lq.value > n) continue;
      if (best === null || !(best.qty > lq.value)) best = { qty: lq.value, price: lv.price };
    }
    if (best) {
      const lp = readNumber(best.price);
      // ขั้นที่ราคา ≤ 0 หรือว่าง = ไม่ใช้ราคาส่ง (เดิม `?.price || product.price` = ตกไปราคาปกติ เมื่อเป็น number 0)
      if (lp.state === "ok" && lp.value > 0) {
        const rawLevel = lp.value * n;
        level = toSatang(rawLevel); // ปัดจุดเดียว หลังคูณ · ใช้เฉพาะเมื่อต่ำกว่า normal (ผ่านเพดานแล้ว) เหมือนโปร
      } else level = normal;
    }
  }

  let net = normal;
  let priceType = "ราคาขายทั่วไป";
  if (normal > Math.min(promo, level)) {
    if (promo <= level) { net = promo; priceType = "ราคาโปรโมชั่น"; }
    else { net = level; priceType = "ราคาขายส่ง"; }
  }
  return { ok: true, net: toBaht(net), totalPrice: toBaht(normal), priceType, problems };
}

/**
 * cartTotals — รวมตะกร้า · คิดราคาทุกแถวใหม่จากข้อมูลของแถวเอง (ไม่เชื่อ `net` `totalPrice` ที่ค้างในแถว · F25)
 * @param {Array<object>} lines  แถวในตะกร้า: price · qty · cost · vatExemption · tempId · promotion · priceLevel... ·
 *                               `pricedAt` (ถ้ามี) = เวลาที่ตัดสินโปรของแถวนั้น (ล็อกราคาตอนใส่ตะกร้า/พักบิล)
 *                               ❓ K12 เป็นข้อ "ต้องเคาะ" ที่ Pack ยังไม่เคาะ (ล็อกราคาตอนพัก หรือดึงราคาล่าสุด · ไม่มีค่าตั้งต้น)
 *                               หน่วยนี้แค่รับได้ทั้ง 2 ทาง: ผู้เรียกส่ง `pricedAt` = ล็อก · ไม่ส่ง = ใช้ `now` · จะใช้ทางไหนรอ Pack
 * @param {{now?: Date|number}} [opts]  ใช้กับแถวที่ไม่มี `pricedAt` (หรือ `pricedAt` เป็น null)
 * @returns {{ok, totalPrice, net, productDiscount, noVatAmount, qty, totalCost, lines, problems}}
 *   - แถวที่มีปัญหาไม่ถูกนับในยอด และอยู่ใน `problems[]` พร้อม index · tempId · code · bug
 *   - ต้นทุนแถวเกินเพดาน = ปัญหา COST_TOO_LARGE · ยอดรวมตะกร้าเกินเพดาน = ปัญหา TOTAL_TOO_LARGE (index -1) (F56)
 *   - `productDiscount` = totalPrice − net ≥ 0 เสมอ
 */
function cartTotals(lines, opts = {}) {
  const rows = Array.isArray(lines) ? lines : [];
  const problems = [];
  const out = [];
  let totalPrice = 0, net = 0, noVat = 0, totalCost = 0, qty = 0;
  rows.forEach((line, index) => {
    const l = line && typeof line === "object" ? line : {};
    const at = l.pricedAt !== undefined && l.pricedAt !== null ? { now: l.pricedAt } : opts;
    const r = linePrice(l, l.qty, at);
    if (!r.ok) {
      for (const pb of r.problems) problems.push({ index, tempId: l.tempId, ...pb });
      return;
    }
    const n = readNumber(l.qty).value;
    const cost = readNumber(l.cost);
    const rawCost = cost.state === "ok" && cost.value > 0 ? cost.value * n : 0;
    if (rawCost > MAX_BAHT) { problems.push({ index, tempId: l.tempId, code: "COST_TOO_LARGE", bug: "F56" }); return; }
    const lineCost = toSatang(rawCost); // ปัดจุดเดียว หลังคูณ (F08)
    const lp = toSatang(r.totalPrice);
    const ln = toSatang(r.net);
    totalPrice += lp;
    net += ln;
    totalCost += lineCost;
    qty += n;
    if (l.vatExemption) noVat += ln;
    out.push({ index, tempId: l.tempId, qty: n, totalPrice: r.totalPrice, net: r.net, totalCost: toBaht(lineCost), priceType: r.priceType });
  });
  const cap = MAX_BAHT * 100;
  if (totalPrice > cap || totalCost > cap) problems.push({ index: -1, code: "TOTAL_TOO_LARGE", bug: "F56" });
  return {
    ok: problems.length === 0 && rows.length > 0,
    totalPrice: toBaht(totalPrice),
    net: toBaht(net),
    productDiscount: toBaht(totalPrice - net),
    noVatAmount: toBaht(noVat),
    qty: roundQty(qty),
    totalCost: toBaht(totalCost),
    lines: out,
    problems: rows.length === 0 ? [{ index: -1, code: "CART_EMPTY", bug: "F24" }] : problems,
  };
}

/**
 * billDiscount — ส่วนลดท้ายบิล (แต้ม · โปรท้ายบิล · ลดมือ) → ยอดก่อน VAT และฐาน VAT
 * @param {object} a
 * @param {number} a.net            ยอดตะกร้าหลังราคาต่อแถว (จาก cartTotals)
 * @param {number} [a.noVatAmount]  ส่วนของสินค้ายกเว้น VAT (จาก cartTotals)
 * @param {number|{value}} [a.pointDiscount]  ส่วนลดจากแต้ม (บาท)
 * @param {number|Array<{discount}>} [a.campaignDiscount]  ส่วนลดโปรท้ายบิล (ยอดรวม หรือรายการแบบ `campaign[]`)
 * @param {number|string} [a.manualDiscount]  ส่วนลดมือ (บาท · '' = ไม่มี)
 * @returns {{ok, requestedDiscount, totalDiscount, droppedDiscount, applied:{point,campaign,manual},
 *            netAfterDiscount, vatableBase, noVatBase, problems}}
 *
 * ต่างจากสูตรเดิม:
 *   - ส่วนลดรวมไม่เกินยอดตะกร้า ยอดก่อน VAT ต่ำสุด 0 ส่วนเกินตัดทิ้ง (K04 · ข้อ #5 · ทางแรก: ลดได้ถึงยอดก่อน VAT)
 *     ตัดจากส่วนลดมือก่อน แล้วโปรท้ายบิล แล้วแต้ม (ลำดับนี้ผมเลือกเอง ❓ Pack ยังไม่ได้เคาะ)
 *   - ส่วนลดติดลบ = ปัญหา (K04 "ไม่กันส่วนลดติดลบ") · ส่วนลด NaN/อ่านไม่ออก = ปัญหา (F30) · ทั้งสองนับเป็น 0
 *   - ฐาน VAT ไม่ติดลบ: หักส่วนลดจากส่วนที่มี VAT ได้ไม่เกินส่วนนั้น ที่เหลือหักจากส่วนยกเว้น VAT (RT-23)
 *     ❓ RT-23 เป็นข้อ "ต้องเคาะ — เงินและสูตรภาษี" ที่ Pack ยังไม่เคาะ (`bug-decisions/receipt-tax.md` RT-23 · ไม่มีค่าตั้งต้น)
 *     พื้น 0 + หักส่วนที่มี VAT ก่อน (แบบเดิม) เป็นทางที่ผมเลือกเอง · อีกทางคือแบ่งส่วนลดตามสัดส่วน · รอ Pack
 *   - คิดเป็นสตางค์ (F08)
 */
function billDiscount(a = {}) {
  const problems = [];
  const read = (v, field, { allowList = false } = {}) => {
    let src = v;
    if (allowList && Array.isArray(v)) {
      let s = 0;
      for (const it of v) {
        const r = read(it && it.discount, field);
        s += r;
      }
      return s;
    }
    if (src && typeof src === "object" && "value" in src) src = src.value;
    const r = readNumber(src);
    if (r.state === "blank") return 0;
    if (r.state === "bad") { problems.push({ field, code: "DISCOUNT_INVALID", bug: r.reason === "comma" ? "K23" : "F30" }); return 0; }
    const sat = toSatang(r.value); // เศษลอยอย่าง -4.44e-16 ปัดเป็น 0 สตางค์ = ไม่มีส่วนลด ไม่ใช่ส่วนลดติดลบ
    if (sat < 0) { problems.push({ field, code: "DISCOUNT_NEGATIVE", bug: "K04" }); return 0; }
    return sat;
  };
  const netR = readNumber(a.net);
  if (netR.state !== "ok" || netR.value < 0) problems.push({ field: "net", code: "NET_INVALID", bug: "F15" });
  const net = netR.state === "ok" && netR.value > 0 ? toSatang(netR.value) : 0;
  const nvR = readNumber(a.noVatAmount);
  const noVat = Math.min(net, nvR.state === "ok" && nvR.value > 0 ? toSatang(nvR.value) : 0);

  const point = read(a.pointDiscount, "pointDiscount");
  const campaign = read(a.campaignDiscount, "campaignDiscount", { allowList: true });
  const manual = read(a.manualDiscount, "manualDiscount");
  const requested = point + campaign + manual;

  let room = net;
  const take = (x) => { const t = Math.min(x, room); room -= t; return t; };
  const appliedPoint = take(point);
  const appliedCampaign = take(campaign);
  const appliedManual = take(manual);
  const applied = appliedPoint + appliedCampaign + appliedManual;

  const netAfter = net - applied;
  const vatPart = net - noVat;
  const vatableBase = Math.max(0, vatPart - applied);
  return {
    ok: problems.length === 0,
    requestedDiscount: toBaht(requested),
    totalDiscount: toBaht(applied),
    droppedDiscount: toBaht(requested - applied),
    applied: { point: toBaht(appliedPoint), campaign: toBaht(appliedCampaign), manual: toBaht(appliedManual) },
    netAfterDiscount: toBaht(netAfter),
    vatableBase: toBaht(vatableBase),
    noVatBase: toBaht(netAfter - vatableBase),
    problems,
  };
}

/**
 * manualDiscountAmount — แปลงที่แคชเชียร์กรอก (บาท หรือ %) เป็นยอดส่วนลดมือ
 * @param {{type:'bath'|'percent', value:number|string}} input  ('bath' สะกดตามแอปเดิม · ชนิดอื่นถือเป็น %)
 * @param {{net:number, cap?:number}} ctx  net = ยอดตะกร้า (ฐานของ %) · cap = เพดานส่วนลดมือ
 *        ผู้เรียกส่ง cap = ยอดตะกร้า − ส่วนลดอื่นที่ไม่ใช่ลดมือ · ละไว้ = net
 * @returns {{ok:boolean, amount:number|'', problem?:{code,bug}}}
 *   - ว่าง = '' (ไม่มีส่วนลด · ค่าเดิมของแอป) · 0 = ลด 0
 *   - เกิน cap = ปฏิเสธ · เดิมเทียบกับ remain ที่หักส่วนลดมือเดิมไปแล้ว ⇒ ลดส่วนลดเดิมลงไม่ได้ (F53)
 *   - % ปัดเป็นสตางค์ (RT-47 · F08) · % เกิน 100 หรือติดลบ = ปฏิเสธ (K04)
 */
function manualDiscountAmount(input = {}, ctx = {}) {
  const { type, value } = input || {};
  const r = readNumber(value);
  if (r.state === "blank") return { ok: true, amount: "" };
  if (r.state === "bad") return { ok: false, amount: "", problem: { code: "DISCOUNT_INVALID", bug: r.reason === "comma" ? "K23" : "F30" } };
  if (toSatang(r.value) < 0) return { ok: false, amount: "", problem: { code: "DISCOUNT_NEGATIVE", bug: "K04" } };
  const netR = readNumber(ctx.net);
  const net = netR.state === "ok" && netR.value > 0 ? toSatang(netR.value) : 0;
  const capR = readNumber(ctx.cap);
  const cap = capR.state === "ok" ? Math.max(0, toSatang(capR.value)) : net;
  let amount;
  if (type === "bath") amount = toSatang(r.value);
  else {
    if (r.value > 100) return { ok: false, amount: "", problem: { code: "PERCENT_OVER_100", bug: "K04" } };
    amount = Math.round((net * r.value) / 100);
  }
  if (amount > cap) return { ok: false, amount: "", problem: { code: "DISCOUNT_OVER_TOTAL", bug: "K04" } };
  return { ok: true, amount: toBaht(amount) };
}

module.exports = { linePrice, cartTotals, billDiscount, manualDiscountAmount };

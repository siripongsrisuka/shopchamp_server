// memberManage — สูตรของการจัดการสมาชิก: ตัดแต้มมือ · เพดานจำนวนสมาชิก · ดัชนีค้นหา `memberList` (ใบ DEV-0001 · ก้อน 9b)
//
// ฟังก์ชันล้วน ไม่แตะฐาน · server (`pos/member/*`) เรียกใน transaction · แอปใหม่เรียกเพื่อแสดงผลก่อนยิง
// ไม้บรรทัดของเดิม (คัดลอกคำต่อคำที่ `lanes/dev/source/compare/old-logic/memberManage.js`):
//   ตัดแต้ม        `main3:src/Modal/Modal_PointMember.js:37-50`
//   เพดานสมาชิก     `main3:src/Modal/Modal_NewMember.js:40-53` · `main3:src/screens/MemberScreen.js:364-376`
//   ดัชนีตอนสร้าง   `main3:src/Modal/Modal_NewMember.js:75-97`
//   ดัชนีตอนลบ      `main3:src/screens/MemberScreen.js:339-347`
//   ย้ายระบบเก่า     `main3:src/hook/useLocalMember.js:48-80`
//   สุ่มตัวอักษร     `main3:src/Utility/function.js:343-346`
//
// API:
//   redeemMemberPoint(member, points) → {ok, error, before, after}
//     error: 'POINTS_NOT_POSITIVE' (≤0 · ไม่ใช่ตัวเลข · ทศนิยมเกิน 2) · 'MEMBER_MISSING' · 'POINT_INSUFFICIENT'
//   memberLimitOf({memberPackage}) → 50 | 3000
//   memberQuota({count, memberPackage}) → {ok, limit, count}
//   pickMemberLetter(rand?) → 'A'..'Z'
//   letterForMemberId(id) → 'A'..'Z' (ตายตัวต่อ id · ใช้ตอนสร้างดัชนีใหม่ ⇒ 2 เครื่องทำพร้อมกันได้ตัวเดียวกัน F27)
//   isMemberLetter(s) → boolean  ('A'..'Z' จากแอป · 'A'+'A'..'Z' จากเว็บอัปไฟล์)
//   memberIndexRowOf(id, member) → {id, name, tel}  (ค่าว่างเป็น '' ไม่ใช่ undefined · F25)
//   memberIndexUpsert(rows, row) → rows ใหม่ (id ซ้ำ = แทนที่ที่ตำแหน่งเดิม · ไม่ซ้ำ = ต่อท้าย)
//   memberIndexRemove(rows, id) → rows ใหม่
//   memberIndexMerge(existing, fresh) → rows ใหม่ (fresh ชนะเมื่อ id ตรง · แถวเดิมที่ fresh ไม่มี = เก็บไว้ ไม่ทิ้ง F27)
"use strict";

const { toNumber } = require("./money");

// ───────── ตัวช่วย ─────────

const isObj = (o) => o !== null && typeof o === "object" && !Array.isArray(o);
const list = (a) => (Array.isArray(a) ? a : []);

// แต้มเป็นหน่วย 1/1,000,000 (ตัดเศษลอยที่ 6 ตำแหน่งแบบเดียวกับ logic.member · F52)
const MICRO = 1e6;
const toMicro = (x) => Math.round(Number((toNumber(x) * MICRO).toPrecision(15)));
const fromMicro = (m) => (m === 0 ? 0 : m / MICRO);
// ทศนิยมไม่เกิน 2 ตำแหน่ง · เทียบผ่าน toFixed เพราะ 0.29 * 100 ไม่เป็นจำนวนเต็มใน float
const atMost2Decimals = (v) => Number(v.toFixed(2)) === v;

// ───────── ตัดแต้มมือ (K12 · F11 · F12 · F52 · F55 · F56) ─────────

/**
 * redeemMemberPoint(member, points) — ตัดแต้มที่ลูกค้าใช้แลกนอกบิล
 *   points ต้องเป็น number > 0 ทศนิยมไม่เกิน 2 (F55 · F52) · ไม่ใช่ = POINTS_NOT_POSITIVE
 *   member ไม่มี (ถูกลบ) = MEMBER_MISSING (F56 · ของเดิมปิดหน้าต่างเหมือนสำเร็จ)
 *   แต้มที่ใช้ได้ = แต้มคงเหลือปัด 2 ตำแหน่งแบบที่จอแสดง (F52 ตัดให้หมดตามที่จอแสดงได้)
 *     ตัดเกิน = POINT_INSUFFICIENT (K12 · ตรวจกับค่าในฐานตอนนั้น ไม่ใช่ค่าที่จอโหลดไว้ F12)
 *   แต้มหลังตัด = แต้มเดิม − points ตัดเศษลอย · ต่ำกว่า 0 (เศษจากการปัดแสดงผล) = 0
 *   แต้มเดิมอ่านไม่ได้ (NaN · ขยะ) = 0 ⇒ ตัดไม่ได้ (F3 ไม่ให้ NaN ผ่านด่าน)
 */
function redeemMemberPoint(member, points) {
  if (typeof points !== "number" || !Number.isFinite(points) || points <= 0 || !atMost2Decimals(points)) {
    return { ok: false, error: "POINTS_NOT_POSITIVE", before: null, after: null };
  }
  if (!isObj(member)) return { ok: false, error: "MEMBER_MISSING", before: null, after: null };
  const beforeM = toMicro(member.point);
  const before = fromMicro(beforeM);
  const shown = Math.round(Number((before * 100).toPrecision(15))); // สตางค์ของแต้มที่จอแสดง
  const wanted = Math.round(points * 100);
  if (wanted > shown) return { ok: false, error: "POINT_INSUFFICIENT", before, after: null };
  const afterM = beforeM - Math.round(points * MICRO);
  return { ok: true, error: null, before, after: afterM <= 0 ? 0 : fromMicro(afterM) };
}

// ───────── เพดานจำนวนสมาชิก (K20 · F58) ─────────

const FREE_MEMBER_LIMIT = 50;
const PACKAGE_MEMBER_LIMIT = 3000;

/** memberLimitOf({memberPackage}) — ไม่มีแพ็กเกจสมาชิก 50 · มี 3,000 (เลขในข้อความของแอปเดิม · K20 ใช้เลขเดียวทุกทาง) */
function memberLimitOf({ memberPackage } = {}) {
  return memberPackage === true ? PACKAGE_MEMBER_LIMIT : FREE_MEMBER_LIMIT;
}

/**
 * memberQuota({count, memberPackage}) — เพิ่มสมาชิกได้อีกไหม
 *   count = จำนวนสมาชิกจริงของร้าน (นับจากฐาน ไม่ใช่ตัวนับ `shop.totalMember` ที่เพี้ยน F58)
 *   ได้เมื่อ count < เพดาน (ของเดิม: ไม่มีแพ็กเกจ `totalMember>49` ปัด · มีแพ็กเกจ `>2999` ปัด ⇒ ตัวที่ 50 / 3,000 ยังเพิ่มได้)
 *   count อ่านไม่ได้ = ไม่ให้เพิ่ม (fail-closed)
 */
function memberQuota({ count, memberPackage } = {}) {
  const limit = memberLimitOf({ memberPackage });
  if (typeof count !== "number" || !Number.isInteger(count) || count < 0) return { ok: false, limit, count: null };
  return { ok: count < limit, limit, count };
}

// ───────── ดัชนีค้นหา memberList (F23-F28 · F13 · F25) ─────────

const LETTER_RE = /^(?:[A-Z]|A[A-Z])$/;

/** isMemberLetter(s) — ตัวอักษรของดัชนีที่ทางเขียนเดิมสร้าง: แอป 1 ตัว · เว็บอัปไฟล์ 'A' + 1 ตัว */
function isMemberLetter(s) {
  return typeof s === "string" && LETTER_RE.test(s);
}

/** pickMemberLetter(rand) — สุ่ม A-Z แบบแอปเดิม · rand ไม่ส่ง = Math.random (ส่งได้เพื่อเทส) */
function pickMemberLetter(rand) {
  const r = typeof rand === "function" ? rand() : Math.random();
  const x = typeof r === "number" && Number.isFinite(r) && r >= 0 && r < 1 ? r : 0;
  return String.fromCharCode(65 + Math.floor(x * 26));
}

/** letterForMemberId(id) — ตัวอักษรตายตัวต่อ id (FNV-1a 32 บิต mod 26) · ใช้ตอนสร้างดัชนีใหม่ให้ทุกเครื่องได้ค่าเดียวกัน (F27) */
function letterForMemberId(id) {
  const s = String(id === undefined || id === null ? "" : id);
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return String.fromCharCode(65 + (h % 26));
}

/** ข้อความของแถวดัชนี: string ตามเดิม · number/boolean (อัปไฟล์) เป็นข้อความ · ไม่มี = '' (F25 undefined ทำ batch ล้มทั้งก้อน) */
const indexText = (v) => (typeof v === "string" ? v : typeof v === "number" || typeof v === "boolean" ? String(v) : "");

/** memberIndexRowOf(id, member) → {id, name, tel} รูปเดียวกับแถวที่แอปเดิมเขียน */
function memberIndexRowOf(id, member) {
  const m = isObj(member) ? member : {};
  return { id: String(id), name: indexText(m.name), tel: indexText(m.tel) };
}

/** memberIndexUpsert(rows, row) — id ซ้ำแทนที่ตำแหน่งเดิม (กันแถวซ้ำเมื่อส่งซ้ำ F23) · แถวขยะคงไว้ตามเดิม */
function memberIndexUpsert(rows, row) {
  const out = list(rows).slice();
  const i = out.findIndex((r) => isObj(r) && r.id === row.id);
  if (i >= 0) out[i] = row;
  else out.push(row);
  return out;
}

/** memberIndexRemove(rows, id) — เอาแถว id นี้ออกทุกแถว (ของเดิม filter แบบเดียวกัน) */
function memberIndexRemove(rows, id) {
  return list(rows).filter((r) => !(isObj(r) && r.id === id));
}

/**
 * memberIndexMerge(existing, fresh) — รวมดัชนีเดิมกับแถวที่อ่านจาก member สด
 *   แถว fresh ทับแถวเดิมที่ id ตรง (ได้ชื่อ เบอร์ ล่าสุด F28) · แถวเดิมที่ fresh ไม่มี = เก็บไว้
 *   (อาจเป็นสมาชิกที่เพิ่งสร้างหลังอ่าน · ของเดิมใช้ set ทับแล้วทำหาย F27) · ลำดับ: แถวเดิมตามเดิม แล้วต่อท้ายแถวใหม่
 */
function memberIndexMerge(existing, fresh) {
  const freshById = new Map();
  for (const r of list(fresh)) if (isObj(r) && typeof r.id === "string") freshById.set(r.id, r);
  const out = [];
  const seen = new Set();
  for (const r of list(existing)) {
    if (isObj(r) && typeof r.id === "string") {
      if (seen.has(r.id)) continue;
      seen.add(r.id);
      out.push(freshById.has(r.id) ? freshById.get(r.id) : r);
    }
  }
  for (const [id, r] of freshById) if (!seen.has(id)) { seen.add(id); out.push(r); }
  return out;
}

module.exports = {
  redeemMemberPoint,
  memberLimitOf,
  memberQuota,
  isMemberLetter,
  pickMemberLetter,
  letterForMemberId,
  memberIndexRowOf,
  memberIndexUpsert,
  memberIndexRemove,
  memberIndexMerge,
  FREE_MEMBER_LIMIT,
  PACKAGE_MEMBER_LIMIT,
};

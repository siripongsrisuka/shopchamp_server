// expenseReport — รายการเดือนและยอดรวมของรายงานค่าใช้จ่าย (ก้อน 9c · DEV-0001)
//
// ที่มา: แอปเดิม `app:screens/ExpenseReportScreen.js:25,64-102` (สูตรเดิมคัดลอกไว้ที่ `lanes/dev/source/compare/old-logic/expenseReport.js`)
//   · `lanes/dev/source/schema/expenseReport.md` §1 · B1 · B5 · `bug-decisions/ui-display.md` F114
//
// แก้จากสูตรเดิม:
//   ① รายการ 6 เดือนย้อนหลัง: สูตรเดิมใช้ `setMonth(getMonth()-n)` ตรง ๆ ⇒ วันที่ 29-31 เดือนซ้ำและบางเดือนหาย (F114 · expenseReport B1)
//      สูตรใหม่นับเดือนปฏิทินบนนาฬิกาไทย (UTC+7) ไม่ขึ้นกับวันที่ และไม่ขึ้นกับโซนของเครื่องที่รัน (server UTC)
//   ② ยอดรวมรายหัวข้อ: สูตรเดิมบวกทศนิยมลอยตัว (`0.1+0.2`) และข้อความที่ไม่ใช่ตัวเลขทำให้ยอดเป็น NaN ทั้งกลุ่ม
//      สูตรใหม่บวกเป็นสตางค์ · ข้อความว่าง = 0 (เท่าสูตรเดิม `Number('')`) · ข้อความอ่านไม่ได้ = ไม่นับ และนับไว้ใน invalidRows
//   ป้ายเดือน (`name` ของ doc) คงรูปเดิมทุกตัวอักษร รวมช่องว่าง 3 ตัวท้าย เพราะแอปเก่าแสดงค่าจาก doc ตรง ๆ
// ฟังก์ชันล้วน ไม่อ่านนาฬิกาเอง (ผู้เรียกส่ง now) ไม่แตะฐาน
"use strict";

const { parseMoney } = require("./money");

const SHOP_OFFSET_MS = 7 * 60 * 60 * 1000; // ร้าน Shopchamp อยู่ไทยทั้งหมด
const MONTH_KEY_RE = /^(\d{4})(0[1-9]|1[0-2])$/;
const THAI_MONTH_SHORT = Object.freeze(["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."]);
const EXPENSE_MONTH_WINDOW = 6; // แอปเดิม `months = [0,1,2,3,4,5]`

function msOf(v) {
  if (v instanceof Date) return v.getTime();
  if (typeof v === "number") return v;
  if (v && typeof v === "object" && typeof v.toMillis === "function") return v.toMillis();
  if (v && typeof v === "object" && typeof v.toDate === "function") {
    const d = v.toDate();
    return d instanceof Date ? d.getTime() : NaN;
  }
  return NaN;
}

/** thaiYearMonth(instant) → {year, month(1-12)} บนนาฬิกาไทย · อ่านไม่ได้ = null */
function thaiYearMonth(instant) {
  const ms = msOf(instant);
  if (!Number.isFinite(ms)) return null;
  const d = new Date(ms + SHOP_OFFSET_MS);
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1 };
}

const keyOf = (year, month) => `${String(year).padStart(4, "0")}${String(month).padStart(2, "0")}`;

/** isExpenseMonthKey(key) — `YYYYMM` เดือน 01-12 */
function isExpenseMonthKey(key) {
  return typeof key === "string" && MONTH_KEY_RE.test(key);
}

/**
 * expenseMonthKeys(now, count=6) → {ok:true, keys:['202611','202610',…]} เดือนนี้ก่อน ย้อนทีละเดือนปฏิทิน
 *   now อ่านไม่ได้ = {ok:false, reason:'now-invalid'} · count นอก 1..120 = {ok:false, reason:'count-invalid'}
 */
function expenseMonthKeys(now, count) {
  const n = count === undefined ? EXPENSE_MONTH_WINDOW : count;
  if (!Number.isInteger(n) || n < 1 || n > 120) return { ok: false, reason: "count-invalid" };
  const ym = thaiYearMonth(now);
  if (!ym) return { ok: false, reason: "now-invalid" };
  const keys = [];
  let { year, month } = ym;
  for (let i = 0; i < n; i++) {
    keys.push(keyOf(year, month));
    month -= 1;
    if (month === 0) { month = 12; year -= 1; }
  }
  return { ok: true, keys };
}

/** expenseMonthLabel(key) → ป้ายรูปเดิม เช่น `'พ.ย. 2569   '` (ปี พ.ศ. · ช่องว่างท้าย 3 ตัว) · key ผิดรูป = null */
function expenseMonthLabel(key) {
  if (!isExpenseMonthKey(key)) return null;
  const year = Number(key.slice(0, 4));
  const month = Number(key.slice(4, 6));
  return `${THAI_MONTH_SHORT[month - 1]} ${year + 543}   `;
}

/** expenseMonthInWindow(key, now, count=6) — เดือนนี้อยู่ในรายการที่จอเลือกได้ไหม (เท่าแอปเดิม: เดือนนี้และย้อนหลัง 5 เดือน) */
function expenseMonthInWindow(key, now, count) {
  const r = expenseMonthKeys(now, count);
  return r.ok && isExpenseMonthKey(key) && r.keys.includes(key);
}

// ยอดเงินแถวรายงาน: ข้อความว่าง/ช่องว่างล้วน/ไม่มีค่า = 0 (เท่า Number('')) · อ่านไม่ได้ ติดลบ ทศนิยมเกิน 2 = null
function rowSatang(price) {
  if (price === undefined || price === null) return 0;
  if (typeof price === "string" && price.trim() === "") return 0;
  const n = parseMoney(price); // ไม่ติดลบ · ทศนิยมไม่เกิน 2 · ไม่รับรูป exponent
  return n === null ? null : Math.round(n * 100);
}

/**
 * summarizeExpenses(rows) — รวมยอดรายหัวข้อ (`expenseId`) แบบจอรายการเดือน
 * @param {Array<{expenseId, expenseName, price}>} rows `expenseReport.expenses`
 * @returns {{items:[{id, name, price}], total:number, invalidRows:number}}
 *   items เรียงยอดมากไปน้อย ยอดเท่ากันคงลำดับที่เจอก่อน (เท่า normalSort ของเดิม) · name = ชื่อของแถวแรกในกลุ่ม (เท่าเดิม)
 *   price และ total เป็นบาท (ทศนิยม 2 ตำแหน่งจากสตางค์) · แถวที่ไม่ใช่ object ข้าม · ราคาอ่านไม่ได้ = ไม่นับ + invalidRows
 */
function summarizeExpenses(rows) {
  const list = Array.isArray(rows) ? rows : [];
  const groups = [];
  const byId = new Map();
  let invalidRows = 0;
  for (const r of list) {
    if (!r || typeof r !== "object" || Array.isArray(r)) continue;
    const s = rowSatang(r.price);
    if (s === null) { invalidRows++; continue; }
    const id = r.expenseId;
    let g = byId.get(id);
    if (!g) {
      g = { id, name: r.expenseName, satang: 0, order: groups.length };
      byId.set(id, g);
      groups.push(g);
    }
    g.satang += s;
  }
  const sorted = groups.slice().sort((a, b) => (b.satang - a.satang) || (a.order - b.order));
  const total = sorted.reduce((t, g) => t + g.satang, 0);
  return {
    items: sorted.map((g) => ({ id: g.id, name: g.name, price: g.satang / 100 })),
    total: total / 100,
    invalidRows,
  };
}

module.exports = {
  EXPENSE_MONTH_WINDOW,
  thaiYearMonth,
  isExpenseMonthKey,
  expenseMonthKeys,
  expenseMonthLabel,
  expenseMonthInWindow,
  summarizeExpenses,
};

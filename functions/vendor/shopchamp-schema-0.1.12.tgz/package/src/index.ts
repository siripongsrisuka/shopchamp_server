// @shopchamp/schema — รูปเอกสาร Firestore และรูปคำขอ API ของ Shopchamp
// แหล่งเดียว: import จากที่นี่ ห้ามนิยามซ้ำในแอปหรือ server
// โครง: 1 ไฟล์ต่อ entity ที่ src/entities/<ชื่อ>.ts · คำขอ API ที่ src/requests/<โดเมน>.ts
//   0.1.0 (ก้อน 0 · DEV-0001): receiptGuard ตัวเดียว เพื่อพิสูจน์ทาง build → test → pack
//   0.2.0 (ก้อน 1-3 · DEV-0001): 14 entity + คำขอ shift · member
//   ก้อน 7: คำขอ payment.* (`requests/gateway.ts`) + ช่องเพิ่มอย่างเดียวของ pgWebhook
//   ก้อน 4 (ร่าง · ยังไม่บั๊มรุ่น): คำขอ sale · profile + field เพิ่มอย่างเดียวของ bill shop shift shiftHistory
//   0.1.4 (ก้อน 5): shiftId/shiftOpenTime ไม่บังคับใน sale.create · shiftId ไม่บังคับใน member.payCredit (ร้านไม่ใช้ระบบกะ)
//                   + SaleIssueTaxInvoiceRequest (ออกใบกำกับผ่าน server)
export * from "./entities/receiptGuard";
export * from "./entities/bill";
export * from "./entities/billId";
export * from "./entities/billDayId";
export * from "./entities/member";
export * from "./entities/paidHistory";
export * from "./entities/pgWebhook";
export * from "./entities/product";
export * from "./entities/promotion";
export * from "./entities/shift";
export * from "./entities/shiftHistory";
export * from "./entities/shop";
export * from "./entities/stock";
export * from "./entities/stockLink";
export * from "./requests/member";
export * from "./requests/shift";
export * from "./requests/sale";
export * from "./requests/profile";
export * from "./requests/gateway";
// 0.1.5 (ก้อน 9 · DEV-0001): stock 9a · member-product 9b · shop-staff 9c · company 9d · report 9e
// 0.1.10 (DEV-0002): report.breakdown · report.memberBills · billList detail · shiftHistory dayBy (ใน requests/report)
// 0.1.11 (DEV-0002): member.payCredit source web · ShiftOpenListRequest (ใน requests/shift) · paidHistory.source · paidHistory.shiftId/shiftOpenTime nullable
// 0.1.12 (DEV-0002): company.packageOrder vat/vatDetail (ใบกำกับเฉพาะรายปี) · AdminPackage price[].day · PackageOrder vatAmount/vatDetail/totalPrice
// 9a สต๊อก
export * from "./entities/supplier";
export * from "./entities/importProduct";
export * from "./entities/requisition";
export * from "./entities/stockOrder";
export * from "./entities/uploadProduct";
export * from "./requests/stock";
// 9b สมาชิกและสินค้า
export * from "./entities/memberList";
export * from "./entities/pointHistory";
export * from "./entities/priceTag";
export * from "./requests/memberManage";
export * from "./requests/promotion";
export * from "./requests/product";
export * from "./requests/priceTag";
// 9c ร้านและพนักงาน
export * from "./entities/checkIn";
export * from "./entities/checkInHistory";
export * from "./entities/expense";
export * from "./entities/expenseReport";
export * from "./entities/profile";
export * from "./entities/buildings";
export * from "./requests/shopStaff";
// 9d บริษัท
export * from "./entities/notification";
export * from "./entities/admin";
export * from "./entities/companyOrder";
export * from "./entities/loginByScan";
export * from "./entities/deletedUser";
export * from "./entities/shopchamShopId";
export * from "./requests/company";
// 9e รายงาน
export * from "./requests/report";
export * from "./requests/cashierCode";
// ก้อน 10 รอบ 2a จุดขาย + ย้ายโครงร้านรุ่นแรก
export * from "./requests/posManage";
// ก้อน 10 รอบ 2c LINE เข้าที่ลับ · เข้าครั้งแรกของร้านรุ่นแรก
export * from "./requests/lineSettings";
export * from "./requests/claimLegacyShop";
// 9f เว็บแฟรนไชส์ (DEV-0002)
export * from "./entities/franchise";
export * from "./requests/franchise";

import { z } from "zod";

/**
 * คำขอ API โดเมนร้านและพนักงาน (ก้อน 9c · DEV-0001) · strict ทุกชั้น field เกิน = ปัด
 *   shop.update · staff.manage · staff.checkIn · expense.manage · expenseReport.manage · profile.manage
 *
 * ที่มา: `lanes/dev/source/schema/{shop,profile,checkIn,checkInHistory,expense,expenseReport}.md` · `bug-decisions/index.md` #14
 *   · `bug-decisions/data-integrity.md` DI-01 DI-12 DI-14 DI-16 DI-22 DI-40 DI-50 DI-80 DI-83 · `auth-security.md` C16 C18 C19
 *
 * หลักร่วม:
 * - ร้านมาจาก token + body.shopId (server เทียบกับ req.shopAccess) · ❌ ไม่รับเวลา ชื่อคนทำ หรือ shopId ของเอกสารจากแอป
 * - #14 / DI-01: แก้ตั้งค่าร้าน "ทีละช่อง ทีละแถว" ใน transaction · ช่องที่เป็นรายการทั้งก้อน (หมวด เสียง รูปจอลูกค้า ผู้รับ LINE)
 *   ต้องส่ง `base` = ค่าที่เครื่องเห็นก่อนแก้ ⇒ ค่าในฐานเปลี่ยนไปแล้ว = 409 ให้เครื่องโหลดใหม่ (ไม่ทับของเครื่องอื่นเงียบ ๆ)
 * - ช่องที่ไม่อยู่ในรายการ = แก้ผ่าน API นี้ไม่ได้ (fail-closed): ตัวตนร้าน แพ็กเกจ โควตารูป ตัวนับสมาชิก token LINE (ก้อน 6) สังกัดแฟรนไชส์
 *   พนักงานและผู้รับแจ้งเตือนไปที่ `staff.manage`
 */

// ─────────────── ชิ้นร่วม ───────────────

const NumOrStr = z.union([z.number().finite(), z.string().max(200)]);
const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });
const ShopIdField = docId("shopId").describe("doc id ร้านของผู้เรียก · server เทียบกับตัวตนจาก token");
const RequestId = z.string().min(1).max(128).describe("id ต่อ 1 การกด · ส่งซ้ำได้ผลเดิม");
const Url = z
  .string()
  .max(2048)
  .regex(/^https:\/\/\S+$/, { message: "ต้องเป็นลิงก์ https" });
const UrlOrEmpty = z.union([z.literal(""), Url]);
const ShortText = (max: number) => z.string().max(max);
const NonBlank = (max: number) =>
  z
    .string()
    .max(max)
    .refine((s) => s.trim() !== "", { message: "ห้ามว่าง" });

/** ยอดเงินจากช่องกรอก (รูปเดียวกับ ShiftMoneyText) · ห้ามติดลบ จุลภาค exponent · ทศนิยมไม่เกิน 2 · ไม่เกิน 9 หลัก */
export const ExpenseMoneyText = z
  .string()
  .regex(/^(\d{1,9}(\.\d{0,2})?|\.\d{1,2})$/, { message: "ยอดเงินต้องเป็นตัวเลขไม่ติดลบ ทศนิยมไม่เกิน 2 ตำแหน่ง และห้ามว่าง" });

// ─────────────── shop.update ───────────────

const CategoryItem = z
  .object({
    id: z.string().min(1).max(128),
    name: NumOrStr.optional(),
    level: NumOrStr.optional(),
    aboveId: z.array(z.string().max(128)).max(20).optional(),
  })
  .strict();
const CategoryTree = z.array(z.object({ level: NumOrStr.optional(), value: z.array(CategoryItem).max(2000) }).strict()).max(20);
const SoundPlayers = z
  .array(
    z
      .object({ mainStatus: z.boolean().optional(), status: z.boolean().optional(), sound: ShortText(200).optional(), name: ShortText(200).optional() })
      .strict(),
  )
  .max(50);
const LineUsers = z.array(z.object({ name: ShortText(200).optional(), userId: z.string().min(1).max(128) }).strict()).max(200);
const LineNoti = z.partialRecord(z.enum(["cancelReceipt", "shift", "checkin", "credit"]), z.array(z.string().min(1).max(128)).max(200));

/** ช่องที่แทนทั้งค่า · `needsBase` = ต้องส่ง base (ค่าเป็นรายการทั้งก้อน) */
const SET_FIELDS = {
  name: { value: NonBlank(100), needsBase: false },
  tel: { value: ShortText(20), needsBase: false },
  logo: { value: UrlOrEmpty, needsBase: false },
  smartAddress: { value: z.array(NumOrStr).max(4), needsBase: false },
  cutOff: { value: z.iso.datetime({ offset: true }).describe("เวลาตัดรอบ ISO · server เก็บเป็น Timestamp"), needsBase: false },
  shift: { value: z.boolean(), needsBase: false },
  receiptPattern: { value: z.enum(["month", "day"]), needsBase: false },
  creditPoint: { value: z.boolean(), needsBase: false },
  soundStatus: { value: z.boolean(), needsBase: false },
  amendBill: { value: z.boolean().describe("สวิตช์เปิดให้แก้บิล (Pack อนุญาต 2026-11-06 ข้อ ⑤) · เจ้าของเท่านั้น"), needsBase: false },
  customerAds: { value: z.array(Url).max(20), needsBase: true },
  smartCategory: { value: CategoryTree, needsBase: true },
  categoryExpense: { value: CategoryTree, needsBase: true },
  soundPlayers: { value: SoundPlayers, needsBase: true },
  lineUsers: { value: LineUsers, needsBase: true },
  lineNoti: { value: LineNoti, needsBase: true },
} as const;

/** ช่องที่เป็น object · รวมทีละคีย์ (คีย์ที่ไม่ส่ง = คงค่าในฐาน) */
const ImageToggle = z.object({ imageId: UrlOrEmpty.optional(), status: z.boolean().optional() }).strict();
const MERGE_FIELDS = {
  receipt: z
    .object({
      footer: ShortText(2000).optional(),
      footerImage: ImageToggle.optional(),
      header: ShortText(2000).optional(),
      headerImage: ImageToggle.optional(),
      headerStatus: z.boolean().optional(),
      footerStatus: z.boolean().optional(),
      promptpayId: ShortText(20).optional(),
      promptpayStatus: z.boolean().optional(),
      price: z.boolean().optional(),
      bottomEnable: z.boolean().optional(),
      thankText: ShortText(200).optional(),
      note: ShortText(2000).optional(),
    })
    .strict(),
  tax: z
    .object({
      name: ShortText(200).optional(),
      tel: ShortText(20).optional(),
      address: ShortText(1000).optional(),
      taxNumber: z.string().regex(/^\d{0,13}$/, { message: "เลขผู้เสียภาษี 13 หลัก" }).optional(),
      branch: ShortText(50).optional(),
      fax: ShortText(20).optional(),
      status: z.boolean().optional(),
      headquarter: z.boolean().optional(),
    })
    .strict(),
  rounding: z.object({ status: z.boolean().optional(), type: z.enum(["up", "down", "half"]).optional() }).strict(),
  shopchampVat: z
    .object({
      status: z.boolean().optional(),
      value: z
        .object({
          type: z.enum(["Include", "Exclude"]),
          amount: z.string().regex(/^\d{1,2}(\.\d{1,2})?$/, { message: "อัตราภาษี 0-99.99" }),
        })
        .strict()
        .optional(),
    })
    .strict(),
  smartPoint: z
    .object({
      rate: NumOrStr.optional(),
      point: NumOrStr.optional(),
      date: z.array(z.object({ id: NumOrStr, value: NumOrStr }).strict()).max(31).optional(),
      days: z.array(z.object({ id: NumOrStr, value: NumOrStr }).strict()).max(7).optional(),
      memberTier: z.array(z.unknown()).max(20).optional(),
      expire: z.object({ status: z.boolean().optional(), duration: ShortText(20).optional(), period: NumOrStr.optional() }).strict().optional(),
    })
    .strict(),
} as const;

/** ช่องที่เป็นรายการแถว มี id · แก้ทีละแถว */
const BluetoothSlot = z.object({ address: ShortText(100).optional(), name: ShortText(200).optional() }).strict();
const PosRow = z
  .object({
    id: z.string().min(1).max(128),
    name: ShortText(100).optional(),
    shiftId: ShortText(128).optional(),
    uniqueId: ShortText(200).optional(),
    deviceName: ShortText(200).optional(),
    posNumber: NumOrStr.optional(),
    printerType: ShortText(50).optional(),
    printerSize: NumOrStr.optional(),
    printerBluetooth: z.object({ android: BluetoothSlot.optional(), ios: BluetoothSlot.optional() }).strict().optional(),
    printerEthernet: ShortText(100).optional(),
    printerUsb: z.object({ vendor_id: NumOrStr.optional(), product_id: NumOrStr.optional(), device_name: ShortText(200).optional() }).strict().optional(),
  })
  .strict();
const PaymentRow = z
  .object({ id: NumOrStr, name: NonBlank(100), mortal: z.boolean().optional(), status: z.boolean().optional() })
  .strict();
const TaxCustomerRow = MERGE_FIELDS.tax.extend({ id: z.string().min(1).max(128) }).strict();
const CouponRow = z
  .object({ id: NumOrStr, name: ShortText(200).optional(), point: NumOrStr.optional(), status: z.boolean().optional(), value: NumOrStr.optional(), imageId: UrlOrEmpty.optional() })
  .strict();
const RewardRow = z
  .object({
    id: z.string().min(1).max(128),
    name: ShortText(200).optional(),
    imageId: UrlOrEmpty.optional(),
    point: NumOrStr.optional(),
    status: z.boolean().optional(),
    detail: ShortText(2000).optional(),
  })
  .strict();
const ROW_FIELDS = {
  POSs: PosRow,
  shopchampPayment: PaymentRow,
  taxCustomer: TaxCustomerRow,
  smartCoupon: CouponRow,
  smartReward: RewardRow,
} as const;

const setOps = Object.entries(SET_FIELDS).map(([field, s]) =>
  z
    .object({
      op: z.literal("set"),
      field: z.literal(field),
      value: s.value,
      base: s.needsBase ? s.value.describe("ค่าที่เครื่องเห็นก่อนแก้ · ต้องเท่าค่าในฐาน") : z.unknown().optional().describe("ไม่ใช้กับช่องนี้"),
    })
    .strict(),
);
const mergeOps = Object.entries(MERGE_FIELDS).map(([field, v]) =>
  z.object({ op: z.literal("merge"), field: z.literal(field), value: v }).strict(),
);
const rowOps = Object.entries(ROW_FIELDS).flatMap(([field, row]) => [
  z.object({ op: z.literal("upsertRow"), field: z.literal(field), row }).strict(),
  z.object({ op: z.literal("patchRow"), field: z.literal(field), id: NumOrStr, patch: (row as z.ZodObject).omit({ id: true }).partial().strict() }).strict(),
  z.object({ op: z.literal("removeRow"), field: z.literal(field), id: NumOrStr }).strict(),
]);

/**
 * ผูกเครื่องนี้กับจุดขายที่ยังว่าง (แทน `app:Modal/Modal_Pos.js:80-96`) · คนมีสิทธิ์ขาย '100' หรือกะ '102' ทำได้ ไม่ต้องมี '101'
 * จุดขายมีเครื่องอื่นผูกอยู่ = 409 pos_in_use · เครื่องเดิมส่งซ้ำ = ผ่าน ไม่เขียน
 */
const ClaimPosOp = z
  .object({
    op: z.literal("claimPos"),
    field: z.literal("POSs"),
    id: z.string().min(1).max(128),
    uniqueId: z.string().min(1, { message: "รหัสเครื่องห้ามว่าง" }).max(200).describe("รหัสเครื่อง (profile.uniqueId ของแอปเดิม)"),
    deviceName: ShortText(200),
  })
  .strict();

export const SHOP_SET_FIELDS = Object.freeze(Object.keys(SET_FIELDS));
export const SHOP_SET_FIELDS_NEED_BASE = Object.freeze(Object.entries(SET_FIELDS).filter(([, s]) => s.needsBase).map(([k]) => k));
export const SHOP_MERGE_FIELDS = Object.freeze(Object.keys(MERGE_FIELDS));
export const SHOP_ROW_FIELDS = Object.freeze(Object.keys(ROW_FIELDS));

export const ShopUpdateOp = z.union([...setOps, ...mergeOps, ...rowOps, ClaimPosOp] as unknown as [z.ZodTypeAny, z.ZodTypeAny, ...z.ZodTypeAny[]]);

export const ShopUpdateRequest = z
  .object({
    shopId: ShopIdField,
    ops: z.array(ShopUpdateOp).min(1).max(20).describe("ทำทั้งชุดใน transaction เดียว · ตัวไหนไม่ผ่าน = ไม่เขียนอะไรเลย"),
  })
  .strict()
  .superRefine((v, ctx) => {
    // ช่องเดียวกันห้ามมีทั้ง set/merge กับ row op ในคำขอเดียว (ลำดับกำกวม) · แถวเดียวกันห้ามซ้ำ
    const seen = new Set<string>();
    (v.ops as Array<{ op: string; field: string; id?: unknown; row?: { id?: unknown } }>).forEach((o, i) => {
      const key = o.op === "set" || o.op === "merge" ? `${o.field}` : `${o.field}#${String(o.op === "upsertRow" ? o.row?.id : o.id)}`;
      const whole = `${o.field}`;
      if (seen.has(key) || (o.op !== "set" && o.op !== "merge" && seen.has(whole)) || ((o.op === "set" || o.op === "merge") && [...seen].some((k) => k.startsWith(`${whole}#`)))) {
        ctx.addIssue({ code: "custom", path: ["ops", i], message: "แก้ช่องหรือแถวเดียวกันซ้ำในคำขอเดียวไม่ได้" });
      }
      seen.add(key);
    });
  });

export type ShopUpdateRequest = z.infer<typeof ShopUpdateRequest>;

// ─────────────── staff.manage ───────────────

/** ผู้รับแจ้งเตือน: ชื่อทางของจอพนักงานเดิม (`app:screens/StaffScreen.js:184-246`) → ช่องใน doc ร้าน */
export const STAFF_NOTIFY_FIELDS = Object.freeze({
  shift: "notiShift",
  cancel: "notiCancelBill",
  safetyStock: "notiStock",
  import: "notiImport",
  summary: "notiSummary",
  checkin: "notiCheckin",
  credit: "notiCredit",
  requisition: "notiRequisition",
} as const);
const NotifyKey = z.enum(Object.keys(STAFF_NOTIFY_FIELDS) as [keyof typeof STAFF_NOTIFY_FIELDS, ...(keyof typeof STAFF_NOTIFY_FIELDS)[]]);
const RightCode = z.string().regex(/^1\d{2}$/, { message: "รหัสสิทธิ์ 3 หลัก 100-199" });
const Rights = z
  .array(RightCode)
  .max(60)
  .refine((a) => new Set(a).size === a.length, { message: "รหัสสิทธิ์ซ้ำ" });
const Tel = z.string().regex(/^0\d{8,9}$/, { message: "เบอร์โทร 9-10 หลัก ขึ้นต้นด้วย 0" });
const StaffId = docId("staffId").describe("uid ของพนักงาน (profile id)");
const CashierCode = z
  .string()
  .min(1, { message: "รหัสแคชเชียร์ห้ามว่าง · จะล้างรหัสให้ส่ง clearPassword (C16)" })
  .max(32)
  .refine((s) => s.trim() === s && !/\s/.test(s), { message: "รหัสแคชเชียร์ห้ามมีช่องว่าง" });

export const StaffFindRequest = z.object({ op: z.literal("find"), shopId: ShopIdField, tel: Tel }).strict();
export const StaffAddRequest = z
  .object({
    op: z.literal("add"),
    shopId: ShopIdField,
    staffId: StaffId,
    rights: Rights.describe("สิทธิ์ตั้งต้นจากแม่แบบตำแหน่งของจอ"),
    notify: z.array(NotifyKey).max(8).default([]).describe("ผู้รับแจ้งเตือนตั้งต้นของตำแหน่ง"),
  })
  .strict();
export const StaffUpdateRequest = z
  .object({
    op: z.literal("update"),
    shopId: ShopIdField,
    staffId: StaffId,
    rights: Rights.optional(),
    status: z.enum(["active", "inActive"]).optional(),
    password: CashierCode.optional(),
    clearPassword: z.literal(true).optional(),
    notify: z.partialRecord(NotifyKey, z.boolean()).optional().describe("เปิด/ปิดรับแจ้งเตือนรายทาง · ทางที่ไม่ส่ง = คงเดิม"),
  })
  .strict()
  .refine((v) => v.rights !== undefined || v.status !== undefined || v.password !== undefined || v.clearPassword !== undefined || v.notify !== undefined, {
    message: "ไม่มีอะไรให้แก้",
  })
  .refine((v) => !(v.password !== undefined && v.clearPassword !== undefined), { message: "ส่ง password กับ clearPassword พร้อมกันไม่ได้" });
export const StaffRemoveRequest = z.object({ op: z.literal("remove"), shopId: ShopIdField, staffId: StaffId }).strict();
/**
 * ตั้งรหัสแคชเชียร์ครั้งแรกจากหน้าเลือกแคชเชียร์ (แทน `app:Modal/Modal_Staff.js:111-122`) · คนมีสิทธิ์ขาย '100' ทำได้ ไม่ต้องมี '101'
 * ตั้งได้เมื่อแถวนั้นยังไม่มีรหัสเท่านั้น (C18) · มีรหัสแล้ว = 409 code_already_set · รหัสเดิมเท่าที่ส่ง = ส่งซ้ำ ผ่าน ไม่เขียน
 */
export const StaffSetCashierCodeRequest = z
  .object({ op: z.literal("setCashierCode"), shopId: ShopIdField, staffId: StaffId, password: CashierCode })
  .strict();

export const StaffManageRequest = z.union([StaffFindRequest, StaffAddRequest, StaffUpdateRequest, StaffRemoveRequest, StaffSetCashierCodeRequest]);
export type StaffManageRequest = z.infer<typeof StaffManageRequest>;

// ─────────────── staff.checkIn ───────────────

export const StaffCheckInRequest = z
  .object({
    shopId: ShopIdField,
    op: z.enum(["in", "out"]).describe("ทิศที่ผู้ใช้กดเอง · ❌ ไม่เดาจากสถานะเดิม (DI-12)"),
    requestId: RequestId,
    imageUrl: Url.describe("รูปเซลฟีที่แอปอัปขึ้น Storage แล้ว"),
  })
  .strict();
export type StaffCheckInRequest = z.infer<typeof StaffCheckInRequest>;

// ─────────────── expense.manage ───────────────

const ExpenseId = docId("expenseId").describe("doc id ของหัวข้อ · ตอนสร้างแอปสุ่ม uuid เอง ⇒ กดซ้ำได้ใบเดิม (B13)");
const ExpenseCategory = z.array(z.string().min(1).max(128)).max(20).describe("เส้นทางหมวด aboveId + id");
const PriceOrEmpty = z.union([z.literal(""), ExpenseMoneyText]);

export const ExpenseCreateRequest = z
  .object({
    op: z.literal("create"),
    shopId: ShopIdField,
    expenseId: ExpenseId,
    name: NonBlank(100).describe("ห้ามว่าง (B4)"),
    category: ExpenseCategory,
    priceStatus: z.boolean(),
    price: PriceOrEmpty.describe("ยอดล็อค · priceStatus false = server เขียน '' (B14)"),
  })
  .strict()
  .refine((v) => !v.priceStatus || v.price !== "", { message: "เปิดล็อคยอดต้องใส่ยอด (B4)", path: ["price"] });
export const ExpenseUpdateRequest = z
  .object({
    op: z.literal("update"),
    shopId: ShopIdField,
    expenseId: ExpenseId,
    name: NonBlank(100).optional(),
    category: ExpenseCategory.optional(),
    priceStatus: z.boolean().optional(),
    price: PriceOrEmpty.optional(),
  })
  .strict()
  .refine((v) => v.name !== undefined || v.category !== undefined || v.priceStatus !== undefined || v.price !== undefined, { message: "ไม่มีอะไรให้แก้" });
export const ExpenseDeleteRequest = z.object({ op: z.literal("delete"), shopId: ShopIdField, expenseId: ExpenseId }).strict();

export const ExpenseManageRequest = z.union([ExpenseCreateRequest, ExpenseUpdateRequest, ExpenseDeleteRequest]);
export type ExpenseManageRequest = z.infer<typeof ExpenseManageRequest>;

// ─────────────── expenseReport.manage ───────────────

const Month = z.string().regex(/^\d{4}(0[1-9]|1[0-2])$/, { message: "เดือนรูป YYYYMM" });
const RowId = z.string().min(1).max(128).describe("uuid แถว · ตอนเพิ่มแอปสุ่มเอง ⇒ กดซ้ำได้แถวเดิม");
const Note = ShortText(500);

export const ExpenseReportAddRequest = z
  .object({ op: z.literal("add"), shopId: ShopIdField, month: Month, rowId: RowId, expenseId: ExpenseId, price: ExpenseMoneyText.describe("ห้ามว่าง (B5)"), note: Note })
  .strict();
export const ExpenseReportUpdateRequest = z
  .object({ op: z.literal("update"), shopId: ShopIdField, month: Month, rowId: RowId, price: ExpenseMoneyText.optional(), note: Note.optional() })
  .strict()
  .refine((v) => v.price !== undefined || v.note !== undefined, { message: "ไม่มีอะไรให้แก้" });
export const ExpenseReportDeleteRequest = z.object({ op: z.literal("delete"), shopId: ShopIdField, month: Month, rowId: RowId }).strict();

export const ExpenseReportManageRequest = z.union([ExpenseReportAddRequest, ExpenseReportUpdateRequest, ExpenseReportDeleteRequest]);
export type ExpenseReportManageRequest = z.infer<typeof ExpenseReportManageRequest>;

// ─────────────── profile.manage ───────────────

const Email = z.string().max(200).regex(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, { message: "อีเมลไม่ถูกรูป" });

export const ProfileCreateRequest = z.object({ op: z.literal("create"), name: NonBlank(100), tel: Tel, email: Email }).strict();
export const ProfileUpdateRequest = z
  .object({
    op: z.literal("update"),
    name: NonBlank(100).optional(),
    tel: Tel.optional(),
    email: Email.optional(),
    imageId: UrlOrEmpty.optional().describe("URL รูปโปรไฟล์ที่อัปแล้ว"),
    wallPaper: z.object({ status: z.boolean(), imageId: UrlOrEmpty }).strict().optional(),
  })
  .strict()
  .refine((v) => v.name !== undefined || v.tel !== undefined || v.email !== undefined || v.imageId !== undefined || v.wallPaper !== undefined, {
    message: "ไม่มีอะไรให้แก้",
  });
export const ProfileEnterShopRequest = z.object({ op: z.literal("enterShop"), shopId: ShopIdField }).strict();
export const ProfileLeaveShopRequest = z.object({ op: z.literal("leaveShop") }).strict();
export const ProfileRemovePortRequest = z
  .object({ op: z.literal("removePort"), portShopId: z.string().min(1).max(128).describe("`port[].shopId` ของแถวที่จะเอาออก (field shop.shopId)") })
  .strict();

export const ProfileManageRequest = z.union([ProfileCreateRequest, ProfileUpdateRequest, ProfileEnterShopRequest, ProfileLeaveShopRequest, ProfileRemovePortRequest]);
export type ProfileManageRequest = z.infer<typeof ProfileManageRequest>;

// @shopchamp/logic — สูตรกลางของ Shopchamp · ฟังก์ชันล้วน ไม่แตะฐาน ไม่ dep schema
// แหล่งเดียว: import จากที่นี่ ห้ามเขียนสูตรซ้ำในแอปหรือ server
//   0.1.0 (ก้อน 0 · DEV-0001): money.toNumber ตัวเดียว เพื่อพิสูจน์ทาง test → pack
//   0.2.0 (ก้อน 1-3 · DEV-0001): 11 โมดูล
// ชื่อซ้ำข้ามโมดูล = throw ตอนโหลด (กันตัวหลังทับตัวแรกเงียบ ๆ)
const MODULES = {
  money: require("./money"),
  billState: require("./billState"),
  businessDay: require("./businessDay"),
  cartTotals: require("./cartTotals"),
  distributeBillDiscount: require("./distributeBillDiscount"),
  docNumber: require("./docNumber"),
  member: require("./member"),
  payment: require("./payment"),
  promotion: require("./promotion"),
  shift: require("./shift"),
  stock: require("./stock"),
  vat: require("./vat"),
  // 0.1.3 (ก้อน 9 · DEV-0001): memberManage 9b · expenseReport 9c · company 9d · report 9e
  memberManage: require("./memberManage"),
  expenseReport: require("./expenseReport"),
  company: require("./company"),
  report: require("./report"),
};

const out = {};
const owner = {};
for (const [mod, exp] of Object.entries(MODULES)) {
  for (const name of Object.keys(exp)) {
    if (name in out) throw new Error(`@shopchamp/logic: ชื่อ ${name} ซ้ำระหว่าง ${owner[name]} กับ ${mod}`);
    out[name] = exp[name];
    owner[name] = mod;
  }
}

module.exports = out;

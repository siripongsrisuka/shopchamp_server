import { z } from "zod";
import { FirestoreTime } from "./receiptGuard";

/**
 * ประกาศถึงร้าน (DEV-0003 0e · Pack สั่ง 2026-11-11) · แบบ `lanes/dev/source/office-announcement-design.md`
 *   ที่เก็บ (server เขียนคนเดียว · rules ไม่เปิดให้ client):
 *     `announcement/{id}`              ใบประกาศ · office สร้าง/แก้/ยกเลิก
 *     `announcement/{id}/seen/{uid}`   เห็น/อ่านแล้วต่อคน · แอปบันทึกผ่าน /announcement/seen
 *     `shopCategory/{id}`              ประเภทร้าน (office ตั้งเอง)
 *     `shopCategoryTag/{shopId}`       ป้ายประเภทของร้าน (office ติด · ร้านแก้เองไม่ได้)
 *   กติกาใครเห็น/เห็นช่องไหน = @shopchamp/logic announcement.js ที่เดียว
 */

export const AnnouncementPlanType = z.enum(["premium", "staff", "member", "warehouse", "delivery"]);
export type AnnouncementPlanType = z.infer<typeof AnnouncementPlanType>;

export const AnnouncementChannels = z
  .object({ banner: z.boolean(), popup: z.boolean(), inbox: z.boolean() })
  .strict()
  .refine((c) => c.banner || c.popup || c.inbox, { message: "ต้องเลือกช่องทางอย่างน้อย 1 ช่อง" });

const DocId = z.string().min(1).max(128).regex(/^[^/]+$/);

export const AnnouncementAudience = z
  .object({
    people: z.enum(["owner", "all"]).describe("owner = humanResource ที่ position มี '001' · all = ทุกคนในร้าน"),
    shops: z
      .object({
        mode: z.enum(["all", "list", "filter"]),
        shopIds: z.array(DocId).max(1000).describe("โหมด list · shop doc id"),
        plans: z
          .object({
            has: z.array(AnnouncementPlanType).describe("ต้องมีแพ็กเกจที่ใช้อยู่ครบทุกตัว"),
            missing: z.array(AnnouncementPlanType).describe("ต้องไม่มีสักตัว"),
          })
          .strict(),
        categoryIds: z.array(DocId).max(20).describe("ประเภทร้าน (shopCategory id) · ร้านมีอย่างน้อย 1 ตัว"),
      })
      .strict()
      .describe("ตั้งหลายตัวกรอง = ต้องตรงทุกข้อ (AND)"),
  })
  .strict();
export type AnnouncementAudience = z.infer<typeof AnnouncementAudience>;

export const AnnouncementTriggerType = z.enum(["newShop", "packageEnding", "packageExpired", "purchased"]);

export const AnnouncementTrigger = z
  .object({
    type: AnnouncementTriggerType,
    days: z.number().int().min(0).max(365).describe("ตั้งต้น newShop 30 · packageEnding 7 · packageExpired 30 · purchased 7"),
    plan: z.union([AnnouncementPlanType, z.literal("any")]).optional().describe("ไม่มีใน newShop · อื่น ไม่ส่ง = any"),
  })
  .strict();
export type AnnouncementTrigger = z.infer<typeof AnnouncementTrigger>;

export const AnnouncementActor = z.object({ uid: z.string(), email: z.string(), name: z.string() }).passthrough();

/** `announcement/{id}` */
export const Announcement = z
  .object({
    kind: z.enum(["campaign", "evergreen"]).describe("ชั่วคราว (มีช่วงเวลา) · ถาวรตามเงื่อนไข"),
    title: z.string().min(1).max(120),
    body: z.string().max(3000),
    images: z.array(z.string().max(1000).regex(/^https:\/\/\S+$/)).max(10).describe("รูปแรก = รูปแบนเนอร์/ปก · อัปที่ Storage announcement/<YYYYMM>/"),
    buttonText: z.string().max(40),
    buttonUrl: z.string().max(500).describe("'' หรือ https"),
    channels: AnnouncementChannels,
    bannerSticky: z.boolean().describe("ปักแบนเนอร์ = ไม่หายเมื่ออ่าน/เห็นครบ 3 ครั้ง · ต้องเปิด banner"),
    audience: AnnouncementAudience,
    startAt: FirestoreTime.optional().describe("ชั่วคราวเท่านั้น"),
    endAt: FirestoreTime.optional().describe("ชั่วคราวเท่านั้น"),
    status: z.enum(["scheduled", "live", "ended", "cancelled"]).optional().describe("ชั่วคราว · ประทับตอนบันทึก (การแสดงตัดสินจากเวลาเสมอ)"),
    trigger: AnnouncementTrigger.optional().describe("ถาวรเท่านั้น"),
    active: z.boolean().optional().describe("ถาวรเท่านั้น · ยกเลิก = false"),
    createdBy: AnnouncementActor,
    createdAt: FirestoreTime,
    updatedAt: FirestoreTime,
    updatedBy: AnnouncementActor.optional(),
    cancelledAt: FirestoreTime.nullable().optional(),
    cancelledBy: AnnouncementActor.nullable().optional(),
  })
  .passthrough();
export type Announcement = z.infer<typeof Announcement>;

const SeenFields = {
  popupSeenAt: FirestoreTime.optional().describe("เห็นป๊อปอัปครั้งแรก"),
  readAt: FirestoreTime.optional().describe("เปิดอ่านครั้งแรก (กดแบนเนอร์ก็นับ)"),
  bannerViews: z.number().int().nonnegative().optional().describe("เข้าหน้าแรกขณะแบนเนอร์อยู่ในแถบ · ครบ 3 = แบนเนอร์หาย"),
};

/** `announcement/{id}/seen/{uid}` · ถาวรแยกต่อรอบที่ cycles · ช่องบนสุดของถาวร = ครั้งแรกที่เคยเห็น/อ่าน (ใช้นับสถิติ office) */
export const AnnouncementSeen = z
  .object({
    ...SeenFields,
    cycles: z.record(z.string(), z.object(SeenFields).passthrough()).optional(),
  })
  .passthrough();
export type AnnouncementSeen = z.infer<typeof AnnouncementSeen>;

/** `shopCategory/{id}` */
export const ShopCategory = z
  .object({
    name: z.string().min(1).max(60),
    order: z.number().int().nonnegative(),
    active: z.boolean(),
    createdAt: FirestoreTime.optional(),
    updatedAt: FirestoreTime.optional(),
    updatedBy: AnnouncementActor.optional(),
  })
  .passthrough();
export type ShopCategory = z.infer<typeof ShopCategory>;

/** `shopCategoryTag/{shopId}` */
export const ShopCategoryTag = z
  .object({
    categoryIds: z.array(DocId).max(20),
    updatedAt: FirestoreTime,
    updatedBy: AnnouncementActor.optional(),
  })
  .passthrough();
export type ShopCategoryTag = z.infer<typeof ShopCategoryTag>;

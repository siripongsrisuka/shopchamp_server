import { z } from "zod";

/**
 * คำขออ่านข้อมูลร้าน/ระบบผ่าน API (DEV-0010 คลื่น 2 · กลุ่ม shop/system) · strict ทุกตัว field เกิน = ปัด
 *   shop.get · shop.findByTel · company.catalog · notification.list
 *
 * ที่มา: `lanes/dev/source/dev0010-survey-shop.md` ข้อ 6 7 11 12 13 · decision Pack ใน `progress-shopchamp-app-reads-to-api.md` §🎯 ข้อ 7 8 9
 * อ่านอย่างเดียวทุกตัว · แอปเก่าไม่เรียก
 */

const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });
const ShopIdField = docId("shopId").describe("doc id ร้านของผู้เรียก · server เทียบกับตัวตนจาก token");

/** shop.get — ข้อมูลร้านก้อนเดียวกับที่แอปเก็บลง redux (แทน fetchShop `redux/shopSlice.js:59`) */
export const ShopGetRequest = z.object({ shopId: ShopIdField }).strict();

/**
 * shop.findByTel — ค้นร้านด้วยเบอร์โทร (แทน `modal/Modal_FindShop.js:60`) · ค้นแบบเท่ากันเป๊ะ ไม่ trim ให้
 *   ไม่มี shopId (ยังไม่ได้เข้าร้าน) · หน้าต่างเดิมให้ค้นเมื่อพิมพ์ครบ 10 หลัก แต่ server ไม่บังคับรูปเบอร์ (ไม่เข้มกว่าเดิม)
 */
export const ShopFindByTelRequest = z
  .object({ tel: z.string().min(1, { message: "เบอร์โทรห้ามว่าง" }).max(20).describe("เบอร์ร้านที่พิมพ์ · เท่ากันเป๊ะ") })
  .strict();

/** ชนิดแคตตาล็อกบริษัท = doc ใน `admin/` ที่จอร้านอ่าน (package = จอแพ็กเกจของฉัน · hardware = จออุปกรณ์ช็อปแชมป์) */
export const COMPANY_CATALOG_KINDS = ["package", "hardware"] as const;
export const CompanyCatalogKind = z.enum(COMPANY_CATALOG_KINDS);

/** company.catalog — ตารางแพ็กเกจ/อุปกรณ์ของบริษัท เฉพาะช่องที่จอใช้ (แทน `PackageScreen.js:41` · `HardwareScreen.js:99`) */
export const CompanyCatalogRequest = z.object({ shopId: ShopIdField, kind: CompanyCatalogKind }).strict();

/** notification.list — ประวัติแจ้งเตือนของร้าน 30 ใบล่าสุด (แทน `NotificationHistory.js:93`) */
export const NotificationListRequest = z.object({ shopId: ShopIdField }).strict();

export type ShopGetRequest = z.infer<typeof ShopGetRequest>;
export type ShopFindByTelRequest = z.infer<typeof ShopFindByTelRequest>;
export type CompanyCatalogKind = z.infer<typeof CompanyCatalogKind>;
export type CompanyCatalogRequest = z.infer<typeof CompanyCatalogRequest>;
export type NotificationListRequest = z.infer<typeof NotificationListRequest>;

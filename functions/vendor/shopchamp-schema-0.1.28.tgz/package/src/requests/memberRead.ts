import { z } from "zod";

/**
 * คำขออ่านสมาชิก/พนักงานผ่าน API (DEV-0010 คลื่น 2 · กลุ่ม member/profile) · strict ทุกตัว field เกิน = ปัด
 *   member.indexSync · member.list · member.get · member.paidHistory · staff.profiles
 *
 * ที่มา: `lanes/dev/source/dev0010-survey-member.md` ข้อ 1 3 4 8 · `dev0010-survey-bill.md` #12
 *   decision Pack ใน `progress-shopchamp-app-reads-to-api.md` §🎯 ข้อ 5 8 9 11 12
 * อ่านอย่างเดียวทุกตัว · แอปเก่าไม่เรียก
 */

const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });
const ShopIdField = docId("shopId").describe("doc id ร้านของผู้เรียก · server เทียบกับตัวตนจาก token");
const CursorField = z.string().min(1).max(300);

/**
 * member.indexSync — ดัชนีค้นหาสมาชิก (`memberList`) ทีละหน้า เรียงเวลาแก้ (แทน `hook/useLocalMember.js:127`)
 *   ไม่ส่ง cursor = โหลดทั้งร้าน · ส่ง cursor = เฉพาะ doc ที่เปลี่ยนหลังจุดนั้น · cursor รูปเดียวกับ stock.sync
 */
export const MemberIndexSyncRequest = z
  .object({
    shopId: ShopIdField,
    cursor: CursorField.optional().describe("nextCursor จากคำตอบก่อน · ไม่ส่ง = เริ่มจากต้น"),
    limit: z.number().int().min(1).max(100).optional().describe("doc ดัชนีต่อหน้า · ไม่ส่ง = 100 (ร้านหนึ่งมีไม่เกินราว 52 doc ต่อคีย์)"),
  })
  .strict();

/**
 * member.list — สมาชิกทั้งร้านทีละหน้า เรียง doc id (แทน `screens/MemberScreen.js:222`)
 *   ไม่ส่ง cursor = หน้าแรก · cursor = nextCursor ของหน้าก่อน (doc id สุดท้าย)
 */
export const MemberListRequest = z
  .object({
    shopId: ShopIdField,
    cursor: CursorField.optional().describe("nextCursor จากคำตอบก่อน · ไม่ส่ง = หน้าแรก"),
    limit: z.number().int().min(1).max(3000).optional().describe("ต่อหน้า · ไม่ส่ง = 1000 · เพดาน 3000 (= เพดานสมาชิกต่อร้าน)"),
  })
  .strict();

/** member.get — สมาชิก 1 คนของร้าน (แทน `modal/Modal_FindMember.js:59`) */
export const MemberGetRequest = z.object({ shopId: ShopIdField, memberId: docId("memberId") }).strict();

/** member.paidHistory — ประวัติชำระเงินเซ็นของสมาชิก 365 วันล่าสุด เฉพาะของร้านนี้ (แทน `screens/MemberPaidScreen.js:54`) */
export const MemberPaidHistoryRequest = z.object({ shopId: ShopIdField, memberId: docId("memberId") }).strict();

/** staff.profiles — ชื่อ/อีเมล/เบอร์/รูปของพนักงานทุกคนในร้าน (แทน `screens/StaffScreen.js:165`) */
export const StaffProfilesRequest = z.object({ shopId: ShopIdField }).strict();

export type MemberIndexSyncRequest = z.infer<typeof MemberIndexSyncRequest>;
export type MemberListRequest = z.infer<typeof MemberListRequest>;
export type MemberGetRequest = z.infer<typeof MemberGetRequest>;
export type MemberPaidHistoryRequest = z.infer<typeof MemberPaidHistoryRequest>;
export type StaffProfilesRequest = z.infer<typeof StaffProfilesRequest>;

import { z } from "zod";

/**
 * คำขออ่านกะผ่าน API (DEV-0010 คลื่น 2 · กลุ่ม bill/shift) · strict ทุกตัว field เกิน = ปัด
 *   shift.get · shift.history
 *
 * ที่มา: `lanes/dev/source/dev0010-survey-bill.md` §B (#8 #9 #10 #11) · decision Pack ใน `progress-shopchamp-app-reads-to-api.md` §🎯 ข้อ 2 8 9
 * อ่านอย่างเดียวทุกตัว · แอปเก่าไม่เรียก
 */

const docId = (what: string) =>
  z
    .string()
    .min(1, { message: `${what} ห้ามว่าง` })
    .max(128)
    .refine((s) => !s.includes("/") && s !== "." && s !== "..", { message: `${what} ห้ามมี /` });
const ShopIdField = docId("shopId").describe("doc id ร้านของผู้เรียก · server เทียบกับตัวตนจาก token");

/**
 * shift.get — เอกสารกะ 1 ใบของจุดขาย (แทน `HomeScreen.js:626` get · listener `ShiftScreen.js:142` `CheckoutScreen.js:199` · Pack ข้อ 2)
 *   shiftId = `shop.POSs[].shiftId` ของจุดที่เครื่องเลือก
 */
export const ShiftGetRequest = z
  .object({ shopId: ShopIdField, shiftId: docId("shiftId").describe("doc id ของ shift (ผูกจุดขาย)") })
  .strict();

/** วันเปิดกะ `YYYYMMDD` แบบ `lastShiftDate` (`stringYMDHMS3`) */
export const ShiftDay = z.string().regex(/^\d{8}$/, { message: "วันต้องเป็น YYYYMMDD" });

/** เพดานจำนวนวันต่อคำขอ = เพดานค่าใน `in` ของ Firestore (แบบพี่น้อง · แอปส่ง 7) */
export const SHIFT_HISTORY_MAX_DATES = 10;

/**
 * shift.history — ประวัติกะของวันเปิดกะที่ระบุ (แทน `ShiftHistoryScreen.js:79` · `lastShiftDate in [7 วัน]`)
 *   ชุดกะเท่าแอปเดิมเป๊ะ (ค้นวันเปิดกะ) · doc ดิบ ไม่แปลงชื่อช่อง · ต่างจาก `report.shiftHistory` (วันธุรกิจของเวลาปิด · แถวสรุป)
 */
export const ShiftHistoryRequest = z
  .object({
    shopId: ShopIdField,
    dates: z
      .array(ShiftDay)
      .min(1, { message: "ต้องระบุวันอย่างน้อย 1 วัน" })
      .max(SHIFT_HISTORY_MAX_DATES, { message: `ระบุได้ไม่เกิน ${SHIFT_HISTORY_MAX_DATES} วัน` })
      .describe("วันเปิดกะ YYYYMMDD · แอปส่ง 7 วันล่าสุดตามเครื่อง"),
  })
  .strict();

export type ShiftGetRequest = z.infer<typeof ShiftGetRequest>;
export type ShiftHistoryRequest = z.infer<typeof ShiftHistoryRequest>;

import { z } from "zod";
import { AnnouncementAudience, AnnouncementPlanType, AnnouncementTriggerType } from "../entities/announcement";

/**
 * คำขอ/คำตอบ API ประกาศถึงร้าน (DEV-0003 0e) · strict (ช่องเกิน = 400 invalid_request)
 * สัญญา: `shopchamp-center/api/office.ann*.yaml` (8) · `announcement.feed.yaml` · `announcement.seen.yaml`
 *   office (`POST /pos/office/ann-*` · auth user · อ่าน = ทีมงาน · เขียน = root) · ตัวตรวจจริงของ annSave = logic.announcementSaveInput
 *   แอป (`POST /pos/announcement/*` · auth shop)
 * เวลาในคำขอ = ISO string หรือ ms · เวลาในคำตอบ = ISO string หรือ null
 */

const DocId = z.string().min(1).max(128).regex(/^[^/]+$/);
const Time = z.union([z.string().min(1).max(40), z.number().int()]).describe("ISO หรือ ms");
const Iso = z.string().nullable();
const Kind = z.enum(["campaign", "evergreen"]);
const Status = z.enum(["scheduled", "live", "ended", "cancelled"]);

// ── office ─────────────────────────────────────────────────────────────

export const OfficeAnnListRequest = z.object({ kind: Kind }).strict();

export const OfficeAnnSaveRequest = z
  .object({
    id: DocId.optional().describe("มี = แก้ใบเดิม (ยกเลิกแล้ว = 409 announcement_cancelled · เปลี่ยน kind = 409 kind_locked)"),
    clientRequestId: z.string().regex(/^[A-Za-z0-9_-]{8,64}$/).optional().describe("สร้างใหม่ · = doc id กันกดซ้ำ · ไม่ส่ง = server สุ่ม"),
    kind: Kind,
    title: z.string().max(200).describe("ตัดช่องว่างแล้ว 1-120"),
    body: z.string().max(3000).optional(),
    images: z.array(z.string().max(1000)).max(10).optional().describe("https ของ Storage announcement/ เท่านั้น"),
    buttonText: z.string().max(40).optional(),
    buttonUrl: z.string().max(500).optional().describe("https · คู่กับ buttonText"),
    channels: z.object({ banner: z.boolean().optional(), popup: z.boolean().optional(), inbox: z.boolean().optional() }).strict(),
    bannerSticky: z.boolean().optional(),
    audience: z
      .object({
        people: z.enum(["owner", "all"]),
        shops: z
          .object({
            mode: z.enum(["all", "list", "filter"]),
            shopIds: z.array(DocId).max(1000).optional(),
            plans: z.object({ has: z.array(AnnouncementPlanType).optional(), missing: z.array(AnnouncementPlanType).optional() }).strict().optional(),
            categoryIds: z.array(DocId).max(20).optional(),
          })
          .strict(),
      })
      .strict(),
    startAt: Time.optional().describe("ชั่วคราวเท่านั้น"),
    endAt: Time.optional().describe("ชั่วคราวเท่านั้น · สร้างใหม่ต้องยังไม่ผ่าน"),
    trigger: z
      .object({ type: AnnouncementTriggerType, days: z.number().int().min(0).max(365).optional(), plan: z.union([AnnouncementPlanType, z.literal("any")]).optional() })
      .strict()
      .optional()
      .describe("ถาวรเท่านั้น"),
    active: z.boolean().optional().describe("ถาวรเท่านั้น · ไม่ส่ง = true"),
  })
  .strict();

export const OfficeAnnCancelRequest = z.object({ id: DocId }).strict();
export const OfficeAnnCategoryListRequest = z.object({}).strict();
export const OfficeAnnCategorySaveRequest = z.object({ id: DocId.optional(), name: z.string().max(200), active: z.boolean() }).strict();
export const OfficeAnnCategoryDeleteRequest = z.object({ id: DocId }).strict();
export const OfficeAnnShopFindRequest = z.object({ q: z.string().min(1).max(128).describe("เลขร้าน (scShopId) หรือ shop doc id") }).strict();
export const OfficeAnnShopTagSetRequest = z.object({ shopId: DocId, categoryIds: z.array(DocId).max(20) }).strict();

export const AnnouncementStats = z.object({ read: z.number().int(), popupSeen: z.number().int() }).nullable();

export const OfficeAnnItem = z.object({
  id: z.string(),
  kind: Kind,
  title: z.string(),
  body: z.string(),
  images: z.array(z.string()),
  buttonText: z.string(),
  buttonUrl: z.string(),
  channels: z.object({ banner: z.boolean(), popup: z.boolean(), inbox: z.boolean() }),
  bannerSticky: z.boolean(),
  audience: AnnouncementAudience.nullable(),
  startAt: Iso,
  endAt: Iso,
  trigger: z.object({ type: AnnouncementTriggerType, days: z.number(), plan: z.string().optional() }).nullable(),
  active: z.boolean().nullable(),
  status: Status.describe("ตามเวลา ณ ตอนอ่าน (logic.announcementDisplayStatus)"),
  createdAt: Iso,
  createdBy: z.object({ uid: z.string(), email: z.string(), name: z.string() }).nullable(),
  updatedAt: Iso,
  cancelledAt: Iso,
  stats: AnnouncementStats.describe("นับสดจาก seen · อ่านไม่ได้ = null"),
});

export const OfficeAnnListResponse = z.object({
  ok: z.literal(true),
  items: z.array(OfficeAnnItem),
  counts: z.object({
    campaign: z.number().int(), evergreen: z.number().int(),
    all: z.number().int(), live: z.number().int(), scheduled: z.number().int(), ended: z.number().int(), cancelled: z.number().int(),
  }).describe("campaign/evergreen = ตัวนับแท็บ · ที่เหลือ = ชิปสถานะของแท็บที่ขอ"),
  canEdit: z.boolean(),
  truncated: z.boolean(),
});
export const OfficeAnnSaveResponse = z.object({ ok: z.literal(true), id: z.string(), created: z.boolean() });
export const OfficeAnnCancelResponse = z.object({ ok: z.literal(true), id: z.string(), status: z.literal("cancelled"), already: z.boolean() });
export const OfficeAnnCategoryListResponse = z.object({
  ok: z.literal(true),
  categories: z.array(z.object({ id: z.string(), name: z.string(), order: z.number(), active: z.boolean(), count: z.number().int() })),
  canEdit: z.boolean(),
});
export const OfficeAnnCategorySaveResponse = z.object({ ok: z.literal(true), id: z.string(), created: z.boolean() });
export const OfficeAnnCategoryDeleteResponse = z.object({ ok: z.literal(true), id: z.string(), deleted: z.literal(true) });
export const OfficeAnnShopFindResponse = z.object({
  ok: z.literal(true),
  shops: z.array(z.object({ shopId: z.string(), scShopId: z.union([z.string(), z.number()]).nullable(), name: z.string(), categoryIds: z.array(z.string()) })),
});
export const OfficeAnnShopTagSetResponse = z.object({ ok: z.literal(true), shopId: z.string(), categoryIds: z.array(z.string()) });

// ── แอป ───────────────────────────────────────────────────────────────

export const AnnouncementFeedRequest = z.object({ shopId: DocId }).strict();

export const AnnouncementFeedItem = z.object({
  id: z.string(),
  kind: Kind,
  title: z.string().describe("แทนตัวแปรแล้ว"),
  body: z.string().describe("แทนตัวแปรแล้ว"),
  images: z.array(z.string()),
  buttonText: z.string(),
  buttonUrl: z.string(),
  bannerSticky: z.boolean(),
  startAt: Iso.describe("ถาวร = null"),
  endAt: Iso,
  readAt: Iso,
  cycleKey: z.string().nullable().describe("ถาวร = รอบปัจจุบัน (ส่งกลับตอน seen ได้)"),
});
export const AnnouncementFeedResponse = z.object({
  ok: z.literal(true),
  banners: z.array(AnnouncementFeedItem),
  popups: z.array(AnnouncementFeedItem),
  inbox: z.array(AnnouncementFeedItem),
  unreadCount: z.number().int(),
});

export const AnnouncementSeenRequest = z.union([
  z.object({ shopId: DocId, kind: z.enum(["popup", "read"]), id: DocId, cycleKey: z.string().min(1).max(160).optional() }).strict(),
  z.object({ shopId: DocId, kind: z.literal("bannerView"), ids: z.array(DocId).min(1).max(20) }).strict(),
]);
export const AnnouncementSeenResponse = z.union([
  z.object({ ok: z.literal(true), id: z.string(), kind: z.enum(["popup", "read"]), already: z.boolean(), cycleKey: z.string().nullable() }),
  z.object({ ok: z.literal(true), kind: z.literal("bannerView"), counted: z.number().int() }),
]);
